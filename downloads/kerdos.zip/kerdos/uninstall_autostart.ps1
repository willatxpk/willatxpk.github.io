# Stops Kerdos from starting with Windows, and stops the background copy that's running now.
$startup = [Environment]::GetFolderPath("Startup")
$lnkPath = Join-Path $startup "Kerdos.lnk"
$oldLnk = Join-Path $startup "Finance Hub.lnk"
if (Test-Path $oldLnk) { Remove-Item $oldLnk }
if (Test-Path $lnkPath) { Remove-Item $lnkPath; Write-Output "Removed startup shortcut." } else { Write-Output "No startup shortcut found." }
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Get-CimInstance Win32_Process -Filter "Name = 'pythonw.exe'" |
  Where-Object { $_.CommandLine -like "*$here*main.py*" } |
  ForEach-Object { Stop-Process -Id $_.ProcessId; Write-Output "Stopped background Kerdos (process $($_.ProcessId))." }
Write-Output "Your data in $here\data is untouched. Use run.bat to start the app by hand."
