# Kerdos

A personal finance app that runs on your own computer. It does five things:

1. **Connects to your bank, card, loan and investment accounts** through Plaid, or imports CSV files you download from your bank.
2. **Sorts your spending into categories.** You can fix any category and tell it to remember that choice for the merchant.
3. **Tracks your net worth** over time: everything you own minus everything you owe. You can add things like a car or home by hand.
4. **Finds your recurring bills and autopays** and **alerts you** before each one is charged, when it goes through, when the price changes, when an expected charge doesn't show up, and when the account paying it looks too low. Alerts appear in the app and can also go to your phone (ntfy) or email.
5. **Builds an investing plan** that puts your monthly surplus in priority order: emergency fund, 401(k) match, high-interest debt, HSA, Roth IRA, 401(k), then a regular brokerage account. It also suggests a stock/bond mix and projects where that could lead.

It also has:

- **Sort:** transactions the app isn't sure about float as bubbles. Drag each into a category bin. With "Teach it" on, every transaction from that merchant goes into the same bin, now and in the future.
- **Card payment matching:** a withdrawal from your bank and a same-sized credit on a card within 5 days are recognised as one card payment. They aren't counted as spending, and they become one recurring "Payment to [card]" bill, with a check for whether it's on autopay and the reason. Transfers between your own accounts are paired the same way.
- **Removing bill suggestions:** **Bills → Remove** hides a suggestion permanently, for example a utility at an old address. Restore it from the "removed" list.
- **Account kinds:** label each account (cash, investment, credit card, loan) on the Accounts page. Bank syncs never overwrite your choice.
- **Insights:** a 12-month breakdown of where your income went (spending by category, invested, kept as savings), your savings rate by month, and a projection of net worth, investments, cash and debt over any number of years.
- **Goals:** for example "max out my Roth IRA", "save 20% of income" or "keep Dining under $400". A plant or pet grows with your progress: each month you meet a goal feeds it, and it droops when you fall behind. Level-ups unlock cosmetics you choose.
- **Companion room:** every XP point is also a coin. Spend coins on the home (cozy corner, then studio, loft, cottage, treehouse), walls, floor, window, bed, lighting, shelf, art and extras. Each has 3-4 upgrade tiers, and higher tiers unlock at higher levels. You keep everything you buy and can switch back.
- **Roth / contribution goals:** if you link the goal to your Roth account, money sent from your bank to that account's institution (e.g. "VANGUARD BUY") counts automatically. The goal lists every deposit it counted.

- **This Month:** what you've spent so far this month against your usual month, how much non-essential money is left to stay on your average (and per day), and **safe to spend**: a 45-day forecast of your checking balance from paychecks, upcoming bills and your usual everyday spending.
- **Subscription checkup** (top of Bills & Alerts): yearly cost of each subscription, price increases, free trials that turned paid, double charges, and avoidable bank fees. Mark one to cancel and you get a reminder 2 days before it renews, plus a warning if it charges you again.
- **Investments:** holdings from your brokerages through Plaid, your real stock/bond mix against your plan's target, and estimated yearly fund fees. When the brokerage reports them, Roth goals count your exact contributions.

It's plain Python 3.12 (standard library only), so there's nothing to install.

## Run it

It's set up to start quietly in the background whenever you sign in to Windows; there's no window. Open it at **http://localhost:8765**, or double-click **Open Kerdos** in this folder.

- Turn background mode on: `install_autostart.ps1` (right-click → Run with PowerShell).
- Turn it off: `uninstall_autostart.ps1`.
- Run it by hand with a console instead: double-click `run.bat`, or `py -3.12 main.py`.
- Messages from the background copy go to `data/app.log`.

A backup is saved to `data/backups` every day the app runs, and the newest 30 are kept. You can also click **Accounts → Back up now**.

## Connect real accounts (Plaid)

Plaid is the service most budgeting apps use to connect to banks. You sign in to your bank inside Plaid's own window, so this app never sees your bank password.

1. Create a free account at https://dashboard.plaid.com/signup.
2. Copy `config.example.json` to `config.json`, then paste your **client_id** and **secret** from *Developers → Keys* into it.
3. Start with `"env": "sandbox"`. Sandbox uses fake test banks; sign in with `user_good` / `pass_good`.
4. To connect your real accounts, request **Production** access in the Plaid dashboard. Personal and hobby projects can usually get a limited number of free live connections. Then switch to `"env": "production"` with your production secret.
5. Restart the app and use **Accounts → Connect a bank**.

The app syncs every 6 hours while it's running (change `sync_interval_hours`), and whenever you click **Sync now**.

**No Plaid?** Download CSV files from each bank's website and use **Accounts → Import a CSV**. Re-importing an overlapping file won't create duplicates.

## Phone & email alerts

- **Phone:** install the free **ntfy** app (iOS/Android) and subscribe to a long random topic name, such as `fh-8e2kq93nd0`. Anyone who knows the name can read the topic, so make it hard to guess. Then set `"ntfy_url": "https://ntfy.sh/fh-8e2kq93nd0"` in `config.json`.
- **Email:** set `notify.email.enabled` to `true` and fill in your SMTP details. For Gmail, use an App Password, not your normal password.
- Restart the app, then click **Bills & Alerts → Send test alert**.

Alerts are checked while the app is running, which is all the time once background mode is on.

## Password

The first time you open the app it asks you to create a password. After that:

- You sign in when you open it, and it locks after 30 minutes with no activity. Change the timeout under **Accounts → Security**. Tick "keep me signed in" to stay signed in for 7 days without auto-lock.
- **🔒 Lock** in the sidebar locks it right away.
- After 5 wrong tries, each further try has to wait longer, up to 15 minutes.
- The password is stored only as a salted PBKDF2 hash. Sessions use an HttpOnly cookie.

### Encrypt your data (recommended)

**Accounts → Encrypt my data** encrypts the database and all backups, so the files are useless to anyone without your password, even someone with access to your PC.

- You get a one-time **recovery code**. Save it in a password manager or on paper.
- After a restart, the app (including syncing and alerts) waits until you sign in once.
- Encrypted files only open under your Windows user on this PC.

**Forgot your password?** Close the app first: run `uninstall_autostart.ps1`, or end `pythonw.exe` in Task Manager. Then, from the `finance-app` folder:

- **With encryption on:** run `py -3.12 main.py --recover` and enter your recovery code and a new password. Without the code, the data can't be opened. That's the point of encryption.
- **Without encryption:** run `py -3.12 main.py --reset-password`, then create a new password in the app. Your data is untouched.

Start the app again afterwards with `install_autostart.ps1` or `run.bat`.

## Privacy & security

- All data stays on this computer in `data/finance.db`. The server only accepts connections from this machine (`127.0.0.1`).
- Plaid access tokens are encrypted with your Windows login (DPAPI), so a copied database file can't be used to reach your accounts.
- `config.json` holds your Plaid secret and any email password. Don't share it or commit it to git (`.gitignore` already excludes it and `data/`).
- Backups are made automatically (see above). On a new PC, you'll need to reconnect your banks, and encrypted backups only open on this PC under your Windows user.

## Use it from your iPhone

This uses **Tailscale**, a free private network between your own devices. Your iPhone reaches your PC as if it were on the same Wi-Fi, from anywhere, and **nothing is exposed to the public internet**.

**One-time setup**

1. **On your PC:** install Tailscale from https://tailscale.com/download/windows and sign in. Using a Google, Microsoft or Apple account is easiest.
2. **On your iPhone:** install **Tailscale** from the App Store, sign in with the **same account**, and allow the VPN when it asks. Leave the switch on.
3. **On your PC,** open PowerShell and run:
   ```
   tailscale serve --bg 8765
   ```
   It prints your PC's private address, like `https://your-pc.tail1234.ts.net`. The first time, it may print a link to turn on HTTPS for your account; open it, click Enable, then run the command again.
4. **In Kerdos on your PC:** go to **Accounts → Phone access → Allow my Tailscale address**. It's filled in for you if Tailscale is running. Click OK.
5. **On your iPhone,** open **Safari**, go to that `https://…ts.net` address, and sign in with your Kerdos password.
6. Tap **Share → Add to Home Screen**. Kerdos now opens like an app, with its own icon and no browser bars.

**Good to know**

- Your PC has to be on and awake. To stop it sleeping while plugged in: Settings → System → Power → Sleep → Never, when plugged in.
- Only devices signed in to *your* Tailscale account can reach it. Never use `tailscale funnel`; that would make it public.
- The phone uses the same password and auto-lock. Use 🔒 Lock when you're done.
- To turn phone access off: run `tailscale serve reset`, and remove the address under Accounts → Phone access.

## About the investing plan

The plan follows the widely published "order of operations" for saving and investing. It's an educational tool, not personalised financial advice. It doesn't know your whole tax situation, your state taxes, or your goals. Contribution limits and Roth income limits are set for **2026** at the top of `app/planner.py`; check them at irs.gov each year. For big decisions, such as backdoor Roth conversions or large rollovers, consider a fee-only fiduciary advisor.

## Files

| Path | What it does |
|---|---|
| `app/server.py` | Web server and JSON API |
| `app/plaid.py` | Plaid connection and sync |
| `app/importer.py` | CSV import |
| `app/categorize.py` | Categories, built-in merchant rules, your rules |
| `app/bills.py` | Recurring bill / autopay detection |
| `app/alerts.py` | Alert rules and phone/email delivery |
| `app/finance.py` | Net worth and spending math |
| `app/planner.py` | Investing plan and IRS limits |
| `app/demo.py` | Demo data |
| `static/` | The web interface |

## Security notes (Nov 2026 hardening)

* **Secrets in config.json are encrypted.** When the app starts it replaces a plain-text Plaid secret (and email password)
  with a value starting with dpapi: that only your Windows user on this PC can read. To change a secret, paste the new
  one in as plain text and restart; it is sealed again. A config.json copied to another PC will not work there.
* **Password guesses are checked one at a time**, so the lockout (5 misses, then a growing wait) cannot be outrun.
* **Requests from other websites or other local programs are refused** (Origin / Sec-Fetch-Site checks, on top of the
  app header and the SameSite cookie), and nothing in a request body is read before you are signed in.
* **A Content-Security-Policy** lets scripts load only from the app itself and Plaid, so text from a bank can never run
  as code and the page cannot send data anywhere else.
