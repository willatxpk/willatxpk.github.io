@echo off
cd /d "%~dp0"
start "" http://localhost:8765
py -3.12 main.py
