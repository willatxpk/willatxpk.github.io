"""A small learner that gets better every time you sort a transaction.

It's a naive Bayes classifier (the classic spam-filter technique) trained on every transaction
you've categorised by hand or with a rule. It looks at the words in the merchant/description,
whether money went in or out, the account type, and roughly how big the amount was.

Unlike a rule, it generalises: sort "SQ *BLUE BOTTLE COFFEE" as Dining a few times and it
starts recognising other "COFFEE" places too. It only acts on transactions the app is
unsure about, only when it's confident, and never touches anything you set yourself.
Learned categories show as "probably right" in the Sort tab so you can check them.
"""
import math
import re
from collections import Counter, defaultdict

from . import categorize, db

AUTO_APPLY_P = 0.80      # apply on its own above this probability...
MIN_WORD_SUPPORT = 2     # ...and only if a word in this transaction was seen 2+ times with that category
TRAIN_SOURCES = ("user", "rule")
STOP = {"the", "and", "of", "to", "for", "des", "indn", "co", "id", "pos", "sq", "tst", "www"}


def features(t, acct_type=None):
    words = [w for w in re.findall(r"[a-z][a-z&+']{1,}", categorize.merchant_key(t["name"], t.get("merchant")))
             if w not in STOP]
    feats = [f"w:{w}" for w in words]
    if len(words) >= 2:
        feats.append(f"p:{words[0]} {words[1]}")  # e.g. a person's first + last name on a Zelle
    amt = t["amount"]
    feats.append("dir:in" if amt > 0 else "dir:out")
    feats.append(f"amt:{int(math.log2(abs(amt) + 1))}")
    if acct_type:
        feats.append(f"acct:{acct_type}")
    return feats


class Model:
    def __init__(self):
        self.class_n = Counter()
        self.feat_n = defaultdict(Counter)   # class -> feature counts
        self.total = Counter()               # class -> total feature count
        self.vocab = set()

    def train(self, rows):
        for t in rows:
            c = t["category"]
            fs = features(t, t.get("acct_type"))
            self.class_n[c] += 1
            self.feat_n[c].update(fs)
            self.total[c] += len(fs)
            self.vocab.update(fs)
        return self

    @property
    def size(self):
        return sum(self.class_n.values())

    def predict(self, t):
        """Returns (category, probability, supporting_word_count) or (None, 0, 0)."""
        if not self.class_n:
            return None, 0.0, 0
        fs = features(t, t.get("acct_type"))
        V, N = len(self.vocab) + 1, self.size
        scores = {}
        for c, n in self.class_n.items():
            s = math.log(n / N)
            fc, tot = self.feat_n[c], self.total[c]
            for f in fs:
                s += math.log((fc[f] + 1) / (tot + V))
            scores[c] = s
        top = max(scores.values())
        exp = {c: math.exp(v - top) for c, v in scores.items()}
        z = sum(exp.values())
        best = max(exp, key=exp.get)
        support = max((self.feat_n[best][f] for f in fs if f.startswith(("w:", "p:"))), default=0)
        return best, exp[best] / z, support


def train():
    rows = db.rows(
        "SELECT t.name, t.merchant, t.amount, t.category, a.type AS acct_type FROM transactions t "
        "LEFT JOIN accounts a ON a.id = t.account_id "
        f"WHERE t.category_source IN ({','.join('?' * len(TRAIN_SOURCES))}) AND t.category IS NOT NULL",
        TRAIN_SOURCES)
    return Model().train(rows)


def _candidates():
    return db.rows(
        "SELECT t.id, t.name, t.merchant, t.amount, t.category, t.category_source, t.plaid_category, "
        "a.type AS acct_type FROM transactions t LEFT JOIN accounts a ON a.id = t.account_id "
        "WHERE coalesce(t.category_source, '') NOT IN ('user', 'rule', 'match', 'split') "
        "AND (t.confidence = 'low' OR t.category = 'Other' OR t.category_source = 'learned')")


def apply(model=None):
    """Fill in uncertain transactions the model is confident about. Returns how many it set."""
    model = model or train()
    if model.size < 10:
        return 0
    changed = 0
    with db.lock():
        conn = db.get()
        for t in _candidates():
            cat, p, support = model.predict(t)
            if cat and p >= AUTO_APPLY_P and support >= MIN_WORD_SUPPORT:
                if t["category_source"] != "learned" or t["category"] != cat:
                    conn.execute("UPDATE transactions SET category = ?, category_source = 'learned', "
                                 "confidence = 'medium' WHERE id = ?", (cat, t["id"]))
                    changed += 1
            elif t["category_source"] == "learned":
                # The model changed its mind (you taught it otherwise): fall back to the normal guess
                c2, s2 = categorize.classify(t["name"], t["merchant"], t["amount"], t["plaid_category"])
                conn.execute("UPDATE transactions SET category = ?, category_source = ?, confidence = ? WHERE id = ?",
                             (c2, s2, categorize.confidence(c2, s2, t["plaid_category"]), t["id"]))
        conn.commit()
    return changed


def suggestions(txs, model=None):
    """Best guess for each transaction (for the Sort bubbles), even below the auto-apply bar."""
    model = model or train()
    out = {}
    for t in txs:
        cat, p, support = model.predict(t)
        if cat and p >= 0.45 and support >= 1:
            out[t["id"]] = {"category": cat, "p": round(p, 2)}
    return out


def stats():
    return {
        "trained_on": train().size,
        "learned": db.row("SELECT count(*) n FROM transactions WHERE category_source = 'learned'")["n"],
    }
