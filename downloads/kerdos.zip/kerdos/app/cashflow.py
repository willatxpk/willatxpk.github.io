"""Cash flow: 'safe to spend' forecast for checking, and month-to-date spending vs your average."""
import calendar
import statistics
from collections import defaultdict
from datetime import date, timedelta

from . import alerts, bills, categorize, db, finance

DEFAULT_ESSENTIALS = ["Housing", "Groceries", "Utilities", "Phone & Internet", "Insurance",
                      "Loan Payment", "Taxes", "Health"]


def essentials():
    return db.get_setting("essential_categories", DEFAULT_ESSENTIALS)


def buffer_amount():
    return float(db.get_setting("cash_buffer", 300))


# ----------------------------------------------------------- paychecks ----
def income_streams(today=None):
    """Recurring deposits (paychecks etc.) with their next expected dates."""
    today = today or date.today()
    since = (today - timedelta(days=150)).isoformat()
    rows = db.rows("SELECT t.date, t.amount, t.name, t.merchant, t.account_id FROM transactions t "
                   "JOIN accounts a ON a.id = t.account_id WHERE t.category = 'Income' AND t.amount > 0 "
                   "AND t.pending = 0 AND a.type = 'depository' AND t.date >= ? ORDER BY t.date", (since,))
    groups = defaultdict(list)
    for r in rows:
        groups[(categorize.merchant_key(r["name"], r["merchant"]), r["account_id"])].append(r)
    out = []
    for (key, acct), items in groups.items():
        by_day = defaultdict(float)
        for r in items:
            by_day[r["date"][:10]] += r["amount"]
        days = sorted(by_day)
        if len(days) < 3:
            continue
        dates = [date.fromisoformat(d) for d in days]
        amts = [by_day[d] for d in days]
        gaps = [(b - a).days for a, b in zip(dates, dates[1:])]
        med = statistics.median(gaps)
        mean = statistics.mean(amts[-4:])
        if mean <= 0 or statistics.pstdev(amts[-6:]) / mean > 0.35:
            continue
        # Payday days of month; anything from the 28th on counts as "end of month"
        from collections import Counter
        dom_counts = Counter(31 if d.day >= 28 else d.day for d in dates[-6:])
        doms = sorted(dd for dd, _ in dom_counts.most_common(2))
        semi = (len(doms) == 2 and abs((doms[1] - doms[0]) - 15) <= 3
                and sum(dom_counts[x] for x in doms) >= len(dates[-6:]) - 1)
        if 12 <= med <= 17 and semi:
            kind, step = "twice a month", None
        elif 6 <= med <= 8:
            kind, step = "weekly", 7
        elif 12 <= med <= 16:
            kind, step = "every 2 weeks", 14
        elif 26 <= med <= 35:
            kind, step = "monthly", None
        else:
            continue
        if (today - dates[-1]).days > 2.5 * max(med, 7):
            continue  # stopped
        out.append({"name": bills._display_name([r["merchant"] or r["name"] for r in items]), "account_id": acct,
                    "amount": round(mean, 2), "cadence": kind, "step": step, "last": dates[-1],
                    "days_of_month": doms if kind == "twice a month" else [dates[-1].day]})
    return out


def _occurrences(stream, start, end):
    """Dates a paycheck stream should land between start and end (inclusive)."""
    out = []
    if stream["step"]:
        d = stream["last"] + timedelta(days=stream["step"])
        while d <= end:
            if d >= start:
                out.append(d)
            d += timedelta(days=stream["step"])
        return out
    d = start
    while d <= end:
        dim = calendar.monthrange(d.year, d.month)[1]
        if any(min(dom, dim) == d.day for dom in stream["days_of_month"]) and d > stream["last"]:
            out.append(d)
        d += timedelta(days=1)
    return out


def _bill_dates(b, start, end):
    if not b["next_date"]:
        return []
    d = date.fromisoformat(b["next_date"])
    out, guard = [], 0
    while d <= end and guard < 60:
        if d >= start:
            out.append(d)
        if b["cadence"] in ("monthly", "every 2 months", "quarterly", "twice a year", "yearly"):
            months = {"monthly": 1, "every 2 months": 2, "quarterly": 3, "twice a year": 6, "yearly": 12}[b["cadence"]]
            d = bills.add_months(d, months)
        else:
            d += timedelta(days=round(b["cadence_days"] or 30))
        guard += 1
    return out


# ------------------------------------------------------------ forecast ----
def forecast(days=45, today=None):
    today = today or date.today()
    end = today + timedelta(days=days)
    accts = [a for a in finance.accounts(include_hidden=False) if a["type"] == "depository"
             and (a.get("subtype") or "checking").lower() not in ("savings", "money market", "cd", "hsa")]
    ids = {a["id"] for a in accts}
    if not accts:
        return {"accounts": [], "points": [], "events": []}
    start_bal = sum((a["available_balance"] if a["available_balance"] is not None else a["current_balance"]) or 0
                    for a in accts)
    events = []
    for s in income_streams(today):
        if s["account_id"] in ids:
            for d in _occurrences(s, today, end):
                events.append({"date": d, "amount": s["amount"], "name": s["name"], "kind": "income"})
    for b in bills.list_bills():
        if b["status"] != "active" or b["account_id"] not in ids or b["id"].startswith("liab:"):
            continue
        if b["merchant"].startswith("xfer:") and b["merchant"].split(":")[1] in ids:
            continue  # moving money between your own checking accounts
        for d in _bill_dates(b, today, end):
            events.append({"date": d, "amount": -(b["avg_amount"] or 0), "name": b["display_name"],
                           "kind": "bill", "autopay": b["autopay"]})
    # Everyday spending from checking that isn't a bill (debit card, ATM, Venmo...)
    since = (today - timedelta(days=90)).isoformat()
    bill_keys = {b["merchant"] for b in bills.list_bills()}
    spend = 0.0
    marks = ",".join("?" * len(ids))
    for t in db.rows(f"SELECT name, merchant, amount, category, pair_kind FROM transactions WHERE account_id IN ({marks}) "
                     "AND amount < 0 AND pending = 0 AND date >= ?", (*ids, since)):
        if t["pair_kind"] or t["category"] in categorize.NON_SPENDING:
            continue
        if categorize.merchant_key(t["name"], t["merchant"]) in bill_keys:
            continue
        spend += -t["amount"]
    daily = spend / 90
    events.sort(key=lambda e: e["date"])
    pending = db.row(f"SELECT coalesce(sum(amount), 0) s FROM transactions WHERE account_id IN ({marks}) "
                     "AND pending = 1", tuple(ids))["s"]
    bal = start_bal + (pending if any(a["available_balance"] is None for a in accts) else 0)
    points, by_day = [], defaultdict(list)
    for e in events:
        by_day[e["date"]].append(e)
    for i in range(days + 1):
        d = today + timedelta(days=i)
        if i:
            bal -= daily
        for e in by_day.get(d, []):
            bal += e["amount"]
        points.append({"date": d.isoformat(), "balance": round(bal, 2)})
    paydays = [e["date"] for e in events if e["kind"] == "income"]
    next_pay = paydays[0] if paydays else None
    window = [p for p in points if not next_pay or p["date"] < next_pay.isoformat()] or points[:1]
    low = min(window, key=lambda p: p["balance"])
    low_all = min(points, key=lambda p: p["balance"])
    buf = buffer_amount()
    return {
        "accounts": [{"id": a["id"], "name": a["name"], "balance": a["available_balance"] if a["available_balance"]
                      is not None else a["current_balance"]} for a in accts],
        "start_balance": round(start_bal, 2), "daily_spending": round(daily, 2), "buffer": buf,
        "next_payday": next_pay.isoformat() if next_pay else None,
        "safe_to_spend": round(max(0, low["balance"] - buf), 2),
        "lowest": low, "lowest_overall": low_all,
        "points": points,
        "events": [{**e, "date": e["date"].isoformat()} for e in events],
        "paychecks": [{k: (v.isoformat() if isinstance(v, date) else v) for k, v in s.items() if k != "step"}
                      for s in income_streams(today) if s["account_id"] in ids],
    }


def check_alerts(today=None):
    """Warn when checking is projected to dip below your cushion in the next 2 weeks."""
    today = today or date.today()
    f = forecast(21, today)
    if not f["points"]:
        return
    soon = [p for p in f["points"] if p["date"] <= (today + timedelta(days=14)).isoformat()]
    low = min(soon, key=lambda p: p["balance"])
    if low["balance"] < f["buffer"]:
        d = date.fromisoformat(low["date"])
        alerts.add(f"lowcash:{low['date']}:{int(low['balance'] // 100)}", "low_cash",
                   f"Checking may dip to {alerts.money(low['balance'])} on {d.strftime('%b')} {d.day}",
                   f"That's below your {alerts.money(f['buffer'])} cushion. Upcoming bills and usual spending "
                   "are counted; consider moving money from savings or holding off on big purchases.",
                   "danger" if low["balance"] < 0 else "warn")


# ---------------------------------------------------------- this month ----
def this_month(today=None, months_back=6):
    today = today or date.today()
    ess = set(essentials())
    month = today.strftime("%Y-%m")
    dim = calendar.monthrange(today.year, today.month)[1]
    hist = [m for m in finance.spending_by_month(months_back + 1, today)[:-1] if m["spending"] or m["income"]]
    n = len(hist) or 1
    avg = defaultdict(float)
    for m in hist:
        for k, v in m["categories"].items():
            avg[k] += v / n
    spent, pend = defaultdict(float), defaultdict(float)
    for t in db.rows("SELECT category, amount, pending FROM transactions WHERE date LIKE ?", (month + "%",)):
        c = t["category"] or "Other"
        if c in categorize.NON_SPENDING:
            continue
        (pend if t["pending"] else spent)[c] += -t["amount"]
    cats = sorted(set(avg) | set(spent) | set(pend), key=lambda c: -(spent[c] + pend[c] + avg[c]))
    rows = []
    for c in cats:
        s, p, a = spent[c], pend[c], avg[c]
        if abs(s) < 0.005 and abs(p) < 0.005 and a < 1:
            continue
        rows.append({"category": c, "essential": c in ess, "spent": round(s, 2), "pending": round(p, 2),
                     "average": round(a, 2), "left": round(a - s - p, 2)})
    frac = today.day / dim
    days_left = dim - today.day + 1

    def group(filter_fn):
        rs = [r for r in rows if filter_fn(r)]
        a = sum(r["average"] for r in rs)
        s = sum(r["spent"] + r["pending"] for r in rs)
        left = a - s
        return {"average": round(a, 2), "spent": round(s, 2), "left": round(left, 2),
                "per_day": round(max(0, left) / days_left, 2), "expected_by_now": round(a * frac, 2),
                "pace": "over" if s > a else ("ahead" if s > a * frac * 1.1 else "on track")}

    top = db.rows("SELECT coalesce(merchant, name) AS who, category, -sum(amount) AS total, count(*) AS n "
                  "FROM transactions WHERE date LIKE ? AND amount < 0 GROUP BY who ORDER BY total DESC LIMIT 40",
                  (month + "%",))
    top = [t for t in top if t["category"] not in ess and t["category"] not in categorize.NON_SPENDING][:8]
    return {
        "month": month, "day": today.day, "days_in_month": dim, "days_left": days_left,
        "months_averaged": len(hist), "essentials": sorted(ess),
        "nonessential": group(lambda r: not r["essential"]), "essential": group(lambda r: r["essential"]),
        "total": group(lambda r: True), "categories": rows, "top_merchants": top,
    }


# ------------------------------------------------------------ calendar ----
def _paid_history(start, end):
    """What was actually paid toward each bill between two dates: {bill key: {day: amount}}.
    Charges are matched to bills the same way the bill detector groups them."""
    rows = db.rows(
        "SELECT t.date, t.amount, t.name, t.merchant, t.category, t.pair_kind, pa.id AS paid_acct_id "
        "FROM transactions t LEFT JOIN transactions p ON p.id = t.pair_id LEFT JOIN accounts pa ON pa.id = p.account_id "
        "WHERE t.amount < 0 AND t.pending = 0 AND substr(t.date, 1, 10) BETWEEN ? AND ?",
        (start.isoformat(), end.isoformat()))
    out = defaultdict(lambda: defaultdict(float))
    for t in rows:
        if t["category"] in bills.SKIP_CATEGORIES:
            continue
        key = categorize.merchant_key(t["name"], t["merchant"])
        if t["pair_kind"] in ("card_payment", "debt_payment") and t["paid_acct_id"]:
            key = "pay:" + t["paid_acct_id"]
        elif t["pair_kind"] in ("transfer", "investment"):
            key = "xfer:" + (t["paid_acct_id"] or "") + ":" + key
        out[key][t["date"][:10]] += -t["amount"]
    return out


def month_calendar(month=None, today=None):
    """Bills and paydays on a month grid (weeks start on Sunday), with the days around it that fill the grid.

    Upcoming dates are predictions from each bill's own history. A bill's most recent payment is shown as
    paid; one that was expected by now but hasn't appeared at the bank is marked late.
    """
    today = today or date.today()
    this_month = today.replace(day=1)
    try:
        first = date.fromisoformat((month or "")[:7] + "-01")
    except ValueError:
        first = this_month
    lo, hi = bills.add_months(this_month, -12), bills.add_months(this_month, 18)
    first = min(max(first, lo), hi)
    last = date(first.year, first.month, calendar.monthrange(first.year, first.month)[1])
    start = first - timedelta(days=(first.weekday() + 1) % 7)    # back to Sunday
    end = last + timedelta(days=(5 - last.weekday()) % 7)         # on to Saturday

    events = defaultdict(list)
    history = _paid_history(start, min(end, today)) if start <= today else {}
    for b in bills.list_bills():
        if b["status"] != "active":
            continue
        base = {"kind": "bill", "id": b["id"], "name": b["display_name"] or b["merchant"],
                "amount": round(b["avg_amount"] or 0, 2), "autopay": b["autopay"], "cadence": b["cadence"],
                "category": b["category"], "account": b.get("account_name"), "pays": b.get("pays_account_name"),
                "debt": bool(b.get("pays_account_id")) or str(b["id"]).startswith("liab:")}
        for day, amount in history.get(b["merchant"], {}).items():   # what really went out, on the day it did
            events[date.fromisoformat(day)].append({**base, "state": "paid", "amount": round(amount, 2)})
        if b["stale"]:
            continue  # looks like it ended: don't keep predicting it
        for d in _bill_dates(b, start, end):
            events[d].append({**base, "state": "late" if d < today else "due"})
    for s in income_streams(today):
        for d in _occurrences(s, max(start, today), end):
            acct = db.row("SELECT name FROM accounts WHERE id = ?", (s["account_id"],))
            events[d].append({"kind": "income", "name": s["name"], "amount": s["amount"], "state": "due",
                              "cadence": s["cadence"], "account": (acct or {}).get("name")})

    order = {"late": 0, "due": 1, "paid": 2}
    days, tot = [], {"due": 0.0, "due_count": 0, "manual_count": 0, "paid": 0.0, "paid_count": 0,
                     "late": 0.0, "late_count": 0, "income": 0.0, "income_count": 0}
    d = start
    while d <= end:
        evs = sorted(events.get(d, []), key=lambda e: (e["kind"] != "income", order[e["state"]], -e["amount"]))
        in_month = d.month == first.month
        if in_month:
            for e in evs:
                if e["kind"] == "income":
                    tot["income"] += e["amount"]
                    tot["income_count"] += 1
                elif e["state"] == "paid":
                    tot["paid"] += e["amount"]
                    tot["paid_count"] += 1
                else:
                    tot["due"] += e["amount"]
                    tot["due_count"] += 1
                    if e["autopay"] not in ("yes", "likely"):
                        tot["manual_count"] += 1
                    if e["state"] == "late":
                        tot["late"] += e["amount"]
                        tot["late_count"] += 1
        days.append({"date": d.isoformat(), "day": d.day, "in_month": in_month, "events": evs})
        d += timedelta(days=1)
    prev, nxt = bills.add_months(first, -1), bills.add_months(first, 1)
    return {"month": first.strftime("%Y-%m"), "title": first.strftime("%B %Y"), "today": today.isoformat(),
            "days": days, "totals": {k: round(v, 2) for k, v in tot.items()},
            "prev": prev.strftime("%Y-%m") if prev >= lo else None,
            "next": nxt.strftime("%Y-%m") if nxt <= hi else None}
