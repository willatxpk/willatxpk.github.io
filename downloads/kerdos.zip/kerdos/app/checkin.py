"""Weekly check-in: a 2-minute review made of decisions, not chores.

  1. Confirm the week's biggest charges (or fix their category)
  2. Decide on new fees / odd charges
  3. "Still worth it?" for up to 3 subscriptions due a review
  4. Accept, adjust or skip one suggested budget change  (at most ~9 decisions in total)
  5. See how this week compares with last week and a typical week

Finishing earns pet coins (15, plus a streak bonus) and keeps your weekly streak going.
"""
from collections import defaultdict
from datetime import date, timedelta

from . import alerts, cashflow, categorize, db, goals, subscriptions, watchdog

BASE_COINS = 15
STREAK_BONUS = 5
MAX_BONUS = 25


def week_id(d):
    return d.strftime("%G-W%V")


def history():
    return db.get_setting("checkins", []) or []


def streak(today=None):
    today = today or date.today()
    done = {c["week"] for c in history()}
    d = today if week_id(today) in done else today - timedelta(days=7)
    n = 0
    while week_id(d) in done:
        n += 1
        d -= timedelta(days=7)
    return n


def coins_earned():
    return sum(c.get("coins", 0) for c in history())


def _spend(start, end):
    """Spending (after refunds) by category between start and end inclusive."""
    out = defaultdict(float)
    for r in db.rows("SELECT category, sum(amount) s FROM transactions WHERE date >= ? AND date <= ? "
                     "GROUP BY category", (start.isoformat(), end.isoformat() + "~")):
        c = r["category"] or "Other"
        if c not in categorize.NON_SPENDING:
            out[c] += -r["s"]
    return out


def compare(today=None):
    today = today or date.today()
    this = _spend(today - timedelta(days=6), today)
    last = _spend(today - timedelta(days=13), today - timedelta(days=7))
    typical = defaultdict(float)
    for w in range(2, 10):  # the 8 weeks before last week
        for c, v in _spend(today - timedelta(days=7 * w + 6), today - timedelta(days=7 * w)).items():
            typical[c] += v / 8
    cats = set(this) | set(typical)
    movers = sorted(({"category": c, "this_week": round(this[c], 2), "typical": round(typical[c], 2),
                      "diff": round(this[c] - typical[c], 2)} for c in cats), key=lambda m: -abs(m["diff"]))
    return {"this_week": round(sum(this.values()), 2), "last_week": round(sum(last.values()), 2),
            "typical_week": round(sum(typical.values()), 2),
            "movers": [m for m in movers if abs(m["diff"]) >= 10][:5]}


def budget_suggestion(today=None):
    today = today or date.today()
    skipped = db.get_setting("checkin_skipped_budget", {}) or {}
    month = cashflow.this_month(today)
    caps = {g["params"].get("category"): g for g in goals.list_goals() if g["kind"] == "spend_cap"}
    frac = month["day"] / month["days_in_month"]
    best = None
    for r in month["categories"]:
        c = r["category"]
        if r["essential"] or r["average"] < 50 or skipped.get(c) == month["month"]:
            continue
        spent = r["spent"] + r["pending"]
        cap = caps.get(c)
        if cap:
            evald = goals.evaluate(cap, today)
            recent = [ch for ch in evald.get("checks", []) if ch.get("scored")][-3:]
            if len(recent) == 3 and all((ch.get("value") or 0) < cap["target"] * 0.75 for ch in recent):
                amt = round(max(r["average"], max(ch.get("value") or 0 for ch in recent)) * 1.05, -1)
                cand = {"category": c, "amount": amt, "goal_id": cap["id"], "current": cap["target"],
                        "why": f"You've stayed well under your ${cap['target']:,.0f} cap for 3 months. Lowering it "
                               f"to ${amt:,.0f} locks in the habit (and your pet still gets credit).", "score": 1}
                best = best or cand
            continue
        pace = spent / (r["average"] * frac) if frac and r["average"] else 0
        if pace > 1.15 and spent > 25:
            amt = round(r["average"] * 0.9, -1) or 10
            cand = {"category": c, "amount": amt, "goal_id": None, "current": None,
                    "why": f"{c} is running " + (f"{pace:.1f}× your usual pace" if pace >= 2 else
                                                 f"{pace * 100 - 100:.0f}% ahead of your usual pace") + " this month "
                           f"(${spent:,.0f} so far vs about ${r['average']:,.0f} in a normal month). A ${amt:,.0f} "
                           "monthly cap would keep it in check.", "score": pace}
            if not best or cand["score"] > best["score"]:
                best = cand
    if best:
        best.pop("score", None)
        best["month"] = month["month"]
    return best


def build(today=None):
    today = today or date.today()
    week = week_id(today)
    done = next((c for c in history() if c["week"] == week), None)
    big = db.rows("SELECT t.id, t.date, t.name, t.merchant, t.amount, t.category, t.category_source, t.pending, "
                  "a.name AS account_name FROM transactions t LEFT JOIN accounts a ON a.id = t.account_id "
                  "WHERE t.amount <= -20 AND t.date >= ? AND coalesce(t.source, '') != 'split' "
                  "AND t.category NOT IN ('Transfer', 'Credit Card Payment', 'Investments') "
                  "ORDER BY t.amount ASC LIMIT 3", ((today - timedelta(days=6)).isoformat(),))
    leaks = [f for f in watchdog.scan(today)["open"] if not f.get("waiting") and not f.get("decision")][:3]
    subs = [s for s in subscriptions.checkup(today)["subscriptions"] if s["needs_review"]][:2]
    st = streak(today)
    return {"week": week, "done": done, "streak": st, "next_reward": BASE_COINS + min(MAX_BONUS, STREAK_BONUS * st),
            "big_charges": big, "leaks": leaks, "subscriptions": subs,
            "budget": budget_suggestion(today), "compare": compare(today),
            "history": history()[-12:], "coins_total": coins_earned(),
            "categories": categorize.all_categories()}


def complete(answers=None, today=None):
    today = today or date.today()
    week = week_id(today)
    hist = history()
    if any(c["week"] == week for c in hist):
        return {"already": True, "coins": 0, "streak": streak(today)}
    prev = streak(today)  # weeks in a row before this one
    coins = BASE_COINS + min(MAX_BONUS, STREAK_BONUS * prev)
    answers = answers or {}
    hist.append({"week": week, "date": today.isoformat(), "coins": coins,
                 "decisions": int(answers.get("decisions") or 0)})
    db.set_setting("checkins", hist[-104:])
    return {"coins": coins, "streak": prev + 1}


def apply_budget(category, amount, goal_id=None, skip=False, today=None):
    today = today or date.today()
    if skip:
        sk = db.get_setting("checkin_skipped_budget", {}) or {}
        sk[category] = today.strftime("%Y-%m")
        db.set_setting("checkin_skipped_budget", sk)
        return {"skipped": True}
    amount = float(amount)
    if amount <= 0:
        raise ValueError("Enter an amount above $0")
    if goal_id:
        g = next((g for g in goals.list_goals() if g["id"] == int(goal_id)), None)
        if not g:
            raise ValueError("That cap no longer exists")
        db.execute("UPDATE goals SET target = ?, name = ? WHERE id = ?",
                   (amount, goals.retarget_name(g["name"], g["target"], amount), g["id"]))
        return {"goal_id": g["id"], "updated": True}
    gid = goals.create({"kind": "spend_cap", "target": amount, "params": {"category": category}})
    return {"goal_id": gid, "created": True}


def check_alerts(today=None):
    """Weekend nudge if this week's check-in isn't done yet."""
    today = today or date.today()
    if today.weekday() < 5 or any(c["week"] == week_id(today) for c in history()):
        return
    if not db.row("SELECT 1 FROM transactions LIMIT 1"):
        return
    st = streak(today)
    alerts.add(f"checkin:{week_id(today)}", "checkin", "Your weekly check-in is ready (2 minutes)",
               (f"Keep your {st}-week streak going. " if st else "") +
               f"Worth {BASE_COINS + min(MAX_BONUS, STREAK_BONUS * st)} pet coins.", "info")
