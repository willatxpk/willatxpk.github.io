"""Minimal Plaid REST client (no SDK needed) + sync into the local database.

Docs: https://plaid.com/docs/api/
"""
import json
import urllib.error
import urllib.request
from datetime import datetime

from . import categorize, config, db

HOSTS = {
    "sandbox": "https://sandbox.plaid.com",
    "production": "https://production.plaid.com",
}


class PlaidError(Exception):
    def __init__(self, payload):
        self.payload = payload if isinstance(payload, dict) else {"error_message": str(payload)}
        super().__init__(self.payload.get("error_message") or str(payload))

    @property
    def code(self):
        return self.payload.get("error_code")


def _call(path, body):
    cfg = config.load()["plaid"]
    host = HOSTS.get(cfg.get("env", "sandbox"), HOSTS["sandbox"])
    payload = dict(body, client_id=cfg["client_id"], secret=cfg["secret"])
    req = urllib.request.Request(
        host + path,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            raise PlaidError(json.loads(e.read().decode("utf-8")))
        except ValueError:
            raise PlaidError({"error_message": f"HTTP {e.code}"})
    except urllib.error.URLError as e:
        raise PlaidError({"error_message": f"Network error: {e.reason}"})


def create_link_token(item_id=None, add_investments=False, redirect_uri=None):
    body = {
        "user": {"client_user_id": "local-user"},
        "client_name": "Kerdos",
        "country_codes": ["US"],
        "language": "en",
    }
    if redirect_uri:
        # Banks like Vanguard send you back here after signing in (sturdier than a pop-up window).
        # The exact URI must be listed in the Plaid Dashboard under allowed redirect URIs.
        body["redirect_uri"] = redirect_uri
    if item_id:  # update mode: re-authenticate an existing connection (or grant investments access)
        body["access_token"] = _token(item_id)
        if add_investments:
            body["additional_consented_products"] = ["investments"]
    else:
        body["products"] = ["transactions"]
        body["optional_products"] = ["liabilities", "investments"]
        body["transactions"] = {"days_requested": 730}
    return _call("/link/token/create", body)["link_token"]


def exchange_public_token(public_token, institution_name=None):
    res = _call("/item/public_token/exchange", {"public_token": public_token})
    item_id, access_token = res["item_id"], res["access_token"]
    db.execute(
        "INSERT INTO items(item_id, access_token, institution) VALUES(?, ?, ?) "
        "ON CONFLICT(item_id) DO UPDATE SET access_token = excluded.access_token, error = NULL",
        (item_id, config.protect(access_token), institution_name),
    )
    sync_item(item_id)
    return item_id


def _token(item_id):
    r = db.row("SELECT access_token FROM items WHERE item_id = ?", (item_id,))
    if not r:
        raise PlaidError({"error_message": "Unknown connection"})
    return config.unprotect(bytes(r["access_token"]))


def remove_item(item_id):
    try:
        _call("/item/remove", {"access_token": _token(item_id)})
    except PlaidError:
        pass  # still remove locally
    with db.lock():
        conn = db.get()
        acct_ids = [r[0] for r in conn.execute("SELECT id FROM accounts WHERE item_id = ?", (item_id,))]
        for a in acct_ids:
            conn.execute("DELETE FROM transactions WHERE account_id = ?", (a,))
            conn.execute("DELETE FROM liabilities WHERE account_id = ?", (a,))
        conn.execute("DELETE FROM accounts WHERE item_id = ?", (item_id,))
        conn.execute("DELETE FROM items WHERE item_id = ?", (item_id,))
        conn.commit()


def _norm_type(t):
    return t if t in ("depository", "credit", "loan", "investment") else "other"


def sync_accounts(item_id, token, institution):
    res = _call("/accounts/get", {"access_token": token})
    if not institution:
        institution = _institution_name(res.get("item", {}).get("institution_id"))
        if institution:
            db.execute("UPDATE items SET institution = ? WHERE item_id = ?", (institution, item_id))
    with db.lock():
        conn = db.get()
        for a in res["accounts"]:
            b = a.get("balances", {})
            conn.execute(
                """INSERT INTO accounts(id, item_id, name, official_name, mask, type, subtype,
                       institution, current_balance, available_balance, currency, credit_limit, source, updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?, 'plaid', datetime('now'))
                   ON CONFLICT(id) DO UPDATE SET name=excluded.name, official_name=excluded.official_name,
                       current_balance=excluded.current_balance, available_balance=excluded.available_balance,
                       credit_limit=excluded.credit_limit,
                       institution=excluded.institution, updated_at=datetime('now')""",
                (
                    a["account_id"], item_id, a.get("name"), a.get("official_name"), a.get("mask"),
                    _norm_type(a.get("type")), a.get("subtype"), institution,
                    b.get("current") or 0, b.get("available"), b.get("iso_currency_code") or "USD", b.get("limit"),
                ),
            )
        conn.commit()


def _institution_name(inst_id):
    if not inst_id:
        return None
    try:
        res = _call("/institutions/get_by_id", {"institution_id": inst_id, "country_codes": ["US"]})
        return res["institution"]["name"]
    except PlaidError:
        return None


def sync_transactions(item_id, token, cursor):
    rules = categorize.load_rules()
    added = modified = removed = 0
    while True:
        body = {"access_token": token, "count": 500}
        if cursor:
            body["cursor"] = cursor
        res = _call("/transactions/sync", body)
        with db.lock():
            conn = db.get()
            for t in res.get("added", []) + res.get("modified", []):
                pfc = t.get("personal_finance_category") or {}
                pfc_s = (f"{pfc.get('primary', '')}|{pfc.get('detailed', '')}|{pfc.get('confidence_level') or ''}"
                         if pfc else None)
                amount = -float(t["amount"])  # Plaid: positive = money out. We flip it.
                existing = conn.execute(
                    "SELECT category, category_source FROM transactions WHERE id = ?",
                    (t["transaction_id"],),
                ).fetchone()
                was_pending = None
                if not existing and t.get("pending_transaction_id"):
                    was_pending = conn.execute(
                        "SELECT category, category_source, notes FROM transactions WHERE id = ?",
                        (t["pending_transaction_id"],)).fetchone()
                if existing and existing["category_source"] in ("user", "match"):
                    cat, src = existing["category"], existing["category_source"]
                elif was_pending and was_pending["category_source"] == "user":
                    cat, src = was_pending["category"], "user"  # you sorted it while it was pending
                else:
                    cat, src = categorize.classify(t.get("name"), t.get("merchant_name"), amount, pfc_s, rules)
                conf = categorize.confidence(cat, src, pfc_s)
                conn.execute(
                    """INSERT INTO transactions(id, account_id, date, name, merchant, amount, plaid_category,
                           category, category_source, pending, confidence, source)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?, 'plaid')
                       ON CONFLICT(id) DO UPDATE SET date=excluded.date, name=excluded.name,
                           merchant=excluded.merchant, amount=excluded.amount,
                           plaid_category=excluded.plaid_category, category=excluded.category,
                           category_source=excluded.category_source, pending=excluded.pending,
                           confidence=excluded.confidence""",
                    (
                        t["transaction_id"], t["account_id"], t["date"], t.get("name") or "",
                        t.get("merchant_name"), amount, pfc_s, cat, src, 1 if t.get("pending") else 0, conf,
                    ),
                )
            added += len(res.get("added", []))
            modified += len(res.get("modified", []))
            for r in res.get("removed", []):
                conn.execute("DELETE FROM transactions WHERE id = ?", (r["transaction_id"],))
                removed += 1
            cursor = res.get("next_cursor")
            conn.execute("UPDATE items SET cursor = ? WHERE item_id = ?", (cursor, item_id))
            conn.commit()
        if not res.get("has_more"):
            break
    return {"added": added, "modified": modified, "removed": removed}


def sync_liabilities(token):
    try:
        res = _call("/liabilities/get", {"access_token": token})
    except PlaidError as e:
        if e.code in ("PRODUCTS_NOT_SUPPORTED", "PRODUCT_NOT_READY", "ADDITIONAL_CONSENT_REQUIRED",
                      "NO_LIABILITY_ACCOUNTS", "INVALID_PRODUCT"):
            return 0
        raise
    lib = res.get("liabilities") or {}
    n = 0
    with db.lock():
        conn = db.get()

        def put(acct, kind, apr, minimum, due, stmt):
            conn.execute(
                """INSERT INTO liabilities(account_id, kind, apr, minimum_payment, next_due_date,
                       last_statement_balance, updated_at) VALUES(?,?,?,?,?,?, datetime('now'))
                   ON CONFLICT(account_id) DO UPDATE SET kind=excluded.kind, apr=excluded.apr,
                       minimum_payment=excluded.minimum_payment, next_due_date=excluded.next_due_date,
                       last_statement_balance=excluded.last_statement_balance, updated_at=datetime('now')""",
                (acct, kind, apr, minimum, due, stmt),
            )

        for c in lib.get("credit") or []:
            aprs = [a.get("apr_percentage") for a in c.get("aprs") or []
                    if a.get("apr_type") == "purchase_apr" and a.get("apr_percentage") is not None]
            put(c["account_id"], "credit", aprs[0] if aprs else None, c.get("minimum_payment_amount"),
                c.get("next_payment_due_date"), c.get("last_statement_balance"))
            n += 1
        for s in lib.get("student") or []:
            put(s["account_id"], "student", s.get("interest_rate_percentage"), s.get("minimum_payment_amount"),
                s.get("next_payment_due_date"), s.get("last_statement_balance"))
            n += 1
        for m in lib.get("mortgage") or []:
            rate = (m.get("interest_rate") or {}).get("percentage")
            put(m["account_id"], "mortgage", rate, m.get("next_monthly_payment"),
                m.get("next_payment_due_date"), None)
            n += 1
        conn.commit()
    return n


def sync_item(item_id):
    item = db.row("SELECT * FROM items WHERE item_id = ?", (item_id,))
    token = config.unprotect(bytes(item["access_token"]))
    try:
        sync_accounts(item_id, token, item.get("institution"))
        # One-time full re-download so older transactions get Plaid's confidence levels too
        refetched = db.get_setting("refetch_v2:" + item_id)
        tx = sync_transactions(item_id, token, item.get("cursor") if refetched else None)
        db.set_setting("refetch_v2:" + item_id, True)
        sync_liabilities(token)
        db.execute(
            "UPDATE items SET last_sync = ?, error = NULL WHERE item_id = ?",
            (datetime.now().isoformat(timespec="seconds"), item_id),
        )
        return tx
    except PlaidError as e:
        db.execute("UPDATE items SET error = ? WHERE item_id = ?", (e.code or str(e), item_id))
        raise


def sync_all():
    results, errors = {}, {}
    for item in db.rows("SELECT item_id, institution FROM items"):
        try:
            results[item["institution"] or item["item_id"]] = sync_item(item["item_id"])
        except PlaidError as e:
            errors[item["institution"] or item["item_id"]] = str(e)
    return {"results": results, "errors": errors}
