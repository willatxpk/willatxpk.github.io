"""Detects recurring bills / subscriptions / autopays from transaction history."""
import calendar
import hashlib
import re
import statistics
from collections import Counter, defaultdict
from datetime import date, timedelta

from . import categorize, db

CADENCES = [  # (label, min_days, max_days, nominal_days)
    ("weekly", 5, 9, 7),
    ("every 2 weeks", 12, 17, 14),
    ("monthly", 25, 36, 30.44),
    ("every 2 months", 55, 66, 61),
    ("quarterly", 84, 98, 91),
    ("twice a year", 170, 196, 182),
    ("yearly", 340, 390, 365),
]
AUTOPAY_HINT = re.compile(r"auto\s*-?pay|autopay|aut pay|automatic pay|recurring|ach (debit|pmt|withdrawal)|"
                          r"\bppd\b|e-?payment", re.I)
MANUAL_HINT = re.compile(r"mobile banking|online banking|online pmt|web pmt|bill pay|billpay|"
                         r"one[- ]time|confirmation#|zelle", re.I)
SKIP_CATEGORIES = {"Income"}
LOOKBACK_DAYS = 430


def _parse(d):
    return date.fromisoformat(d[:10])


def add_months(d, n, day=None):
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    day = day or d.day
    return date(y, m, min(day, calendar.monthrange(y, m)[1]))


def _cadence(median_days):
    for label, lo, hi, nominal in CADENCES:
        if lo <= median_days <= hi:
            return label, nominal
    return None, None


def _predict_next(dates, label, nominal):
    last = dates[-1]
    if label in ("monthly", "every 2 months", "quarterly", "twice a year", "yearly"):
        months = {"monthly": 1, "every 2 months": 2, "quarterly": 3, "twice a year": 6, "yearly": 12}[label]
        typical_day = Counter(d.day for d in dates[-6:]).most_common(1)[0][0]
        return add_months(last, months, typical_day)
    return last + timedelta(days=round(nominal))


def _display_name(names):
    name = Counter(names).most_common(1)[0][0]
    name = re.sub(r"\s{2,}", " ", name).strip()
    return name[:48]


def _day_spread(dates):
    """How much the day-of-month wanders (handles month-end wrap)."""
    days = [d.day for d in dates[-6:]]
    if len(days) < 2:
        return 99
    med = statistics.median(days)
    return max(min(abs(x - med), 31 - abs(x - med)) for x in days)


def judge_autopay(items, dates, account_type, liability=None):
    """Returns (autopay, reason). autopay: yes | likely | no | unknown."""
    names = [f"{t['name']} {t.get('merchant') or ''}" for t in items]
    if any(AUTOPAY_HINT.search(n) for n in names):
        return "yes", "The bank description says it's an automatic payment."
    if account_type == "credit":
        return "yes", "Charged to a credit card on a schedule, which is automatic by nature."
    manual = sum(1 for n in names if MANUAL_HINT.search(n))
    if manual >= max(1, len(names) // 2):
        return "no", "Looks like payments you make by hand (online/mobile banking)."
    if liability and liability.get("next_due_date") and len(dates) >= 3:
        due_day = _parse(liability["next_due_date"]).day
        offsets = [((due_day - d.day) % 31) for d in dates[-4:]]
        if max(offsets) - min(offsets) <= 2 and max(offsets) <= 5:
            when = "on the due date" if max(offsets) == 0 else (
                f"{min(offsets)} days before the due date" if min(offsets) == max(offsets)
                else f"{min(offsets)}-{max(offsets)} days before the due date")
            return "likely", f"Paid {when} every month, like an automatic payment."
    if len(dates) >= 3 and _day_spread(dates) <= 2:
        return "likely", "Paid on almost the same day every cycle."
    if len(dates) >= 3:
        return "no", "The payment day moves around, which usually means it's paid by hand."
    return "unknown", "Not enough history to tell yet."


def detect(today=None):
    """Re-detects recurring streams, updates the bills table.

    Returns (first_run, new_bills, paid_events) so alerts can be generated.
    paid_events: list of (bill_dict, previous_avg_amount).
    """
    today = today or date.today()
    since = (today - timedelta(days=LOOKBACK_DAYS)).isoformat()
    txs = db.rows(
        "SELECT t.*, a.type AS account_type, pa.id AS paid_acct_id, pa.name AS paid_acct_name "
        "FROM transactions t LEFT JOIN accounts a ON a.id = t.account_id "
        "LEFT JOIN transactions p ON p.id = t.pair_id LEFT JOIN accounts pa ON pa.id = p.account_id "
        "WHERE t.amount < 0 AND t.date >= ? AND t.pending = 0 ORDER BY t.date",
        (since,),
    )
    liabs = {r["account_id"]: r for r in db.rows(
        "SELECT l.*, a.name AS acct_name, a.current_balance FROM liabilities l JOIN accounts a ON a.id = l.account_id")}

    groups = defaultdict(list)
    for t in txs:
        if t["category"] in SKIP_CATEGORIES:
            continue
        if t["pair_kind"] in ("card_payment", "debt_payment") and t["paid_acct_id"]:
            # Every payment toward the same card is one stream, whatever the description says
            groups["pay:" + t["paid_acct_id"]].append(t)
        elif t["pair_kind"] in ("transfer", "investment"):
            groups["xfer:" + (t["paid_acct_id"] or "") + ":" + categorize.merchant_key(t["name"], t["merchant"])].append(t)
        else:
            groups[categorize.merchant_key(t["name"], t["merchant"])].append(t)

    found = {}
    for key, items in groups.items():
        is_payment = key.startswith("pay:")
        by_day = defaultdict(list)
        for t in items:
            by_day[t["date"][:10]].append(t)
        days = sorted(by_day)
        if len(days) < 2:
            continue
        dates = [_parse(d) for d in days]
        amounts = [abs(sum(t["amount"] for t in by_day[d])) for d in days]
        intervals = [(b - a).days for a, b in zip(dates, dates[1:])]
        med = statistics.median(intervals)
        label, nominal = _cadence(med)
        if is_payment and not label and 18 <= med <= 45:
            label, nominal = "monthly", 30.44  # card payments wobble around the due date
        if not label:
            continue
        tol = max(3, 0.2 * nominal)
        regular = sum(1 for i in intervals if abs(i - med) <= tol)
        mean_amt = statistics.mean(amounts)
        cv = statistics.pstdev(amounts) / mean_amt if mean_amt else 1
        category = Counter(t["category"] for t in items).most_common(1)[0][0]
        if not is_payment:
            if len(days) == 2:
                if not (label == "monthly" and cv < 0.03):
                    continue
            elif regular / len(intervals) < 0.66:
                continue
            if category not in categorize.BILL_CATEGORIES and cv > 0.08:
                continue  # irregular amounts in a non-bill category = groceries, gas, etc.
            if label in ("weekly", "every 2 weeks") and category not in categorize.BILL_CATEGORIES and cv > 0.02:
                continue
        if (today - dates[-1]).days > 2 * nominal + 10:
            continue  # stopped happening: probably cancelled
        last_tx = by_day[days[-1]][-1]
        paid_acct = key[4:] if is_payment else None
        lib = liabs.get(paid_acct) if paid_acct else None
        autopay, reason = judge_autopay(items, dates, last_tx.get("account_type"), lib)
        next_date = _predict_next(dates, label, nominal)
        avg = (amounts[-1] if len(amounts) > 1 and abs(amounts[-1] - amounts[-2]) < 0.01
               else statistics.mean(amounts[-3:]))
        if lib and lib.get("next_due_date"):
            next_date = _parse(lib["next_due_date"])  # the bank knows the real due date
            if lib.get("last_statement_balance"):
                avg = lib["last_statement_balance"]
        bid = ("pay:" + paid_acct) if is_payment else "rec:" + hashlib.sha1(key.encode()).hexdigest()[:12]
        found[bid] = {
            "merchant": key,
            "display_name": (f"Payment to {last_tx['paid_acct_name']}" if is_payment
                             else _display_name([t["merchant"] or t["name"] for t in items])),
            "account_id": last_tx["account_id"],
            "pays_account_id": paid_acct,
            "category": category,
            "avg_amount": round(avg, 2),
            "last_amount": round(amounts[-1], 2),
            "cadence_days": nominal,
            "cadence": label,
            "last_date": days[-1],
            "next_date": next_date.isoformat(),
            "occurrences": len(days),
            "autopay": autopay,
            "autopay_reason": reason,
        }

    # Due dates the bank reports for cards/loans we haven't seen payments for (e.g. paid from an unlinked bank)
    paid_accounts = {b["pays_account_id"] for b in found.values() if b["pays_account_id"]}
    for acct_id, lib in liabs.items():
        if acct_id in paid_accounts or not lib.get("next_due_date"):
            continue
        amt = lib["last_statement_balance"] or lib["minimum_payment"] or 0
        if amt <= 0:
            continue
        due = _parse(lib["next_due_date"])
        found["liab:" + acct_id] = {
            "merchant": "liab:" + acct_id,
            "display_name": f"{lib['acct_name']} payment due",
            "account_id": acct_id,
            "pays_account_id": acct_id,
            "category": "Credit Card Payment" if lib["kind"] == "credit" else "Loan Payment",
            "avg_amount": round(amt, 2),
            "last_amount": round(amt, 2),
            "cadence_days": 30.44,
            "cadence": "monthly",
            "last_date": add_months(due, -1).isoformat(),
            "next_date": due.isoformat(),
            "occurrences": None,
            "autopay": "unknown",
            "autopay_reason": "No payments to this account found in your linked banks, so autopay can't be checked.",
        }

    existing = {b["id"]: b for b in db.rows("SELECT * FROM bills")}
    first_run = not existing and not db.get_setting("bills_initialized")
    new_bills, paid_events = [], []
    with db.lock():
        conn = db.get()
        for bid, b in found.items():
            old = existing.get(bid)
            if old is None:
                conn.execute(
                    """INSERT INTO bills(id, merchant, display_name, account_id, category, avg_amount,
                           last_amount, cadence_days, cadence, last_date, next_date, occurrences, autopay,
                           pays_account_id, autopay_reason)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (bid, b["merchant"], b["display_name"], b["account_id"], b["category"], b["avg_amount"],
                     b["last_amount"], b["cadence_days"], b["cadence"], b["last_date"], b["next_date"],
                     b["occurrences"], b["autopay"], b["pays_account_id"], b["autopay_reason"]),
                )
                new_bills.append(dict(b, id=bid, status="active"))
            else:
                if old["last_date"] and b["last_date"] > old["last_date"] and not bid.startswith("liab:"):
                    paid_events.append((dict(old, **b, id=bid), old["avg_amount"]))
                edited = old["user_edited"]
                conn.execute(
                    """UPDATE bills SET display_name=?, account_id=?, category=?, avg_amount=?, last_amount=?,
                           cadence_days=?, cadence=?, last_date=?, next_date=?, occurrences=?, autopay=?,
                           pays_account_id=?, autopay_reason=?, updated_at=datetime('now') WHERE id=?""",
                    (old["display_name"] if edited else b["display_name"], b["account_id"], b["category"],
                     b["avg_amount"], b["last_amount"], b["cadence_days"], b["cadence"], b["last_date"],
                     b["next_date"], b["occurrences"], old["autopay"] if edited else b["autopay"],
                     b["pays_account_id"],
                     "You set this yourself." if edited and old["autopay"] != b["autopay"] else b["autopay_reason"],
                     bid),
                )
        for bid, old in existing.items():
            if bid in found:
                continue
            # Stopped streams disappear, except ones you removed: those are remembered so
            # the same suggestion never comes back.
            if old["status"] == "active":
                conn.execute("DELETE FROM bills WHERE id = ?", (bid,))
        conn.commit()
    db.set_setting("bills_initialized", True)
    return first_run, new_bills, paid_events


def is_stale(b, today=None):
    """Expected charge is well overdue: the bill probably ended (moved out, cancelled)."""
    if not b.get("next_date") or (b.get("id") or "").startswith("liab:"):
        return False
    overdue = ((today or date.today()) - _parse(b["next_date"])).days
    return overdue > max(10, 0.4 * (b.get("cadence_days") or 30))


def list_bills():
    out = db.rows(
        "SELECT b.*, a.name AS account_name, a.mask AS account_mask, a.type AS account_type, "
        "pa.name AS pays_account_name FROM bills b LEFT JOIN accounts a ON a.id = b.account_id "
        "LEFT JOIN accounts pa ON pa.id = b.pays_account_id "
        "ORDER BY (b.status != 'active'), b.next_date"
    )
    for b in out:
        b["stale"] = is_stale(b)
    return out


def monthly_equivalent(b):
    return (b["avg_amount"] or 0) * 30.44 / (b["cadence_days"] or 30.44)
