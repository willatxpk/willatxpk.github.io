"""Builds alerts about bills/autopays and delivers them (in-app, phone push via ntfy, email)."""
import smtplib
import sqlite3
import urllib.request
from collections import defaultdict
from datetime import date, timedelta
from email.message import EmailMessage

from . import bills, config, db


def money(v):
    return f"${abs(v):,.2f}"


def _nice_date(iso, today):
    d = date.fromisoformat(iso)
    delta = (d - today).days
    when = {0: "today", 1: "tomorrow"}.get(delta, f"in {delta} days")
    return f"{d.strftime('%a %b')} {d.day} ({when})"


def _acct_label(account_id):
    a = db.row("SELECT name, mask FROM accounts WHERE id = ?", (account_id,))
    if not a:
        return "your account"
    return f"{a['name']}" + (f" ••{a['mask']}" if a.get("mask") else "")


def add(key, kind, title, body="", severity="info"):
    try:
        db.execute(
            "INSERT INTO alerts(key, kind, severity, title, body) VALUES(?,?,?,?,?)",
            (key, kind, severity, title, body),
        )
        return True
    except sqlite3.IntegrityError:
        return False  # already raised this exact alert


def run_checks(today=None):
    today = today or date.today()
    days_ahead = int(db.get_setting("alert_days_ahead", 3))
    first_run, new_bills, paid_events = bills.detect(today)

    if first_run and new_bills:
        total = sum(bills.monthly_equivalent(b) for b in new_bills)
        auto = sum(1 for b in new_bills if b["autopay"] in ("yes", "likely"))
        add(f"init:{today}", "summary",
            f"Found {len(new_bills)} recurring bills (~{money(total)}/month)",
            f"{auto} look like autopay. Review them on the Bills page and mark any that aren't.")
    elif not first_run:
        for b in new_bills:
            add(f"new:{b['id']}", "new_recurring",
                f"New recurring charge: {b['display_name']} {money(b['avg_amount'])} {b['cadence']}",
                f"Charged to {_acct_label(b['account_id'])}. Next expected {_nice_date(b['next_date'], today)}.",
                "warn")

    for b, prev_avg in paid_events:
        if b.get("status") != "active":
            continue
        add(f"paid:{b['id']}:{b['last_date']}", "paid",
            f"Paid: {b['display_name']} {money(b['last_amount'])}",
            f"{'Autopay' if b['autopay'] in ('yes', 'likely') else 'Payment'} went through on "
            f"{b['last_date']} from {_acct_label(b['account_id'])}.")
        if prev_avg and abs(b["last_amount"] - prev_avg) > max(5, 0.10 * prev_avg) \
                and b["category"] not in ("Utilities", "Credit Card Payment"):
            direction = "went up" if b["last_amount"] > prev_avg else "went down"
            add(f"change:{b['id']}:{b['last_date']}", "amount_change",
                f"{b['display_name']} {direction}: {money(prev_avg)} → {money(b['last_amount'])}",
                "Check whether a price increase or plan change was expected.",
                "warn" if b["last_amount"] > prev_avg else "info")

    active = [b for b in bills.list_bills() if b["status"] == "active"]
    horizon = today + timedelta(days=days_ahead)
    upcoming_by_acct = defaultdict(list)
    for b in active:
        if not b["next_date"]:
            continue
        nd = date.fromisoformat(b["next_date"])
        if today <= nd <= today + timedelta(days=7):
            upcoming_by_acct[b["account_id"]].append(b)
        if today <= nd <= horizon:
            when = _nice_date(b['next_date'], today).split(' (')[1].rstrip(')')
            if b["autopay"] in ("yes", "likely"):
                add(f"upcoming:{b['id']}:{b['next_date']}", "upcoming",
                    f"Autopay {when}: {b['display_name']} ~{money(b['avg_amount'])}",
                    f"Expected {_nice_date(b['next_date'], today)} from {_acct_label(b['account_id'])}.")
            else:
                # Not on autopay (or can't tell): this one needs you to act
                add(f"upcoming:{b['id']}:{b['next_date']}", "due_manual",
                    f"Pay by hand {when}: {b['display_name']} ~{money(b['avg_amount'])}",
                    f"Due {_nice_date(b['next_date'], today)}. "
                    + (b.get("autopay_reason") or "This doesn't look like it's on autopay."), "warn")
        overdue = (today - nd).days
        if 4 <= overdue <= 20 and not b["id"].startswith("liab:") and b["cadence_days"] >= 25:
            add(f"missed:{b['id']}:{b['next_date']}", "missed",
                f"Expected charge didn't show up: {b['display_name']}",
                f"It usually posts around {b['next_date']}. The autopay may have failed, the date moved, "
                "or the subscription was cancelled.", "warn")

    # Will the funding account cover this week's autopays?
    for acct_id, items in upcoming_by_acct.items():
        a = db.row("SELECT * FROM accounts WHERE id = ?", (acct_id,))
        if not a or a["type"] != "depository":
            continue
        due = sum(b["avg_amount"] or 0 for b in items)
        bal = a["available_balance"] if a["available_balance"] is not None else a["current_balance"]
        if due > (bal or 0):
            add(f"lowbal:{acct_id}:{today}", "low_balance",
                f"Low balance: {_acct_label(acct_id)} may not cover upcoming autopays",
                f"{money(due)} due in the next 7 days ({', '.join(b['display_name'] for b in items)}) "
                f"but the balance is {money(bal or 0)}.", "danger")

    deliver_pending()


# ------------------------------------------------------------ delivery ----
def _ascii(s):
    return s.encode("latin-1", "replace").decode("latin-1")


def send_ntfy(url, title, body, severity):
    req = urllib.request.Request(
        url, data=body.encode("utf-8"), method="POST",
        headers={
            "Title": _ascii(title),
            "Priority": {"danger": "high", "warn": "default"}.get(severity, "low"),
            "Tags": {"danger": "warning", "warn": "bell"}.get(severity, "moneybag"),
        },
    )
    urllib.request.urlopen(req, timeout=15).read()


def send_email(cfg, subject, body):
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = cfg["username"]
    msg["To"] = cfg["to"] or cfg["username"]
    msg.set_content(body)
    with smtplib.SMTP(cfg["smtp_host"], int(cfg["smtp_port"]), timeout=20) as s:
        s.starttls()
        s.login(cfg["username"], cfg["password"])
        s.send_message(msg)


def deliver_pending():
    pending = db.rows("SELECT * FROM alerts WHERE delivered = 0 ORDER BY id")
    if not pending:
        return {"sent": 0}
    notify = config.load().get("notify", {})
    min_sev = db.get_setting("push_min_severity", "info")
    rank = {"info": 0, "warn": 1, "danger": 2}
    to_send = [a for a in pending if rank[a["severity"]] >= rank.get(min_sev, 0)]
    errors = []
    if to_send and notify.get("ntfy_url"):
        for a in to_send:
            try:
                send_ntfy(notify["ntfy_url"], a["title"], a["body"] or "", a["severity"])
            except Exception as e:  # noqa: BLE001 - delivery is best effort
                errors.append(f"ntfy: {e}")
                break
    em = notify.get("email", {})
    if to_send and em.get("enabled"):
        body = "\n\n".join(f"• {a['title']}\n  {a['body'] or ''}" for a in to_send)
        try:
            send_email(em, f"Kerdos: {len(to_send)} alert(s)", body)
        except Exception as e:  # noqa: BLE001
            errors.append(f"email: {e}")
    # Mark delivered either way, so configuring push later doesn't replay a backlog.
    db.execute("UPDATE alerts SET delivered = 1 WHERE delivered = 0")
    if errors:
        db.set_setting("last_delivery_error", errors[0])
    return {"sent": len(to_send), "errors": errors}
