"""Estimated income tax for the year: federal, Social Security and Medicare, and state.

Everything is worked out from what you type in (it is prefilled from your Investing Plan profile). The
rate tables live in tax_data_2026.json next to this file: federal figures from the IRS inflation
adjustments, state figures from the Tax Foundation's yearly table. Replace that file each year.

This is an estimate for planning, not a tax return. It covers wages, other ordinary income and long-term
gains, the standard or itemized deduction, the child tax credit, and each state's brackets, standard
deduction and personal exemptions. It leaves out the alternative minimum tax, the net investment income
tax, self-employment tax, most credits, city and county income taxes, and state payroll taxes.
"""
import json
import os

from . import db, planner

STATUSES = {"single": "Single", "mfj": "Married filing jointly", "mfs": "Married filing separately",
            "hoh": "Head of household"}
DEFAULTS = {"filing_status": "single", "state": "", "wages": 0.0, "wages2": 0.0, "other_income": 0.0, "ltcg": 0.0,
            "pretax_401k": 0.0, "hsa": 0.0, "other_adjust": 0.0, "itemized": 0.0, "children": 0, "fica": True,
            "fed_withheld": 0.0, "state_withheld": 0.0}
_DATA = None


def data():
    global _DATA
    if _DATA is None:
        with open(os.path.join(os.path.dirname(__file__), "tax_data_2026.json"), encoding="utf-8") as f:
            _DATA = json.load(f)
    return _DATA


def get_inputs():
    saved = db.get_setting("tax_inputs")
    inp = dict(DEFAULTS)
    if saved:
        inp.update({k: v for k, v in saved.items() if k in DEFAULTS})
        return inp
    p = planner.get_profile()   # first visit: start from what the Investing Plan already knows
    inp["filing_status"] = p.get("filing_status") if p.get("filing_status") in STATUSES else "single"
    inp["wages"] = float(p.get("annual_income") or 0)
    inp["pretax_401k"] = round(min(planner.LIMITS["k401"], inp["wages"] * float(p.get("current_401k_pct") or 0) / 100), 2)
    inp["hsa"] = float(p.get("hsa_ytd") or 0) if p.get("hsa_eligible") else 0.0
    return inp


def save_inputs(body):
    inp = get_inputs()
    for k, default in DEFAULTS.items():
        if k not in body:
            continue
        v = body[k]
        if k == "filing_status":
            if v in STATUSES:
                inp[k] = v
        elif k == "state":
            v = (v or "").upper()
            if v == "" or v in data()["states"]:
                inp[k] = v
        elif isinstance(default, bool):
            inp[k] = bool(v)
        else:
            try:
                num = float(v or 0)
            except (TypeError, ValueError):
                raise ValueError("Enter numbers only")
            if not 0 <= num <= 1e9:
                raise ValueError("Amounts must be zero or more")
            inp[k] = int(min(num, 20)) if k == "children" else round(num, 2)
    db.set_setting("tax_inputs", inp)
    return inp


def _stack(amount, brackets):
    """Tax on `amount` through brackets given as [(rate, lower, upper_or_None)]. Returns (tax, rows, top rate)."""
    tax, rows, top = 0.0, [], brackets[0][0] if brackets else 0.0
    for rate, lo, hi in brackets:
        if amount <= lo:
            break
        part = min(amount, hi) - lo if hi is not None else amount - lo
        tax += part * rate
        top = rate
        rows.append({"rate": round(rate * 100, 3), "from": lo, "to": hi, "amount": round(part, 2), "tax": round(part * rate, 2)})
    return tax, rows, top


def _federal_brackets(status):
    out, lo = [], 0.0
    for rate, hi in data()["federal"]["brackets"][status]:
        out.append((rate, lo, hi))
        lo = hi or lo
    return out


def _state_brackets(st, status):
    table = st.get("married" if status == "mfj" else "single") or st.get("single") or []
    return [(rate / 100.0, lo, table[i + 1][1] if i + 1 < len(table) else None) for i, (rate, lo) in enumerate(table)]


def estimate(inp=None):
    inp = inp or get_inputs()
    d, fed = data(), data()["federal"]
    status = inp["filing_status"]
    wages = inp["wages"] + (inp["wages2"] if status == "mfj" else 0.0)
    gross = wages + inp["other_income"] + inp["ltcg"]
    adjustments = min(inp["pretax_401k"] + inp["hsa"] + inp["other_adjust"], max(0.0, gross))
    agi = max(0.0, gross - adjustments)

    # ---- federal income tax
    std = fed["standard_deduction"][status]
    deduction = max(std, inp["itemized"])
    taxable = max(0.0, agi - deduction)
    gains = min(inp["ltcg"], taxable)                 # long-term gains sit on top of ordinary income
    ordinary = taxable - gains
    ord_tax, rows, marginal = _stack(ordinary, _federal_brackets(status))
    lt = fed["ltcg"][status]
    in_zero = max(0.0, min(taxable, lt["zero_to"]) - ordinary)
    in_fifteen = max(0.0, min(taxable, lt["fifteen_to"]) - max(ordinary, lt["zero_to"]))
    in_twenty = max(0.0, gains - in_zero - in_fifteen)
    gain_rows = [{"rate": r, "amount": round(a, 2), "tax": round(a * r / 100, 2)}
                 for r, a in ((0, in_zero), (15, in_fifteen), (20, in_twenty)) if a > 0]
    gain_tax = in_fifteen * 0.15 + in_twenty * 0.20
    ctc = fed["child_tax_credit"]
    over = max(0.0, agi - (ctc["phaseout_mfj"] if status == "mfj" else ctc["phaseout_single"]))
    credit = max(0.0, inp["children"] * ctc["per_child"] - 50 * -(-over // 1000))
    credit = min(credit, ord_tax + gain_tax)          # counted only up to the tax it can offset
    fed_tax = ord_tax + gain_tax - credit

    # ---- Social Security and Medicare (on wages; pre-tax 401(k) money is still counted)
    fica = {"ss": 0.0, "medicare": 0.0, "addl": 0.0}
    if inp["fica"]:
        earners = [inp["wages"]] + ([inp["wages2"]] if status == "mfj" else [])
        fica["ss"] = sum(min(w, fed["ss_wage_base"]) for w in earners) * fed["ss_rate"]
        fica["medicare"] = wages * fed["medicare_rate"]
        fica["addl"] = max(0.0, wages - fed["addl_medicare"][status]) * fed["addl_medicare"]["rate"]
    fica_total = sum(fica.values())

    # ---- state income tax
    state, state_tax, state_marginal = None, 0.0, 0.0
    st = d["states"].get(inp["state"])
    if st:
        married = status == "mfj"
        s_std = (st.get("std_married") if married else st.get("std_single")) or 0.0
        exempt = ((st.get("exempt_married") if married else st.get("exempt_single")) or 0.0) \
            + (st.get("exempt_dependent") or 0.0) * inp["children"]
        as_credit = bool(st.get("exempt_is_credit"))
        s_taxable = max(0.0, agi - s_std - (0.0 if as_credit else exempt))
        s_tax, s_rows, state_marginal = _stack(s_taxable, _state_brackets(st, status))
        s_credit = min(exempt, s_tax) if as_credit else 0.0
        state_tax = s_tax - s_credit
        if st.get("kind") == "none":
            state_marginal = 0.0
        state = {"code": inp["state"], "name": st["name"], "kind": st.get("kind"), "deduction": round(s_std, 2),
                 "exemption": round(exempt, 2), "exemption_is_credit": as_credit, "credit": round(s_credit, 2),
                 "taxable": round(s_taxable, 2), "before_credits": round(s_tax, 2), "tax": round(state_tax, 2),
                 "marginal": round(state_marginal * 100, 2), "rows": s_rows, "notes": st.get("notes") or ""}

    total = fed_tax + fica_total + state_tax
    saved = inp["pretax_401k"] + inp["hsa"]
    take_home = gross - total - saved
    fica_marginal = 0.0
    if inp["fica"]:
        fica_marginal = fed["medicare_rate"] + (fed["ss_rate"] if inp["wages"] < fed["ss_wage_base"] else 0.0) \
            + (fed["addl_medicare"]["rate"] if wages > fed["addl_medicare"][status] else 0.0)
    income_marginal = (marginal if ordinary > 0 else 0.0) + state_marginal
    return {
        "inputs": inp, "year": fed["year"], "states_year": d.get("states_year"),
        "statuses": [{"key": k, "label": v} for k, v in STATUSES.items()],
        "states": sorted(({"code": c, "name": s["name"]} for c, s in d["states"].items()), key=lambda s: s["name"]),
        "income": {"wages": round(wages, 2), "gross": round(gross, 2), "adjustments": round(adjustments, 2), "agi": round(agi, 2)},
        "federal": {"standard_deduction": std, "deduction": round(deduction, 2),
                    "deduction_kind": "itemized" if inp["itemized"] > std else "standard",
                    "taxable": round(taxable, 2), "ordinary_taxable": round(ordinary, 2), "ordinary_tax": round(ord_tax, 2),
                    "gains_tax": round(gain_tax, 2), "gain_rows": gain_rows, "credit": round(credit, 2),
                    "tax": round(fed_tax, 2), "marginal": round(marginal * 100, 1) if ordinary > 0 else 0, "rows": rows},
        "fica": {k: round(v, 2) for k, v in fica.items()} | {"total": round(fica_total, 2)},
        "state": state,
        "total_tax": round(total, 2), "pretax_savings": round(saved, 2),
        "effective": round(total / gross * 100, 1) if gross else 0,
        "take_home": {"year": round(take_home, 2), "month": round(take_home / 12, 2), "biweekly": round(take_home / 26, 2)},
        "withholding": {
            "federal": round(inp["fed_withheld"] - fed_tax, 2) if inp["fed_withheld"] else None,   # positive = refund
            "state": round(inp["state_withheld"] - state_tax, 2) if inp["state_withheld"] and state else None},
        "next_1000": {"tax": round(1000 * (income_marginal + fica_marginal), 2),
                      "keep": round(1000 * (1 - income_marginal - fica_marginal), 2),
                      "saved_by_401k": round(1000 * income_marginal, 2)},
        "sources": {"federal": fed.get("sources") or [], "states": d.get("states_source")},
    }
