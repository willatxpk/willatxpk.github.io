"""Your own investing rules, checked against what you hold, plus a stress test and your notes on each holding.

The app does not decide what you should own. You set the rules (the starting numbers are widely published
rules of thumb, there so you have something to edit, not written for you). Each day the app measures your
holdings against them and does the arithmetic of what it would take to be back inside a rule. Whether to
act, and how, stays with you.
"""
from datetime import date

from . import db, investments

RULES = [
    {"key": "single_max", "text": "No single company is more than {v}% of my investments", "unit": "%", "default": 10,
     "min": 1, "max": 100, "starter": True,
     "about": "A common rule of thumb keeps any one company to somewhere between 5% and 10%."},
    {"key": "singles_total_max", "text": "Individual stocks together are no more than {v}% of my investments", "unit": "%",
     "default": 25, "min": 1, "max": 100, "starter": False,
     "about": "The 'core and satellite' idea: broad funds as the core, hand-picked stocks as a smaller part."},
    {"key": "drift_band", "text": "Rebalance when any part of my mix is more than {v} points off my target", "unit": "pts",
     "default": 5, "min": 1, "max": 50, "starter": True,
     "about": "A 5-point band is the most widely used trigger. Your target comes from the Investing Plan page."},
    {"key": "risky_max", "text": "No more than {v}% of my money in holdings tagged High or Very high risk", "unit": "%",
     "default": 30, "min": 1, "max": 100, "starter": False,
     "about": "There is no standard number here: it depends on how much of a swing you can sit through."},
    {"key": "fee_max", "text": "Flag any fund that charges more than {v}% a year", "unit": "%", "default": 0.25,
     "min": 0, "max": 5, "starter": True,
     "about": "Broad index funds usually charge well under 0.2% a year; fees come straight out of returns."},
    {"key": "cash_max", "text": "No more than {v}% sitting as cash in my investment accounts", "unit": "%", "default": 5,
     "min": 0, "max": 100, "starter": True,
     "about": "Cash in a brokerage account is often money that was deposited but never invested."},
    {"key": "review_drop", "text": "Review a holding when it is {v}% or more below its one-year high", "unit": "%",
     "default": 20, "min": 1, "max": 95, "starter": True,
     "about": "A fall of 20% is the usual definition of a bear market. 'Review' means re-read why you own it."},
    {"key": "review_gain", "text": "Review a holding when it is worth {v}% or more above what I paid", "unit": "%",
     "default": 100, "min": 1, "max": 5000, "starter": False,
     "about": "A big winner can quietly become a much larger share of your money than you planned."},
]
# Rough calendar-year results of broad indexes (US stocks, international stocks, US bonds, cash)
SCENARIOS = [
    ("drop20", "Stocks fall 20%", "Every stock holding falls 20%; bonds and cash stay flat.",
     {"us_stocks": -20, "intl_stocks": -20, "bonds": 0, "cash": 0, "crypto": -40}),
    ("y2022", "A year like 2022", "Stocks and bonds fell together: US stocks about -18%, international -16%, bonds -13%.",
     {"us_stocks": -18, "intl_stocks": -16, "bonds": -13, "cash": 1.5, "crypto": -60}),
    ("y2008", "A year like 2008", "The financial crisis: US stocks about -37%, international -43%, bonds +5%.",
     {"us_stocks": -37, "intl_stocks": -43, "bonds": 5, "cash": 1.5, "crypto": -70}),
    ("drop50", "Stocks fall by half", "Roughly the worst peak-to-bottom falls of 2000-02 and 2007-09; bonds and cash flat.",
     {"us_stocks": -50, "intl_stocks": -50, "bonds": 0, "cash": 0, "crypto": -80}),
]
CLASS_NAME = {"us_stocks": "US stocks", "intl_stocks": "International stocks", "bonds": "Bonds", "cash": "Cash", "crypto": "Crypto"}


def _money(v):
    return f"${abs(v):,.0f}"


def _lower(name):
    return name if name.startswith("US") else name.lower()


def _pct(v):
    return f"{v:.1f}".rstrip("0").rstrip(".") + "%"


def get():
    saved = db.get_setting("invest_rules", {}) or {}
    mine = saved.get("rules") or {}
    out = []
    for r in RULES:
        m = mine.get(r["key"]) or {}
        out.append({**r, "value": m.get("value", r["default"]), "on": bool(m.get("on", r["starter"]))})
    return {"adopted": bool(saved.get("adopted")), "rules": out}


def save(body):
    saved = db.get_setting("invest_rules", {}) or {}
    mine = saved.get("rules") or {}
    known = {r["key"]: r for r in RULES}
    for key, val in (body.get("rules") or {}).items():
        r = known.get(key)
        if not r or not isinstance(val, dict):
            continue
        try:
            num = float(val.get("value", r["default"]))
        except (TypeError, ValueError):
            raise ValueError("Enter a number for each rule")
        if not r["min"] <= num <= r["max"]:
            raise ValueError(f"“{r['text'].replace('{v}', '…')}” needs a number between {r['min']:g} and {r['max']:g}")
        mine[key] = {"on": bool(val.get("on")), "value": round(num, 2)}
    saved["rules"] = mine
    if body.get("adopt") or body.get("rules"):
        saved["adopted"] = True          # from here on these are your rules, not the starting suggestions
    if body.get("reset"):
        saved = {}
    db.set_setting("invest_rules", saved)
    return get()


def _positions(s, ins):
    """Holdings merged by ticker, with the risk tag and price facts worked out for the briefing."""
    out = {}
    for h in s["holdings"]:
        x = ins["holdings"].get(f"{h['account_id']}|{h['security_id']}") or {}
        t = (h.get("ticker") or "").upper()
        e = out.setdefault(t or h.get("name") or h["security_id"], {
            "ticker": t if t and h["asset_class"] != "cash" else None, "label": t or (h.get("name") or "Holding")[:26],
            "name": h.get("name") or t, "value": 0.0, "cost": 0.0, "cost_known": True, "cls": h["asset_class"],
            "risk": x.get("risk") or {}, "stats": x.get("stats") or {}, "er": h.get("expense_ratio"),
            "fund": (h.get("type") or "").lower() in ("etf", "mutual fund", "fund")})
        e["value"] += h["value"] or 0
        if h.get("cost_basis"):
            e["cost"] += h["cost_basis"]
        else:
            e["cost_known"] = False
    for e in out.values():
        e["single"] = "One company" in (e["risk"].get("why") or "")
    return sorted(out.values(), key=lambda e: -e["value"])


def check(today=None):
    """Measure today's holdings against the rules that are switched on. Returns the rules, one result per
    active rule, and the stress test."""
    cfg = get()
    s = investments.summary()
    total = s["total"] or 0
    if not total:
        return {**cfg, "results": [], "stress": [], "total": 0, "date": (today or date.today()).isoformat()}
    ins = investments.insights(today)
    pos = _positions(s, ins)
    share = lambda v: v / total * 100  # noqa: E731
    try:
        monthly = investments.buy_plan(today, with_prices=False)["amount"]
    except Exception:  # noqa: BLE001
        monthly = 0
    results = []

    def add(rule, status, headline, lines=(), items=()):
        results.append({"key": rule["key"], "rule": rule["text"].replace("{v}", f"{rule['value']:g}"), "status": status,
                        "headline": headline, "lines": list(lines), "items": list(items)})

    def by_new_money(amount):
        if not monthly:
            return f" With new money only, that is about {_money(amount)}."
        months = max(1, round(amount / monthly))
        span = f"{months} month{'s' if months != 1 else ''}" if months <= 24 else f"about {months / 12:.0f} years"
        return f" With new money only, that is about {_money(amount)}, or {span} at your {_money(monthly)} a month."

    for r in cfg["rules"]:
        if not r["on"]:
            continue
        v, k = r["value"], r["key"]
        if k == "single_max":
            singles = [e for e in pos if e["single"]]
            over = [e for e in singles if share(e["value"]) > v]
            if not singles:
                add(r, "ok", "You hold no individual companies, only funds.")
            elif not over:
                add(r, "ok", f"Inside your rule. Your largest single company is {singles[0]['label']} at {_pct(share(singles[0]['value']))}.")
            else:
                items = []
                for e in over:
                    move = e["value"] - v / 100 * total            # moved into other holdings, total unchanged
                    grow = e["value"] / (v / 100) - total          # new money added elsewhere
                    items.append({"ticker": e["ticker"], "label": e["label"],
                                  "text": f"{_pct(share(e['value']))} of your investments, {_money(move)} over your {v:g}% line. "
                                          f"Moving {_money(move)} from it into your other holdings would put it at {v:g}%."
                                          + by_new_money(grow)})
                add(r, "breach", f"{len(over)} compan{'ies are' if len(over) != 1 else 'y is'} over your {v:g}% line.", items=items)
        elif k == "singles_total_max":
            amt = sum(e["value"] for e in pos if e["single"])
            if share(amt) <= v:
                add(r, "ok", f"Inside your rule. Individual stocks are {_pct(share(amt))} of your investments.")
            else:
                move = amt - v / 100 * total
                add(r, "breach", f"Individual stocks are {_pct(share(amt))} of your investments, over your {v:g}% line.",
                    [f"That is {_money(move)} above the line. Moving {_money(move)} from individual stocks into funds would put them at {v:g}%."
                     + by_new_money(amt / (v / 100) - total)],
                    [{"ticker": e["ticker"], "label": e["label"], "text": f"{_money(e['value'])}, {_pct(share(e['value']))}"} for e in pos if e["single"]][:6])
        elif k == "drift_band":
            off = sorted(((c, d) for c, d in s["drift"].items() if abs(d) > v), key=lambda cd: -abs(cd[1]))
            if not off:
                worst = max(s["drift"].items(), key=lambda cd: abs(cd[1]))
                add(r, "ok", f"Inside your band. The furthest from target is {CLASS_NAME.get(worst[0], worst[0])}, {abs(worst[1]):g} points {'over' if worst[1] > 0 else 'under'}.")
            else:
                lines = []
                for c, d in off:
                    lines.append(f"{CLASS_NAME.get(c, c)}: {s['actual'][c]:g}% now against a target of {s['target'][c]:g}% "
                                 f"({abs(d):g} points {'over' if d > 0 else 'under'}, which is {_money(abs(d) / 100 * total)}).")
                highs = [(c, d) for c, d in off if d > 0 and s["target"][c] > 0]
                if highs:
                    c, d = highs[0]
                    need = s["mix_dollars"][c] / (s["target"][c] / 100) - total
                    lines.append(f"Matching your target exactly means moving {_money(d / 100 * total)} out of {_lower(CLASS_NAME.get(c, c))} into the parts that are under."
                                 + by_new_money(need) + " Selling in a taxable account can create a tax bill; inside an IRA or 401(k) it does not.")
                add(r, "breach", f"{len(off)} part{'s' if len(off) != 1 else ''} of your mix {'are' if len(off) != 1 else 'is'} outside your {v:g}-point band.", lines)
        elif k == "risky_max":
            amt = ins["risk_mix"].get("high", 0) + ins["risk_mix"].get("very_high", 0)
            if share(amt) <= v:
                add(r, "ok", f"Inside your rule. {_pct(share(amt))} of your money is in High or Very high risk holdings.")
            else:
                add(r, "breach", f"{_pct(share(amt))} of your money is in High or Very high risk holdings, over your {v:g}% line.",
                    [f"That is {_money(amt - v / 100 * total)} above the line."],
                    [{"ticker": e["ticker"], "label": e["label"], "text": f"{e['risk'].get('label')} risk · {_money(e['value'])}"}
                     for e in pos if e["risk"].get("rank", 0) >= 3][:6])
        elif k == "fee_max":
            pricey = [e for e in pos if e["er"] is not None and e["er"] > v]
            unknown = [e for e in pos if e["fund"] and e["er"] is None]
            if not pricey:
                add(r, "ok", "No fund you hold charges more than your ceiling."
                    + (f" The fee isn't known for {len(unknown)} fund{'s' if len(unknown) != 1 else ''}, so check {'those' if len(unknown) != 1 else 'that one'} yourself." if unknown else ""))
            else:
                add(r, "breach", f"{len(pricey)} fund{'s charge' if len(pricey) != 1 else ' charges'} more than {v:g}% a year.", items=[
                    {"ticker": e["ticker"], "label": e["label"],
                     "text": f"{e['er']:g}% a year, about {_money(e['value'] * e['er'] / 100)} a year on your {_money(e['value'])}. "
                             f"At {v:g}% the same balance would cost {_money(e['value'] * v / 100)}."} for e in pricey])
        elif k == "cash_max":
            amt = s["mix_dollars"].get("cash", 0)
            if share(amt) <= v:
                add(r, "ok", f"Inside your rule. Cash is {_pct(share(amt))} of your investment accounts.")
            else:
                add(r, "breach", f"Cash is {_pct(share(amt))} of your investment accounts, over your {v:g}% line.",
                    [f"{_money(amt)} is sitting as cash; {_money(amt - v / 100 * total)} of it is above your line."])
        elif k == "review_drop":
            hit = [e for e in pos if e["stats"].get("from_high") is not None and e["stats"]["from_high"] <= -v]
            if not hit:
                add(r, "ok", f"Nothing you hold is {v:g}% or more below its one-year high.")
            else:
                add(r, "review", f"{len(hit)} holding{'s are' if len(hit) != 1 else ' is'} {v:g}% or more below {'their' if len(hit) != 1 else 'its'} one-year high.", items=[
                    {"ticker": e["ticker"], "label": e["label"], "note": True,
                     "text": f"{abs(e['stats']['from_high']):.0f}% below its one-year high of ${e['stats']['high52']:,.2f}."} for e in hit])
        elif k == "review_gain":
            hit = [e for e in pos if e["cost_known"] and e["cost"] > 0 and (e["value"] - e["cost"]) / e["cost"] * 100 >= v]
            if not hit:
                add(r, "ok", f"Nothing you hold is {v:g}% or more above what you paid.")
            else:
                add(r, "review", f"{len(hit)} holding{'s are' if len(hit) != 1 else ' is'} {v:g}% or more above what you paid.", items=[
                    {"ticker": e["ticker"], "label": e["label"], "note": True,
                     "text": f"Worth {_money(e['value'])} against {_money(e['cost'])} paid (up {(e['value'] - e['cost']) / e['cost'] * 100:.0f}%); now {_pct(share(e['value']))} of your investments."}
                    for e in hit])
    notes = db.get_setting("holding_notes", {}) or {}
    for res in results:
        for it in res["items"]:
            n = notes.get(it.get("ticker") or "")
            if it.pop("note", False) and n and (n.get("exit") or n.get("why")):
                it["your_note"] = n.get("exit") or n.get("why")

    stress = []
    mix = s["mix_dollars"]
    for key, label, about, moves in SCENARIOS:
        change = sum(mix.get(c, 0) * p / 100 for c, p in moves.items())
        stress.append({"key": key, "label": label, "about": about, "change": round(change, 2),
                       "pct": round(change / total * 100, 1), "after": round(total + change, 2),
                       "rows": [{"name": CLASS_NAME[c], "move": p, "change": round(mix.get(c, 0) * p / 100, 2)}
                                for c, p in moves.items() if mix.get(c, 0) > 0.5]})
    singles = [e for e in pos if e["single"]]
    if singles:
        e = singles[0]
        stress.append({"key": "single", "label": f"{e['label']} falls by half", "ticker": e["ticker"],
                       "about": f"Your largest single company loses half its value and nothing else moves.",
                       "change": round(-e["value"] / 2, 2), "pct": round(-e["value"] / 2 / total * 100, 1),
                       "after": round(total - e["value"] / 2, 2), "rows": []})
    return {**cfg, "results": results, "stress": stress, "total": round(total, 2),
            "date": (today or date.today()).isoformat(),
            "note": "These are your rules and plain arithmetic on what you hold. Nothing here says what you should do: "
                    "whether to act on a rule, and how, is your call. The stress test is an illustration, not a forecast."}


def get_note(ticker):
    return (db.get_setting("holding_notes", {}) or {}).get((ticker or "").upper()) or {}


def save_note(ticker, body):
    from . import prices
    t = (ticker or "").upper().strip()
    if not prices.SYMBOL.match(t):
        raise ValueError("That doesn't look like a ticker symbol")
    notes = db.get_setting("holding_notes", {}) or {}
    why, exit_ = str(body.get("why") or "").strip()[:600], str(body.get("exit") or "").strip()[:600]
    if why or exit_:
        notes[t] = {"why": why, "exit": exit_, "updated": date.today().isoformat()}
    else:
        notes.pop(t, None)
    db.set_setting("holding_notes", notes)
    return notes.get(t) or {}
