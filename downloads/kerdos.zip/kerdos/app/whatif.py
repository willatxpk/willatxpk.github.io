"""What-if simulator: try a decision before you make it.

You stack changes (a raise, a car, a cheaper apartment, more into your 401k, a big purchase,
cutting a category) and the app runs your net-worth projection twice, with and without them,
using your real last-12-months income and spending as the starting point.
"""
from . import db, insights, planner

KINDS = ("raise", "spending", "rent", "car", "k401", "invest", "purchase", "cut")


def loan_payment(principal, apr, years):
    n = max(1, round(years * 12))
    r = apr / 100 / 12
    if principal <= 0:
        return 0.0
    return principal / n if r == 0 else principal * r / (1 - (1 + r) ** -n)


def _num(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def to_changes(items):
    """Turn the friendly cards from the page into projection changes."""
    prof = planner.get_profile()
    rate = planner.marginal_rate(_num(prof.get("annual_income")), prof.get("filing_status", "single")) \
        if _num(prof.get("annual_income")) else 0.22
    out, notes = [], []
    for it in items:
        k = it.get("kind")
        start = max(0, int(_num(it.get("start_months"))))
        if k == "raise":
            yearly = _num(it.get("amount"))
            take_home = yearly * (1 - rate - 0.0765) / 12  # federal bracket + Social Security/Medicare
            out.append({"kind": "income", "monthly": take_home, "start": start})
            notes.append(f"A ${yearly:,.0f}/yr raise is about ${take_home:,.0f}/month after taxes "
                         f"(using your {rate * 100:.0f}% bracket; state tax not included).")
        elif k in ("spending", "rent"):
            out.append({"kind": "spending", "monthly": _num(it.get("amount")), "start": start})
        elif k == "cut":
            out.append({"kind": "spending", "monthly": -abs(_num(it.get("amount"))), "start": start})
        elif k == "car":
            price, down = _num(it.get("price")), _num(it.get("down"))
            apr, years = _num(it.get("apr"), 7), _num(it.get("years"), 5)
            pay = loan_payment(price - down, apr, years)
            out.append({"kind": "loan", "price": price, "down": down, "apr": apr, "payment": pay,
                        "depreciation": 0.15, "start": start})
            if _num(it.get("running")):
                out.append({"kind": "spending", "monthly": _num(it.get("running")), "start": start})
            notes.append(f"Car loan: ${pay:,.0f}/month for {years:g} years; total interest about "
                         f"${pay * years * 12 - (price - down):,.0f}. The car is counted as an asset losing ~15%/yr.")
        elif k == "k401":
            monthly = _num(it.get("amount"))
            out.append({"kind": "pretax401k", "monthly": monthly, "tax_rate": rate, "start": start})
            notes.append(f"${monthly:,.0f}/month more into a 401(k) only lowers your take-home by about "
                         f"${monthly * (1 - rate):,.0f}, because it's taken out before taxes.")
        elif k == "invest":
            out.append({"kind": "invest", "monthly": _num(it.get("amount")), "start": start})
        elif k == "purchase":
            out.append({"kind": "one_time", "amount": _num(it.get("amount")), "start": start})
    return out, notes


def _at(points, month):
    best = min(points, key=lambda p: abs(p["month"] - month))
    return best["net"]


def run(items, years=10, today=None):
    years = max(1, min(40, int(_num(years, 10))))
    changes, notes = to_changes(items or [])
    base = insights.projection(years=years, today=today)
    scen = insights.projection(years=years, today=today, changes=changes)
    marks = [m for m in (12, 60, 120, 240, 360) if m <= years * 12] or [years * 12]
    if years * 12 not in marks:
        marks.append(years * 12)

    def rate(f):
        return round((f["income"] - f["spending"]) / f["income"], 4) if f.get("income") else None

    bf, sf = base["first_year"], scen["first_year"]
    spend_m = sf.get("spending") or 0
    cash_now = base["points"][0]["cash"]
    return {
        "years": years, "notes": notes, "changes": changes,
        "baseline": {"points": base["points"], "flow": bf, "save_rate": rate(bf),
                     "debt_free_months": base["debt_free_months"], "milestones": base["milestones"]},
        "scenario": {"points": scen["points"], "flow": sf, "save_rate": rate(sf),
                     "debt_free_months": scen["debt_free_months"], "milestones": scen["milestones"]},
        "at": [{"months": m, "baseline": _at(base["points"], m), "scenario": _at(scen["points"], m),
                "difference": _at(scen["points"], m) - _at(base["points"], m)} for m in marks],
        "leftover_change": round((sf.get("leftover") or 0) - (bf.get("leftover") or 0), 2),
        "emergency_months": round(cash_now / spend_m, 1) if spend_m else None,
        "assumptions": base["assumptions"],
        "negative_leftover": (sf.get("leftover") or 0) < 0,
    }


def saved():
    return db.get_setting("whatif_saved", []) or []


def save(name, items):
    name = (name or "").strip()[:60] or "My scenario"
    lst = [s for s in saved() if s["name"] != name] + [{"name": name, "items": items}]
    db.set_setting("whatif_saved", lst[-12:])
    return lst


def delete(name):
    db.set_setting("whatif_saved", [s for s in saved() if s["name"] != name])
