"""Investment holdings from Plaid (Investments product): what you own, your real stock/bond mix
vs the plan's target, estimated yearly fund fees, and exact IRA contributions.

Plaid's Investments product has to be enabled for your Plaid account (dashboard.plaid.com) and
each brokerage connection has to grant it once (the app asks, through Plaid's own window).
"""
import math
import re
import statistics
from datetime import date, timedelta

from . import config, db, planner
from .plaid import PlaidError, _call

SCHEMA = """
CREATE TABLE IF NOT EXISTS holdings (
    account_id TEXT, security_id TEXT, name TEXT, ticker TEXT, type TEXT, quantity REAL,
    value REAL, cost_basis REAL, asset_class TEXT, updated_at TEXT,
    PRIMARY KEY (account_id, security_id)
);
CREATE TABLE IF NOT EXISTS inv_transactions (
    id TEXT PRIMARY KEY, account_id TEXT, date TEXT, name TEXT, amount REAL, quantity REAL,
    type TEXT, subtype TEXT, security_id TEXT
);
CREATE TABLE IF NOT EXISTS securities (
    security_id TEXT PRIMARY KEY, ticker TEXT, name TEXT, type TEXT
);
"""

# Expense ratios (% per year) for widely held index funds/ETFs. Approximate: check your fund's page.
EXPENSE_RATIOS = {
    "VTI": .03, "VTSAX": .04, "VOO": .03, "VFIAX": .04, "VXUS": .05, "VTIAX": .09, "BND": .03, "BNDX": .07,
    "VBTLX": .04, "VT": .06, "VTWAX": .10, "VUG": .04, "VTV": .04, "VB": .05, "VO": .04, "VEA": .05, "VWO": .07,
    "VGT": .10, "VNQ": .13, "VIG": .05, "VYM": .06, "SCHB": .03, "SCHX": .03, "SCHD": .06, "SCHF": .06,
    "SPY": .0945, "IVV": .03, "ITOT": .03, "IXUS": .07, "AGG": .03, "QQQ": .20, "QQQM": .15, "SPLG": .02,
    "FXAIX": .015, "FZROX": 0.0, "FZILX": 0.0, "FSKAX": .015, "FTIHX": .06, "SWTSX": .03, "SWPPX": .02,
    "VFFVX": .08, "VTTSX": .08, "VFIFX": .08, "VTHRX": .08, "VTIVX": .08, "VLXVX": .08, "VSVNX": .08,
}


def _init():
    db.get().executescript(SCHEMA)


def classify(name, ticker, typ):
    n = f"{name or ''} {ticker or ''}".lower()
    if typ == "cash" or re.search(r"money market|cash|settlement|sweep|vmfxx|spaxx|swvxx", n):
        return "cash"
    if typ == "cryptocurrency" or re.search(r"bitcoin|ethereum|crypto|\bbtc\b|\beth\b", n):
        return "crypto"
    if re.search(r"target (retirement|date)|\b20[2-7]\d fund|lifecycle|freedom index 20", n):
        return "target_date"
    if typ == "fixed income" or re.search(r"bond|treasury|income fund|tips|aggregate|fixed", n):
        return "bonds"
    if re.search(r"international|intl|ex-us|ex us|developed|emerging|world ex|foreign|europe|pacific|vxus|ixus|vea|vwo", n):
        return "intl_stocks"
    return "us_stocks"


def _target_date_split(name):
    """Rough glide path for target-date funds: % stocks by years until the fund's target year."""
    m = re.search(r"(20[2-7]\d)", name or "")
    years = int(m.group(1)) - date.today().year if m else 25
    stocks = max(30, min(90, 50 + years * 1.6))
    return stocks / 100


def _remember(conn, securities):
    """Keep ticker and name for every security seen, so positions you've since sold can still be priced."""
    for s in securities or []:
        conn.execute("INSERT OR REPLACE INTO securities VALUES(?,?,?,?)",
                     (s["security_id"], s.get("ticker_symbol"), s.get("name"), s.get("type")))


def sync(item_id, token):
    """Pull holdings and the last 2 years of investment transactions for one connection."""
    _init()
    res = _call("/investments/holdings/get", {"access_token": token})
    secs = {s["security_id"]: s for s in res.get("securities", [])}
    now = date.today().isoformat()
    with db.lock():
        conn = db.get()
        accts = [a["account_id"] for a in res.get("accounts", [])]
        _remember(conn, res.get("securities"))
        for a in accts:
            conn.execute("DELETE FROM holdings WHERE account_id = ?", (a,))
        for h in res.get("holdings", []):
            s = secs.get(h["security_id"], {})
            conn.execute(
                "INSERT OR REPLACE INTO holdings VALUES(?,?,?,?,?,?,?,?,?,?)",
                (h["account_id"], h["security_id"], s.get("name"), s.get("ticker_symbol"), s.get("type"),
                 h.get("quantity"), h.get("institution_value"), h.get("cost_basis"),
                 classify(s.get("name"), s.get("ticker_symbol"), s.get("type")), now))
        for a in res.get("accounts", []):
            bal = (a.get("balances") or {}).get("current")
            if bal is not None:
                conn.execute("UPDATE accounts SET current_balance = ?, updated_at = datetime('now') WHERE id = ?",
                             (bal, a["account_id"]))
        conn.commit()
    start = (date.today() - timedelta(days=730)).isoformat()
    offset, total = 0, None
    while total is None or offset < total:
        tx = _call("/investments/transactions/get", {"access_token": token, "start_date": start,
                                                     "end_date": date.today().isoformat(),
                                                     "options": {"offset": offset, "count": 500}})
        total = tx.get("total_investment_transactions", 0)
        batch = tx.get("investment_transactions", [])
        with db.lock():
            conn = db.get()
            _remember(conn, tx.get("securities"))
            for t in batch:
                conn.execute("INSERT OR REPLACE INTO inv_transactions VALUES(?,?,?,?,?,?,?,?,?)",
                             (t["investment_transaction_id"], t["account_id"], t["date"], t.get("name"),
                              t.get("amount"), t.get("quantity"), t.get("type"), t.get("subtype"),
                              t.get("security_id")))
            conn.commit()
        if not batch:
            break
        offset += len(batch)
    db.set_setting(f"inv_synced:{item_id}", now)
    return len(res.get("holdings", []))


def sync_all():
    """Returns {institution: status}. Items without investments access report why."""
    from . import config as cfg_mod
    out = {}
    for item in db.rows("SELECT * FROM items"):
        if not db.row("SELECT 1 FROM accounts WHERE item_id = ? AND type = 'investment'", (item["item_id"],)):
            continue
        name = item["institution"] or item["item_id"]
        try:
            n = sync(item["item_id"], cfg_mod.unprotect(bytes(item["access_token"])))
            out[name] = {"ok": True, "holdings": n}
            db.set_setting(f"inv_status:{item['item_id']}", "ok")
        except PlaidError as e:
            code = e.code or ""
            status = ("needs_consent" if code in ("ADDITIONAL_CONSENT_REQUIRED", "PRODUCT_NOT_ENABLED",
                                                  "INVALID_PRODUCT", "PRODUCTS_NOT_SUPPORTED")
                      else "not_ready" if code == "PRODUCT_NOT_READY" else "error")
            if code in ("INVALID_PRODUCT",) and "not enabled" in str(e).lower():
                status = "plan"  # your Plaid account itself doesn't have Investments yet
            db.set_setting(f"inv_status:{item['item_id']}", status)
            out[name] = {"ok": False, "status": status, "error": str(e)}
    return out


def summary():
    _init()
    rows = db.rows("SELECT h.*, a.name AS account_name, a.subtype AS account_subtype FROM holdings h "
                   "JOIN accounts a ON a.id = h.account_id WHERE a.is_hidden = 0 ORDER BY h.value DESC")
    total = sum(r["value"] or 0 for r in rows)
    mix = {"us_stocks": 0.0, "intl_stocks": 0.0, "bonds": 0.0, "cash": 0.0, "crypto": 0.0}
    fees, fee_known_value = 0.0, 0.0
    for r in rows:
        v = r["value"] or 0
        if r["asset_class"] == "target_date":
            st = _target_date_split(r["name"])
            mix["us_stocks"] += v * st * 0.6
            mix["intl_stocks"] += v * st * 0.4
            mix["bonds"] += v * (1 - st)
        else:
            mix[r["asset_class"]] = mix.get(r["asset_class"], 0) + v
        er = EXPENSE_RATIOS.get((r["ticker"] or "").upper())
        r["expense_ratio"] = er
        if er is not None:
            fees += v * er / 100
            fee_known_value += v
        r["gain"] = (v - r["cost_basis"]) if r["cost_basis"] else None
        r["gain_pct"] = round((v - r["cost_basis"]) / r["cost_basis"] * 100, 2) if r["cost_basis"] else None
        r["fee_dollars"] = round(v * er / 100, 2) if er is not None else None
    p = planner.get_profile()
    target = planner.target_allocation(int(p.get("age") or 30), p.get("risk", "moderate"))
    tgt = {"us_stocks": target["mix"][0]["pct"], "intl_stocks": target["mix"][1]["pct"], "bonds": target["mix"][2]["pct"],
           "cash": 0, "crypto": 0}
    actual = {k: round(v / total * 100, 1) if total else 0 for k, v in mix.items()}
    items = db.rows("SELECT i.item_id, i.institution FROM items i WHERE EXISTS (SELECT 1 FROM accounts a "
                    "WHERE a.item_id = i.item_id AND a.type = 'investment')")
    for it in items:
        it["status"] = db.get_setting(f"inv_status:{it['item_id']}", "unknown")
        it["synced"] = db.get_setting(f"inv_synced:{it['item_id']}")
    return {
        "holdings": rows, "total": round(total, 2), "actual": actual, "target": tgt,
        "mix_dollars": {k: round(v, 2) for k, v in mix.items()},
        "drift": {k: round(actual[k] - tgt[k], 1) for k in tgt},
        "fees_per_year": round(fees, 2), "fees_known_pct": round(fee_known_value / total * 100) if total else 0,
        "connections": items, "plaid_configured": config.plaid_configured(),
    }


def holding_prices():
    """Latest price and one-month change for each fund or stock you hold. Only ticker symbols are looked up."""
    from . import prices
    _init()
    rows = db.rows("SELECT DISTINCT h.ticker FROM holdings h JOIN accounts a ON a.id = h.account_id "
                   "WHERE a.is_hidden = 0 AND h.ticker IS NOT NULL AND h.asset_class != 'cash'")
    px = prices.month([r["ticker"] for r in rows])
    return {k: {key: v[key] for key in ("price", "month_ago", "change", "change_pct", "low", "high", "stale")}
            for k, v in px.items()}


def has_activity(account_ids):
    """Has Plaid sent any inside-the-account activity for these accounts?"""
    _init()
    if not account_ids:
        return False
    marks = ",".join("?" * len(account_ids))
    return bool(db.row(f"SELECT 1 FROM inv_transactions WHERE account_id IN ({marks}) LIMIT 1", account_ids))


def ira_contributions(account_ids, year):
    """Exact contributions into these accounts from Plaid investment transactions."""
    _init()
    if not account_ids:
        return []
    marks = ",".join("?" * len(account_ids))
    rows = db.rows(f"SELECT id, account_id, date, name, amount, type, subtype FROM inv_transactions WHERE account_id IN ({marks}) "
                   "AND date BETWEEN ? AND ? AND (subtype IN ('contribution', 'deposit') "
                   "OR (type = 'cash' AND subtype = 'deposit') OR (type = 'transfer' AND amount < 0)) ORDER BY date",
                   (*account_ids, f"{year}-01-01", f"{year}-12-31"))
    # Plaid: negative amount = cash into the account
    found = [{"id": r["id"], "date": r["date"], "amount": abs(r["amount"] or 0), "name": r["name"] or "Contribution",
              "type": r["type"], "account_id": r["account_id"]}
             for r in rows if (r["amount"] or 0) < 0 or r["subtype"] == "contribution"]
    # Money arriving and the purchase it paid for are one contribution, not two. A purchase made within a
    # week after a deposit into the same account (or a couple of days before it settles) that the deposit
    # can cover is that deposit being invested, so only the deposit is counted.
    left = {f["id"]: f["amount"] for f in found if f["type"] != "buy"}
    out = []
    for f in found:
        if f["type"] == "buy":
            day = date.fromisoformat(f["date"][:10])
            payer = next((d for d in found if d["id"] in left and d["account_id"] == f["account_id"]
                          and left[d["id"]] >= f["amount"] - 0.01
                          and -2 <= (day - date.fromisoformat(d["date"][:10])).days <= 7), None)
            if payer:
                left[payer["id"]] -= f["amount"]
                continue
        out.append(f)
    return out


# ------------------------------------------------------------------ today's buy plan
# Broad, low-cost Vanguard index funds for each part of the plan. ETFs have no minimum (Vanguard
# sells them in dollar amounts); the Admiral mutual funds need $3,000 to start.
FUNDS = {
    "us_stocks": {"etf": ("VTI", "Vanguard Total Stock Market ETF"),
                  "fund": ("VTSAX", "Vanguard Total Stock Market Index Fund (Admiral)")},
    "intl_stocks": {"etf": ("VXUS", "Vanguard Total International Stock ETF"),
                    "fund": ("VTIAX", "Vanguard Total International Stock Index Fund (Admiral)")},
    "bonds": {"etf": ("BND", "Vanguard Total Bond Market ETF"),
              "fund": ("VBTLX", "Vanguard Total Bond Market Index Fund (Admiral)")},
}
BROAD = {"us_stocks": {"VTI", "VTSAX", "VOO", "VFIAX", "ITOT", "SCHB", "FSKAX", "FZROX", "FXAIX", "SWTSX", "IVV", "SPLG"},
         "intl_stocks": {"VXUS", "VTIAX", "IXUS", "FTIHX", "FZILX", "VEA", "SCHF"},
         "bonds": {"BND", "VBTLX", "AGG", "BNDX"}}
CLASS_NAME = {"us_stocks": "US stocks", "intl_stocks": "International stocks", "bonds": "Bonds"}


def _bought_this_month(today):
    _init()
    rows = db.rows("SELECT amount, subtype FROM inv_transactions WHERE type = 'buy' AND date >= ?",
                   (today.strftime("%Y-%m-01"),))
    return round(sum(abs(r["amount"] or 0) for r in rows if "reinvest" not in (r["subtype"] or "")), 2)


def buy_settings():
    return db.get_setting("buy_plan", {}) or {}


def save_buy_settings(data):
    s = buy_settings()
    if data.get("reset_amount"):
        s.pop("amount", None)
    elif "amount" in data:
        try:
            amt = float(data["amount"])
        except (TypeError, ValueError):
            raise ValueError("Enter a dollar amount")
        if not 0 < amt <= 1_000_000:
            raise ValueError("Enter an amount above $0")
        s["amount"] = round(amt, 2)
    if data.get("vehicle") in ("etf", "fund", "auto"):
        s["vehicle"] = data["vehicle"]
    db.set_setting("buy_plan", s)
    return s


def buy_plan(today=None, with_prices=True):
    """Split your next contribution across funds so your mix moves toward your own target.

    This is arithmetic on the target you set on the Investing Plan page (age and risk level):
    new money goes to whatever is furthest below target, so you rebalance without selling.
    Recent prices are shown for context only and never change the split.
    """
    from . import prices
    today = today or date.today()
    s = summary()
    cfg = buy_settings()
    plan = planner.build_plan(today)
    steps = {st["key"]: st for st in plan["steps"]}
    monthly = round(sum(steps[k]["monthly"] for k in ("roth", "taxable") if k in steps), 2)
    bought = _bought_this_month(today)
    if cfg.get("amount"):
        amount, source = float(cfg["amount"]), "set by you"
    elif monthly > 0:
        left = monthly - bought
        amount = left if left >= 25 else monthly
        source = ("what's left of this month's plan" if 25 <= left < monthly - 1
                  else "your Investing Plan's monthly amount")
    else:
        amount, source = 500.0, "an example amount"
    amount = float(round(amount)) if not cfg.get("amount") else round(amount, 2)

    held = {}
    for h in s["holdings"]:
        if h.get("ticker"):
            held.setdefault(h["asset_class"], []).append(h)
    total = s["total"]
    cur = dict(s["mix_dollars"])
    tgt = s["target"]
    vehicle = cfg.get("vehicle", "auto")
    td = sorted(held.get("target_date", []), key=lambda h: -(h["value"] or 0))
    td_value = sum(h["value"] or 0 for h in td)

    lines = []
    if td and total and td_value / total >= 0.5:
        # Mostly in a target-date fund: it already holds the whole mix and rebalances itself
        h = td[0]
        lines.append({"asset_class": "target_date", "class_name": "Target-date fund", "ticker": h["ticker"].upper(),
                      "name": h["name"], "amount": amount, "owned": True,
                      "why": "Most of your money is in this target-date fund. It already holds stocks and bonds "
                             "in one fund and rebalances itself, so new money simply goes here."})
        mode = "target_date"
    else:
        classes = ("us_stocks", "intl_stocks", "bonds")
        after = total + amount
        gaps = {k: max(0.0, tgt[k] / 100 * after - cur.get(k, 0)) for k in classes}
        gsum = sum(gaps.values())
        weights = ({k: g / gsum for k, g in gaps.items()} if gsum > 0 else {k: tgt[k] / 100 for k in classes})
        buys = {k: round(amount * w) for k, w in weights.items()}
        top = max(buys, key=buys.get)
        for k in classes:  # don't bother with crumbs
            if k != top and 0 < buys[k] < min(25, amount * 0.05):
                buys[k] = 0
        buys[top] = round(amount - sum(v for k, v in buys.items() if k != top), 2)
        for k in classes:
            if buys[k] <= 0:
                continue
            own = sorted((h for h in held.get(k, []) if h["ticker"].upper() in BROAD[k]),
                         key=lambda h: -(h["value"] or 0))
            if own and vehicle == "auto":
                ticker, name, owned = own[0]["ticker"].upper(), own[0]["name"], True
            else:
                ticker, name = FUNDS[k]["fund" if vehicle == "fund" else "etf"]
                owned = any(h["ticker"].upper() == ticker for h in held.get(k, []))
            drift = s["drift"].get(k, 0) if total else 0
            now_pct = s["actual"].get(k, 0) if total else 0
            new_pct = round((cur.get(k, 0) + buys[k]) / after * 100, 1) if after else 0
            if not total:
                why = f"{tgt[k]}% of your plan."
            elif drift <= -1:
                why = (f"{CLASS_NAME[k]} are {abs(drift):g} points under your {tgt[k]}% target "
                       f"({now_pct:g}% now, {new_pct:g}% after this buy).")
            else:
                why = f"Keeps {CLASS_NAME[k].lower()} near your {tgt[k]}% target ({now_pct:g}% now)."
            lines.append({"asset_class": k, "class_name": CLASS_NAME[k], "ticker": ticker, "name": name,
                          "amount": buys[k], "owned": owned, "why": why, "target_pct": tgt[k], "now_pct": now_pct,
                          "after_pct": new_pct})
        mode = "rebalance" if total else "start"

    px = prices.month([ln["ticker"] for ln in lines]) if with_prices else {}
    for ln in lines:
        p = px.get(ln["ticker"])
        ln["price"] = p
        ln["shares"] = round(ln["amount"] / p["price"], 3) if p and p.get("price") else None
        ln["expense_ratio"] = EXPENSE_RATIOS.get(ln["ticker"])
    skipped = [CLASS_NAME[k] for k in ("us_stocks", "intl_stocks", "bonds")
               if mode != "target_date" and not any(ln["asset_class"] == k for ln in lines) and tgt[k] > 0]
    labels = {"roth": "Roth IRA", "taxable": "taxable brokerage account", "hsa": "HSA"}
    where = [{"key": k, "label": labels[k], "monthly": steps[k]["monthly"]}
             for k in ("roth", "hsa", "taxable") if k in steps and steps[k]["monthly"] > 0]
    return {"amount": amount, "amount_source": source, "custom_amount": bool(cfg.get("amount")),
            "monthly_plan": monthly, "bought_this_month": bought, "vehicle": vehicle, "mode": mode,
            "lines": lines, "skipped": skipped, "where": where, "total": total, "target": tgt,
            "has_prices": any(ln["price"] for ln in lines), "date": today.isoformat(),
            "disclaimer": "This is arithmetic on the target mix you chose on the Investing Plan page: new money "
                          "goes to whatever is furthest below target. It is not a prediction and not advice from "
                          "a licensed advisor. Last month's price moves are shown for context and never change "
                          "the split. Prices come from Yahoo Finance and may be delayed."}


# ------------------------------------------------------------------ money in vs. growth
PERIODS = (("3m", "3 months", 91), ("6m", "6 months", 182), ("1y", "1 year", 365), ("2y", "2 years", 730))
_NOT_A_TRADE = re.compile(r"split|stock distribution|spin|merger")


def _daily(hist, days):
    """One price per calendar day: the latest close on or before it (the first close for earlier days)."""
    out, j, last = [], 0, hist[0][1]
    for d in days:
        while j < len(hist) and hist[j][0] <= d:
            last = hist[j][1]
            j += 1
        out.append(last)
    return out


def performance(period="1y", account=None, today=None):
    """How much of your balance is money you put in and how much is the market.

    The past is rebuilt rather than recorded: start from the shares you hold today, walk the buys
    and sells your brokerage reports backwards to get the shares you held on each earlier day, and
    multiply by that day's closing price. "Money in" is the balance on the first day plus what you
    bought, minus what you sold, since. Growth is the rest: price changes and reinvested dividends.
    """
    from . import prices
    _init()
    today = today or date.today()
    span = {k: n for k, _, n in PERIODS}
    if period not in span:
        period = "1y"
    start = today - timedelta(days=span[period])
    accounts = db.rows("SELECT a.id, a.name FROM accounts a WHERE a.is_hidden = 0 AND EXISTS "
                       "(SELECT 1 FROM holdings h WHERE h.account_id = a.id) ORDER BY a.name")
    ids = [a["id"] for a in accounts]
    if account in ids:
        ids = [account]
    else:
        account = None
    out = {"period": period, "periods": [{"key": k, "label": lab} for k, lab, _ in PERIODS],
           "account": account, "accounts": accounts, "points": []}
    if not ids:
        return out
    marks = ",".join("?" * len(ids))
    days = [(start + timedelta(days=i)).isoformat() for i in range(span[period] + 1)]
    n = len(days)
    index = {d: i for i, d in enumerate(days)}

    pos = {}
    for h in db.rows(f"SELECT * FROM holdings WHERE account_id IN ({marks})", ids):
        qty, ticker = h["quantity"] or 0, (h["ticker"] or "").upper()
        if not qty and h["value"]:  # no share count reported: carry it as dollars, drawn flat
            qty, ticker = h["value"], ""
        pos[(h["account_id"], h["security_id"])] = {
            "qty": qty, "value": h["value"] or 0, "ticker": ticker,
            "name": h["name"] or h["ticker"] or "Holding", "cls": h["asset_class"], "txs": []}
    known = {s["security_id"]: s for s in db.rows("SELECT * FROM securities")}
    first_activity, reinvested = None, 0.0
    for t in db.rows(f"SELECT * FROM inv_transactions WHERE account_id IN ({marks}) ORDER BY date, id", ids):
        first_activity = first_activity or t["date"]
        sub = (t["subtype"] or "").lower()
        qty = t["quantity"] or 0
        if (not t["security_id"] or not qty or t["type"] not in ("buy", "sell", "cancel", "transfer")
                or _NOT_A_TRADE.search(sub) or t["date"] <= days[0]):
            continue
        amount = t["amount"] or 0
        if t["type"] == "buy":
            qty, amount = abs(qty), abs(amount)
        elif t["type"] == "sell":
            qty, amount = -abs(qty), -abs(amount)
        key = (t["account_id"], t["security_id"])
        p = pos.get(key)
        if not p:  # something you've sold completely since
            s = known.get(t["security_id"]) or {}
            p = pos[key] = {"qty": 0, "value": 0, "ticker": (s.get("ticker") or "").upper(),
                            "name": s.get("name") or t["name"] or "Sold holding",
                            "cls": classify(s.get("name") or t["name"], s.get("ticker"), s.get("type")), "txs": []}
        p["txs"].append({"date": min(t["date"], days[-1]), "qty": qty, "amount": amount,
                         "reinvest": "reinvest" in sub, "in_kind": t["type"] == "transfer"})

    px = prices.history([p["ticker"] for p in pos.values() if p["ticker"] and p["cls"] != "cash"])
    value, flows = [0.0] * n, [0.0] * n
    total_now = sum(p["value"] for p in pos.values())
    unpriced, unpriced_value, movers = [], 0.0, []
    for p in pos.values():
        now_price = p["value"] / p["qty"] if p["qty"] else None
        hist = px.get(p["ticker"])
        if p["cls"] == "cash":
            series = [now_price or 1.0] * n
        elif hist:
            series = _daily(hist, days)
            if now_price:
                series[-1] = now_price  # end on the value your brokerage reports
        else:  # no price history: drawn flat at today's price
            last = p["txs"][-1] if p["txs"] else None
            flat = now_price or (abs(last["amount"] / last["qty"]) if last and last["amount"] else 0.0)
            series = [flat] * n
            if p["value"] > 0:
                unpriced.append(p["ticker"] or p["name"])
                unpriced_value += p["value"]
        held, k = p["qty"], len(p["txs"]) - 1
        vals = [0.0] * n
        for i in range(n - 1, -1, -1):
            while k >= 0 and p["txs"][k]["date"] > days[i]:
                held -= p["txs"][k]["qty"]
                k -= 1
            vals[i] = max(held, 0.0) * series[i]
            value[i] += vals[i]
        put = 0.0
        for t in p["txs"]:
            i = index[t["date"]]
            if t["reinvest"]:  # dividends buying more shares are growth, not your money going in
                reinvested += abs(t["amount"]) or abs(t["qty"]) * series[i]
                continue
            f = t["qty"] * series[i] if t["in_kind"] or not t["amount"] else t["amount"]
            flows[i] += f
            put += f
        gain = vals[-1] - vals[0] - put
        if abs(gain) >= 1 and p["cls"] != "cash":
            movers.append({"label": p["ticker"] or p["name"][:28], "name": p["name"], "gain": round(gain, 2)})

    first = next((i for i in range(n) if value[i] > 0.005 or flows[i]), None)
    if first is None:
        return out
    begin = max(0, first - 1)
    put_in, run = [], value[0]
    for i in range(n):
        run += flows[i]
        put_in.append(run)
    growth = value[-1] - put_in[-1]
    length = n - 1 - begin
    # Money weighted by how long it was invested, so a deposit made last week doesn't dilute the return
    weighted = value[begin] + sum(flows[i] * (n - 1 - i) / length for i in range(begin + 1, n)) if length else 0
    assumed = None
    if not first_activity:
        assumed = "none"
    elif first_activity > (start + timedelta(days=45)).isoformat() and value[begin] > 0:
        assumed = first_activity
    movers.sort(key=lambda m: -abs(m["gain"]))
    out.update({
        "points": [{"date": days[i], "value": round(value[i], 2), "put_in": round(put_in[i], 2)}
                   for i in range(begin, n)],
        "start_date": days[begin], "start_value": round(value[begin], 2), "end_value": round(value[-1], 2),
        "net_put_in": round(put_in[-1] - value[begin], 2), "growth": round(growth, 2),
        "growth_pct": round(growth / weighted * 100, 1) if weighted > 1 else None,
        "reinvested": round(reinvested, 2), "movers": movers[:6],
        "priced_pct": round((total_now - unpriced_value) / total_now * 100) if total_now else 100,
        "unpriced": unpriced[:4], "unpriced_count": len(unpriced), "assumed_before": assumed,
    })
    return out


# ------------------------------------------------------------------ risk tags, daily briefing, one stock's history
MARKET = "VTI"   # a total US stock market fund, used only as a yardstick to compare against
RISK_LEVELS = [("very_low", "Very low"), ("low", "Low"), ("medium", "Medium"), ("high", "High"), ("very_high", "Very high")]
FUND_TYPES = {"etf", "mutual fund", "fund", "fixed income"}


def _pct(now, then):
    return round((now - then) / then * 100, 2) if then else None


def _price_stats(hist):
    """Plain facts about one price history ([[day, close], ...], oldest first)."""
    closes = [c for _, c in hist if c and c > 0]
    if len(closes) < 30:
        return None
    last, year = closes[-1], closes[-253:]

    def back(n):
        return closes[-1 - n] if len(closes) > n else None

    moves = [math.log(b / a) for a, b in zip(year, year[1:])]
    peak, drop = year[0], 0.0
    for c in year:
        peak = max(peak, c)
        drop = max(drop, (peak - c) / peak)
    hi, lo = max(year), min(year)
    return {"price": round(last, 2), "date": hist[-1][0], "d1": _pct(last, back(1)), "m1": _pct(last, back(21)),
            "m3": _pct(last, back(63)), "y1": _pct(last, back(252)), "high52": round(hi, 2), "low52": round(lo, 2),
            "from_high": _pct(last, hi), "from_low": _pct(last, lo),
            "vol": round(statistics.pstdev(moves) * math.sqrt(252) * 100, 1) if len(moves) > 20 else None,
            "drawdown": round(drop * 100, 1)}


def risk_of(asset_class, typ, stats):
    """How bumpy a holding is, in five steps. This describes how it has behaved and what kind of thing it is;
    it is not a prediction. One company can fall much further than a fund holding hundreds, so a single
    stock is never rated below High however calm its past year was."""
    typ = (typ or "").lower()
    vol = (stats or {}).get("vol")
    single = typ in ("equity", "stock")
    why = []
    if asset_class == "cash":
        rank, why = 0, ["Cash or a money market fund: the value barely moves"]
    elif asset_class == "crypto" or typ in ("cryptocurrency", "derivative"):
        rank, why = 4, ["Crypto or a derivative: prices can swing very widely"]
    else:
        if vol is None:
            rank = 1 if asset_class == "bonds" else 3 if single else 2
        else:
            rank = 0 if vol < 3 else 1 if vol < 9 else 2 if vol < 22 else 3 if vol < 38 else 4
        if single:
            rank = max(rank, 3)
            why.append("One company, so it rises or falls on that company alone")
        elif asset_class == "bonds":
            why.append("A bond fund")
        elif asset_class == "target_date":
            why.append("A target-date fund: a mix of stocks and bonds")
        else:
            why.append("A fund holding many companies")
        if vol is not None:
            why.append(f"swung about {vol:.0f}% a year lately")
            if stats.get("drawdown", 0) >= 5:
                why.append(f"fell as much as {stats['drawdown']:.0f}% from a peak in the past year")
        else:
            why.append("no price history to measure")
    key, label = RISK_LEVELS[rank]
    return {"level": key, "label": label, "rank": rank, "why": "; ".join(why) + "."}


def insights(today=None):
    """Risk tag and price facts for every holding, the risk mix, and today's briefing.

    The briefing is a list of observations about what you hold (what moved, what is concentrated, what has
    drifted from your own target). It deliberately does not tell you to buy or sell anything.
    """
    from . import prices
    today = today or date.today()
    s = summary()
    hist = prices.history([h["ticker"] for h in s["holdings"] if h.get("ticker") and h["asset_class"] != "cash"])
    total = s["total"] or 0
    by_holding, by_ticker, mix = {}, {}, {k: 0.0 for k, _ in RISK_LEVELS}
    as_of = None
    for h in s["holdings"]:
        t = (h.get("ticker") or "").upper()
        st = _price_stats(hist[t]) if t in hist and h["asset_class"] != "cash" else None
        risk = risk_of(h["asset_class"], h.get("type"), st)
        by_holding[f"{h['account_id']}|{h['security_id']}"] = {"risk": risk, "stats": st}
        mix[risk["level"]] += h["value"] or 0
        if st:
            as_of = max(as_of or st["date"], st["date"])
            e = by_ticker.setdefault(t, {"ticker": t, "name": h["name"], "value": 0.0, "stats": st, "risk": risk,
                                         "single": "One company" in risk["why"]})
            e["value"] += h["value"] or 0

    items = []

    def add(icon, title, text, ticker=None, tone=""):
        items.append({"icon": icon, "title": title, "text": text, "ticker": ticker, "tone": tone})

    money = lambda v: f"${abs(v):,.0f}"  # noqa: E731
    priced = [e for e in by_ticker.values() if e["stats"].get("d1") is not None]
    if priced and total:
        change = sum(e["value"] - e["value"] / (1 + e["stats"]["d1"] / 100) for e in priced)
        add("📊", "Since the last close", f"Your holdings are {'up' if change >= 0 else 'down'} about {money(change)} "
            f"({abs(change) / total * 100:.1f}%) on the latest prices.", tone="up" if change >= 0 else "down")
    for e in sorted(priced, key=lambda e: -abs(e["stats"]["d1"]))[:3]:
        d1 = e["stats"]["d1"]
        if abs(d1) >= 1.5:
            add("▲" if d1 > 0 else "▼", f"{e['ticker']} {'rose' if d1 > 0 else 'fell'} {abs(d1):.1f}% on the day",
                f"About {money(e['value'] - e['value'] / (1 + d1 / 100))} on what you hold.", e["ticker"], "up" if d1 > 0 else "down")
    for e in sorted((e for e in priced if e["stats"].get("m1") is not None), key=lambda e: -abs(e["stats"]["m1"]))[:2]:
        m1 = e["stats"]["m1"]
        if abs(m1) >= 8:
            add("🗓", f"{e['ticker']} is {'up' if m1 > 0 else 'down'} {abs(m1):.0f}% over the past month",
                "A big move for one month. Click it to see the year.", e["ticker"], "up" if m1 > 0 else "down")
    for e in priced:
        st = e["stats"]
        if st["from_high"] is not None and st["from_high"] >= -1.5 and (st.get("y1") or 0) > 5:
            add("⛰", f"{e['ticker']} is at or near its highest price in a year", f"${st['price']:,.2f} against a one-year high of ${st['high52']:,.2f}.", e["ticker"])
        elif st["from_low"] is not None and st["from_low"] <= 4 and st["from_high"] <= -12:
            add("🕳", f"{e['ticker']} is near its lowest price in a year", f"${st['price']:,.2f}, which is {abs(st['from_high']):.0f}% below its one-year high.", e["ticker"])
    singles = sorted((e for e in by_ticker.values() if e["single"]), key=lambda e: -e["value"])
    if total:
        for e in singles[:2]:
            share = e["value"] / total * 100
            if share >= 10:
                add("🎯", f"{e['ticker']} is {share:.0f}% of your investments", "That is a lot riding on one company.", e["ticker"], "warn")
        single_share = sum(e["value"] for e in singles) / total * 100
        if len(singles) > 1 and single_share >= 25:
            add("🧺", f"Individual stocks are {single_share:.0f}% of your investments", "The rest is in funds, which spread the risk across many companies.", tone="warn")
        risky = (mix["high"] + mix["very_high"]) / total * 100
        if risky >= 1:
            add("🌡", f"{risky:.0f}% of your money is in holdings tagged High or Very high risk", "See the Risk column in the tables below.")
    names = {"us_stocks": "US stocks", "intl_stocks": "International stocks", "bonds": "Bonds", "cash": "Cash", "crypto": "Crypto"}
    off = sorted(((k, v) for k, v in s["drift"].items() if abs(v) >= 5), key=lambda kv: -abs(kv[1]))
    if off and total:
        k, v = off[0]
        add("⚖️", f"{names.get(k, k)} are {abs(v):g} points {'above' if v > 0 else 'below'} your target mix",
            "Today's buy plan below points new money at whatever is furthest under target.", tone="warn")
    if not items:
        add("😌", "A quiet day", "Nothing notable has changed in what you hold.")
    return {"date": today.isoformat(), "as_of": as_of, "holdings": by_holding, "total": total,
            "risk_levels": [{"key": k, "label": lab} for k, lab in RISK_LEVELS],
            "risk_mix": {k: round(v, 2) for k, v in mix.items()}, "briefing": items[:9],
            "note": "These are facts about what you already hold, refreshed with each day's prices. They are not advice to "
                    "buy or sell anything, and a price that has risen or fallen says nothing reliable about where it goes next."}


def stock(ticker):
    """One ticker's daily closes for about two years, the facts about it, and your position in it."""
    from . import prices
    _init()
    t = (ticker or "").upper().strip()
    if not prices.SYMBOL.match(t):
        raise ValueError("That doesn't look like a ticker symbol")
    both = prices.history([t, MARKET])
    hist = both.get(t)
    if not hist:
        raise ValueError(f"No price history could be found for {t} right now")
    market = _price_stats(both[MARKET]) if MARKET in both and t != MARKET else None
    rows = db.rows("SELECT h.*, a.name AS account_name FROM holdings h JOIN accounts a ON a.id = h.account_id "
                   "WHERE a.is_hidden = 0 AND upper(h.ticker) = ?", (t,))
    st = _price_stats(hist)
    first = rows[0] if rows else {}
    qty = sum(r["quantity"] or 0 for r in rows)
    value = sum(r["value"] or 0 for r in rows)
    cost = sum(r["cost_basis"] or 0 for r in rows) if rows and all(r["cost_basis"] for r in rows) else None
    cls = first.get("asset_class") or classify(first.get("name"), t, first.get("type"))
    typ = first.get("type") or ("etf" if any(t in v for v in BROAD.values()) or t in EXPENSE_RATIOS else None)
    name = first.get("name")
    if not name:
        known = db.row("SELECT name FROM securities WHERE upper(ticker) = ?", (t,))
        name = (known or {}).get("name") or next((n for f in FUNDS.values() for tk, n in f.values() if tk == t), t)
    from . import rules
    return {"ticker": t, "name": name, "points": hist, "stats": st, "risk": risk_of(cls, typ, st),
            "expense_ratio": EXPENSE_RATIOS.get(t), "note": rules.get_note(t),
            "market": {"ticker": MARKET, "y1": market["y1"], "m1": market["m1"], "vol": market["vol"],
                       "drawdown": market["drawdown"]} if market else None,
            "position": {"shares": round(qty, 4), "value": round(value, 2), "cost": round(cost, 2) if cost else None,
                         "avg_cost": round(cost / qty, 2) if cost and qty else None,
                         "gain": round(value - cost, 2) if cost else None,
                         "accounts": sorted({r["account_name"] for r in rows})} if rows else None}
