"""Splitting everyday costs with a partner (groceries, eating out...).

You both pay for shared things on your own cards. Your partner connects their card through Plaid
(they sign in to their bank in Plaid's own window; this app never sees their password), or you add
what they paid by hand. To respect their privacy, only their purchases in the shared categories
are ever saved: everything else on their card is discarded as it arrives, and their balances are
never stored.

Then, for every shared purchase:
  * you paid   -> a "their share" line takes their part off your spending
  * they paid  -> a "your share" line adds your part to your spending
so Groceries, Dining etc. show what the food really cost YOU, and a running tab says who owes whom.

The share lines are ordinary transactions with source = 'split' and are rebuilt by splits.apply().
"""
import uuid
from datetime import date, datetime, timedelta

from . import categorize, config, db
from .plaid import PlaidError, _call

SCHEMA = """
CREATE TABLE IF NOT EXISTS partner_items (
    item_id TEXT PRIMARY KEY, access_token BLOB NOT NULL, institution TEXT, cursor TEXT,
    last_sync TEXT, error TEXT
);
CREATE TABLE IF NOT EXISTS partner_tx (
    id TEXT PRIMARY KEY, item_id TEXT, account_name TEXT, date TEXT NOT NULL, name TEXT NOT NULL,
    merchant TEXT, amount REAL NOT NULL, category TEXT, pending INTEGER DEFAULT 0, source TEXT DEFAULT 'plaid'
);
"""
DEFAULT_CATEGORIES = ["Groceries", "Dining"]
NOT_SHAREABLE = {"Income", "Transfer", "Credit Card Payment", "Investments"}


def _init():
    db.get().executescript(SCHEMA)


def get():
    """Partner settings, or None if you haven't set one up."""
    return db.get_setting("partner", None) or None


def _save(p):
    db.set_setting("partner", p)


def save(data):
    old = get() or {}
    name = (data.get("name") or "").strip()[:40]
    if not name:
        raise ValueError("Give your partner a name")
    try:
        mine = float(data.get("your_share") if data.get("your_share") not in (None, "") else 50)
    except (TypeError, ValueError):
        raise ValueError("Your share should be a number")
    if not 1 <= mine <= 99:
        raise ValueError("Your share should be between 1% and 99%")
    cats = [categorize.canonical(c) for c in (data.get("categories") or []) if c and c not in NOT_SHAREABLE]
    cats = list(dict.fromkeys(cats)) or DEFAULT_CATEGORIES
    match = [m.strip().lower() for m in (data.get("settle_match") or []) if isinstance(m, str) and len(m.strip()) >= 3]
    since = (data.get("since") or old.get("since") or date.today().replace(day=1).isoformat())[:10]
    try:
        date.fromisoformat(since)
    except ValueError:
        raise ValueError("The start date should look like 2026-11-01")
    p = {"name": name, "your_share": mine, "categories": cats, "settle_match": match, "since": since,
         "excluded": old.get("excluded", []), "included": old.get("included", []),
         "settlements": old.get("settlements", [])}
    refetch = bool(old) and (set(cats) - set(old.get("categories", [])) or since < old.get("since", since))
    _save(p)
    _init()
    if refetch:  # other purchases of theirs were thrown away, so ask the bank again
        db.execute("UPDATE partner_items SET cursor = NULL")
    # anything of theirs that's no longer shared is forgotten
    marks = ",".join("?" * len(cats))
    db.execute(f"DELETE FROM partner_tx WHERE source = 'plaid' AND (category NOT IN ({marks}) OR date < ?)",
               (*cats, since))
    return p


def remove():
    """Stop sharing: disconnect their bank and forget everything of theirs."""
    _init()
    for it in db.rows("SELECT item_id FROM partner_items"):
        remove_item(it["item_id"])
    db.execute("DELETE FROM partner_tx")
    db.set_setting("partner", None)


# ------------------------------------------------------------------ their bank connection
def link_token(item_id=None, redirect_uri=None):
    body = {"user": {"client_user_id": "partner"}, "client_name": "Kerdos", "country_codes": ["US"],
            "language": "en"}
    if redirect_uri:
        body["redirect_uri"] = redirect_uri
    if item_id:
        body["access_token"] = _token(item_id)
    else:
        body["products"] = ["transactions"]
        body["transactions"] = {"days_requested": 90}
    return _call("/link/token/create", body)["link_token"]


def _token(item_id):
    r = db.row("SELECT access_token FROM partner_items WHERE item_id = ?", (item_id,))
    if not r:
        raise PlaidError({"error_message": "Unknown connection"})
    return config.unprotect(bytes(r["access_token"]))


def connect(public_token, institution=None):
    if not get():
        raise ValueError("Set up your partner first")
    _init()
    res = _call("/item/public_token/exchange", {"public_token": public_token})
    db.execute("INSERT INTO partner_items(item_id, access_token, institution) VALUES(?, ?, ?) "
               "ON CONFLICT(item_id) DO UPDATE SET access_token = excluded.access_token, error = NULL",
               (res["item_id"], config.protect(res["access_token"]), institution))
    sync_item(res["item_id"])
    return res["item_id"]


def remove_item(item_id):
    _init()
    try:
        _call("/item/remove", {"access_token": _token(item_id)})
    except PlaidError:
        pass
    db.execute("DELETE FROM partner_tx WHERE item_id = ?", (item_id,))
    db.execute("DELETE FROM partner_items WHERE item_id = ?", (item_id,))


def sync_item(item_id):
    _init()
    p = get()
    item = db.row("SELECT * FROM partner_items WHERE item_id = ?", (item_id,))
    if not p or not item:
        return 0
    token = config.unprotect(bytes(item["access_token"]))
    cats, since = set(p["categories"]), p["since"]
    rules = categorize.load_rules()
    cursor, kept = item.get("cursor"), 0
    try:
        while True:
            body = {"access_token": token, "count": 500}
            if cursor:
                body["cursor"] = cursor
            res = _call("/transactions/sync", body)
            names = {a["account_id"]: (a.get("name") or "Card") + (f" ••{a['mask']}" if a.get("mask") else "")
                     for a in res.get("accounts", [])}
            with db.lock():
                conn = db.get()
                for t in res.get("added", []) + res.get("modified", []):
                    pfc = t.get("personal_finance_category") or {}
                    pfc_s = (f"{pfc.get('primary', '')}|{pfc.get('detailed', '')}|{pfc.get('confidence_level') or ''}"
                             if pfc else None)
                    amount = -float(t["amount"])
                    cat, _src = categorize.classify(t.get("name"), t.get("merchant_name"), amount, pfc_s, rules)
                    if t.get("pending_transaction_id"):
                        conn.execute("DELETE FROM partner_tx WHERE id = ?", (t["pending_transaction_id"],))
                    if cat in cats and t["date"] >= since:   # only shared purchases are ever saved
                        conn.execute(
                            "INSERT OR REPLACE INTO partner_tx(id, item_id, account_name, date, name, merchant, amount, "
                            "category, pending, source) VALUES(?,?,?,?,?,?,?,?,?, 'plaid')",
                            (t["transaction_id"], item_id, names.get(t["account_id"]), t["date"], t.get("name") or "",
                             t.get("merchant_name"), amount, cat, 1 if t.get("pending") else 0))
                        kept += 1
                    else:
                        conn.execute("DELETE FROM partner_tx WHERE id = ?", (t["transaction_id"],))
                for r in res.get("removed", []):
                    conn.execute("DELETE FROM partner_tx WHERE id = ?", (r["transaction_id"],))
                cursor = res.get("next_cursor")
                conn.execute("UPDATE partner_items SET cursor = ? WHERE item_id = ?", (cursor, item_id))
                conn.commit()
            if not res.get("has_more"):
                break
        db.execute("UPDATE partner_items SET last_sync = ?, error = NULL WHERE item_id = ?",
                   (datetime.now().isoformat(timespec="seconds"), item_id))
    except PlaidError as e:
        db.execute("UPDATE partner_items SET error = ? WHERE item_id = ?", (e.code or str(e), item_id))
        raise
    return kept


def sync_all():
    _init()
    out = {}
    for it in db.rows("SELECT item_id, institution FROM partner_items"):
        try:
            out[it["institution"] or it["item_id"]] = {"ok": True, "kept": sync_item(it["item_id"])}
        except PlaidError as e:
            out[it["institution"] or it["item_id"]] = {"ok": False, "error": str(e)}
    return out


# ------------------------------------------------------------------ by-hand entries and switches
def add_manual(data):
    p = get()
    if not p:
        raise ValueError("Set up your partner first")
    _init()
    name = (data.get("name") or "").strip()[:80]
    if not name:
        raise ValueError("What was it for?")
    try:
        amt = abs(float(data.get("amount")))
    except (TypeError, ValueError):
        raise ValueError("Enter the amount they paid")
    if amt <= 0:
        raise ValueError("Enter the amount they paid")
    d = (data.get("date") or date.today().isoformat())[:10]
    try:
        date.fromisoformat(d)
    except ValueError:
        raise ValueError("The date should look like 2026-11-08")
    cat = categorize.canonical(data.get("category") or p["categories"][0])
    tid = "m:" + uuid.uuid4().hex[:10]
    db.execute("INSERT INTO partner_tx(id, item_id, account_name, date, name, merchant, amount, category, pending, source) "
               "VALUES(?, NULL, 'Added by hand', ?, ?, NULL, ?, ?, 0, 'manual')", (tid, d, name, -amt, cat))
    return tid


def delete_manual(tid):
    _init()
    db.execute("DELETE FROM partner_tx WHERE id = ? AND source = 'manual'", (tid,))


def toggle(tid, shared):
    """Mark one purchase as shared or not (overrides the category rule)."""
    p = get()
    if not p:
        return
    _init()
    tid = str(tid)
    ex, inc = set(p.get("excluded", [])), set(p.get("included", []))
    mine = db.row("SELECT category, date FROM transactions WHERE id = ? AND coalesce(source, '') != 'split'", (tid,))
    by_rule = bool(mine and mine["category"] in p["categories"]) or \
        bool(db.row("SELECT 1 FROM partner_tx WHERE id = ?", (tid,)))
    ex.discard(tid)
    inc.discard(tid)
    if shared and not by_rule:
        inc.add(tid)
    elif not shared and by_rule:
        ex.add(tid)
    p["excluded"], p["included"] = sorted(ex)[-2000:], sorted(inc)[-2000:]
    _save(p)


def settle(undo=False, today=None):
    """Record that you squared up: the running tab goes back to zero."""
    p = get()
    if not p:
        return
    today = today or date.today()
    if undo:
        p["settlements"] = p.get("settlements", [])[:-1]
    else:
        bal = balance(p)["balance"]
        if abs(bal) < 0.01:
            raise ValueError("You're already even")
        p.setdefault("settlements", []).append({"date": today.isoformat(), "amount": round(bal, 2)})
    _save(p)


# ------------------------------------------------------------------ the math
def _settle_text(p, t):
    text = f"{t['name']} {t['merchant'] or ''} | {categorize.merchant_key(t['name'], t['merchant'])}".lower()
    return any(m and m in text for m in p.get("settle_match", []))


def _my_shared(p):
    """Your own purchases that are shared: (rows by rule minus the ones you switched off) + switched on."""
    cats = p["categories"]
    marks = ",".join("?" * len(cats))
    ex = set(p.get("excluded", []))
    rows = db.rows(f"SELECT t.id, t.account_id, t.date, t.name, t.merchant, t.amount, t.category, t.pending, "
                   f"a.name AS account_name FROM transactions t LEFT JOIN accounts a ON a.id = t.account_id "
                   f"WHERE t.category IN ({marks}) AND t.date >= ? AND coalesce(t.source, '') != 'split'",
                   (*cats, p["since"]))
    out = [r for r in rows if r["id"] not in ex]
    inc = [i for i in p.get("included", [])]
    if inc:
        have = {r["id"] for r in out}
        im = ",".join("?" * len(inc))
        for r in db.rows(f"SELECT t.id, t.account_id, t.date, t.name, t.merchant, t.amount, t.category, t.pending, "
                         f"a.name AS account_name FROM transactions t LEFT JOIN accounts a ON a.id = t.account_id "
                         f"WHERE t.id IN ({im}) AND coalesce(t.source, '') != 'split'", inc):
            if r["id"] not in have and r["category"] not in NOT_SHAREABLE:
                out.append(r)
    return out


def _their_shared(p):
    _init()
    ex = set(p.get("excluded", []))
    return [r for r in db.rows("SELECT * FROM partner_tx WHERE date >= ?", (p["since"],)) if r["id"] not in ex]


def split_rows():
    """Share lines for splits.apply(): (id, account_id, date, name, merchant, amount, category)."""
    p = get()
    if not p:
        return []
    theirs_pct = (100 - p["your_share"]) / 100
    mine_pct = p["your_share"] / 100
    out = []
    for t in _my_shared(p):
        if t["pending"] or not t["account_id"]:
            continue
        amt = round(-t["amount"] * theirs_pct, 2)
        if abs(amt) >= 0.01:
            out.append((f"split:{t['id']}:p", t["account_id"], t["date"],
                        f"{p['name']}'s share: {t['merchant'] or t['name']}", p["name"], amt, t["category"]))
    home = db.row("SELECT id FROM accounts WHERE is_hidden = 0 ORDER BY (type = 'depository') DESC, "
                  "(subtype = 'checking') DESC, id LIMIT 1")
    if home:
        for t in _their_shared(p):
            if t["pending"]:
                continue
            amt = round(t["amount"] * mine_pct, 2)
            if abs(amt) >= 0.01:
                out.append((f"split:partner:{t['id']}:q", home["id"], t["date"],
                            f"Your share: {t['merchant'] or t['name']} ({p['name']} paid)", p["name"], amt,
                            t["category"]))
    return out


def settle_payments(p=None):
    """Transfers between the two of you (found by the text you gave), newest first."""
    p = p or get()
    if not p or not p.get("settle_match"):
        return []
    rows = db.rows("SELECT id, date, name, merchant, amount, category, category_source, confidence FROM transactions "
                   "WHERE date >= ? AND pending = 0 AND coalesce(source, '') != 'split' ORDER BY date DESC", (p["since"],))
    return [r for r in rows if _settle_text(p, r)]


def balance(p=None):
    p = p or get()
    mine_pct, theirs_pct = p["your_share"] / 100, (100 - p["your_share"]) / 100
    you_paid = sum(-t["amount"] for t in _my_shared(p) if not t["pending"])
    they_paid = sum(-t["amount"] for t in _their_shared(p) if not t["pending"])
    pays = settle_payments(p)
    received = sum(t["amount"] for t in pays if t["amount"] > 0)
    sent = sum(-t["amount"] for t in pays if t["amount"] < 0)
    settled = sum(s["amount"] for s in p.get("settlements", []))
    bal = you_paid * theirs_pct - they_paid * mine_pct - received + sent - settled
    return {"you_paid": round(you_paid, 2), "they_paid": round(they_paid, 2), "received": round(received, 2),
            "sent": round(sent, 2), "settled": round(settled, 2), "balance": round(bal, 2),
            "fair_you": round((you_paid + they_paid) * mine_pct, 2),
            "fair_them": round((you_paid + they_paid) * theirs_pct, 2)}


def recent_charges(q="", today=None):
    """Your recent purchases outside the shared categories, to share one-off things (tickets, a trip)."""
    p = get()
    if not p:
        return []
    today = today or date.today()
    where = ["t.amount < 0", "t.date >= ?", "coalesce(t.source, '') != 'split'", "t.pending = 0"]
    params = [max(p["since"], (today - timedelta(days=120)).isoformat())]
    if q:
        where.append("(t.name LIKE ? OR t.merchant LIKE ?)")
        params += [f"%{q}%"] * 2
    rows = db.rows("SELECT t.id, t.date, t.name, t.merchant, t.amount, t.category FROM transactions t "
                   f"WHERE {' AND '.join(where)} ORDER BY t.date DESC LIMIT 60", params)
    skip = set(p["categories"]) | NOT_SHAREABLE
    inc = set(p.get("included", []))
    return [r for r in rows if r["category"] not in skip and r["id"] not in inc][:12]


def summary(today=None):
    today = today or date.today()
    _init()
    p = get()
    base = {"partner": p, "categories": [c for c in categorize.all_categories() if c not in NOT_SHAREABLE and c != "Other"],
            "default_categories": DEFAULT_CATEGORIES, "plaid_configured": config.plaid_configured()}
    if not p:
        return base
    ex, inc = set(p.get("excluded", [])), set(p.get("included", []))
    mine, theirs = _my_shared(p), _their_shared(p)
    months = {}
    for who, rows in (("you", mine), ("them", theirs)):
        for t in rows:
            if t["pending"]:
                continue
            m = months.setdefault(t["date"][:7], {"month": t["date"][:7], "you": 0.0, "them": 0.0, "cats": {}})
            m[who] += -t["amount"]
            c = m["cats"].setdefault(t["category"], {"you": 0.0, "them": 0.0})
            c[who] += -t["amount"]
    month_list = []
    for k in sorted(months, reverse=True)[:6]:
        m = months[k]
        total = m["you"] + m["them"]
        month_list.append({"month": k, "you": round(m["you"], 2), "them": round(m["them"], 2), "total": round(total, 2),
                           "your_cost": round(total * p["your_share"] / 100, 2),
                           "cats": [{"category": c, "you": round(v["you"], 2), "them": round(v["them"], 2)}
                                    for c, v in sorted(m["cats"].items(), key=lambda kv: -(kv[1]["you"] + kv[1]["them"]))]})
    cutoff = (today - timedelta(days=45)).isoformat()
    cats = p["categories"]
    marks = ",".join("?" * len(cats))
    recent = []
    # everything by rule in the last 45 days, including what you switched off, so you can switch it back
    for t in db.rows(f"SELECT t.id, t.date, t.name, t.merchant, t.amount, t.category, t.pending FROM transactions t "
                     f"WHERE (t.category IN ({marks}) OR t.id IN ({','.join('?' * len(inc)) or 'NULL'})) AND t.date >= ? "
                     f"AND coalesce(t.source, '') != 'split'", (*cats, *inc, max(cutoff, p["since"]))):
        if t["category"] in NOT_SHAREABLE:
            continue
        recent.append({"id": t["id"], "who": "you", "date": t["date"], "name": t["merchant"] or t["name"],
                       "amount": round(-t["amount"], 2), "category": t["category"], "pending": bool(t["pending"]),
                       "shared": t["id"] not in ex, "manual": False})
    for t in db.rows("SELECT * FROM partner_tx WHERE date >= ?", (max(cutoff, p["since"]),)):
        recent.append({"id": t["id"], "who": "them", "date": t["date"], "name": t["merchant"] or t["name"],
                       "amount": round(-t["amount"], 2), "category": t["category"], "pending": bool(t["pending"]),
                       "shared": t["id"] not in ex, "manual": t["source"] == "manual"})
    recent.sort(key=lambda r: r["date"], reverse=True)
    items = db.rows("SELECT item_id, institution, last_sync, error FROM partner_items")
    pays = [{"date": t["date"], "name": t["merchant"] or t["name"], "amount": t["amount"]} for t in settle_payments(p)[:8]]
    return {**base, "balance": balance(p), "months": month_list, "recent": recent[:80], "connections": items,
            "payments": pays, "their_count": len(theirs), "settlements": p.get("settlements", [])[-5:]}
