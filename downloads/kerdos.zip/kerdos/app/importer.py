"""CSV import for banks you don't want to (or can't) connect through Plaid.

Understands the common export layouts:
  * Date, Description, Amount                (negative = money out)
  * Date, Description, Debit, Credit
  * Transaction Date, Payee/Merchant/Name/Memo, Amount, (Category)
"""
import csv
import hashlib
import io
from datetime import datetime

from . import categorize, db

DATE_KEYS = ["date", "transaction date", "posted date", "post date", "posting date", "trans. date"]
DESC_KEYS = ["description", "payee", "merchant", "name", "memo", "details", "transaction"]
AMOUNT_KEYS = ["amount", "transaction amount", "amount (usd)"]
DEBIT_KEYS = ["debit", "withdrawal", "withdrawals", "money out", "debit amount"]
CREDIT_KEYS = ["credit", "deposit", "deposits", "money in", "credit amount"]
DATE_FORMATS = ["%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%d/%m/%Y", "%Y/%m/%d", "%b %d, %Y", "%d %b %Y"]


def _find(header, keys):
    low = [h.strip().lower() for h in header]
    for k in keys:
        if k in low:
            return low.index(k)
    for i, h in enumerate(low):
        if any(k in h for k in keys):
            return i
    return None


def _money(s):
    s = (s or "").strip().replace("$", "").replace(",", "")
    if not s:
        return None
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()")
    try:
        v = float(s)
    except ValueError:
        return None
    return -v if neg else v


def _date(s):
    s = (s or "").strip()
    for f in DATE_FORMATS:
        try:
            return datetime.strptime(s, f).date().isoformat()
        except ValueError:
            continue
    return None


def import_csv(text, account_id, flip_sign=False):
    """Returns {'imported': n, 'skipped': n}. Re-importing the same file is safe (dedup by hash)."""
    acct = db.row("SELECT id, type FROM accounts WHERE id = ?", (account_id,))
    if not acct:
        raise ValueError("Pick an account to import into")
    is_card = acct["type"] == "credit"
    reader = csv.reader(io.StringIO(text.lstrip("﻿")))
    all_rows = [r for r in reader if any(c.strip() for c in r)]
    if not all_rows:
        raise ValueError("The file is empty")
    header = all_rows[0]
    di, ni = _find(header, DATE_KEYS), _find(header, DESC_KEYS)
    ai, dbi, cri = _find(header, AMOUNT_KEYS), _find(header, DEBIT_KEYS), _find(header, CREDIT_KEYS)
    if di is None or ni is None or (ai is None and dbi is None):
        raise ValueError("Couldn't find Date / Description / Amount columns in the header row: "
                         + ", ".join(header))
    rules = categorize.load_rules()
    imported = skipped = 0
    seen = {}
    with db.lock():
        conn = db.get()
        for r in all_rows[1:]:
            r = r + [""] * (len(header) - len(r))
            d = _date(r[di])
            name = r[ni].strip()
            if ai is not None and _money(r[ai]) is not None:
                amt = _money(r[ai])
                if flip_sign:  # many credit-card exports show purchases as positive
                    amt = -amt
            else:
                debit, credit = _money(r[dbi]) if dbi is not None else None, _money(r[cri]) if cri is not None else None
                amt = (credit or 0) - abs(debit or 0)
            if not d or not name or amt is None:
                skipped += 1
                continue
            base = f"{account_id}|{d}|{name}|{amt:.2f}"
            seen[base] = seen.get(base, 0) + 1  # identical rows on the same day are distinct purchases
            tx_id = "csv-" + hashlib.sha1(f"{base}|{seen[base]}".encode()).hexdigest()[:20]
            cat, src = categorize.classify(name, None, amt, None, rules)
            if is_card and amt > 0 and src == "default":
                cat = "Credit Card Payment"  # money coming *into* a card is a payment, not income
            cur = conn.execute(
                """INSERT OR IGNORE INTO transactions(id, account_id, date, name, merchant, amount,
                       category, category_source, confidence, source) VALUES(?,?,?,?,?,?,?,?,?, 'csv')""",
                (tx_id, account_id, d, name, None, amt, cat, src, categorize.confidence(cat, src)),
            )
            if cur.rowcount:
                imported += 1
            else:
                skipped += 1
        conn.commit()
    return {"imported": imported, "skipped": skipped}
