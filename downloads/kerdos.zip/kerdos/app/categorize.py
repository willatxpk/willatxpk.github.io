"""Expense categorization.

Priority (highest first):
  1. A category you set by hand on a transaction        (source = user)
  2. Your own rules ("merchant contains X -> category")  (source = rule)
  3. Built-in keyword rules for well-known merchants     (source = builtin)
  4. Plaid's personal_finance_category                   (source = plaid)
  5. Sign-based fallback (Income / Other)                (source = default)
"""
import re

from . import db

CATEGORIES = [
    "Income", "Housing", "Utilities", "Phone & Internet", "Groceries", "Dining",
    "Transportation", "Shopping", "Subscriptions", "Entertainment", "Health",
    "Insurance", "Travel", "Personal Care", "Education", "Gifts & Donations",
    "Fees & Interest", "Taxes", "Loan Payment", "Credit Card Payment",
    "Transfer", "Investments", "Other",
]

# Not counted as spending (money moving between your own accounts, or income).
NON_SPENDING = {"Income", "Transfer", "Credit Card Payment", "Investments"}

# Categories that look like bills when they recur.
BILL_CATEGORIES = {
    "Housing", "Utilities", "Phone & Internet", "Subscriptions", "Insurance",
    "Loan Payment", "Credit Card Payment", "Health", "Education", "Entertainment",
}

BUILTIN_RULES = [
    (r"payroll|direct dep|salary|paycheck|adp |gusto|dir dep", "Income"),
    (r"netflix|spotify|hulu|disney\s*\+|disney plus|hbo|max\.com|youtube premium|"
     r"apple\.com/bill|icloud|patreon|audible|paramount\+|peacock|chatgpt|openai|"
     r"claude\.ai|anthropic|dropbox|adobe|microsoft 365|xbox game pass|playstation plus|"
     r"nintendo online|amazon prime|prime video|siriusxm|new york times|nytimes", "Subscriptions"),
    (r"\brent\b|apartments?|property mgmt|mortgage|landlord|hoa dues", "Housing"),
    (r"electric|edison|pg&e|pge |power co|water (dept|utility)|gas co|socalgas|"
     r"utility|utilities|waste management|sewer", "Utilities"),
    (r"verizon|at&t|t-mobile|tmobile|comcast|xfinity|spectrum|cox comm|"
     r"google fi|mint mobile|internet|fiber", "Phone & Internet"),
    (r"geico|state farm|progressive|allstate|insurance|lemonade|usaa ins", "Insurance"),
    (r"student loan|navient|nelnet|mohela|aidvantage|sallie mae|auto loan|car loan|"
     r"toyota financial|honda financial|loan pmt", "Loan Payment"),
    (r"credit card payment|card payment|payment,? thank you|autopay payment|"
     r"cardmember serv|crd pmt|epay.*card", "Credit Card Payment"),
    (r"whole foods|trader joe|safeway|kroger|ralphs|vons|aldi|publix|wegmans|"
     r"sprouts|grocery|market basket|h-e-b|heb |food lion|albertsons", "Groceries"),
    (r"starbucks|mcdonald|chipotle|doordash|uber eats|ubereats|grubhub|restaurant|"
     r"cafe|coffee|pizza|taco|burger|sushi|panera|subway|chick-fil-a|bar & grill", "Dining"),
    (r"\bshell\b|chevron|exxon|\bmobil\b|arco|76 |bp |gas station|uber(?! eats)|lyft|"
     r"metro|transit|parking|toll|fastrak|dmv", "Transportation"),
    (r"amazon|amzn|target|walmart|costco|best buy|ebay|etsy|ikea|home depot|lowe's", "Shopping"),
    (r"cvs|walgreens|pharmacy|doctor|medical|dental|clinic|hospital|kaiser|optometr", "Health"),
    (r"airline|delta air|united air|american air|southwest|airbnb|hotel|marriott|"
     r"hilton|expedia|booking\.com", "Travel"),
    (r"gym|fitness|planet fitness|equinox|24 hour|barber|salon|spa ", "Personal Care"),
    (r"tuition|university|college|coursera|udemy|textbook", "Education"),
    (r"donation|charity|red cross|gofundme|church", "Gifts & Donations"),
    (r"overdraft|atm fee|service fee|interest charge|late fee|foreign transaction", "Fees & Interest"),
    (r"\birs\b|tax payment|franchise tax|dept of revenue", "Taxes"),
    (r"vanguard|fidelity|schwab|robinhood|betterment|wealthfront|e\*trade|etrade|"
     r"brokerage|ira contrib", "Investments"),
    (r"transfer|zelle|venmo|cash app|paypal transfer|xfer", "Transfer"),
    (r"movie|cinema|amc |regal|steam|ticketmaster|concert|spotify", "Entertainment"),
]
_BUILTIN = [(re.compile(p, re.I), c) for p, c in BUILTIN_RULES]

_PFC_DETAILED = {
    "FOOD_AND_DRINK_GROCERIES": "Groceries",
    "RENT_AND_UTILITIES_RENT": "Housing",
    "RENT_AND_UTILITIES_TELEPHONE": "Phone & Internet",
    "RENT_AND_UTILITIES_INTERNET_AND_CABLE": "Phone & Internet",
    "LOAN_PAYMENTS_CREDIT_CARD_PAYMENT": "Credit Card Payment",
    "GENERAL_SERVICES_INSURANCE": "Insurance",
    "GENERAL_SERVICES_EDUCATION": "Education",
    "GENERAL_SERVICES_AUTOMOTIVE": "Transportation",
    "GOVERNMENT_AND_NON_PROFIT_TAX_PAYMENT": "Taxes",
    "TRANSFER_OUT_INVESTMENT_AND_RETIREMENT_FUNDS": "Investments",
    "TRANSFER_IN_INVESTMENT_AND_RETIREMENT_FUNDS": "Investments",
    "ENTERTAINMENT_TV_AND_MOVIES": "Subscriptions",
    "ENTERTAINMENT_MUSIC_AND_AUDIO": "Subscriptions",
}
_PFC_PRIMARY = {
    "INCOME": "Income",
    "TRANSFER_IN": "Transfer",
    "TRANSFER_OUT": "Transfer",
    "LOAN_PAYMENTS": "Loan Payment",
    "BANK_FEES": "Fees & Interest",
    "ENTERTAINMENT": "Entertainment",
    "FOOD_AND_DRINK": "Dining",
    "GENERAL_MERCHANDISE": "Shopping",
    "HOME_IMPROVEMENT": "Housing",
    "MEDICAL": "Health",
    "PERSONAL_CARE": "Personal Care",
    "GENERAL_SERVICES": "Other",
    "GOVERNMENT_AND_NON_PROFIT": "Gifts & Donations",
    "TRANSPORTATION": "Transportation",
    "TRAVEL": "Travel",
    "RENT_AND_UTILITIES": "Utilities",
}


def _pfc_parts(pfc):
    parts = (pfc or "").split("|") + ["", "", ""]
    return parts[0], parts[1], parts[2]


def from_plaid(pfc):
    """pfc is 'PRIMARY|DETAILED|CONFIDENCE' as stored."""
    if not pfc:
        return None
    primary, detailed, _ = _pfc_parts(pfc)
    return _PFC_DETAILED.get(detailed) or _PFC_PRIMARY.get(primary)


def confidence(cat, src, pfc=None):
    """How sure we are: high | medium | low. Low ones show up in the Sort tab."""
    if src in ("user", "rule", "match"):
        return "high"
    if src == "learned":
        return "medium"  # learned from your sorts: shown under "probably right" in Sort
    if src == "default" or cat == "Other":
        return "low"
    if src == "builtin":
        return "high"
    level = _pfc_parts(pfc)[2]
    if level in ("VERY_HIGH", "HIGH"):
        return "high"
    if level == "MEDIUM":
        return "medium"
    if level in ("LOW", "UNKNOWN"):
        return "low"
    return "medium"  # older rows without a stored level


MIN_RULE_LEN = 2


def _loose(s):
    """Lowercase, punctuation to spaces, single spaces: 'DES:PAYROLL  ID:9' -> 'des payroll id 9'."""
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9&+]+", " ", (s or "").lower())).strip()


def match_texts(name, merchant):
    """Every form a rule may be compared against: the raw description, a punctuation-free
    version, and the cleaned-up merchant key that 'Teach it' builds rules from."""
    raw = f"{merchant or ''} {name or ''}".lower()
    return (raw, _loose(raw), merchant_key(name, merchant), merchant_key(name), merchant_key(merchant or ""))


def rule_matches(pattern, *texts):
    """Long rules match anywhere in the description. Short ones (2-3 characters, like "ov")
    must be a whole word, so "ov" matches "OV 1234" but not "MOVIE" or "GOVERNMENT"."""
    if not pattern:
        return False
    if len(pattern) <= 3:
        rx = re.compile(r"(?<![a-z0-9])" + re.escape(pattern) + r"(?![a-z0-9])")
        return any(rx.search(t or "") for t in texts)
    return any(pattern in (t or "") for t in texts)


def unsure_sql(alias="", medium=False):
    """The one definition of 'the app isn't sure about this transaction': what the Sort page shows and what
    its badge counts, so the two can never disagree.

    Left out on purpose: anything you set yourself or a rule or a matched transfer set; the app's own
    bookkeeping lines for shared costs (they are rebuilt automatically, so sorting one would never stick);
    and things the learner has confidently filed under Other (those sit with the 'probably right' ones)."""
    p = alias + "." if alias else ""
    levels = f"{p}confidence = 'low' OR {p}confidence IS NULL" + (f" OR {p}confidence = 'medium'" if medium else "")
    return (f"coalesce({p}category_source, '') NOT IN ('user', 'rule', 'match', 'split') "
            f"AND coalesce({p}source, '') != 'split' "
            f"AND ({levels} OR ({p}category = 'Other' AND coalesce({p}category_source, '') != 'learned'))")


def teach_pattern(name, merchant):
    """What 'Teach it' remembers. Plaid's clean merchant name when there is one ("shake shack");
    otherwise the first three words of the description, so a memo or reference number doesn't
    make the rule too specific to ever match again."""
    if merchant:
        key = merchant_key(merchant)
        if len(key) >= MIN_RULE_LEN:
            return key
    words = merchant_key(name).split()
    out, content = [], 0
    for w in words:  # three meaningful words; little words like "to"/"of" ride along
        out.append(w)
        if w not in ("to", "of", "for", "from", "at", "the", "and", "des", "zelle", "venmo", "paypal"):
            content += 1
        if content == 3:
            break
    return " ".join(out) or (name or "").lower()[:30]


def load_rules():
    return [
        (r["pattern"].lower(), r["category"])
        for r in db.rows("SELECT pattern, category FROM rules ORDER BY length(pattern) DESC")
    ]


def classify(name, merchant, amount, plaid_category, rules=None):
    cat, src = _classify(name, merchant, amount, plaid_category, rules)
    return canonical(cat), src  # categories you've combined always land in the combined one


# ------------------------------------------------------- combining ----
def aliases():
    return db.get_setting("category_aliases", {}) or {}


def canonical(cat):
    a, n = aliases(), 0
    while cat in a and n < 10:
        cat, n = a[cat], n + 1
    return cat


def all_categories():
    """The category list you see: built-ins and your own, minus ones merged into others."""
    a = aliases()
    base = [c for c in CATEGORIES if c not in a]
    for c in sorted(set(db.get_setting("custom_categories", []) or [])):
        if c not in a and c not in base:
            base.append(c)
    return base


def apply_alias_sets():
    """A combined category inherits behaviour from what went into it (bill, not-spending...)."""
    for src, dst in aliases().items():
        for s in (NON_SPENDING, BILL_CATEGORIES):
            if src in s:
                s.add(dst)


def merge(sources, target):
    """Combine `sources` into `target` everywhere: transactions (even ones you set), rules,
    bills, goals, the essentials list, and future auto-categorising. Undoable."""
    import json as _json
    from datetime import datetime as _dt
    target = (target or "").strip()[:40]
    sources = [s for s in dict.fromkeys(sources or []) if s and s != target]
    if not target or not sources:
        raise ValueError("Pick at least one category to combine and a name for the result")
    marks = ",".join("?" * len(sources))
    hist = {"target": target, "sources": sources, "at": _dt.now().isoformat(timespec="seconds"),
            "aliases": aliases(), "custom": db.get_setting("custom_categories", []) or [],
            "essentials": db.get_setting("essential_categories"),
            "tx": [[r["id"], r["category"]] for r in db.rows(
                f"SELECT id, category FROM transactions WHERE category IN ({marks})", sources)],
            "rules": [[r["id"], r["category"]] for r in db.rows(
                f"SELECT id, category FROM rules WHERE category IN ({marks})", sources)],
            "bills": [[r["id"], r["category"]] for r in db.rows(
                f"SELECT id, category FROM bills WHERE category IN ({marks})", sources)],
            "goals": []}
    with db.lock():
        conn = db.get()
        conn.execute(f"UPDATE transactions SET category = ? WHERE category IN ({marks})", (target, *sources))
        conn.execute(f"UPDATE rules SET category = ? WHERE category IN ({marks})", (target, *sources))
        conn.execute(f"UPDATE bills SET category = ? WHERE category IN ({marks})", (target, *sources))
        for g in conn.execute("SELECT id, params FROM goals WHERE kind = 'spend_cap'").fetchall():
            p = _json.loads(g["params"] or "{}")
            if p.get("category") in sources:
                hist["goals"].append([g["id"], g["params"]])
                p["category"] = target
                conn.execute("UPDATE goals SET params = ? WHERE id = ?", (_json.dumps(p), g["id"]))
        conn.commit()
    ess = hist["essentials"]
    if ess is not None and any(s in ess for s in sources):
        db.set_setting("essential_categories", [c for c in ess if c not in sources] + ([target] if target not in ess else []))
    elif ess is None:
        from . import cashflow
        default = cashflow.DEFAULT_ESSENTIALS
        if any(s in default for s in sources):
            db.set_setting("essential_categories", [c for c in default if c not in sources] + [target])
    a = aliases()
    for k, v in list(a.items()):
        if v in sources:
            a[k] = target
    for s in sources:
        a[s] = target
    a.pop(target, None)
    db.set_setting("category_aliases", a)
    custom = [c for c in hist["custom"] if c not in sources]
    if target not in CATEGORIES and target not in custom:
        custom.append(target)
    db.set_setting("custom_categories", custom)
    apply_alias_sets()
    history = db.get_setting("merge_history", []) or []
    history.append(hist)
    db.set_setting("merge_history", history[-20:])
    return {"moved": len(hist["tx"]), "target": target, "sources": sources}


def unmerge_last():
    """Undo the most recent combine: every transaction goes back to its old category."""
    history = db.get_setting("merge_history", []) or []
    if not history:
        raise ValueError("Nothing to undo")
    h = history.pop()
    with db.lock():
        conn = db.get()
        for tid, cat in h["tx"]:
            conn.execute("UPDATE transactions SET category = ? WHERE id = ?", (cat, tid))
        for rid, cat in h["rules"]:
            conn.execute("UPDATE rules SET category = ? WHERE id = ?", (cat, rid))
        for bid, cat in h["bills"]:
            conn.execute("UPDATE bills SET category = ? WHERE id = ?", (cat, bid))
        for gid, params in h["goals"]:
            conn.execute("UPDATE goals SET params = ? WHERE id = ?", (params, gid))
        conn.commit()
    db.set_setting("category_aliases", h["aliases"])
    db.set_setting("custom_categories", h["custom"])
    if h["essentials"] is None:
        db.execute("DELETE FROM settings WHERE key = 'essential_categories'")
    else:
        db.set_setting("essential_categories", h["essentials"])
    db.set_setting("merge_history", history)
    return {"restored": len(h["tx"]), "target": h["target"], "sources": h["sources"]}


def _classify(name, merchant, amount, plaid_category, rules=None):
    texts = match_texts(name, merchant)
    text = texts[0]
    rules = load_rules() if rules is None else rules
    for pattern, cat in rules:
        if rule_matches(pattern, *texts):
            return cat, "rule"
    for rx, cat in _BUILTIN:
        if rx.search(text):
            # An inflow that matches a merchant keyword is usually a refund; keep merchant category
            return cat, "builtin"
    cat = from_plaid(plaid_category)
    if cat:
        return cat, "plaid"
    return ("Income" if amount > 0 else "Other"), "default"


def recategorize_all():
    """Re-run classification for every transaction you haven't set by hand."""
    rules = load_rules()
    with db.lock():
        conn = db.get()
        txs = conn.execute(
            "SELECT id, name, merchant, amount, plaid_category FROM transactions "
            "WHERE coalesce(category_source, '') NOT IN ('user', 'split')"  # split = roommate shares
        ).fetchall()
        for t in txs:
            cat, src = classify(t["name"], t["merchant"], t["amount"], t["plaid_category"], rules)
            conn.execute(
                "UPDATE transactions SET category = ?, category_source = ?, confidence = ? WHERE id = ?",
                (cat, src, confidence(cat, src, t["plaid_category"]), t["id"]),
            )
        conn.commit()
    from . import learner, transfers  # paired card payments / transfers override keyword guesses
    transfers.match_all()
    learner.apply()  # then fill in what's still uncertain from what you've taught it
    return len(txs)


def merchant_key(name, merchant=None):
    """Normalise a description so recurring charges group together."""
    s = (merchant or name or "").lower()
    s = re.sub(r"https?://\S+", " ", s)
    s = re.sub(r"[#*]\s*\w*\d\w*", " ", s)        # reference numbers like #12345, *AB12C
    s = re.sub(r"\d{2}/\d{2}(/\d{2,4})?", " ", s)   # dates
    s = re.sub(r"\b\d+\b", " ", s)
    s = re.sub(r"\b(pos|debit|purchase|ach|ppd|web|id|ref|recurring|autopay|auto pay|"
               r"payment|pmt|online|bill|co|inc|llc|www|com)\b", " ", s)
    s = re.sub(r"[^a-z&+ ]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s[:40] or (name or "unknown").lower()[:40]


def backfill_confidence():
    """Rows saved before confidence existed get one from how they were categorised."""
    with db.lock():
        conn = db.get()
        rows_ = conn.execute("SELECT id, category, category_source, plaid_category FROM transactions "
                             "WHERE confidence IS NULL").fetchall()
        for r in rows_:
            conn.execute("UPDATE transactions SET confidence = ? WHERE id = ?",
                         (confidence(r["category"], r["category_source"], r["plaid_category"]), r["id"]))
        conn.commit()
    return len(rows_)
