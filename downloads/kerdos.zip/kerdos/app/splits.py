"""Shared costs with roommates.

When a roommate pays you back (Zelle/Venmo...), that money isn't income and isn't a transfer
between your accounts: it's their share of rent and utilities. Each repayment is spread over the
shared categories (in proportion to what you paid for them recently) as "their share" lines, so
Housing, Utilities etc. show only YOUR part everywhere in the app. The original repayment is
kept as a Transfer so it isn't double counted.

The share lines are ordinary transactions with source = 'split' (ids 'split:<original>:<n>'),
rebuilt from scratch every time apply() runs, so editing a roommate fixes the whole history.
"""
import re
import uuid
from collections import defaultdict
from datetime import date, timedelta

from . import categorize, db

PERSON_PAY = re.compile(r"zelle|venmo|cash ?app|square cash|paypal|apple cash|google pay|transfer from|"
                        r"from .* (via|on)|p2p|popmoney|chime", re.I)
WINDOW_DAYS = 90    # repayments are spread in proportion to the shared bills of the previous ~3 months


def roommates():
    return db.get_setting("roommates", []) or []


def _save(rms):
    db.set_setting("roommates", rms)


def default_shared():
    used = {r["category"] for r in db.rows("SELECT DISTINCT category FROM transactions")}
    pick = ["Housing"] + [c for c in ("Utilities & Phone", "Utilities", "Phone & Internet") if c in used][:1]
    return pick


def _matches(rm, t):
    # Raw bank text and the cleaned-up merchant key ("zelle payment from jane" -> "zelle from jane")
    text = f"{t['name']} {t['merchant'] or ''} | {categorize.merchant_key(t['name'], t['merchant'])}".lower()
    return any(p and p in text for p in rm.get("match", []))


def upsert(data):
    name = (data.get("name") or "").strip()[:40]
    match = [m.strip().lower() for m in (data.get("match") or []) if isinstance(m, str) and len(m.strip()) >= 3]
    if not name:
        raise ValueError("Give your roommate a name")
    if not match:
        raise ValueError("Add the text their payments show up with (at least 3 letters), e.g. 'zelle from jane'")
    share = float(data.get("share") or 50)
    if not 1 <= share <= 99:
        raise ValueError("Their share should be between 1% and 99%")
    cats = [categorize.canonical(c) for c in (data.get("categories") or []) if c] or default_shared()
    rms = roommates()
    rid = data.get("id") or uuid.uuid4().hex[:8]
    entry = {"id": rid, "name": name, "match": match, "share": share, "categories": cats,
             "since": data.get("since") or None}
    rms = [r for r in rms if r["id"] != rid] + [entry]
    _save(rms)
    apply()
    return entry


def remove(rid):
    _save([r for r in roommates() if r["id"] != rid])
    apply()


def _shared_spend(cats, start, end):
    """Money you paid out for these categories between start and end, by category (refunds excluded)."""
    if not cats:
        return {}
    marks = ",".join("?" * len(cats))
    rows = db.rows(f"SELECT category, -sum(amount) s FROM transactions WHERE category IN ({marks}) AND amount < 0 "
                   "AND pending = 0 AND coalesce(source, '') != 'split' AND date >= ? AND date <= ? GROUP BY category",
                   (*cats, start, end))
    return {r["category"]: r["s"] for r in rows if r["s"] and r["s"] > 0}


def apply():
    """Rebuild every 'their share' line. Safe to run any time."""
    rms = roommates()
    prev = db.get_setting("split_prev", {}) or {}   # what each repayment was categorised as before we took it over
    with db.lock():
        conn = db.get()
        conn.execute("DELETE FROM transactions WHERE source = 'split'")
        conn.commit()
    candidates = db.rows("SELECT t.* FROM transactions t JOIN accounts a ON a.id = t.account_id "
                         "WHERE t.amount > 0 AND t.pending = 0 AND coalesce(t.source, '') != 'split' ORDER BY t.date")
    owned = {}
    for t in candidates:
        rm = next((r for r in rms if _matches(r, t) and (not r.get("since") or t["date"] >= r["since"])), None)
        if rm:
            owned[t["id"]] = (t, rm)
    new_rows, takeover = [], []
    for tid, (t, rm) in owned.items():
        d = date.fromisoformat(t["date"][:10])
        spend = _shared_spend(rm["categories"], (d - timedelta(days=WINDOW_DAYS)).isoformat(), t["date"][:10])
        total = sum(spend.values())
        weights = ({c: v / total for c, v in spend.items()} if total
                   else {rm["categories"][0]: 1.0})
        left = round(t["amount"], 2)
        parts = sorted(weights.items(), key=lambda kv: -kv[1])
        for n, (cat, w) in enumerate(parts):
            amt = left if n == len(parts) - 1 else round(t["amount"] * w, 2)
            left = round(left - amt, 2)
            if abs(amt) < 0.01:
                continue
            new_rows.append((f"split:{tid}:{n}", t["account_id"], t["date"], f"{rm['name']}'s share of {cat}",
                             rm["name"], amt, cat))
        takeover.append(t)
    new_rows = [r + ("roommate_share",) for r in new_rows]
    kinds = {t["id"]: "roommate" for t in takeover}
    # Partner cost sharing: share lines for what each of you paid, and transfers that settle the tab
    from . import partner
    new_rows += [r + ("partner_share",) for r in partner.split_rows()]
    for t in partner.settle_payments():
        if t["id"] not in owned:
            owned[t["id"]] = (t, None)
            takeover.append(t)
            kinds[t["id"]] = "partner_settle"
    restore = [k for k in prev if k not in owned]
    with db.lock():
        conn = db.get()
        for r in new_rows:
            conn.execute("INSERT OR REPLACE INTO transactions(id, account_id, date, name, merchant, amount, category, "
                         "category_source, confidence, pending, source, notes, pair_id, pair_kind) "
                         "VALUES(?,?,?,?,?,?,?, 'split', 'high', 0, 'split', NULL, NULL, ?)", r)
        for t in takeover:
            if t["id"] not in prev and t["category_source"] != "split":
                prev[t["id"]] = [t["category"], t["category_source"], t["confidence"]]
            conn.execute("UPDATE transactions SET category = 'Transfer', category_source = 'split', confidence = 'high', "
                         "pair_id = NULL, pair_kind = ? WHERE id = ?", (kinds[t["id"]], t["id"]))
        for tid in restore:  # roommate removed or changed: give the repayment its old category back
            cat, src, conf = prev.pop(tid)
            conn.execute("UPDATE transactions SET category = ?, category_source = ?, confidence = ?, pair_kind = NULL "
                         "WHERE id = ? AND category_source = 'split'", (cat, src, conf, tid))
        conn.commit()
    db.set_setting("split_prev", prev)
    return len(new_rows)


def suggestions(today=None):
    """People who send you money regularly: likely roommates."""
    today = today or date.today()
    since = (today - timedelta(days=200)).isoformat()
    rows = db.rows("SELECT t.name, t.merchant, t.amount, t.date, t.category_source FROM transactions t "
                   "JOIN accounts a ON a.id = t.account_id WHERE t.amount > 0 AND t.pending = 0 "
                   "AND a.type = 'depository' AND t.pair_id IS NULL AND coalesce(t.source, '') != 'split' "
                   "AND t.category IN ('Transfer', 'Income', 'Other') AND t.date >= ?", (since,))
    known = [m for r in roommates() for m in r["match"]]
    groups = defaultdict(list)
    for r in rows:
        text = f"{r['name']} {r['merchant'] or ''}"
        if not PERSON_PAY.search(text) or _matches({"match": known}, r):
            continue
        groups[categorize.merchant_key(r["name"], r["merchant"])].append(r)
    out = []
    for key, rs in groups.items():
        months = {r["date"][:7] for r in rs}
        if len(months) < 2:
            continue
        sample = max(rs, key=lambda r: r["date"])
        out.append({"key": key, "example": sample["name"], "payments": len(rs), "months": len(months),
                    "total": round(sum(r["amount"] for r in rs), 2),
                    "per_month": round(sum(r["amount"] for r in rs) / len(months), 2),
                    "match": key.strip()[:40]})
    out.sort(key=lambda s: -s["total"])
    return out[:6]


def ledger(rm, months=6, today=None):
    """Month by month: their share of the shared bills vs what they paid you."""
    today = today or date.today()
    out, running = [], 0.0
    y, m = today.year, today.month
    keys = []
    for _ in range(months):
        keys.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    keys.reverse()
    since = rm.get("since") or ""
    if not since:  # start the tab when their repayments start, not before
        first = db.row("SELECT min(date) d FROM transactions WHERE source = 'split' AND pair_kind = 'roommate_share' AND merchant = ?", (rm["name"],))["d"]
        since = first[:7] + "-01" if first else ""
    keys = [k for k in keys if not since or k >= since[:7]] or keys[-1:]
    for k in keys:
        start, end = k + "-01", k + "-31"
        owed = sum(_shared_spend(rm["categories"], max(start, since), end).values()) * rm["share"] / 100 \
            if (not since or end >= since) else 0
        paid = db.row("SELECT coalesce(sum(amount), 0) s FROM transactions WHERE source = 'split' AND pair_kind = 'roommate_share' AND merchant = ? "
                      "AND date LIKE ?", (rm["name"], k + "%"))["s"]
        running += owed - paid
        out.append({"month": k, "owed": round(owed, 2), "paid": round(paid, 2), "balance": round(running, 2)})
    return out


def summary(today=None):
    today = today or date.today()
    rms = []
    for r in roommates():
        led = ledger(r, 6, today)
        # Only completed months settle up; the current month is still in progress
        settled = led[-2]["balance"] if len(led) > 1 else 0
        rms.append({**r, "ledger": led, "balance": settled, "this_month": led[-1]})
    cats = sorted({c for r in rms for c in r["categories"]})
    year_ago = (today - timedelta(days=365)).isoformat()
    covered = db.row("SELECT coalesce(sum(amount), 0) s FROM transactions WHERE source = 'split' AND pair_kind = 'roommate_share' AND date >= ?",
                     (year_ago,))["s"]
    return {"roommates": rms, "suggestions": suggestions(today), "default_categories": default_shared(),
            "categories": categorize.all_categories(), "shared_categories": cats,
            "covered_last_year": round(covered, 2)}
