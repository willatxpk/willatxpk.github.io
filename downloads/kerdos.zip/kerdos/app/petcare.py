"""Looking after the companion: food, water and play, what it is thinking, and the colours you paint things.

None of this is a chore with a penalty. Needs run down slowly (you choose how slowly), the companion
never gets sick, and its health and growth still come only from your real money goals. Caring for it
builds a bond, and the bond unlocks tricks and colour themes.
"""
import hashlib
import re
import time
from datetime import date, datetime

from . import db

# pace: (label, hours for food / water / fun to run from full to empty)
PACES = {
    "relaxed": ("Relaxed (lasts a few days)", 120, 96, 72),
    "normal": ("Normal (lasts a day or two)", 48, 36, 24),
    "lively": ("Lively (lasts a few hours)", 12, 8, 6),
}
FOODS = {
    "pet": [
        {"id": "carrot", "emoji": "🥕", "name": "Carrot", "food": 35, "water": 0, "fun": 0},
        {"id": "apple", "emoji": "🍎", "name": "Apple", "food": 28, "water": 10, "fun": 0},
        {"id": "fish", "emoji": "🐟", "name": "Fish", "food": 45, "water": 0, "fun": 0},
        {"id": "cheese", "emoji": "🧀", "name": "Cheese", "food": 40, "water": 0, "fun": 5},
        {"id": "berry", "emoji": "🍓", "name": "Strawberry", "food": 20, "water": 12, "fun": 6},
        {"id": "cookie", "emoji": "🍪", "name": "Cookie", "food": 12, "water": 0, "fun": 25},
    ],
    "plant": [
        {"id": "plantfood", "emoji": "🌿", "name": "Plant food", "food": 45, "water": 0, "fun": 0},
        {"id": "compost", "emoji": "🍂", "name": "Compost", "food": 32, "water": 5, "fun": 5},
        {"id": "sun", "emoji": "☀️", "name": "Sunbeam", "food": 8, "water": 0, "fun": 35},
        {"id": "song", "emoji": "🎵", "name": "A song", "food": 0, "water": 0, "fun": 28},
    ],
}
LABELS = {
    "pet": {"food": ["🍽", "Food"], "water": ["💧", "Water"], "fun": ["🎾", "Fun"]},
    "plant": {"food": ["🌱", "Nutrients"], "water": ["💧", "Water"], "fun": ["☀️", "Sunshine"]},
}
# bond points needed, name, what reaching it unlocks: (kind, id, description)
BOND = [
    (0, "Just met", None),
    (15, "Friendly", ("trick", "spin", "a spin when you pet it")),
    (40, "Buddies", ("theme", "sunset", "the Sunset colour theme")),
    (80, "Good friends", ("trick", "flip", "a backflip")),
    (140, "Close friends", ("theme", "forest", "the Forest colour theme")),
    (220, "Best friends", ("trick", "dance", "a little dance")),
    (330, "Inseparable", ("theme", "galaxy", "the Galaxy colour theme")),
]
FREE_THEMES = ["classic", "pastel"]
PLAY_BOND_PER_DAY = 6
PAINT_KEYS = {"body", "belly", "cheeks", "eyes", "hat", "leaf", "flower", "pot", "wall", "floor", "trim",
              "curtain", "frame", "shelf", "rug", "lamp", "toy", "bed", "bowl"}


def clean_colors(data):
    """Only known things, only #rrggbb: these values are written straight into the room picture."""
    out = {}
    if isinstance(data, dict):
        for k, v in data.items():
            if k in PAINT_KEYS and isinstance(v, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", v):
                out[k] = v.lower()
    return out


def _care(comp):
    c = comp.get("care")
    if not isinstance(c, dict):
        c = comp["care"] = {"food": 65.0, "water": 65.0, "fun": 65.0, "at": time.time(), "bond": 0, "pace": "relaxed"}
    return c


def _settle(c, now):
    """Run the needs down for the time that has passed since they were last touched."""
    _, hf, hw, hp = PACES.get(c.get("pace"), PACES["relaxed"])
    hours = max(0.0, (now - float(c.get("at") or now)) / 3600)
    for key, span in (("food", hf), ("water", hw), ("fun", hp)):
        c[key] = max(0.0, min(100.0, float(c.get(key, 65)) - 100.0 * hours / span))
    c["at"] = now


def _bond_level(points):
    return max(i for i, (need, _, _) in enumerate(BOND) if points >= need)


def craving(c, comp, kind, today=None):
    """One favourite a day (the same all day), until it has had it."""
    today = today or date.today()
    if c.get("craved_day") == today.isoformat() or kind not in FOODS:
        return None
    options = [f for f in FOODS[kind] if f["food"] >= 20]
    seed = hashlib.sha256(f"{today.isoformat()}|{comp.get('name') or ''}|{kind}".encode()).digest()
    return options[seed[0] % len(options)]


def view(comp, kind, stage, now=None, today=None):
    """What the Goals page shows. Read-only: nothing is saved just by looking."""
    kind = kind if kind in FOODS else "pet"
    c = dict(_care({"care": dict(comp["care"])} if isinstance(comp.get("care"), dict) else {}))
    _settle(c, now or time.time())
    points = int(c.get("bond", 0))
    lv = _bond_level(points)
    unlocked = [u for _, _, u in BOND[:lv + 1] if u]
    nxt = BOND[lv + 1] if lv + 1 < len(BOND) else None
    want = craving(c, comp, kind, today)
    egg = kind == "pet" and stage == 0
    return {
        "food": round(c["food"]), "water": round(c["water"]), "fun": round(c["fun"]),
        "pace": c.get("pace") if c.get("pace") in PACES else "relaxed",
        "paces": [{"key": k, "label": v[0]} for k, v in PACES.items()],
        "labels": LABELS[kind], "egg": egg,
        "foods": [] if egg else [{k: f[k] for k in ("id", "emoji", "name", "food", "fun")} for f in FOODS[kind]],
        "craving": None if egg or not want else {"id": want["id"], "emoji": want["emoji"], "name": want["name"]},
        "bond": {
            "points": points, "level": lv, "name": BOND[lv][1], "floor": BOND[lv][0],
            "next": nxt[0] if nxt else None, "next_name": nxt[1] if nxt else None,
            "next_unlock": nxt[2][2] if nxt else None,
            "tricks": [u[1] for u in unlocked if u[0] == "trick"],
            "themes": FREE_THEMES + [u[1] for u in unlocked if u[0] == "theme"],
            "locked_themes": [{"id": u[1], "at": name} for _, name, u in BOND[lv + 1:] if u and u[0] == "theme"],
        },
    }


def act(comp, kind, stage, data, now=None, today=None):
    """Feed, water, play or change the pace. Changes comp["care"] in place and says what happened."""
    if kind not in FOODS:
        raise ValueError("Adopt a companion first")
    now = now or time.time()
    day = (today or date.today()).isoformat()
    c = _care(comp)
    _settle(c, now)
    action = data.get("action")
    res = {"action": action, "bond": 0}
    before = _bond_level(int(c.get("bond", 0)))

    def bond(n):
        c["bond"] = int(c.get("bond", 0)) + n
        res["bond"] += n

    if action == "pace":
        if data.get("pace") not in PACES:
            raise ValueError("Unknown pace")
        c["pace"] = data["pace"]
        return res
    egg = kind == "pet" and stage == 0
    if egg and action in ("feed", "water"):
        raise ValueError("It hasn't hatched yet. It hatches at level 2.")
    if action == "feed":
        food = next((f for f in FOODS[kind] if f["id"] == data.get("food")), None)
        if not food:
            raise ValueError("Unknown food")
        main = "fun" if food["fun"] > food["food"] else "food"
        if c[main] >= 95:
            res["full"] = True
            return res
        want = craving(c, comp, kind, today)
        hungry = c[main] < 70
        for k in ("food", "water", "fun"):
            c[k] = min(100.0, c[k] + food[k])
        if hungry:
            bond(2)
        if want and want["id"] == food["id"]:
            bond(3)
            c["craved_day"] = day
            res["craved"] = True
        res["food"] = food["name"]
    elif action == "water":
        if c["water"] >= 95:
            res["full"] = True
            return res
        if c["water"] < 70:
            bond(2)
        c["water"] = 100.0
    elif action == "play":
        try:
            n = max(1, min(10, int(data.get("n") or 1)))
        except (TypeError, ValueError):
            n = 1
        c["fun"] = min(100.0, c["fun"] + 8 * n)
        if c.get("play_day") != day:
            c["play_day"], c["play_n"] = day, 0
        gain = min(max(0, PLAY_BOND_PER_DAY - int(c.get("play_n", 0))), n)
        c["play_n"] = int(c.get("play_n", 0)) + gain
        if gain:
            bond(gain)
    else:
        raise ValueError("Unknown action")
    if c.get("visit_day") != day:  # a little extra for the first hello of the day
        c["visit_day"] = day
        bond(2)
        res["visit"] = True
    after = _bond_level(int(c.get("bond", 0)))
    if after > before:
        res["level_up"] = BOND[after][1]
        res["unlock"] = "; ".join(u[2] for _, _, u in BOND[before + 1:after + 1] if u)
    return res


def thoughts(state, comp, now=None):
    """What the companion is thinking: its needs first, then real things about your money, then daydreams.

    Each thought is {icon, text, kind, link?}. The room shows the icon in a bubble; the page shows the text.
    """
    kind = state.get("kind")
    if kind not in FOODS:
        return []
    care = state["care"]
    pet = kind == "pet"
    out = []

    def add(icon, text, why, link=None):
        out.append({"icon": icon, "text": text, "kind": why, "link": link})

    if care["egg"]:
        add("🥚", "…it's warm in here. I'll hatch when you reach level 2.", "idle")
    else:
        if care["food"] < 15:
            add("🍽", "My tummy is rumbling so loudly!" if pet else "My soil is completely out of nutrients.", "need")
        elif care["food"] < 40:
            add("🍽", "I'm getting hungry." if pet else "I could use some plant food.", "need")
        if care["water"] < 15:
            add("💧", "So thirsty… my bowl is empty." if pet else "My leaves are parched!", "need")
        elif care["water"] < 40:
            add("💧", "My water bowl is getting low." if pet else "A little water would be lovely.", "need")
        if care["fun"] < 15:
            add("🎾" if pet else "☀️", "I'm so bored. Play with me?" if pet else "It's gloomy in here. Some sunshine?", "need")
        elif care["fun"] < 40:
            add("🎾" if pet else "☀️", "Want to play?" if pet else "I'd enjoy a sunbeam or a song.", "need")
        want = care.get("craving")
        if want and care["food"] < 95:
            add(want["emoji"], f"I keep thinking about {want['name'].lower()} today…", "craving")

    # ---- real things about your money
    goals = state.get("goals") or []
    for g in goals:
        if g["status"] == "missed":
            add("😟", f"We went over on “{g['name']}” this time. Next month is a fresh start.", "money", "#goals")
        elif g["status"] == "behind":
            add("📉", f"We're a little behind on “{g['name']}”. A small step counts.", "money", "#goals")
    for g in goals:
        if g.get("streak", 0) >= 2:
            add("🔥", f"{g['streak']} months in a row on “{g['name']}”!", "money", "#goals")
        elif g["status"] == "done":
            add("🏆", f"We did it: “{g['name']}”!", "money", "#goals")
        elif g["status"] == "ahead":
            add("⭐", f"We're ahead on “{g['name']}”.", "money", "#goals")
    if not goals:
        add("🎯", "Shall we set a goal together?", "money", "#goals")
    try:
        from . import checkin
        n = db.row("SELECT count(*) AS n FROM transactions WHERE coalesce(category_source, '') "
                   "NOT IN ('user', 'rule', 'match') AND (confidence = 'low' OR category = 'Other')")["n"]
        if n:
            add("🫧", f"{n} purchase{'s are' if n != 1 else ' is'} waiting to be sorted. Sorting earns me coins!", "money", "#sort")
        if not any(c["week"] == checkin.week_id(date.today()) for c in checkin.history()):
            add("📝", "This week's check-in is ready when you are.", "money", "#checkin")
        alerts = db.row("SELECT count(*) AS n FROM alerts WHERE is_read = 0")["n"]
        if alerts:
            add("🔔", f"There {'are' if alerts != 1 else 'is'} {alerts} alert{'s' if alerts != 1 else ''} to look at.", "money", "#bills")
    except Exception:  # noqa: BLE001  (a thought is never worth breaking the page for)
        pass
    for slot in (state.get("room") or {}).get("slots", []):
        nxt = slot.get("next")
        if nxt and not nxt["locked"] and nxt["affordable"]:
            add("🛋", f"We can afford the {nxt['name'].lower()} now!", "money")
            break
    if state.get("next_level_xp"):
        add("🌱", f"{state['next_level_xp'] - state['xp']} more XP and I grow to level {state['level'] + 1}.", "money")

    # ---- daydreams
    hour = (datetime.fromtimestamp(now) if now else datetime.now()).hour
    if hour >= 22 or hour < 6:
        add("💤", "Zzz… it's late. Sleep well.", "idle")
    elif hour < 11:
        add("🌤", "Good morning!", "idle")
    if not care["egg"] and min(care["food"], care["water"], care["fun"]) >= 60:
        add("💖", "I feel great today." if pet else "I'm soaking it all in.", "idle")
    add("🎶", "La la la…", "idle")
    return out[:9]
