"""Pairs money moving between your own accounts.

A withdrawal from checking and a same-sized credit on a card a few days apart
is one card payment, not $X of spending plus $X of income. Pairs are labelled:

  card_payment  bank -> credit card
  debt_payment  bank -> loan
  investment    cash -> investment account
  transfer      anything else between your accounts (e.g. checking -> savings)
"""
import re
from datetime import date

from . import db

MAX_DAYS = 5
HINT = re.compile(r"payment|pmt|transfer|xfer|trnsfr|autopay|auto pay|e-?pay|thank you|deposit|withdraw|"
                  r"online banking|mobile banking|to crd|from chk|to sav|from sav|ach", re.I)
PAIRABLE_CATS = {"Credit Card Payment", "Transfer", "Loan Payment", "Investments"}


def _kind(out_type, in_type):
    if in_type == "credit":
        return "card_payment"
    if in_type == "loan":
        return "debt_payment"
    if in_type == "investment" and out_type != "investment":
        return "investment"
    return "transfer"


# category for (kind, side)
CATEGORY = {
    ("card_payment", "out"): "Credit Card Payment", ("card_payment", "in"): "Credit Card Payment",
    ("debt_payment", "out"): "Loan Payment", ("debt_payment", "in"): "Transfer",
    ("investment", "out"): "Investments", ("investment", "in"): "Investments",
    ("transfer", "out"): "Transfer", ("transfer", "in"): "Transfer",
}


def match_all():
    """Recompute every pair from scratch. Safe to run any time."""
    txs = db.rows(
        "SELECT t.id, t.date, t.amount, t.name, t.merchant, t.category, t.category_source, t.account_id, "
        "a.type AS acct_type FROM transactions t JOIN accounts a ON a.id = t.account_id "
        "WHERE t.pending = 0 AND coalesce(t.category_source, '') != 'split' ORDER BY t.date")
    ins = [t for t in txs if t["amount"] > 0.99]
    outs = [t for t in txs if t["amount"] < -0.99]
    by_amount = {}
    for o in outs:
        by_amount.setdefault(round(-o["amount"], 2), []).append(o)

    candidates = []
    for i in ins:
        for o in by_amount.get(round(i["amount"], 2), []):
            if o["account_id"] == i["account_id"]:
                continue
            gap = abs((date.fromisoformat(i["date"][:10]) - date.fromisoformat(o["date"][:10])).days)
            if gap > MAX_DAYS:
                continue
            text = f"{i['name']} {i['merchant'] or ''} {o['name']} {o['merchant'] or ''}"
            looks_like_move = (i["category"] in PAIRABLE_CATS or o["category"] in PAIRABLE_CATS
                               or HINT.search(text))
            if not looks_like_move:
                continue
            # Paycheck into checking matched to something else? never.
            if i["category"] == "Income" and i["category_source"] in ("user", "rule"):
                continue
            candidates.append((gap, i, o))

    candidates.sort(key=lambda c: c[0])
    used, pairs = set(), []
    for gap, i, o in candidates:
        if i["id"] in used or o["id"] in used:
            continue
        used.update((i["id"], o["id"]))
        pairs.append((i, o, _kind(o["acct_type"], i["acct_type"])))

    with db.lock():
        conn = db.get()
        # Forget old pairs; rows that were only categorised because of a pair get re-guessed below
        stale = [r[0] for r in conn.execute(
            "SELECT id FROM transactions WHERE category_source = 'match'")]
        conn.execute("UPDATE transactions SET pair_id = NULL, pair_kind = NULL WHERE pair_id IS NOT NULL "
                     "AND coalesce(category_source, '') != 'split'")
        paired_ids = set()
        for i, o, kind in pairs:
            for t, side, other in ((i, "in", o), (o, "out", i)):
                paired_ids.add(t["id"])
                if t["category_source"] == "user":
                    conn.execute("UPDATE transactions SET pair_id = ?, pair_kind = ? WHERE id = ?",
                                 (other["id"], kind, t["id"]))
                else:
                    conn.execute(
                        "UPDATE transactions SET pair_id = ?, pair_kind = ?, category = ?, "
                        "category_source = 'match', confidence = 'high' WHERE id = ?",
                        (other["id"], kind, CATEGORY[(kind, side)], t["id"]))
        conn.commit()
    leftover = [s for s in stale if s not in paired_ids]
    if leftover:
        _reclassify(leftover)
    return len(pairs)


def _reclassify(ids):
    from . import categorize
    rules = categorize.load_rules()
    with db.lock():
        conn = db.get()
        for tid in ids:
            t = conn.execute("SELECT * FROM transactions WHERE id = ?", (tid,)).fetchone()
            cat, src = categorize.classify(t["name"], t["merchant"], t["amount"], t["plaid_category"], rules)
            conn.execute("UPDATE transactions SET category = ?, category_source = ?, confidence = ? WHERE id = ?",
                         (cat, src, categorize.confidence(cat, src, t["plaid_category"]), tid))
        conn.commit()
