"""Subscription checkup: what you pay for, what it costs per year, price hikes, possible
duplicates, free trials that turned paid, and 'cancel by' reminders.

The app can't see whether you *use* a service, so instead it asks you to review each one every
6 months (keep or cancel) and remembers your answer.
"""
from collections import defaultdict
from datetime import date, timedelta

from . import alerts, bills, categorize, db

NOT_SUBSCRIPTIONS = {"Housing", "Utilities", "Insurance", "Loan Payment", "Credit Card Payment", "Transfer",
                     "Investments", "Taxes", "Income", "Phone & Internet"}
REVIEW_EVERY_DAYS = 182


def _reviews():
    return db.get_setting("subscription_reviews", {}) or {}


def _save_reviews(r):
    db.set_setting("subscription_reviews", r)


def _history(b):
    """Every charge in this subscription's stream, oldest first: [(date, amount)]."""
    rows = db.rows("SELECT date, amount, name, merchant FROM transactions WHERE amount < 0 AND pending = 0 "
                   "AND date >= ? ORDER BY date", ((date.today() - timedelta(days=800)).isoformat(),))
    return [(r["date"], -r["amount"]) for r in rows
            if categorize.merchant_key(r["name"], r["merchant"]) == b["merchant"]]


def checkup(today=None):
    today = today or date.today()
    reviews = _reviews()
    subs = []
    for b in bills.list_bills():
        if b["status"] != "active" or b["category"] in NOT_SUBSCRIPTIONS or b["id"].startswith(("liab:", "pay:")):
            continue
        if b["merchant"].startswith("xfer:"):
            continue
        hist = _history(b)
        yearly = round(bills.monthly_equivalent(b) * 12, 2)
        flags = []
        if len(hist) >= 2:
            first_amt, last_amt = hist[0][1], hist[-1][1]
            if last_amt > first_amt * 1.04 and last_amt - first_amt >= 0.5:
                flags.append({"kind": "price_up", "text": f"Price went up from ${first_amt:,.2f} to ${last_amt:,.2f} "
                                                          f"since {hist[0][0][:7]} (+{(last_amt / first_amt - 1) * 100:.0f}%)"})
        if hist:
            first_paid = date.fromisoformat(hist[0][0][:10])
            tiny = [h for h in hist if h[1] <= 1.5]
            if tiny and len(hist) > len(tiny):
                flags.append({"kind": "trial", "text": "Started with a $0-1 charge and then switched to the full price: "
                                                       "a free trial that turned paid?"})
            elif (today - first_paid).days <= 75 and len(hist) <= 3:
                flags.append({"kind": "new", "text": f"New since {first_paid.strftime('%b %d')}. If this began as a free "
                                                     "trial, make sure you meant to keep it."})
        if b["category"] == "Fees & Interest":
            flags.append({"kind": "fee", "text": "This is a bank fee. Banks often waive it if you keep a minimum "
                                                 "balance or set up direct deposit, or you can switch to a no-fee account."})
        # Same service charged twice in one billing cycle
        by_month = defaultdict(int)
        for d, _ in hist:
            by_month[d[:7]] += 1
        if b["cadence"] == "monthly" and any(n >= 2 for n in list(by_month.values())[-3:]):
            flags.append({"kind": "double", "text": "Charged twice in the same month recently: possible double charge "
                                                    "or two accounts."})
        r = reviews.get(b["id"], {})
        due_review = not r.get("reviewed") or (today - date.fromisoformat(r["reviewed"])).days > REVIEW_EVERY_DAYS
        subs.append({"id": b["id"], "name": b["display_name"], "category": b["category"], "amount": b["avg_amount"],
                     "cadence": b["cadence"], "yearly": yearly, "next_date": b["next_date"],
                     "account_name": b.get("account_name"), "flags": flags,
                     "history": [{"date": d, "amount": round(a, 2)} for d, a in hist[-12:]],
                     "decision": r.get("decision"), "reviewed": r.get("reviewed"), "remind_on": r.get("remind_on"),
                     "needs_review": due_review})
    # Several services of the same kind (e.g. three video streamers) or the same name on two accounts
    names = defaultdict(list)
    for s in subs:
        names[s["name"].lower().split()[0] if s["name"] else ""].append(s)
    for group in names.values():
        if len(group) > 1:
            for s in group:
                s["flags"].append({"kind": "duplicate", "text": f"Looks like {len(group)} charges for the same "
                                                                f"service ({', '.join(g['name'] for g in group)})."})
    subs.sort(key=lambda s: -s["yearly"])
    keep = [s for s in subs if s["decision"] != "cancel"]
    return {"subscriptions": subs, "yearly_total": round(sum(s["yearly"] for s in keep), 2),
            "monthly_total": round(sum(s["yearly"] for s in keep) / 12, 2),
            "to_review": sum(1 for s in subs if s["needs_review"]),
            "flagged": sum(1 for s in subs if s["flags"])}


def decide(bill_id, decision, remind_on=None):
    """decision: keep | cancel. 'cancel' sets a reminder (default: 2 days before it renews)."""
    if decision not in ("keep", "cancel", "undo"):
        raise ValueError("Pick keep or cancel")
    reviews = _reviews()
    if decision == "undo":
        reviews.pop(bill_id, None)
        _save_reviews(reviews)
        return {}
    b = db.row("SELECT * FROM bills WHERE id = ?", (bill_id,))
    if not b:
        raise ValueError("Subscription not found")
    entry = {"decision": decision, "reviewed": date.today().isoformat()}
    if decision == "cancel":
        if not remind_on and b["next_date"]:
            remind_on = (date.fromisoformat(b["next_date"]) - timedelta(days=2)).isoformat()
        entry["remind_on"] = remind_on or date.today().isoformat()
    reviews[bill_id] = entry
    _save_reviews(reviews)
    return entry


def check_reminders(today=None):
    """Raise 'cancel X before it renews' alerts on the reminder date, and a nudge if it charged anyway."""
    today = today or date.today()
    for bill_id, r in _reviews().items():
        if r.get("decision") != "cancel" or not r.get("remind_on"):
            continue
        b = db.row("SELECT * FROM bills WHERE id = ?", (bill_id,))
        if not b:
            continue
        if date.fromisoformat(r["remind_on"]) <= today:
            alerts.add(f"cancel:{bill_id}:{r['remind_on']}", "cancel_reminder",
                       f"Reminder: cancel {b['display_name']}",
                       f"You marked it to cancel. It renews around {b['next_date']} for ~${b['avg_amount']:,.2f}.", "warn")
        if b["last_date"] and b["last_date"] > r["reviewed"]:
            alerts.add(f"stillcharging:{bill_id}:{b['last_date']}", "cancel_reminder",
                       f"{b['display_name']} charged you again",
                       f"${b['last_amount']:,.2f} on {b['last_date']}, after you marked it to cancel. "
                       "Check that the cancellation went through.", "warn")
