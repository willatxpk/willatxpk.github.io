"""Goals, scoring, and the companion (plant or pet) that thrives when you hit them.

Goal kinds
  contribute  put $X into something this calendar year (e.g. max out a Roth IRA)
  save_rate   keep X% of income each month
  spend_cap   spend at most $X/month in a category
  balance     grow an account (or several) to $X
  payoff      pay a card/loan down to $0
"""
import calendar
import json
import re
from datetime import date

from . import categorize, db, finance, planner

KINDS = ("contribute", "save_rate", "spend_cap", "balance", "payoff")
SORTS_PER_COIN = 10  # every 10 transactions you categorise by hand earn 1 coin
LEVELS = [0, 40, 100, 180, 280, 400, 550, 730, 950, 1200, 1500]  # XP needed for level 1..11
UNLOCKS = {
    2: [("pot", "terracotta"), ("pot", "ocean"), ("pot", "midnight")],
    4: [("accent", "ladybug"), ("accent", "butterfly"), ("accent", "snail")],
    6: [("hat", "party"), ("hat", "beanie"), ("hat", "crown")],
    8: [("glow", "fireflies"), ("glow", "sparkles"), ("glow", "moon")],
}


# ------------------------------------------------------------------ CRUD ----
def list_goals(include_inactive=False):
    q = "SELECT * FROM goals" + ("" if include_inactive else " WHERE active = 1") + " ORDER BY id"
    out = db.rows(q)
    for g in out:
        g["params"] = json.loads(g["params"] or "{}")
    return out


def create(data):
    kind = data.get("kind")
    if kind not in KINDS:
        raise ValueError("Unknown goal type")
    name = (data.get("name") or "").strip()[:80]
    target = float(data.get("target") or 0)
    params = data.get("params") or {}
    if kind == "spend_cap" and not params.get("category"):
        raise ValueError("Pick a category")
    if kind in ("balance", "payoff") and not params.get("account_ids"):
        raise ValueError("Pick at least one account")
    if kind == "payoff":
        start = sum(_balance(a) for a in params["account_ids"])
        if start <= 0:
            raise ValueError("That account doesn't have a balance to pay off")
        params["start_balance"] = start
        target = 0
    if kind == "balance" and target <= 0:
        raise ValueError("Enter a target amount")
    if kind == "save_rate" and not 0 < target < 100:
        raise ValueError("Enter a percentage between 1 and 99")
    if kind in ("contribute", "spend_cap") and target <= 0:
        raise ValueError("Enter a target amount")
    params["created"] = date.today().isoformat()
    if params.get("account_ids"):  # remember what the accounts look like, so reconnects don't break the goal
        rows = {a["id"]: a for a in db.rows("SELECT id, name, institution, subtype, mask FROM accounts")}
        params["account_hints"] = [_account_hint(rows[i]) for i in params["account_ids"] if i in rows]
    if kind == "balance":
        params["start_balance"] = sum(_balance(a) for a in params["account_ids"])
    cur = db.execute("INSERT INTO goals(kind, name, target, params) VALUES(?,?,?,?)",
                     (kind, name or default_name(kind, target, params), target, json.dumps(params)))
    return cur.lastrowid


def default_name(kind, target, params):
    return {
        "contribute": f"Put ${target:,.0f} in this year",
        "save_rate": f"Save {target:g}% of income",
        "spend_cap": f"{params.get('category', 'Spending')} under ${target:,.0f}/mo",
        "balance": f"Reach ${target:,.0f}",
        "payoff": "Pay it off",
    }[kind]


def retarget_name(name, old, new):
    """'Keep Dining under $420/mo' with 420 -> 600 becomes 'Keep Dining under $600/mo'."""
    def repl(m):
        raw = m.group(0)
        try:
            val = float(raw.replace(",", ""))
        except ValueError:
            return raw
        if abs(val - (old or 0)) > 0.005:
            return raw
        if "," in raw or new >= 1000:
            return f"{new:,.0f}" if new == int(new) else f"{new:,.2f}"
        return f"{new:g}"
    return re.sub(r"\d[\d,]*(?:\.\d+)?", repl, name)


def _balance(account_id):
    a = db.row("SELECT current_balance FROM accounts WHERE id = ?", (account_id,))
    return (a or {}).get("current_balance") or 0


# -------------------------------------------------------------- progress ----
def _month_keys(year, upto_month):
    return [f"{year:04d}-{m:02d}" for m in range(1, upto_month + 1)]


def _monthly_income_spending(months):
    out = {}
    for m in finance.spending_by_month(24):
        out[m["month"]] = m
    return {k: out.get(k, {"income": 0, "spending": 0, "categories": {}}) for k in months}


def _contributions(goal, year):
    """Money that went toward a 'contribute' goal this calendar year.

    Plaid usually can't see transactions *inside* investment accounts, so besides deposits
    that land in the chosen account we also count withdrawals from your other accounts that
    went to that account's institution (e.g. "VANGUARD BUY" from checking for a Vanguard Roth).
    Returns (total, list of counted items).
    """
    p = goal["params"]
    start, end = f"{year}-01-01", f"{year}-12-31"
    counted, seen = [], set()
    from . import investments
    acct_ids, diag = resolve_accounts(goal)

    # 1) Contributions your brokerage reports from inside the account (exact, when Plaid has them)
    removed = {str(x) for x in p.get("excluded") or []}   # things you said not to count toward this goal
    exact_all = investments.ira_contributions(acct_ids, year)
    exact = [e for e in exact_all if str(e["id"]) not in removed]
    for e in exact_all:
        counted.append({"id": e["id"], "date": e["date"], "amount": round(e["amount"], 2), "name": e["name"],
                        "why": "reported by your brokerage", "kind": "brokerage"})
    diag["brokerage_reported"] = len(exact)
    diag["brokerage_data"] = investments.has_activity(acct_ids)

    def same_as_exact(d, amount):
        """A bank withdrawal that the brokerage already reported (same amount within a week)."""
        dd = date.fromisoformat(d[:10])
        return any(abs(e["amount"] - amount) < 0.01 and abs((date.fromisoformat(e["date"][:10]) - dd).days) <= 7
                   for e in exact)

    def add(r, amount, why):
        if r["id"] in seen:
            return
        seen.add(r["id"])
        if r.get("pair_id"):
            seen.add(r["pair_id"])
        if same_as_exact(r["date"], amount):
            return  # already counted from the brokerage side
        counted.append({"id": r["id"], "date": r["date"], "amount": round(amount, 2),
                        "name": (r.get("merchant") or r["name"])[:40], "why": why, "kind": "bank",
                        "category": r.get("category")})
        diag["bank_side"] = diag.get("bank_side", 0) + 1

    if acct_ids:
        marks = ",".join("?" * len(acct_ids))
        for r in db.rows(f"SELECT id, date, amount, name, merchant, pair_id, category FROM transactions "
                         f"WHERE account_id IN ({marks}) AND amount > 0 AND date BETWEEN ? AND ?",
                         (*acct_ids, start, end)):
            add(r, r["amount"], "deposit into the account")
        # Money sent to the account's institution from your bank/cards
        insts = {(a["institution"] or "").strip().lower() for a in db.rows(
            f"SELECT institution FROM accounts WHERE id IN ({marks}) AND type = 'investment'", acct_ids)}
        insts = {i.split()[0] for i in insts if i and i != "manual"}  # "Vanguard" from "Vanguard Group"
        for inst in insts:
            for r in db.rows(
                    f"SELECT t.id, t.date, t.amount, t.name, t.merchant, t.pair_id, t.category FROM transactions t "
                    f"JOIN accounts a ON a.id = t.account_id LEFT JOIN transactions p ON p.id = t.pair_id "
                    f"WHERE t.amount < 0 AND a.type != 'investment' AND t.date BETWEEN ? AND ? "
                    f"AND t.category IN ('Investments', 'Transfer') "
                    f"AND (lower(t.name) LIKE ? OR lower(coalesce(t.merchant, '')) LIKE ?) "
                    f"AND (p.account_id IS NULL OR p.account_id IN ({marks}))",
                    (start, end, f"%{inst}%", f"%{inst}%", *acct_ids)):
                add(r, -r["amount"], f"sent to {inst.title()}")
    text = (p.get("match_text") or "").strip().lower()
    if text:
        for r in db.rows("SELECT id, date, amount, name, merchant, pair_id, category FROM transactions "
                         "WHERE amount < 0 AND date BETWEEN ? AND ? "
                         "AND (lower(name) LIKE ? OR lower(coalesce(merchant,'')) LIKE ?)",
                         (start, end, f"%{text}%", f"%{text}%")):
            add(r, -r["amount"], f'description contains "{text}"')
    for e in db.rows("SELECT * FROM goal_entries WHERE goal_id = ? AND date BETWEEN ? AND ?",
                     (goal["id"], start, end)):
        counted.append({"id": f"entry-{e['id']}", "date": e["date"], "amount": e["amount"],
                        "name": e["note"] or "Logged by you", "why": "logged by you", "entry_id": e["id"],
                        "kind": "entry"})
    counted.sort(key=lambda c: c["date"])
    diag["excluded"] = [c for c in counted if str(c["id"]) in removed]
    counted = [c for c in counted if str(c["id"]) not in removed]
    return round(sum(c["amount"] for c in counted), 2), counted, diag


def _account_hint(a):
    return {"institution": a.get("institution"), "subtype": (a.get("subtype") or "").lower(),
            "mask": a.get("mask"), "name": a.get("name")}


def resolve_accounts(goal):
    """The goal's linked accounts, found again if a bank was reconnected (new account IDs).

    Matches the account it was linked to by institution + account type (+ last 4 digits), and
    for IRA goals with no link at all, picks your Roth/IRA accounts. Fixes the link for next time.
    """
    p = goal["params"]
    want = p.get("account_ids") or []
    rows = {a["id"]: a for a in db.rows("SELECT id, name, institution, subtype, mask, type FROM accounts "
                                        "WHERE is_hidden = 0")}
    found = [i for i in want if i in rows]
    hints = p.get("account_hints") or []
    diag = {"linked": [rows[i]["name"] for i in found], "repaired": False, "missing": len(want) - len(found)}
    if len(found) < len(want) or not want:
        invest = [a for a in rows.values() if a["type"] == "investment"]
        picks = []
        for h in hints:
            m = [a for a in invest if (a["institution"] or "").lower() == (h.get("institution") or "").lower()
                 and (a["subtype"] or "").lower() == (h.get("subtype") or "")
                 and (not h.get("mask") or not a["mask"] or a["mask"] == h["mask"])]
            picks += [a["id"] for a in m if a["id"] not in found and a["id"] not in picks]
        if not picks and not hints and re.search(r"\b(roth|ira)\b", goal["name"] or "", re.I):
            kind = "roth" if re.search(r"roth", goal["name"], re.I) else "ira"
            picks = [a["id"] for a in invest if kind in (a["subtype"] or "").lower()]
        if picks:
            found += picks
            diag.update(linked=[rows[i]["name"] for i in found], repaired=True, missing=0)
            p["account_ids"] = found
            p["account_hints"] = [_account_hint(rows[i]) for i in found]
            db.execute("UPDATE goals SET params = ? WHERE id = ?", (json.dumps(p), goal["id"]))
    elif not hints and found:  # remember what the accounts look like, for future reconnects
        p["account_hints"] = [_account_hint(rows[i]) for i in found]
        db.execute("UPDATE goals SET params = ? WHERE id = ?", (json.dumps(p), goal["id"]))
    return found, diag


def evaluate(goal, today=None):
    """Returns progress, pace, a status (ahead | on_track | behind | done | missed) and monthly checks."""
    today = today or date.today()
    kind, target, p = goal["kind"], goal["target"] or 0, goal["params"]
    created = date.fromisoformat(p.get("created", today.isoformat()))
    res = {"id": goal["id"], "kind": kind, "name": goal["name"], "target": target, "params": p,
           "checks": [], "milestones": 0}
    if kind == "contribute":
        year = today.year
        done, counted, diag = _contributions(goal, year)
        res["counted"] = counted
        res["excluded"] = diag.pop("excluded", [])
        res["diag"] = diag
        days_in_year = 366 if calendar.isleap(year) else 365
        frac_year = today.timetuple().tm_yday / days_in_year
        expected = target * frac_year
        res.update(progress=done, progress_pct=min(1, done / target) if target else 0, expected=round(expected, 2),
                   remaining=round(max(0, target - done), 2),
                   per_month_needed=round(max(0, target - done) / max(1, 12 - today.month + 1), 2))
        res["status"] = "done" if done >= target else ("ahead" if done >= expected * 1.05 else
                                                       "on_track" if done >= expected * 0.85 else "behind")
        res["milestones"] = int(min(1, done / target) * 10) if target else 0
        res["unit"] = "$"
    elif kind in ("save_rate", "spend_cap"):
        start_month = max(created.replace(day=1), date(today.year, 1, 1))
        keys = [k for k in _month_keys(today.year, today.month) if k >= start_month.strftime("%Y-%m")]
        if len(keys) < 3:  # show some history even for a brand-new goal (not scored)
            back = [m["month"] for m in finance.spending_by_month(4) if m["month"] < (keys[0] if keys else "9")]
            keys = back[-(3 - len(keys)):] + keys if back else keys
        data = _monthly_income_spending(keys)
        current = today.strftime("%Y-%m")
        left_out = {}
        if kind == "spend_cap":
            removed = [str(x) for x in p.get("excluded") or []]
            if removed:
                marks = ",".join("?" * len(removed))
                for r in db.rows(f"SELECT substr(date, 1, 7) AS m, sum(-amount) AS total FROM transactions WHERE id IN ({marks}) "
                                 "AND category = ? AND pending = 0 GROUP BY m", (*removed, p["category"])):
                    left_out[r["m"]] = r["total"] or 0
            rows = db.rows("SELECT id, date, name, merchant, amount, category FROM transactions WHERE category = ? "
                           "AND pending = 0 AND substr(date, 1, 7) = ? ORDER BY date DESC LIMIT 80", (p["category"], current))
            items = [{"id": r["id"], "date": r["date"], "name": (r["merchant"] or r["name"])[:40], "amount": round(-r["amount"], 2),
                      "kind": "bank", "category": r["category"], "why": ""} for r in rows]
            res["counted"] = [i for i in items if str(i["id"]) not in removed]
            res["excluded"] = [i for i in items if str(i["id"]) in removed]
        for k in keys:
            m = data[k]
            if kind == "save_rate":
                inc = m["income"]
                value = (inc - m["spending"]) / inc * 100 if inc > 0 else None
                ok = value is not None and value >= target
            else:
                value = m["categories"].get(p["category"], 0) - left_out.get(k, 0)
                if k == current:  # judge the running month against a prorated cap
                    dim = calendar.monthrange(today.year, today.month)[1]
                    ok = value <= target * today.day / dim * 1.1 or value <= target
                else:
                    ok = value <= target
            res["checks"].append({
                "month": k, "value": None if value is None else round(value, 1), "pass": bool(ok),
                "partial": k == current, "scored": k >= created.strftime("%Y-%m") and k != current,
            })
        scored = [c for c in res["checks"] if c["scored"]]
        cur = next((c for c in res["checks"] if c["partial"]), None)
        streak = 0
        for c in reversed(scored):
            if not c["pass"]:
                break
            streak += 1
        res.update(streak=streak, passed=sum(c["pass"] for c in scored), scored=len(scored),
                   current=cur["value"] if cur else None, unit="%" if kind == "save_rate" else "$")
        if cur is None or cur["value"] is None:
            res["status"] = "on_track"
        else:
            res["status"] = "on_track" if cur["pass"] else "behind"
            if kind == "spend_cap" and cur["value"] > target:
                res["status"] = "missed"
    elif kind == "balance":
        now = sum(_balance(a) for a in p["account_ids"])
        start = p.get("start_balance", 0)
        pct = 0 if target <= start else (now - start) / (target - start)
        res.update(progress=round(now, 2), progress_pct=max(0, min(1, now / target)) if target else 0,
                   remaining=round(max(0, target - now), 2), unit="$")
        res["milestones"] = int(max(0, min(1, pct)) * 10)
        res["status"] = "done" if now >= target else _pace_status(p.get("by_date"), created, today, pct)
    elif kind == "payoff":
        now = sum(_balance(a) for a in p["account_ids"])
        start = p.get("start_balance") or now or 1
        pct = max(0, min(1, 1 - now / start))
        res.update(progress=round(start - now, 2), progress_pct=pct, remaining=round(max(0, now), 2),
                   start_balance=start, unit="$")
        res["milestones"] = int(pct * 10)
        res["status"] = "done" if now <= 0.5 else _pace_status(p.get("by_date"), created, today, pct)
    return res


def _pace_status(by_date, created, today, pct):
    if not by_date:
        return "on_track" if pct > 0 else "behind"
    end = date.fromisoformat(by_date)
    span = max(1, (end - created).days)
    expected = min(1, max(0, (today - created).days / span))
    if today > end:
        return "missed"
    return "ahead" if pct >= expected + 0.05 else "on_track" if pct >= expected - 0.1 else "behind"


# ------------------------------------------------------------ companion ----
STATUS_HEALTH = {"done": 100, "ahead": 100, "on_track": 80, "behind": 35, "missed": 10}


def companion_state(today=None):
    today = today or date.today()
    goals = [evaluate(g, today) for g in list_goals()]
    comp = db.get_setting("companion") or {}
    xp, log = 0, []
    for g in goals:
        if g["kind"] in ("save_rate", "spend_cap"):
            for c in g["checks"]:
                if c["scored"]:
                    gained = 25 if c["pass"] else 0
                    xp += gained
                    log.append({"month": c["month"], "goal": g["name"], "pass": c["pass"], "xp": gained,
                                "text": _check_text(g, c)})
        else:
            xp += g["milestones"] * 12
            if g["milestones"]:
                log.append({"month": today.strftime("%Y-%m"), "goal": g["name"], "pass": True,
                            "xp": g["milestones"] * 12,
                            "text": f"{g['name']}: {int(g.get('progress_pct', 0) * 100)}% there"})
        already_met = g["kind"] == "balance" and g["params"].get("start_balance", 0) >= g["target"]
        if g["status"] == "done" and not already_met:
            xp += 50
            log.append({"month": today.strftime("%Y-%m"), "goal": g["name"], "pass": True, "xp": 50,
                        "text": f"Goal complete: {g['name']}"})
    # Extra care for goal-independent good habits: every month you kept money (saved > 0)
    for m in finance.spending_by_month(12)[:-1]:
        if m["income"] > 0 and m["income"] > m["spending"]:
            xp += 5
    level = max(i + 1 for i, need in enumerate(LEVELS) if xp >= need)
    # Coins (not XP) for sorting: categorising doesn't make the pet grow, but it does buy furniture
    sorted_n = db.row("SELECT count(*) n FROM transactions WHERE category_source = 'user'")["n"]
    sort_coins = sorted_n // SORTS_PER_COIN
    from . import checkin
    checkin_coins = checkin.coins_earned()
    sort_coins_only = sort_coins
    sort_coins += checkin_coins  # weekly check-ins also pay out coins (not XP)
    nxt = LEVELS[level] if level < len(LEVELS) else None
    health = round(sum(STATUS_HEALTH[g["status"]] for g in goals) / len(goals)) if goals else 60
    mood = "thriving" if health >= 80 else "content" if health >= 60 else "thirsty" if health >= 35 else "wilting"
    picks = comp.get("picks", {})
    pending = [{"level": lv, "options": [{"slot": s, "value": v} for s, v in opts]}
               for lv, opts in UNLOCKS.items() if level >= lv and str(lv) not in picks]
    log.sort(key=lambda e: e["month"], reverse=True)
    out = {
        "kind": comp.get("kind"), "name": comp.get("name"), "picks": picks,
        "xp": xp, "level": level, "level_floor": LEVELS[level - 1], "next_level_xp": nxt,
        "health": health, "mood": mood, "stage": _stage(level), "pending_unlocks": pending,
        "log": log[:24], "goals": goals,
        "coins": max(0, xp + sort_coins - comp.get("spent", 0)), "coins_earned": xp + sort_coins,
        "coins_from_sorting": sort_coins_only, "coins_from_checkins": checkin_coins, "sorted_total": sorted_n, "coins_spent": comp.get("spent", 0),
        "goals_done": sum(1 for g in goals if g["status"] == "done"),
        "room": room_state(comp, level, max(0, xp + sort_coins - comp.get("spent", 0))),
    }
    from . import petcare
    out["colors"] = petcare.clean_colors(comp.get("colors"))
    out["care"] = petcare.view(comp, comp.get("kind"), out["stage"])
    out["thoughts"] = petcare.thoughts(out, comp)
    return out


def _stage(level):
    return 0 if level <= 1 else 1 if level <= 3 else 2 if level <= 5 else 3 if level <= 7 else 4


def _check_text(g, c):
    month = date.fromisoformat(c["month"] + "-01").strftime("%b")
    if g["kind"] == "save_rate":
        v = "no income" if c["value"] is None else f"{c['value']:.0f}%"
        return f"{month}: saved {v} (goal {g['target']:g}%)"
    return f"{month}: {g['params'].get('category')} ${c['value']:,.0f} (cap ${g['target']:,.0f})"


# ----------------------------------------------------------------- room ----
# Coins: every XP point you earn is also a coin to spend on the room. Each slot has tiers;
# buying a higher tier upgrades it (you keep older ones and can switch back).
DECOR = {  # slot: [(item_id, name, price, min_level), ...] in upgrade order; tier 0 is free
    "home":   [("home_corner", "Cozy corner", 0, 1), ("home_studio", "Studio apartment", 250, 3),
               ("home_loft", "Sunny loft", 600, 5), ("home_cottage", "Garden cottage", 1100, 8),
               ("home_tree", "Treehouse", 1800, 11)],
    "wall":   [("wall_plain", "Plain wall", 0, 1), ("wall_stripe", "Striped wallpaper", 60, 1),
               ("wall_floral", "Floral wallpaper", 140, 3), ("wall_sky", "Night-sky mural", 320, 6)],
    "floor":  [("floor_bare", "Bare floor", 0, 1), ("floor_woven", "Woven rug", 50, 1),
               ("floor_plush", "Round plush rug", 120, 3), ("floor_persian", "Patterned rug", 260, 5)],
    "window": [("win_none", "No window", 0, 1), ("win_small", "Small window", 40, 1),
               ("win_curtain", "Window with curtains", 110, 2), ("win_bay", "Big window with a view", 240, 5)],
    "bed":    [("bed_none", "Nothing", 0, 1), ("bed_box", "Cardboard box", 30, 1), ("bed_cushion", "Floor cushion", 90, 2),
               ("bed_cozy", "Cozy bed", 180, 4), ("bed_canopy", "Canopy bed", 380, 7)],
    "lamp":   [("lamp_none", "No lamp", 0, 1), ("lamp_desk", "Little lamp", 45, 1),
               ("lamp_floor", "Floor lamp", 100, 3), ("lamp_string", "String lights", 210, 5)],
    "shelf":  [("shelf_none", "No shelf", 0, 1), ("shelf_small", "Small shelf", 70, 2),
               ("shelf_books", "Bookshelf", 160, 4), ("shelf_trophy", "Trophy shelf (shows goals completed)", 330, 7)],
    "art":    [("art_none", "Bare wall", 0, 1), ("art_doodle", "Framed doodle", 35, 1),
               ("art_landscape", "Landscape painting", 120, 3), ("art_gallery", "Gallery wall", 250, 6)],
    "buddy":  [("buddy_none", "Nothing", 0, 1), ("buddy_ball", "Toy ball", 25, 1), ("buddy_cactus", "Potted cactus", 80, 2),
               ("buddy_fish", "Aquarium", 300, 8)],
}
DECOR_INDEX = {item[0]: (slot, i, item) for slot, items in DECOR.items() for i, item in enumerate(items)}


def room_state(comp, level, coins):
    owned = set(comp.get("owned", []))
    equipped = dict(comp.get("equipped", {}))
    slots = []
    for slot, items in DECOR.items():
        eq = equipped.get(slot) if equipped.get(slot) in owned else items[0][0]
        equipped[slot] = eq
        cur_tier = DECOR_INDEX[eq][1]
        tiers = []
        for i, (iid, name, price, lvl) in enumerate(items):
            have = i == 0 or iid in owned
            tiers.append({"id": iid, "name": name, "price": price, "level": lvl, "owned": have,
                          "equipped": iid == eq, "locked": level < lvl, "affordable": coins >= price})
        nxt = next((t for t in tiers if not t["owned"]), None)
        slots.append({"slot": slot, "tiers": tiers, "tier": cur_tier, "next": nxt})
    total_tiers = sum(len(v) - 1 for v in DECOR.values())
    return {"equipped": equipped, "slots": slots, "owned_count": len(owned), "total_items": total_tiers,
            "layout": comp.get("layout") or {}}


def _clean_layout(data):
    """Where you dragged the furniture, the pet and its ball: small offsets inside the room picture."""
    def pair(v, n=2):
        if not isinstance(v, (list, tuple)) or len(v) < n:
            return None
        try:
            return [max(-400.0, min(400.0, float(x))) for x in v[:3]]
        except (TypeError, ValueError):
            return None
    out = {"furn": {}}
    if isinstance(data, dict):
        for slot, v in (data.get("furn") or {}).items():
            if (slot in DECOR or slot == "bowl") and pair(v):
                out["furn"][slot] = pair(v)[:2]
        for key in ("pet", "ball"):
            if pair(data.get(key)):
                out[key] = pair(data[key])
    return out


def set_companion(data):
    comp = db.get_setting("companion") or {}
    if data.get("buy"):
        iid = data["buy"]
        if iid not in DECOR_INDEX:
            raise ValueError("Unknown item")
        slot, tier, (_, name, price, lvl) = DECOR_INDEX[iid]
        state = companion_state()
        if iid in comp.get("owned", []):
            raise ValueError("You already have that")
        if state["level"] < lvl:
            raise ValueError(f"Unlocks at level {lvl}")
        if state["coins"] < price:
            raise ValueError(f"Needs {price} coins (you have {state['coins']})")
        comp.setdefault("owned", []).append(iid)
        comp["spent"] = comp.get("spent", 0) + price
        comp.setdefault("equipped", {})[slot] = iid
    if data.get("equip"):
        iid = data["equip"]
        if iid not in DECOR_INDEX:
            raise ValueError("Unknown item")
        slot, tier, _ = DECOR_INDEX[iid]
        if tier > 0 and iid not in comp.get("owned", []):
            raise ValueError("Buy it first")
        comp.setdefault("equipped", {})[slot] = iid
    if "layout" in data:
        comp["layout"] = _clean_layout(data["layout"])
    if data.get("kind") in ("plant", "pet"):
        comp["kind"] = data["kind"]
    if "name" in data:
        comp["name"] = (data.get("name") or "").strip()[:24]
    if data.get("pick_level") is not None:
        lv = int(data["pick_level"])
        opts = UNLOCKS.get(lv, [])
        choice = data.get("pick_value")
        if not any(v == choice for _, v in opts):
            raise ValueError("Not an option for that level")
        state = companion_state()
        if state["level"] < lv:
            raise ValueError("Not unlocked yet")
        comp.setdefault("picks", {})[str(lv)] = {"slot": opts[0][0], "value": choice}
    result = None
    if isinstance(data.get("care"), dict):  # feed, water, play, or change how fast needs run down
        from . import petcare
        state = companion_state()
        result = petcare.act(comp, state["kind"], state["stage"], data["care"])
    if "colors" in data:
        from . import petcare
        comp["colors"] = petcare.clean_colors(data["colors"])
    db.set_setting("companion", comp)
    if result is not None:
        state = companion_state()
        return {"care": state["care"], "thoughts": state["thoughts"], "result": result}
    return comp


def presets():
    """Suggested goals based on your data."""
    p = planner.get_profile()
    accts = finance.accounts(False)
    roth = [a for a in accts if (a.get("subtype") or "").lower() in ("roth", "roth ira")]
    lim = planner.LIMITS["ira"] + (planner.LIMITS["ira_catchup_50"] if (p.get("age") or 0) >= 50 else 0)
    avg = finance.averages(3)
    top_cats = [k for k in avg["categories"] if k not in ("Housing", "Loan Payment", "Taxes", "Insurance")][:3]
    out = [
        {"kind": "contribute", "name": "Max out my Roth IRA", "target": lim,
         "params": {"account_ids": [a["id"] for a in roth], "match_text": ""},
         "hint": ("Counts deposits into " + ", ".join(a["name"] for a in roth)) if roth
         else "Pick your Roth account, or type text that appears on the transfer (like VANGUARD)."},
        {"kind": "save_rate", "name": "Save 20% of my income", "target": 20, "params": {}},
        {"kind": "balance", "name": "Emergency fund: 6 months of essentials",
         "target": round((avg["essential"] or avg["spending"]) * 6, -2),
         "params": {"account_ids": [a["id"] for a in accts if a["type"] == "depository"
                                    and (a.get("subtype") or "") in ("savings", "money market")]}},
    ]
    for c in top_cats[:2]:
        out.append({"kind": "spend_cap", "name": f"Keep {c} under ${round(avg['categories'][c] * 0.85, -1):,.0f}/mo",
                    "target": round(avg["categories"][c] * 0.85, -1), "params": {"category": c}})
    debts = [a for a in accts if a["type"] in ("credit", "loan") and (a["current_balance"] or 0) > 0]
    for d in debts[:2]:
        if d["type"] == "loan":
            out.append({"kind": "payoff", "name": f"Pay off {d['name']}", "target": 0,
                        "params": {"account_ids": [d["id"]]}})
    return out


def categories():
    return categorize.CATEGORIES
