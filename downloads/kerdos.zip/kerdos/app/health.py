"""Connection health: is every number in the app fresh?

Checks each bank connection (Plaid errors, last sync), each account (balance age, quiet
transaction feeds, investment data), manual balances that need a refresh, and the app's own
housekeeping (background sync, backups). Problems become alerts so a broken connection never
quietly shows old numbers.
"""
from datetime import date, datetime, timedelta

from . import alerts, config, db

# Plaid error codes -> (what it means, what to do, can the user fix it by reconnecting?)
ERRORS = {
    "ITEM_LOGIN_REQUIRED": ("The bank wants you to sign in again (password change, new security step, "
                            "or the connection simply expired).", "Tap Reconnect and sign in.", True),
    "PENDING_EXPIRATION": ("Your consent for this connection is about to expire.", "Tap Reconnect to renew it.", True),
    "PENDING_DISCONNECT": ("The bank is about to cut this connection off.", "Tap Reconnect to keep it.", True),
    "USER_PERMISSION_REVOKED": ("Access was turned off from the bank's side.", "Tap Reconnect to allow it again.", True),
    "ACCESS_NOT_GRANTED": ("Some data wasn't shared when you connected.", "Tap Reconnect and allow all accounts.", True),
    "NO_ACCOUNTS": ("The bank didn't share any accounts.", "Tap Reconnect and tick the accounts you want.", True),
    "ITEM_LOCKED": ("The bank locked the login after too many tries.", "Unlock it on the bank's website, then Reconnect.", True),
    "INSTITUTION_DOWN": ("The bank's systems are down.", "Nothing to do: the app retries automatically.", False),
    "INSTITUTION_NOT_RESPONDING": ("The bank isn't answering right now.", "Nothing to do: the app retries automatically.", False),
    "INSTITUTION_NOT_AVAILABLE": ("The bank isn't available through Plaid right now.", "The app retries automatically.", False),
    "PRODUCT_NOT_READY": ("The bank is still preparing your data.", "Give it a few minutes; the next sync picks it up.", False),
    "RATE_LIMIT_EXCEEDED": ("Too many requests in a short time.", "The next scheduled sync will work.", False),
}
INV_STATUS = {
    "needs_consent": "Holdings and contributions aren't shared yet: use Grant access on the Investments page.",
    "plan": "Your Plaid account doesn't include Investments yet (enable it in the Plaid Dashboard).",
    "not_ready": "The brokerage is still preparing investment data.",
    "error": "The last investments sync failed.",
}

STALE_BALANCE_DAYS = 2      # Plaid balances refresh at every sync (every few hours)
MANUAL_STALE_DAYS = 60      # remind you to update hand-entered balances


def _days_since(ts, now):
    if not ts:
        return None
    try:
        t = datetime.fromisoformat(str(ts).replace("Z", ""))
    except ValueError:
        return None
    return round((now - t).total_seconds() / 86400, 1)


def _expected_gap(account_id, today):
    """How often this account normally gets transactions (median gap over the last 6 months, in days)."""
    rows = db.rows("SELECT DISTINCT substr(date, 1, 10) d FROM transactions WHERE account_id = ? AND date >= ? "
                   "ORDER BY d", (account_id, (today - timedelta(days=180)).isoformat()))
    days = [date.fromisoformat(r["d"]) for r in rows]
    if len(days) < 6:
        return None
    gaps = sorted((b - a).days for a, b in zip(days, days[1:]))
    return gaps[len(gaps) // 2]


def check(today=None, now=None):
    now = now or datetime.now()
    today = today or now.date()
    utc_now = now + (datetime.utcnow() - datetime.now())
    cfg = config.load()
    interval = float(cfg.get("sync_interval_hours", 6))
    items = db.rows("SELECT item_id, institution, last_sync, error, created_at FROM items")
    accts = db.rows("SELECT * FROM accounts WHERE is_hidden = 0 ORDER BY institution, name")
    last_tx = {r["account_id"]: r["d"] for r in db.rows(
        "SELECT account_id, max(substr(date, 1, 10)) d FROM transactions WHERE pending = 0 GROUP BY account_id")}
    try:
        held = {r["account_id"] for r in db.rows("SELECT DISTINCT account_id FROM holdings")}
    except Exception:  # noqa: BLE001 - table appears after the first investments sync
        held = set()

    issues = []

    def issue(level, title, detail, fix=None, item_id=None, account_id=None):
        issues.append({"level": level, "title": title, "detail": detail, "fix": fix,
                       "item_id": item_id, "account_id": account_id})

    conns = []
    for it in items:
        name = it["institution"] or "Bank"
        age_h = (_days_since(it["last_sync"], now) or 0) * 24 if it["last_sync"] else None
        code = (it["error"] or "").strip()
        meaning = ERRORS.get(code)
        state = "ok"
        if code:
            state = "action" if (meaning[2] if meaning else True) else "waiting"
            what, todo, _ = meaning or (f"The last sync failed ({code}).", "Try Reconnect; if it keeps failing, "
                                        "disconnect and connect it again.", True)
            issue("danger" if state == "action" else "warn", f"{name}: {what}", todo,
                  "reconnect" if state == "action" else None, item_id=it["item_id"])
        elif not it["last_sync"]:
            state = "waiting"
            issue("warn", f"{name} hasn't synced yet", "Press Sync now.", "sync", item_id=it["item_id"])
        elif age_h > max(interval * 4, 30):
            state = "stale"
            issue("warn", f"{name} last synced {age_h / 24:.0f} days ago",
                  "The app normally syncs every few hours. Press Sync now; if it fails, Reconnect.", "sync",
                  item_id=it["item_id"])
        inv = db.get_setting(f"inv_status:{it['item_id']}")
        has_inv = any(a["item_id"] == it["item_id"] and a["type"] == "investment" for a in accts)
        if has_inv and inv and inv != "ok":
            issue("warn" if inv != "error" else "danger", f"{name}: investment data missing", INV_STATUS.get(inv, inv),
                  "grant" if inv == "needs_consent" else None, item_id=it["item_id"])
        conns.append({"item_id": it["item_id"], "institution": name, "last_sync": it["last_sync"],
                      "hours_since_sync": round(age_h, 1) if age_h is not None else None,
                      "error": code or None, "meaning": meaning[0] if meaning else None,
                      "state": state, "investments": inv if has_inv else None})

    rows = []
    for a in accts:
        bal_age = _days_since(a.get("updated_at"), utc_now)  # SQLite datetime('now') is UTC
        last = last_tx.get(a["id"])
        quiet_days = (today - date.fromisoformat(last)).days if last else None
        flags = []
        if a["source"] == "plaid":
            if bal_age is not None and bal_age > STALE_BALANCE_DAYS:
                flags.append(f"balance is {bal_age:.0f} days old")
            gap = _expected_gap(a["id"], today) if a["type"] in ("depository", "credit") else None
            if gap is not None and quiet_days is not None and quiet_days > max(14, gap * 4):
                flags.append(f"no new transactions in {quiet_days} days (usually every {max(gap, 1)} days)")
                issue("warn", f"{a['name']}: transactions stopped arriving",
                      f"Nothing new in {quiet_days} days, but this account usually has activity every "
                      f"{max(gap, 1)} day{'s' if gap > 1 else ''}. If you still use it, Reconnect the bank.",
                      "reconnect", item_id=a["item_id"], account_id=a["id"])
            if a["type"] == "investment" and a["id"] not in held:
                flags.append("no holdings data")
        elif a["source"] == "manual" and a["type"] != "credit":
            if bal_age is not None and bal_age > MANUAL_STALE_DAYS:
                flags.append(f"you last updated this {bal_age:.0f} days ago")
                issue("info", f"{a['name']}: balance may be out of date",
                      f"You entered it {bal_age:.0f} days ago. Update it on the Accounts page.", "accounts",
                      account_id=a["id"])
        rows.append({"id": a["id"], "name": a["name"], "institution": a["institution"], "mask": a["mask"],
                     "type": a["type"], "source": a["source"], "item_id": a["item_id"],
                     "balance_age_days": bal_age, "last_transaction": last, "quiet_days": quiet_days,
                     "flags": flags})

    # The app's own housekeeping
    last_sync = db.get_setting("last_sync")
    sync_age = _days_since(last_sync, now)
    if items and sync_age is not None and sync_age * 24 > max(interval * 4, 30):
        issue("warn", "Background syncing seems to have stopped",
              f"Last automatic sync was {sync_age:.0f} days ago. Is the app running on your PC? "
              "Restarting the PC (or run.bat) starts it again.", "sync")
    last_backup = db.get_setting("last_backup")
    backup_age = (today - date.fromisoformat(last_backup)).days if last_backup else None
    if backup_age is not None and backup_age > 3:
        issue("warn", "Backups are behind", f"Last backup was {backup_age} days ago.", "backup")

    order = {"danger": 0, "warn": 1, "info": 2}
    issues.sort(key=lambda i: order[i["level"]])
    worst = issues[0]["level"] if issues else "ok"
    return {"status": worst, "issues": issues, "connections": conns, "accounts": rows,
            "last_sync": last_sync, "last_backup": last_backup, "sync_interval_hours": interval,
            "plaid_configured": config.plaid_configured(cfg)}


def check_alerts(today=None):
    """Raise an alert (once per problem per week) for anything that needs you."""
    today = today or date.today()
    week = today.strftime("%G-W%V")
    for i in check(today)["issues"]:
        if i["level"] == "info":
            continue
        key = f"health:{i['item_id'] or i['account_id'] or ''}:{i['title'][:60]}:{week}"
        alerts.add(key, "connection", i["title"], i["detail"], i["level"])
