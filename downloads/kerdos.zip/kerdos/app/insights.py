"""Where your income went over the last year, and where things are heading."""
import re
from collections import defaultdict
from datetime import date, timedelta

from . import categorize, db, finance, planner


def _months_back(today, n):
    y, m = today.year, today.month
    out = []
    for _ in range(n):
        out.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    return list(reversed(out))


def year_summary(today=None, months=12, month=None):
    """Trailing `months` months, including the current partial month, or one month ("YYYY-MM")."""
    today = today or date.today()
    if month:
        if not re.fullmatch(r"\d{4}-\d{2}", month):
            raise ValueError("Month must look like 2026-10")
        keys, months = [month], 1
    else:
        keys = _months_back(today, months)
    start = keys[0] + "-01"
    txs = db.rows(
        "SELECT t.date, t.amount, t.category, t.pair_kind, a.type AS acct_type, a.subtype AS acct_subtype "
        "FROM transactions t JOIN accounts a ON a.id = t.account_id "
        "WHERE t.date >= ? AND t.pending = 0 AND a.is_hidden = 0", (start,))
    per_month = {k: {"month": k, "income": 0.0, "spending": 0.0, "invested": 0.0, "to_savings": 0.0} for k in keys}
    cat_totals = defaultdict(float)
    for t in txs:
        m = per_month.get(t["date"][:7])
        if m is None:
            continue
        cat, amt = t["category"] or "Other", t["amount"]
        if cat == "Income":
            m["income"] += amt
        elif cat == "Investments":
            if t["acct_type"] != "investment" and amt < 0:
                m["invested"] += -amt
        elif cat == "Transfer":
            if t["acct_type"] == "depository" and (t["acct_subtype"] or "") in ("savings", "money market", "cd", "hsa"):
                m["to_savings"] += amt
        elif cat not in categorize.NON_SPENDING:
            m["spending"] += -amt
            cat_totals[cat] += -amt
    # Custom categories that net to money *in* (e.g. "Interest", roommate paying you back) count as income
    extra_income = {k: -v for k, v in cat_totals.items() if v < 0}
    for k in extra_income:
        del cat_totals[k]
    income = sum(m["income"] for m in per_month.values()) + sum(extra_income.values())
    spending = sum(cat_totals.values())
    invested = sum(m["invested"] for m in per_month.values())
    saved = income - spending - invested

    ranked = sorted(cat_totals.items(), key=lambda kv: -kv[1])
    top, rest = ranked[:5], ranked[5:]
    slices = [{"key": k, "label": k, "amount": round(v, 2), "kind": "spending"} for k, v in top]
    if rest:
        slices.append({"key": "other_spending", "label": f"Other spending ({len(rest)} categories)",
                       "amount": round(sum(v for _, v in rest), 2), "kind": "spending",
                       "detail": [{"label": k, "amount": round(v, 2)} for k, v in rest]})
    slices.append({"key": "invested", "label": "Invested", "amount": round(invested, 2), "kind": "invested"})
    if saved > 0:
        slices.append({"key": "saved", "label": "Kept as savings", "amount": round(saved, 2), "kind": "saved"})

    monthly = []
    for m in per_month.values():
        inc = m["income"]
        monthly.append({
            "month": m["month"], "income": round(inc, 2), "spending": round(m["spending"], 2),
            "invested": round(m["invested"], 2), "to_savings": round(m["to_savings"], 2),
            "savings_rate": round((inc - m["spending"]) / inc, 4) if inc > 0 else None,
        })

    p = planner.get_profile()
    k401 = None
    if p.get("has_401k") and p.get("annual_income") and p.get("current_401k_pct"):
        k401 = round(p["annual_income"] * p["current_401k_pct"] / 100 * months / 12, 2)
    return {
        "start": start, "end": today.isoformat(), "months": months, "month": month,
        "income": round(income, 2), "extra_income": {k: round(v, 2) for k, v in extra_income.items()},
        "spending": round(spending, 2), "invested": round(invested, 2), "saved": round(saved, 2),
        "to_savings_accounts": round(sum(m["to_savings"] for m in per_month.values()), 2),
        "savings_rate": round((income - spending) / income, 4) if income > 0 else None,
        "slices": slices, "categories": [{"label": k, "amount": round(v, 2)} for k, v in ranked],
        "monthly": monthly, "payroll_401k_estimate": k401,
    }


def projection(years=10, annual_return=0.07, inflation=0.03, raise_rate=0.03, extra_monthly=0.0, today=None,
               changes=()):
    """Month-by-month simulation using your last 12 months as the starting habits.

    `changes` (for What-if): dicts with kind income | spending | invest | pretax401k | loan | one_time,
    applied from month `start` (0 = now). See whatif.py."""
    today = today or date.today()
    s = year_summary(today, 12)
    months_seen = sum(1 for m in s["monthly"] if m["income"] or m["spending"]) or 1
    income_m = s["income"] / months_seen
    spend_m = s["spending"] / months_seen
    invest_m = s["invested"] / months_seen + extra_monthly
    invest_rate = invest_m / income_m if income_m else 0

    accts = finance.accounts(include_hidden=False)
    cash = sum(a["current_balance"] or 0 for a in accts if a["type"] == "depository")
    invest = sum(a["current_balance"] or 0 for a in accts if a["type"] == "investment")
    other = sum(a["current_balance"] or 0 for a in accts if a["type"] == "other")
    cards = sum(a["current_balance"] or 0 for a in accts if a["type"] == "credit")
    libs = {r["account_id"]: r for r in db.rows("SELECT * FROM liabilities")}
    loans = [{"balance": a["current_balance"] or 0, "apr": (libs.get(a["id"]) or {}).get("apr") or 6.0}
             for a in accts if a["type"] == "loan" and (a["current_balance"] or 0) > 0]
    loan_total = sum(l["balance"] for l in loans)
    loan_apr = (sum(l["balance"] * l["apr"] for l in loans) / loan_total / 100) if loan_total else 0
    # What you currently pay toward loans each month (already inside spending)
    since = (today - timedelta(days=365)).isoformat()
    lp = db.row("SELECT -sum(t.amount) s FROM transactions t JOIN accounts a ON a.id = t.account_id "
                "WHERE t.category = 'Loan Payment' AND t.amount < 0 AND a.type != 'loan' AND t.date >= ?", (since,))
    loan_pay_m = ((lp or {}).get("s") or 0) / months_seen
    if loan_total and loan_pay_m <= loan_total * loan_apr / 12:
        loan_pay_m = loan_total * (loan_apr / 12 + 0.01)  # assume at least interest + 1%

    r = annual_return / 12
    points = [{"month": 0, "date": today.isoformat(), "cash": round(cash), "investments": round(invest),
               "debt": round(loan_total + cards), "net": round(cash + invest + other - loan_total - cards),
               "spending": round(spend_m * 12)}]
    debt_free = None if loan_total else 0
    milestones = {}
    # What-if extras
    new_loans, new_assets, flows = [], [], []
    for c in changes:
        if c["kind"] == "loan":
            new_loans.append({"start": c.get("start", 0), "balance": max(0.0, c["price"] - c.get("down", 0)),
                              "apr": c.get("apr", 0) / 100, "payment": c["payment"], "down": c.get("down", 0),
                              "started": False, "price": c["price"], "dep": c.get("depreciation")})
    for t in range(1, years * 12 + 1):
        g_inc = (1 + raise_rate) ** (t / 12)
        g_inf = (1 + inflation) ** (t / 12)
        income = income_m * g_inc
        spending = spend_m * g_inf
        if loan_total > 0:
            interest = loan_total * loan_apr / 12
            pay = min(loan_pay_m, loan_total + interest)
            loan_total = loan_total + interest - pay
            if loan_total <= 0.5:
                loan_total = 0
                debt_free = t
        elif debt_free:  # loans paid off during the projection: that payment is now free money
            spending = max(spending - loan_pay_m * g_inf, 0)
        contrib = invest_rate * income
        extra_cash = 0.0
        for c in changes:
            if c.get("start", 0) >= t:
                continue
            k = c["kind"]
            if k == "income":
                income += c["monthly"] * (1 + raise_rate) ** ((t - c.get("start", 0)) / 12)
            elif k == "spending":
                spending += c["monthly"] * g_inf
            elif k == "invest":
                contrib += c["monthly"]
            elif k == "pretax401k":
                contrib += c["monthly"]
                income -= c["monthly"] * (1 - c.get("tax_rate", 0.22))
            elif k == "one_time" and c.get("start", 0) == t - 1:
                extra_cash -= c["amount"]
        for ln in new_loans:
            if ln["start"] >= t:
                continue
            if not ln["started"]:
                ln["started"] = True
                extra_cash -= ln["down"]
                if ln["dep"] is not None:
                    new_assets.append({"value": ln["price"], "dep": ln["dep"]})
            if ln["balance"] > 0:
                interest = ln["balance"] * ln["apr"] / 12
                pay = min(ln["payment"], ln["balance"] + interest)
                ln["balance"] = max(0.0, ln["balance"] + interest - pay)
                spending += pay
        for a in new_assets:
            a["value"] *= (1 - a["dep"]) ** (1 / 12)
        leftover = income - spending - contrib
        if t <= 12:
            flows.append({"income": income, "spending": spending, "investing": contrib, "leftover": leftover})
        invest = invest * (1 + r) + contrib
        cash += leftover + extra_cash
        if cash < 0:  # shortfalls come out of investments
            invest += cash
            cash = 0
        new_debt = sum(ln["balance"] for ln in new_loans if ln["started"])
        new_value = sum(a["value"] for a in new_assets)
        net = cash + invest + other + new_value - loan_total - cards - new_debt
        for mark in (100_000, 250_000, 500_000, 1_000_000):
            if mark not in milestones and net >= mark and points[0]["net"] < mark:
                milestones[mark] = t
        if t % 3 == 0:
            d = date(today.year + (today.month - 1 + t) // 12, (today.month - 1 + t) % 12 + 1, 1)
            points.append({"month": t, "date": d.isoformat(), "cash": round(cash), "investments": round(invest),
                           "debt": round(loan_total + cards + new_debt), "net": round(net),
                           "spending": round(spending * 12), "deflator": round(g_inf, 4)})
    return {
        "assumptions": {
            "years": years, "annual_return": annual_return, "inflation": inflation, "raise_rate": raise_rate,
            "income_monthly": round(income_m, 2), "spending_monthly": round(spend_m, 2),
            "investing_monthly": round(invest_m, 2), "extra_monthly": extra_monthly,
            "loan_payment_monthly": round(loan_pay_m, 2), "loan_apr": round(loan_apr, 4),
            "months_of_history": months_seen,
        },
        "points": points,
        "history": finance.history(),
        "milestones": [{"amount": k, "months": v} for k, v in sorted(milestones.items())],
        "debt_free_months": debt_free,
        "first_year": {k: round(sum(f[k] for f in flows) / len(flows), 2) for k in flows[0]} if flows else {},
        "first_month": {k: round(v, 2) for k, v in flows[0].items()} if flows else {},
    }
