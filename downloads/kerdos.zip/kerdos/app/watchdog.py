"""Fee & odd-charge catcher: money leaking out without you noticing.

Flags (last 90 days): bank fees, credit-card interest, duplicate charges, subscription price
hikes, unusually large charges from a place you know, and refunds you're waiting for that
haven't arrived. You decide each one: Expected / Dispute it / Cancel it / Waiting for a refund.
Disputes and refunds are watched: when money comes back from the same merchant the flag
closes itself.
"""
import re
import statistics
from collections import defaultdict
from datetime import date, timedelta

from . import alerts, bills, categorize, db, subscriptions

FEE = re.compile(r"overdraft|\bnsf\b|insufficient fund|returned item|\batm fee|atm withdrawal fee|non-?network|"
                 r"foreign (transaction|exchange|txn)|intl? (transaction|txn) fee|international fee|"
                 r"(monthly|maintenance|service|account) (fee|charge)|late (fee|charge)|wire (transfer )?fee|"
                 r"cash advance fee|annual fee|paper statement|excess (withdrawal|transaction)|stop payment fee", re.I)
INTEREST = re.compile(r"interest charge|purchase interest|finance charge|interest charged|cash advance interest|"
                      r"int(erest)? chg|minimum interest", re.I)
LOOKBACK_DAYS = 90
REFUND_WAIT_DAYS = 30
SKIP_CATS = categorize.NON_SPENDING | {"Housing", "Loan Payment", "Taxes"}


def _decisions():
    return db.get_setting("watch_decisions", {}) or {}


def _save(d):
    db.set_setting("watch_decisions", d)


REFUND_WORDS = re.compile(r"(?<![a-z])(refund|return|returned|credit|reversal|reversed|adjustment|merchandise)(?![a-z])")


def _key(t):
    """Merchant key that treats 'BEST BUY REFUND' the same as 'BEST BUY'."""
    return " ".join(REFUND_WORDS.sub(" ", categorize.merchant_key(t["name"], t["merchant"])).split())


def _money_back(t, after, upto=None):
    """A credit from the same merchant after `after` (a refund or dispute credit)."""
    k = _key(t)
    rows = db.rows("SELECT * FROM transactions WHERE amount > 0 AND date >= ? AND coalesce(source, '') != 'split' "
                   "AND id != ?", (after, t["id"]))
    for r in rows:
        if _key(r) == k and r["amount"] >= min(abs(t["amount"]) * 0.4, abs(t["amount"]) - 0.01):
            if not upto or r["date"] <= upto:
                return r
    return None


def scan(today=None):
    today = today or date.today()
    since = (today - timedelta(days=LOOKBACK_DAYS)).isoformat()
    txs = db.rows("SELECT t.*, a.name AS account_name, a.type AS acct_type FROM transactions t "
                  "JOIN accounts a ON a.id = t.account_id WHERE t.date >= ? AND coalesce(t.source, '') != 'split' "
                  "ORDER BY t.date", (since,))
    flags = []

    def flag(fid, kind, title, detail, t=None, amount=None, actions=("expected", "dispute"), bill_id=None):
        flags.append({"id": fid, "kind": kind, "title": title, "detail": detail, "amount": round(amount or 0, 2),
                      "date": t["date"][:10] if t else None, "tx_id": t["id"] if t else None,
                      "merchant": (t["merchant"] or t["name"]) if t else None,
                      "account": t["account_name"] if t else None, "actions": list(actions), "bill_id": bill_id})

    outs = [t for t in txs if t["amount"] < 0 and not t["pending"]]
    # 1. Fees and interest
    for t in outs:
        text = f"{t['name']} {t['merchant'] or ''}"
        if INTEREST.search(text) or (t["acct_type"] == "credit" and t["category"] == "Fees & Interest"
                                     and "interest" in text.lower()):
            flag(f"int:{t['id']}", "interest", f"Interest charged on {t['account_name']}",
                 "You carried a balance past the due date. Paying the full statement balance each month avoids this; "
                 "if it's your first time, card issuers often refund it if you call and ask.", t, -t["amount"])
        elif FEE.search(text) or t["category"] == "Fees & Interest":
            flag(f"fee:{t['id']}", "fee", f"Fee: {t['name'][:48]}",
                 "Banks often refund a fee if you ask, especially the first one. Many fees go away with direct "
                 "deposit, a minimum balance, or a no-fee account.", t, -t["amount"])
    # 2. Duplicate charges: same merchant, same amount, same account, within 2 days
    seen = defaultdict(list)
    for t in outs:
        if t["category"] in SKIP_CATS or -t["amount"] < 10 or t["pair_kind"]:
            continue
        k = (t["account_id"], _key(t), round(t["amount"], 2))
        for prev in seen[k]:
            if (date.fromisoformat(t["date"][:10]) - date.fromisoformat(prev["date"][:10])).days <= 2:
                flag(f"dup:{t['id']}", "duplicate", f"Possible double charge: {t['merchant'] or t['name'][:40]}",
                     f"Charged {alerts.money(t['amount'])} twice ({prev['date'][:10]} and {t['date'][:10]}) on "
                     f"{t['account_name']}. If you only bought once, dispute the second one.", t, -t["amount"])
                break
        seen[k].append(t)
    # 3. Unusually large charge from somewhere you go regularly
    hist = defaultdict(list)
    for t in db.rows("SELECT name, merchant, amount, date FROM transactions WHERE amount < 0 AND pending = 0 "
                     "AND date >= ? AND date < ?", ((today - timedelta(days=365)).isoformat(), since)):
        hist[_key(t)].append(-t["amount"])
    for t in outs:
        if t["category"] in SKIP_CATS or t["pair_kind"]:
            continue
        past = hist.get(_key(t), [])
        if len(past) >= 4:
            med = statistics.median(past)
            if -t["amount"] >= max(med * 3, med + 50):
                flag(f"big:{t['id']}", "unusual", f"Unusually large: {t['merchant'] or t['name'][:40]}",
                     f"{alerts.money(t['amount'])} vs your usual {alerts.money(med)} there. Fine if you meant it; "
                     "otherwise check for a wrong amount or a charge that isn't yours.", t, -t["amount"])
    # 4. Subscription / bill price hikes (latest charge vs the one before)
    for b in bills.list_bills():
        if b["status"] != "active" or b["merchant"].startswith("xfer:") or b["id"].startswith(("liab:", "pay:")):
            continue
        if b["category"] in subscriptions.NOT_SUBSCRIPTIONS:
            continue  # utilities etc. change every month by nature
        h = subscriptions._history(b)
        if len(h) < 2 or h[-1][0] < since:
            continue
        if len(h) >= 3 and abs(h[-2][1] - h[-3][1]) > h[-3][1] * 0.02:
            continue  # the price was never fixed: not a subscription hike
        (d0, a0), (d1, a1) = h[-2], h[-1]
        if a1 > a0 * 1.04 and a1 - a0 >= 0.5:
            yearly = (a1 - a0) * 12 * 30.44 / (b["cadence_days"] or 30.44)
            flag(f"hike:{b['id']}:{d1[:10]}", "price_up", f"Price went up: {b['display_name']}",
                 f"Now {alerts.money(a1)} (was {alerts.money(a0)}), about {alerts.money(yearly)} more a year. "
                 "Worth a call to ask for the old price, or cancel if you don't use it much.",
                 {"id": None, "date": d1, "merchant": b["display_name"], "name": b["display_name"],
                  "account_name": b.get("account_name")}, a1 - a0, ("expected", "cancel"), b["id"])
    # 5. Refunds / disputes you're waiting on (from your decisions)
    dec = _decisions()
    for fid, d in dec.items():
        if d.get("decision") not in ("dispute", "refund") or not d.get("tx_id"):
            continue
        t = db.row("SELECT t.*, a.name AS account_name FROM transactions t LEFT JOIN accounts a ON a.id = t.account_id "
                   "WHERE t.id = ?", (d["tx_id"],))
        if not t:
            continue
        back = _money_back(t, t["date"][:10])
        waited = (today - date.fromisoformat(d["on"])).days
        if back:
            d.update(decision="resolved", resolved_on=back["date"][:10], resolved_amount=back["amount"])
            alerts.add(f"refund_back:{fid}", "refund", f"Money back from {t['merchant'] or t['name'][:40]}",
                       f"{alerts.money(back['amount'])} arrived on {back['date'][:10]}. Closed it for you.", "info")
        elif fid.startswith("wait:") and not any(f["id"] == fid for f in flags):
            flag(fid, "refund_wait", f"Waiting for a refund: {t['merchant'] or t['name'][:40]}",
                 f"You marked this {waited} days ago. "
                 + ("Nothing has come back yet: time to follow up with the merchant or your card."
                    if waited >= REFUND_WAIT_DAYS else "The app will tell you when the money comes back."),
                 t, -t["amount"], ("got_it", "stop_tracking"))
    _save(dec)

    open_, done = [], []
    for f in flags:
        d = dec.get(f["id"])
        f["decision"] = d.get("decision") if d else None
        f["decided_on"] = d.get("on") if d else None
        if d and d.get("decision") in ("expected", "cancel", "resolved", "stop_tracking", "got_it"):
            done.append(f)
        elif d and d.get("decision") == "dispute":
            f["waiting"] = True
            open_.append(f)
        else:
            open_.append(f)
    # Disputes on flags that dropped out of the 90-day window still show until money comes back
    for fid, d in dec.items():
        if d.get("decision") == "dispute" and not any(f["id"] == fid for f in flags) and d.get("snapshot"):
            open_.append({**d["snapshot"], "decision": "dispute", "decided_on": d["on"], "waiting": True})

    year_ago = (today - timedelta(days=365)).isoformat()
    fee_year = 0.0
    for t in db.rows("SELECT name, merchant, amount, category FROM transactions WHERE amount < 0 AND pending = 0 "
                     "AND date >= ?", (year_ago,)):
        text = f"{t['name']} {t['merchant'] or ''}"
        if t["category"] == "Fees & Interest" or FEE.search(text) or INTEREST.search(text):
            fee_year += -t["amount"]
    sev = {"duplicate": 0, "interest": 1, "fee": 2, "refund_wait": 3, "price_up": 4, "unusual": 5}
    open_.sort(key=lambda f: (f.get("waiting", False), sev.get(f["kind"], 9), f["date"] or ""))
    done.sort(key=lambda f: f.get("decided_on") or "", reverse=True)
    recovered = sum(d.get("resolved_amount") or 0 for d in dec.values() if d.get("decision") == "resolved")
    return {"open": open_, "done": done[:20], "fees_last_year": round(fee_year, 2),
            "at_stake": round(sum(f["amount"] for f in open_ if not f.get("waiting")), 2),
            "recovered": round(recovered, 2)}


def decide(fid, decision, today=None):
    if decision not in ("expected", "dispute", "cancel", "refund", "got_it", "stop_tracking", "undo"):
        raise ValueError("Unknown choice")
    today = today or date.today()
    dec = _decisions()
    if decision == "undo":
        dec.pop(fid, None)
        _save(dec)
        return {}
    flags = {f["id"]: f for f in scan(today)["open"]}
    f = flags.get(fid)
    entry = {"decision": decision, "on": today.isoformat(), "tx_id": f["tx_id"] if f else None}
    if f and decision == "dispute":
        entry["snapshot"] = {k: f[k] for k in ("id", "kind", "title", "detail", "amount", "date", "tx_id", "merchant",
                                               "account", "actions", "bill_id")}
    if decision == "cancel" and f and f.get("bill_id"):
        subscriptions.decide(f["bill_id"], "cancel")
        subscriptions.check_reminders()
    dec[fid] = entry
    _save(dec)
    return entry


def track_refund(tx_id, today=None):
    t = db.row("SELECT id, amount FROM transactions WHERE id = ?", (tx_id,))
    if not t or t["amount"] >= 0:
        raise ValueError("Pick a charge")
    dec = _decisions()
    dec[f"wait:{tx_id}"] = {"decision": "refund", "on": (today or date.today()).isoformat(), "tx_id": tx_id}
    _save(dec)
    return {"ok": True}


def recent_charges(q="", today=None):
    """Charges you could be waiting on a refund for (last 60 days, $5+)."""
    today = today or date.today()
    where, params = ["t.amount <= -5", "t.date >= ?", "coalesce(t.source, '') != 'split'"], \
        [(today - timedelta(days=60)).isoformat()]
    if q:
        where.append("(t.name LIKE ? OR t.merchant LIKE ?)")
        params += [f"%{q}%"] * 2
    return db.rows("SELECT t.id, t.date, t.name, t.merchant, t.amount, a.name AS account_name FROM transactions t "
                   f"LEFT JOIN accounts a ON a.id = t.account_id WHERE {' AND '.join(where)} "
                   "AND t.category NOT IN ('Transfer', 'Credit Card Payment', 'Investments', 'Loan Payment') "
                   "ORDER BY t.date DESC LIMIT 40", params)


def check_alerts(today=None):
    today = today or date.today()
    res = scan(today)
    for f in res["open"]:
        if f.get("waiting") or f["decision"]:
            continue
        if f["kind"] in ("duplicate", "interest", "fee"):
            alerts.add(f"watch:{f['id']}", "leak", f["title"],
                       f"{alerts.money(f['amount'])} on {f['date']}. Decide on the Fees & Odd Charges page.",
                       "danger" if f["kind"] == "duplicate" else "warn")
        elif f["kind"] == "refund_wait" and "follow up" in f["detail"]:
            alerts.add(f"watch:{f['id']}:late", "refund", f["title"], f["detail"], "warn")
