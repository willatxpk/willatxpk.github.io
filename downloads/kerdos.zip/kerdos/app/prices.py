"""Recent fund prices (last month, daily closes) from Yahoo Finance's public chart feed.

Only the ticker symbol is sent, never anything about you or your accounts. Results are cached
for a few hours, and if the feed can't be reached the last cached numbers are used (or none).
"""
import json
import re
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from . import db

URL = "https://query1.finance.yahoo.com/v8/finance/chart/{sym}?range=1mo&interval=1d"
TTL = 4 * 3600
SYMBOL = re.compile(r"^[A-Z][A-Z0-9.\-]{0,9}$")
_mem = {}


def _fetch(sym):
    req = urllib.request.Request(URL.format(sym=sym.replace(".", "-")), headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=8) as resp:
        res = json.loads(resp.read().decode("utf-8"))["chart"]["result"][0]
    stamps = res.get("timestamp") or []
    closes = res["indicators"]["quote"][0].get("close") or []
    pts = [{"t": t * 1000, "v": round(c, 4)} for t, c in zip(stamps, closes) if c is not None]
    if len(pts) < 2:
        raise ValueError("no price history")
    meta = res.get("meta") or {}
    last = meta.get("regularMarketPrice") or pts[-1]["v"]
    first = pts[0]["v"]
    return {"symbol": sym, "name": meta.get("longName") or meta.get("shortName") or sym,
            "price": round(last, 2), "month_ago": round(first, 2),
            "change": round(last - first, 2), "change_pct": round((last - first) / first * 100, 2) if first else 0,
            "low": round(min(p["v"] for p in pts), 2), "high": round(max(p["v"] for p in pts), 2),
            "points": pts, "fetched": time.time()}


def month(symbols):
    """{symbol: last-month price info}. Symbols that can't be looked up are simply left out."""
    syms = sorted({(s or "").upper().strip() for s in symbols} - {""})
    syms = [s for s in syms if SYMBOL.match(s)]
    if not _mem:
        _mem.update(db.get_setting("price_cache", {}) or {})
    now = time.time()
    stale = [s for s in syms if s not in _mem or now - _mem[s].get("fetched", 0) > TTL]

    def grab(s):
        try:
            return s, _fetch(s)
        except (urllib.error.URLError, ValueError, KeyError, IndexError, TypeError, OSError):
            return s, None

    if stale:
        with ThreadPoolExecutor(max_workers=6) as pool:
            for s, info in pool.map(grab, stale):
                if info:
                    _mem[s] = info
        db.set_setting("price_cache", {k: v for k, v in _mem.items() if now - v.get("fetched", 0) < 14 * 86400})
    out = {}
    for s in syms:
        if s in _mem:
            out[s] = dict(_mem[s], stale=now - _mem[s]["fetched"] > TTL * 2)
    return out


# ------------------------------------------------------------------ two years of daily closes
HIST_URL = "https://query1.finance.yahoo.com/v8/finance/chart/{sym}?range=2y&interval=1d"
HIST_TTL = 12 * 3600
_hist = {}


def _fetch_history(sym):
    # Yahoo writes share classes with a dash (BRK-B), brokerages with a dot (BRK.B)
    req = urllib.request.Request(HIST_URL.format(sym=sym.replace(".", "-")), headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        res = json.loads(resp.read().decode("utf-8"))["chart"]["result"][0]
    offset = (res.get("meta") or {}).get("gmtoffset") or 0
    closes = res["indicators"]["quote"][0].get("close") or []
    days = {}
    for t, c in zip(res.get("timestamp") or [], closes):
        if c is not None and c > 0:
            days[time.strftime("%Y-%m-%d", time.gmtime(t + offset))] = round(c, 4)
    if len(days) < 2:
        raise ValueError("no price history")
    return {"fetched": time.time(), "days": [[d, c] for d, c in sorted(days.items())]}


def history(symbols):
    """{symbol: [[iso_date, close], ...]} for about the last two years, oldest first.

    Closes are not adjusted for dividends, so a reinvested dividend shows up as extra shares
    (which is how your brokerage records it too). Symbols that can't be looked up are left out.
    """
    syms = sorted({(s or "").upper().strip() for s in symbols} - {""})
    syms = [s for s in syms if SYMBOL.match(s)]
    if not _hist:
        _hist.update(db.get_setting("price_hist_cache", {}) or {})
    now = time.time()
    stale = [s for s in syms if s not in _hist or now - _hist[s].get("fetched", 0) > HIST_TTL]

    def grab(s):
        try:
            return s, _fetch_history(s)
        except (urllib.error.URLError, ValueError, KeyError, IndexError, TypeError, OSError):
            return s, None

    if stale:
        got = False
        with ThreadPoolExecutor(max_workers=6) as pool:
            for s, info in pool.map(grab, stale):
                if info:
                    _hist[s] = info
                    got = True
        if got:
            db.set_setting("price_hist_cache",
                           {k: v for k, v in _hist.items() if now - v.get("fetched", 0) < 14 * 86400})
    return {s: _hist[s]["days"] for s in syms if s in _hist}
