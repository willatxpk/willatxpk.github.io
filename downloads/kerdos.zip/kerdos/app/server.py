"""Local web server: JSON API + static UI. Listens on 127.0.0.1 only."""
import json
import mimetypes
import os
import re
import threading
import time
import traceback
import uuid
from datetime import date, datetime, timedelta
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse

from . import (alerts, auth, bills, cashflow, categorize, checkin, config, db, demo, finance, goals, health, importer,
               insights, investments, learner, partner, plaid, planner, splits, subscriptions, transfers, undo, watchdog,
               whatif)

STATIC = os.path.join(db.ROOT, "static")
ROUTES = []


def route(method, pattern):
    def deco(fn):
        ROUTES.append((method, re.compile("^" + pattern + "$"), fn))
        return fn
    return deco


from . import aisort, debt, rules, taxes  # noqa: E402


class ApiError(Exception):
    def __init__(self, msg, status=400):
        super().__init__(msg)
        self.status = status


def refresh_derived():
    """Recompute everything that depends on transactions/balances."""
    splits.apply()  # roommate repayments first, so they're never mistaken for transfers
    transfers.match_all()
    learner.apply()
    finance.snapshot()
    alerts.run_checks()
    for extra in (cashflow.check_alerts, subscriptions.check_reminders, health.check_alerts, watchdog.check_alerts,
                  checkin.check_alerts):
        try:
            extra()
        except Exception:  # noqa: BLE001 - one broken check shouldn't stop the others
            traceback.print_exc()
    alerts.deliver_pending()
    aisort.kick()   # anything still unsure gets a second opinion from the local model, in the background


# ------------------------------------------------------------------ API ----
@route("GET", "/api/status")
def status(q, body):
    cfg = config.load()
    return {
        "plaid_configured": config.plaid_configured(cfg),
        "plaid_env": cfg["plaid"].get("env", "sandbox"),
        "items": db.rows("SELECT item_id, institution, last_sync, error, created_at FROM items"),
        "has_data": bool(db.row("SELECT 1 FROM accounts LIMIT 1")),
        "has_demo": bool(db.row("SELECT 1 FROM accounts WHERE source = 'demo' LIMIT 1")),
        "unread_alerts": db.row("SELECT count(*) AS n FROM alerts WHERE is_read = 0")["n"],
        "pending_count": db.row("SELECT count(*) n FROM transactions WHERE pending = 1")["n"],
        "sort_count": db.row("SELECT count(*) AS n FROM transactions WHERE " + categorize.unsure_sql())["n"],
        "companion": (db.get_setting("companion") or {}).get("kind"),
        "appearance": db.get_setting("appearance", {}) or {},
        "notify": {"ntfy": bool(cfg["notify"].get("ntfy_url")),
                   "email": bool(cfg["notify"].get("email", {}).get("enabled"))},
        "last_delivery_error": db.get_setting("last_delivery_error"),
        "alert_days_ahead": db.get_setting("alert_days_ahead", 3),
        "push_min_severity": db.get_setting("push_min_severity", "info"),
        "categories": categorize.all_categories(),
        "health": _health_status(),
        "checkin_done": any(c["week"] == checkin.week_id(date.today()) for c in checkin.history()),
        "checkin_streak": checkin.streak(),
    }


def _health_status():
    try:
        h = health.check()
        return {"status": h["status"], "issues": sum(1 for i in h["issues"] if i["level"] != "info")}
    except Exception:  # noqa: BLE001
        return {"status": "unknown", "issues": 0}


@route("GET", "/api/dashboard")
def dashboard(q, body):
    months = finance.spending_by_month(6)
    upcoming = [b for b in bills.list_bills() if b["status"] == "active" and b["next_date"]
                and b["next_date"] <= (date.today() + timedelta(days=14)).isoformat()
                and b["next_date"] >= date.today().isoformat()]
    hist = finance.history()
    month_ago = (date.today() - timedelta(days=30)).isoformat()
    prev = next((h for h in reversed(hist) if h["date"] <= month_ago), None)
    nw = finance.net_worth()
    return {
        "net_worth": nw,
        "net_worth_change_30d": round(nw["net"] - prev["net"], 2) if prev else None,
        "history": hist[-120:],
        "months": months,
        "averages": finance.averages(3),
        "upcoming": upcoming,
        "alerts": db.rows("SELECT * FROM alerts WHERE is_read = 0 ORDER BY id DESC LIMIT 6"),
        "recent": finance.recent_transactions(8),
        "accounts": finance.accounts(),
    }


@route("GET", "/api/accounts")
def get_accounts(q, body):
    accts = finance.accounts()
    libs = {r["account_id"]: r for r in db.rows("SELECT * FROM liabilities")}
    for a in accts:
        a["liability"] = libs.get(a["id"])
    return {"accounts": accts, "net_worth": finance.net_worth(),
            "items": db.rows("SELECT item_id, institution, last_sync, error FROM items")}


@route("POST", "/api/accounts")
def add_account(q, body):
    name = (body.get("name") or "").strip()
    typ = body.get("type")
    if not name or typ not in ("depository", "credit", "loan", "investment", "other"):
        raise ApiError("Name and a valid type are required")
    aid = "man-" + uuid.uuid4().hex[:10]
    bal = float(body.get("balance") or 0)
    db.execute(
        "INSERT INTO accounts(id, name, type, subtype, institution, current_balance, available_balance, "
        "is_manual, source) VALUES(?,?,?,?,?,?,?,1,'manual')",
        (aid, name, typ, body.get("subtype") or None, body.get("institution") or "Manual", bal,
         bal if typ == "depository" else None))
    if body.get("apr") not in (None, ""):
        db.execute("INSERT INTO liabilities(account_id, kind, apr) VALUES(?,?,?)",
                   (aid, "credit" if typ == "credit" else "loan", float(body["apr"])))
    finance.snapshot()
    return {"id": aid}


@route("POST", r"/api/accounts/(?P<aid>[^/]+)")
def update_account(q, body, aid):
    a = db.row("SELECT * FROM accounts WHERE id = ?", (aid,))
    if not a:
        raise ApiError("Account not found", 404)
    if "is_hidden" in body:
        db.execute("UPDATE accounts SET is_hidden = ? WHERE id = ?", (1 if body["is_hidden"] else 0, aid))
    if "name" in body and body["name"].strip():
        db.execute("UPDATE accounts SET name = ? WHERE id = ?", (body["name"].strip(), aid))
    if body.get("type") in ("depository", "credit", "loan", "investment", "other"):
        # Bank syncs never overwrite this, so your label sticks
        db.execute("UPDATE accounts SET type = ?, subtype = ? WHERE id = ?",
                   (body["type"], (body.get("subtype") or None), aid))
    if "balance" in body and a["source"] != "plaid":
        bal = float(body["balance"] or 0)
        db.execute("UPDATE accounts SET current_balance = ?, available_balance = ?, updated_at = datetime('now') "
                   "WHERE id = ?", (bal, bal if a["type"] == "depository" else None, aid))
    if "apr" in body:
        if body["apr"] in (None, ""):
            db.execute("DELETE FROM liabilities WHERE account_id = ? AND next_due_date IS NULL", (aid,))
        else:
            db.execute("INSERT INTO liabilities(account_id, kind, apr) VALUES(?,?,?) "
                       "ON CONFLICT(account_id) DO UPDATE SET apr = excluded.apr",
                       (aid, "credit" if a["type"] == "credit" else "loan", float(body["apr"])))
    finance.snapshot()
    return {"ok": True}


@route("DELETE", r"/api/accounts/(?P<aid>[^/]+)")
def delete_account(q, body, aid):
    a = db.row("SELECT * FROM accounts WHERE id = ?", (aid,))
    if not a:
        raise ApiError("Account not found", 404)
    if a["source"] == "plaid":
        raise ApiError("This account is linked through a bank connection. Disconnect the bank instead, "
                       "or hide the account.")
    with db.lock():
        conn = db.get()
        conn.execute("DELETE FROM transactions WHERE account_id = ?", (aid,))
        conn.execute("DELETE FROM liabilities WHERE account_id = ?", (aid,))
        conn.execute("DELETE FROM bills WHERE account_id = ?", (aid,))
        conn.execute("DELETE FROM accounts WHERE id = ?", (aid,))
        conn.commit()
    refresh_derived()
    return {"ok": True}


@route("GET", "/api/transactions")
def get_transactions(q, body):
    where, params = ["1=1"], []
    if q.get("month"):
        where.append("t.date LIKE ?")
        params.append(q["month"] + "%")
    if q.get("category"):
        where.append("t.category = ?")
        params.append(q["category"])
    if q.get("account"):
        where.append("t.account_id = ?")
        params.append(q["account"])
    if q.get("q"):
        where.append("(t.name LIKE ? OR t.merchant LIKE ? OR t.notes LIKE ?)")
        params += ["%" + q["q"] + "%"] * 3
    if q.get("uncategorized"):
        where.append("t.category = 'Other'")
    if q.get("pending"):
        where.append("t.pending = 1")
    if not q.get("shares"):  # roommate share lines are shown on the repayment they came from
        where.append("coalesce(t.source, '') != 'split'")
    limit = min(int(q.get("limit") or 300), 2000)
    txs = db.rows(
        "SELECT t.*, a.name AS account_name FROM transactions t LEFT JOIN accounts a ON a.id = t.account_id "
        f"WHERE {' AND '.join(where)} ORDER BY t.date DESC, t.rowid DESC LIMIT ?", params + [limit])
    months = [r["m"] for r in db.rows("SELECT DISTINCT substr(date,1,7) AS m FROM transactions ORDER BY m DESC")]
    shared = [t for t in txs if t.get("category_source") == "split"]
    if shared:
        parts = {}
        for r in db.rows("SELECT id, category, amount FROM transactions WHERE source = 'split'"):
            parts.setdefault(r["id"].rsplit(":", 1)[0][6:], []).append({"category": r["category"], "amount": r["amount"]})
        for t in shared:
            t["shares"] = parts.get(t["id"], [])
    return {"transactions": txs, "months": months}


@route("POST", r"/api/transactions/(?P<tid>[^/]+)")
def update_transaction(q, body, tid):
    t = db.row("SELECT * FROM transactions WHERE id = ?", (tid,))
    if not t:
        raise ApiError("Transaction not found", 404)
    if "notes" in body:
        db.execute("UPDATE transactions SET notes = ? WHERE id = ?", (body["notes"], tid))
    cat = categorize.canonical(body.get("category") or "") or None
    changed, resolved = 0, []
    if cat:
        is_new = cat not in categorize.all_categories()
        _remember_category(cat)
        snap = undo.snapshot()
        rule_info = None
        before = _uncertain_ids()
        db.execute("UPDATE transactions SET category = ?, category_source = 'user', confidence = 'high' "
                   "WHERE id = ?", (cat, tid))
        changed = 1
        if body.get("apply_to_merchant"):
            pattern = (body.get("pattern") or categorize.teach_pattern(t["name"], t["merchant"])).strip().lower()
            if len(pattern) < categorize.MIN_RULE_LEN:
                raise ApiError("Rule text must be at least 2 characters")
            rule_info = {"pattern": pattern, "prev": undo.rule_state(pattern)}
            db.execute("DELETE FROM rules WHERE pattern = ?", (pattern,))
            db.execute("INSERT INTO rules(pattern, category) VALUES(?, ?)", (pattern, cat))
            changed += categorize.recategorize_all()  # also re-runs the learner
        else:
            learner.apply()
        resolved = _resolved_since(before, exclude=tid)
        name = (t["merchant"] or t["name"] or "")[:40]
        undo.record(f"{name} → {cat}", snap, rule_info, cat if is_new else None)
        alerts.run_checks()
    return {"ok": True, "updated": changed, "resolved": resolved}


def _uncertain_ids():
    """What the Sort tab shows by default: transactions the app is unsure about."""
    return {r["id"] for r in db.rows("SELECT id FROM transactions WHERE " + categorize.unsure_sql())}


def _resolved_since(before, exclude=None):
    """Transactions that were uncertain before an action and got sorted by it (via a rule or the learner)."""
    out = []
    for tid_ in before - _uncertain_ids() - {exclude}:
        r = db.row("SELECT id, category, category_source FROM transactions WHERE id = ?", (tid_,))
        if r:
            out.append({"id": r["id"], "category": r["category"], "how": r["category_source"]})
    return out


def _remember_category(cat):
    if cat not in categorize.all_categories():
        custom = set(db.get_setting("custom_categories", []))
        custom.add(cat)
        db.set_setting("custom_categories", sorted(custom))


@route("GET", "/api/rules")
def get_rules(q, body):
    return {"rules": db.rows("SELECT * FROM rules ORDER BY pattern")}


@route("POST", "/api/rules")
def add_rule(q, body):
    pattern, cat = (body.get("pattern") or "").strip().lower(), body.get("category")
    if len(pattern) < categorize.MIN_RULE_LEN or not cat:
        raise ApiError("Enter at least 2 characters of text to match and a category")
    _remember_category(cat)
    db.execute("DELETE FROM rules WHERE pattern = ?", (pattern,))
    db.execute("INSERT INTO rules(pattern, category) VALUES(?, ?)", (pattern, cat))
    n = categorize.recategorize_all()
    alerts.run_checks()
    return {"ok": True, "rechecked": n}


@route("DELETE", r"/api/rules/(?P<rid>\d+)")
def delete_rule(q, body, rid):
    db.execute("DELETE FROM rules WHERE id = ?", (int(rid),))
    categorize.recategorize_all()
    return {"ok": True}


@route("GET", "/api/debt")
def get_debt(q, body):
    return debt.summary()


@route("POST", "/api/debt/limit")
def set_debt_limit(q, body):
    try:
        debt.set_limit(body.get("account_id"), body.get("limit"))
    except ValueError as e:
        raise ApiError(str(e))
    return {"ok": True}


@route("GET", "/api/debt/rewards")
def get_rewards(q, body):
    return debt.rewards()


@route("POST", "/api/debt/rewards")
def set_rewards(q, body):
    try:
        debt.save_rewards(body.get("account_id"), body)
    except ValueError as e:
        raise ApiError(str(e))
    return debt.rewards()


@route("GET", "/api/taxes")
def get_taxes(q, body):
    return taxes.estimate()


@route("POST", "/api/taxes")
def post_taxes(q, body):
    if body.get("reset"):
        db.execute("DELETE FROM settings WHERE key = 'tax_inputs'")
        return taxes.estimate()
    try:
        return taxes.estimate(taxes.save_inputs(body))
    except ValueError as e:
        raise ApiError(str(e))


BACKGROUNDS = {"aurora", "sunset", "ocean", "forest", "berry", "slate", "plain", "custom"}


@route("POST", "/api/settings/appearance")
def set_appearance(q, body):
    """The app's background. Only known names and #rrggbb colours are kept."""
    cur = db.get_setting("appearance", {}) or {}
    if body.get("bg") in BACKGROUNDS:
        cur["bg"] = body["bg"]
    if body.get("intensity") in ("subtle", "normal", "vivid"):
        cur["intensity"] = body["intensity"]
    custom = body.get("custom")
    if isinstance(custom, list) and len(custom) == 4 and all(
            isinstance(c, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", c) for c in custom):
        cur["custom"] = [c.lower() for c in custom]
    db.set_setting("appearance", cur)
    return cur


@route("GET", "/api/calendar")
def get_calendar(q, body):
    return cashflow.month_calendar(q.get("month"))


@route("GET", "/api/bills")
def get_bills(q, body):
    items = bills.list_bills()
    active = [b for b in items if b["status"] == "active"]
    for b in items:
        b["monthly_equivalent"] = round(bills.monthly_equivalent(b), 2)
    return {
        "bills": items,
        "monthly_total": round(sum(bills.monthly_equivalent(b) for b in active), 2),
        "autopay_monthly_total": round(sum(bills.monthly_equivalent(b) for b in active
                                           if b["autopay"] in ("yes", "likely")), 2),
    }


@route("POST", r"/api/bills/(?P<bid>[^/]+)")
def update_bill(q, body, bid):
    if not db.row("SELECT 1 FROM bills WHERE id = ?", (bid,)):
        raise ApiError("Bill not found", 404)
    if body.get("autopay") in ("yes", "likely", "no", "unknown"):
        db.execute("UPDATE bills SET autopay = ?, user_edited = 1 WHERE id = ?", (body["autopay"], bid))
    if body.get("status") in ("active", "ignored", "dismissed"):
        status = "dismissed" if body["status"] == "ignored" else body["status"]
        db.execute("UPDATE bills SET status = ?, user_edited = 1 WHERE id = ?", (status, bid))
        if status == "dismissed":  # its pending alerts no longer matter
            db.execute("UPDATE alerts SET is_read = 1 WHERE key LIKE ?", (f"%:{bid}:%",))
    if (body.get("display_name") or "").strip():
        db.execute("UPDATE bills SET display_name = ?, user_edited = 1 WHERE id = ?",
                   (body["display_name"].strip()[:60], bid))
    return {"ok": True}


@route("GET", "/api/alerts")
def get_alerts(q, body):
    return {"alerts": db.rows("SELECT * FROM alerts ORDER BY id DESC LIMIT 200")}


@route("POST", "/api/alerts/read")
def read_alerts(q, body):
    if body.get("id"):
        db.execute("UPDATE alerts SET is_read = 1 WHERE id = ?", (int(body["id"]),))
    else:
        db.execute("UPDATE alerts SET is_read = 1")
    return {"ok": True}


@route("POST", "/api/alerts/settings")
def alert_settings(q, body):
    if "alert_days_ahead" in body:
        db.set_setting("alert_days_ahead", max(0, min(14, int(body["alert_days_ahead"]))))
    if body.get("push_min_severity") in ("info", "warn", "danger"):
        db.set_setting("push_min_severity", body["push_min_severity"])
    alerts.run_checks()
    return {"ok": True}


@route("POST", "/api/alerts/test")
def test_alert(q, body):
    cfg = config.load()["notify"]
    if not cfg.get("ntfy_url") and not cfg.get("email", {}).get("enabled"):
        raise ApiError("No push channel set up. Add ntfy_url or email settings to config.json first.")
    alerts.add(f"test:{time.time()}", "test", "Test alert from Kerdos",
               "If you can read this on your phone/email, alerts are working.")
    res = alerts.deliver_pending()
    if res.get("errors"):
        raise ApiError("Delivery failed: " + "; ".join(res["errors"]))
    return {"ok": True}


@route("GET", "/api/networth")
def get_networth(q, body):
    return {"current": finance.net_worth(), "history": finance.history(), "accounts": finance.accounts(False)}


@route("GET", "/api/spending")
def get_spending(q, body):
    return {"months": finance.spending_by_month(int(q.get("months") or 12)), "averages": finance.averages(3)}


@route("GET", "/api/profile")
def get_profile(q, body):
    return planner.get_profile()


@route("POST", "/api/profile")
def save_profile(q, body):
    return planner.save_profile(body)


@route("GET", "/api/plan")
def get_plan(q, body):
    plan = planner.build_plan()
    plan["card_balances"] = round(sum(a["current_balance"] or 0 for a in finance.accounts(False)
                                      if a["type"] == "credit"), 2)
    return plan


@route("GET", "/api/sort")
def sort_queue(q, body):
    txs = db.rows(
        "SELECT t.id, t.date, t.name, t.merchant, t.amount, t.category, t.confidence, t.category_source, "
        "t.pending, a.name AS account_name, a.type AS acct_type FROM transactions t "
        "LEFT JOIN accounts a ON a.id = t.account_id "
        "WHERE " + categorize.unsure_sql("t", bool(q.get("medium"))) + " "
        "ORDER BY t.pending DESC, t.date DESC LIMIT 400")
    model = learner.train()
    sugg = learner.suggestions(txs, model)
    second = aisort.guesses(txs)
    for t in txs:
        t["pattern"] = categorize.teach_pattern(t["name"], t["merchant"])
        t["suggestion"] = sugg.get(t["id"])
        if t["suggestion"]:
            t["suggestion"]["by"] = "learner"
        elif t["id"] in second:           # the learner has no view: show what the local model thinks
            t["suggestion"] = {"category": second[t["id"]]["category"], "p": None, "by": "ai", "why": second[t["id"]]["reason"]}
    aisort.kick()
    ai = aisort.status()
    counts = db.row(
        "SELECT coalesce(sum(CASE WHEN " + categorize.unsure_sql() + " THEN 1 ELSE 0 END), 0) AS low, "
        "coalesce(sum(CASE WHEN confidence = 'medium' AND " + categorize.unsure_sql(medium=True) + " THEN 1 ELSE 0 END), 0) AS medium "
        "FROM transactions")
    sorted_n = db.row("SELECT count(*) n FROM transactions WHERE category_source = 'user'")["n"]
    since = (date.today() - timedelta(days=365)).isoformat()
    usage = {r["category"]: r["n"] for r in db.rows(
        "SELECT category, count(*) n FROM transactions WHERE date >= ? GROUP BY category", (since,))}
    last = undo.peek()
    return {"transactions": txs, "counts": counts, "sorted_total": sorted_n, "category_usage": usage,
            "ai": {k: ai[k] for k in ("ollama", "enabled", "model", "busy", "left")},
            "undo": last["label"] if last else None,
            "coins_from_sorting": sorted_n // goals.SORTS_PER_COIN, "sorts_per_coin": goals.SORTS_PER_COIN,
            "learner": {"trained_on": model.size,
                        "learned": db.row("SELECT count(*) n FROM transactions WHERE category_source = 'learned'")["n"]}}


@route("GET", "/api/ai")
def ai_status(q, body):
    return aisort.status()


@route("POST", "/api/ai")
def ai_save(q, body):
    """Switch the local model's second opinions on or off, choose the model, or ask it now."""
    try:
        aisort.save({k: body[k] for k in ("enabled", "model") if k in body})
    except ValueError as e:
        raise ApiError(str(e))
    if body.get("run"):
        aisort.kick()
    return aisort.status()


@route("POST", "/api/sort/accept")
def sort_accept(q, body):
    """Keep the current guess for these transactions (marks them as checked by you)."""
    ids = body.get("ids") or []
    before = _uncertain_ids()
    snap = undo.snapshot()
    with db.lock():
        conn = db.get()
        for tid in ids:
            conn.execute("UPDATE transactions SET category_source = 'user', confidence = 'high' WHERE id = ?", (tid,))
        conn.commit()
    learner.apply()
    undo.record(f"Kept the guess for {len(ids)} transaction{'s' if len(ids) != 1 else ''}", snap)
    return {"ok": True, "n": len(ids), "resolved": _resolved_since(before - set(ids))}


@route("POST", "/api/sort/undo")
def sort_undo(q, body):
    try:
        r = undo.undo()
    except ValueError as e:
        raise ApiError(str(e))
    learner.apply()
    nxt = undo.peek()
    r["next"] = nxt["label"] if nxt else None
    return r


@route("GET", "/api/categories")
def categories_info(q, body):
    since = (date.today() - timedelta(days=365)).isoformat()
    counts = {r["category"]: r["n"] for r in db.rows(
        "SELECT category, count(*) n FROM transactions WHERE date >= ? GROUP BY category", (since,))}
    hist = db.get_setting("merge_history", []) or []
    return {"categories": [{"name": c, "count": counts.get(c, 0)} for c in categorize.all_categories()],
            "aliases": categorize.aliases(),
            "last_merge": ({"target": hist[-1]["target"], "sources": hist[-1]["sources"], "at": hist[-1]["at"],
                            "moved": len(hist[-1]["tx"])} if hist else None)}


@route("POST", "/api/categories/merge")
def categories_merge(q, body):
    try:
        r = categorize.merge(body.get("sources") or [], body.get("target") or "")
    except ValueError as e:
        raise ApiError(str(e))
    refresh_derived()
    return r


@route("POST", "/api/categories/unmerge")
def categories_unmerge(q, body):
    try:
        r = categorize.unmerge_last()
    except ValueError as e:
        raise ApiError(str(e))
    refresh_derived()
    return r


@route("GET", "/api/insights/summary")
def insights_summary(q, body):
    try:
        return insights.year_summary(months=int(q.get("months") or 12), month=q.get("month") or None)
    except ValueError as e:
        raise ApiError(str(e))


@route("GET", "/api/insights/projection")
def insights_projection(q, body):
    f = lambda k, d: float(q[k]) if q.get(k) not in (None, "") else d  # noqa: E731
    return insights.projection(years=max(1, min(40, int(f("years", 10)))), annual_return=f("ret", 7) / 100,
                               inflation=f("infl", 3) / 100, raise_rate=f("raise", 3) / 100,
                               extra_monthly=f("extra", 0))


@route("GET", "/api/goals")
def get_goals(q, body):
    state = goals.companion_state()
    state["presets"] = goals.presets()
    state["accounts"] = [{"id": a["id"], "name": a["name"], "type": a["type"], "subtype": a["subtype"],
                          "balance": a["current_balance"]} for a in finance.accounts(False)]
    state["categories"] = STATUS_CATEGORIES()
    state["entries"] = db.rows("SELECT * FROM goal_entries ORDER BY date DESC LIMIT 100")
    return state


def STATUS_CATEGORIES():
    return categorize.all_categories()


@route("POST", "/api/goals")
def add_goal(q, body):
    try:
        return {"id": goals.create(body)}
    except ValueError as e:
        raise ApiError(str(e))


@route("POST", r"/api/goals/(?P<gid>\d+)")
def update_goal(q, body, gid):
    g = db.row("SELECT * FROM goals WHERE id = ?", (int(gid),))
    if not g:
        raise ApiError("Goal not found", 404)
    name = (body.get("name") or "").strip()[:80]
    if body.get("target") not in (None, ""):
        try:
            new_target = float(str(body["target"]).replace("$", "").replace(",", "").replace("%", ""))
        except ValueError:
            raise ApiError("Enter a number for the target")
        if new_target <= 0 and g["kind"] != "payoff":
            raise ApiError("The target must be more than 0")
        db.execute("UPDATE goals SET target = ? WHERE id = ?", (new_target, int(gid)))
        if not name or name == g["name"]:  # you didn't rename it: keep the number in the name in step
            name = goals.retarget_name(g["name"], g["target"], new_target)
    if name:
        db.execute("UPDATE goals SET name = ? WHERE id = ?", (name, int(gid)))
    if g["kind"] == "contribute" and ("account_ids" in body or "match_text" in body):
        p = json.loads(g["params"] or "{}")
        if "account_ids" in body:
            rows = {a["id"]: a for a in db.rows("SELECT id, name, institution, subtype, mask FROM accounts")}
            p["account_ids"] = [i for i in body["account_ids"] or [] if i in rows]
            p["account_hints"] = [goals._account_hint(rows[i]) for i in p["account_ids"]]
        if "match_text" in body:
            p["match_text"] = (body.get("match_text") or "").strip()[:40]
        db.execute("UPDATE goals SET params = ? WHERE id = ?", (json.dumps(p), int(gid)))
    return {"ok": True}


@route("POST", r"/api/goals/(?P<gid>\d+)/exclude")
def goal_exclude(q, body, gid):
    """Stop (or resume) counting one transaction toward a goal."""
    g = db.row("SELECT * FROM goals WHERE id = ?", (int(gid),))
    if not g:
        raise ApiError("Goal not found", 404)
    tid = str(body.get("id") or "")[:160]
    if not tid:
        raise ApiError("Which transaction?")
    p = json.loads(g["params"] or "{}")
    removed = [str(x) for x in p.get("excluded") or [] if str(x) != tid]
    if body.get("exclude", True):
        removed.append(tid)
    p["excluded"] = removed[-500:]
    db.execute("UPDATE goals SET params = ? WHERE id = ?", (json.dumps(p), int(gid)))
    return {"ok": True}


@route("DELETE", r"/api/goals/(?P<gid>\d+)")
def delete_goal(q, body, gid):
    db.execute("DELETE FROM goal_entries WHERE goal_id = ?", (int(gid),))
    db.execute("DELETE FROM goals WHERE id = ?", (int(gid),))
    return {"ok": True}


@route("POST", r"/api/goals/(?P<gid>\d+)/entries")
def add_goal_entry(q, body, gid):
    amt = float(body.get("amount") or 0)
    if not amt:
        raise ApiError("Enter an amount")
    db.execute("INSERT INTO goal_entries(goal_id, date, amount, note) VALUES(?,?,?,?)",
               (int(gid), body.get("date") or date.today().isoformat(), amt, (body.get("note") or "")[:120]))
    return {"ok": True}


@route("DELETE", r"/api/goal_entries/(?P<eid>\d+)")
def delete_goal_entry(q, body, eid):
    db.execute("DELETE FROM goal_entries WHERE id = ?", (int(eid),))
    return {"ok": True}


@route("POST", "/api/companion")
def update_companion(q, body):
    try:
        return goals.set_companion(body)
    except ValueError as e:
        raise ApiError(str(e))


@route("GET", "/api/cashflow/forecast")
def cf_forecast(q, body):
    return cashflow.forecast(int(q.get("days") or 45))


@route("GET", "/api/cashflow/month")
def cf_month(q, body):
    return cashflow.this_month()


@route("POST", "/api/cashflow/settings")
def cf_settings(q, body):
    if "essentials" in body:
        db.set_setting("essential_categories", [c for c in body["essentials"] if isinstance(c, str)])
    if body.get("buffer") not in (None, ""):
        db.set_setting("cash_buffer", max(0, float(body["buffer"])))
    return {"ok": True}


@route("GET", "/api/subscriptions")
def subs_list(q, body):
    return subscriptions.checkup()


@route("POST", r"/api/subscriptions/(?P<bid>[^/]+)")
def subs_decide(q, body, bid):
    try:
        r = subscriptions.decide(bid, body.get("decision"), body.get("remind_on"))
    except ValueError as e:
        raise ApiError(str(e))
    subscriptions.check_reminders()
    return r


@route("GET", "/api/investments")
def inv_summary(q, body):
    return investments.summary()


@route("GET", "/api/investments/buy")
def inv_buy(q, body):
    return investments.buy_plan()


@route("POST", "/api/investments/buy")
def inv_buy_settings(q, body):
    try:
        investments.save_buy_settings(body)
    except ValueError as e:
        raise ApiError(str(e))
    return investments.buy_plan()


@route("GET", "/api/investments/rules")
def inv_rules(q, body):
    return rules.check()


@route("POST", "/api/investments/rules")
def inv_rules_save(q, body):
    try:
        rules.save(body)
    except ValueError as e:
        raise ApiError(str(e))
    return rules.check()


@route("POST", "/api/investments/note")
def inv_note(q, body):
    try:
        return rules.save_note(body.get("ticker"), body)
    except ValueError as e:
        raise ApiError(str(e))


@route("GET", "/api/investments/insights")
def inv_insights(q, body):
    return investments.insights()


@route("GET", "/api/investments/stock")
def inv_stock(q, body):
    try:
        return investments.stock(q.get("ticker"))
    except ValueError as e:
        raise ApiError(str(e))


@route("GET", "/api/investments/prices")
def inv_prices(q, body):
    return investments.holding_prices()


@route("GET", "/api/investments/performance")
def inv_performance(q, body):
    return investments.performance(q.get("period") or "1y", q.get("account") or None)


@route("POST", "/api/investments/sync")
def inv_sync(q, body):
    if not config.plaid_configured():
        raise ApiError("Plaid isn't set up")
    return investments.sync_all()


# -------- connection health
@route("GET", "/api/health")
def get_health(q, body):
    return health.check()


# -------- roommates
@route("GET", "/api/roommates")
def get_roommates(q, body):
    return splits.summary()


@route("POST", "/api/roommates")
def save_roommate(q, body):
    try:
        r = splits.upsert(body)
    except ValueError as e:
        raise ApiError(str(e))
    refresh_derived()
    return r


@route("DELETE", r"/api/roommates/(?P<rid>[\w-]+)")
def delete_roommate(q, body, rid):
    splits.remove(rid)
    refresh_derived()
    return {"ok": True}


# -------- fees & odd charges
@route("GET", "/api/leaks")
def get_leaks(q, body):
    return watchdog.scan()


@route("POST", "/api/leaks/decide")
def leaks_decide(q, body):
    try:
        return watchdog.decide(body.get("id") or "", body.get("decision"))
    except ValueError as e:
        raise ApiError(str(e))


@route("GET", "/api/leaks/charges")
def leaks_charges(q, body):
    return {"charges": watchdog.recent_charges(q.get("q") or "")}


@route("POST", "/api/leaks/track")
def leaks_track(q, body):
    try:
        return watchdog.track_refund(body.get("tx_id"))
    except ValueError as e:
        raise ApiError(str(e))


# -------- what if
@route("POST", "/api/whatif")
def run_whatif(q, body):
    return whatif.run(body.get("items") or [], body.get("years") or 10)


@route("GET", "/api/whatif/saved")
def whatif_saved(q, body):
    return {"saved": whatif.saved()}


@route("POST", "/api/whatif/save")
def whatif_save(q, body):
    return {"saved": whatif.save(body.get("name"), body.get("items") or [])}


@route("POST", "/api/whatif/delete")
def whatif_delete(q, body):
    whatif.delete(body.get("name"))
    return {"saved": whatif.saved()}


# -------- weekly check-in
@route("GET", "/api/checkin")
def get_checkin(q, body):
    return checkin.build()


@route("POST", "/api/checkin/budget")
def checkin_budget(q, body):
    try:
        return checkin.apply_budget(body.get("category"), body.get("amount") or 0, body.get("goal_id"),
                                    bool(body.get("skip")))
    except ValueError as e:
        raise ApiError(str(e))


@route("POST", "/api/checkin/complete")
def checkin_complete(q, body):
    return checkin.complete(body)


# -------- partner cost sharing
def _partner_redirect(body):
    origin = (body.get("origin") or "").rstrip("/")
    host = (urlparse(origin).hostname or "").lower() if origin else ""
    return f"{origin}/oauth.html" if origin.startswith("https://") and host in auth.allowed_hosts() else None


@route("GET", "/api/partner")
def get_partner(q, body):
    return partner.summary()


@route("POST", "/api/partner")
def save_partner(q, body):
    try:
        partner.save(body)
    except ValueError as e:
        raise ApiError(str(e))
    if config.plaid_configured():
        partner.sync_all()
    refresh_derived()
    return partner.summary()


@route("DELETE", "/api/partner")
def delete_partner(q, body):
    partner.remove()
    refresh_derived()
    return {"ok": True}


@route("POST", "/api/partner/link_token")
def partner_link_token(q, body):
    if not config.plaid_configured():
        raise ApiError("Add your Plaid client_id and secret to config.json first (see README).")
    redirect = _partner_redirect(body)
    try:
        return {"link_token": partner.link_token(body.get("item_id"), redirect), "redirect": bool(redirect)}
    except plaid.PlaidError as e:
        if redirect and "redirect" in str(e).lower():
            try:
                return {"link_token": partner.link_token(body.get("item_id"), None), "redirect": False,
                        "redirect_hint": redirect}
            except plaid.PlaidError as e2:
                raise ApiError(f"Plaid: {e2}")
        raise ApiError(f"Plaid: {e}")


@route("POST", "/api/partner/exchange")
def partner_exchange(q, body):
    try:
        if body.get("item_id"):   # reconnected an existing link
            partner.sync_item(body["item_id"])
        else:
            partner.connect(body["public_token"], body.get("institution"))
    except plaid.PlaidError as e:
        raise ApiError(f"Plaid: {e}")
    except ValueError as e:
        raise ApiError(str(e))
    refresh_derived()
    return partner.summary()


@route("DELETE", r"/api/partner/items/(?P<item_id>[^/]+)")
def partner_remove_item(q, body, item_id):
    partner.remove_item(item_id)
    refresh_derived()
    return {"ok": True}


@route("POST", "/api/partner/tx")
def partner_add_tx(q, body):
    try:
        partner.add_manual(body)
    except ValueError as e:
        raise ApiError(str(e))
    refresh_derived()
    return partner.summary()


@route("DELETE", r"/api/partner/tx/(?P<tid>[^/]+)")
def partner_del_tx(q, body, tid):
    partner.delete_manual(tid)
    refresh_derived()
    return {"ok": True}


@route("POST", "/api/partner/toggle")
def partner_toggle(q, body):
    partner.toggle(body.get("id"), bool(body.get("shared")))
    refresh_derived()
    return partner.summary()


@route("POST", "/api/partner/settle")
def partner_settle(q, body):
    try:
        partner.settle(undo=bool(body.get("undo")))
    except ValueError as e:
        raise ApiError(str(e))
    return partner.summary()


@route("GET", "/api/partner/charges")
def partner_charges(q, body):
    return {"charges": partner.recent_charges(q.get("q") or "")}


# -------- bank connections
@route("POST", "/api/plaid/link_token")
def link_token(q, body):
    if not config.plaid_configured():
        raise ApiError("Add your Plaid client_id and secret to config.json first (see README).")
    item_id, add_inv = body.get("item_id"), bool(body.get("add_investments"))
    # Use Plaid's redirect sign-in when the app is opened over HTTPS at your Tailscale address
    origin = (body.get("origin") or "").rstrip("/")
    host = (urlparse(origin).hostname or "").lower() if origin else ""
    redirect = f"{origin}/oauth.html" if origin.startswith("https://") and host in auth.allowed_hosts() else None
    try:
        return {"link_token": plaid.create_link_token(item_id, add_inv, redirect), "redirect": bool(redirect)}
    except plaid.PlaidError as e:
        if redirect and "redirect" in str(e).lower():
            # Not allowlisted in the Plaid Dashboard yet: fall back to the pop-up and say how to fix it
            try:
                tok = plaid.create_link_token(item_id, add_inv, None)
            except plaid.PlaidError as e2:
                raise ApiError(f"Plaid: {e2}")
            return {"link_token": tok, "redirect": False, "redirect_hint": redirect}
        raise ApiError(f"Plaid: {e}")


@route("POST", "/api/plaid/exchange")
def exchange(q, body):
    try:
        item_id = plaid.exchange_public_token(body["public_token"], body.get("institution"))
    except plaid.PlaidError as e:
        raise ApiError(f"Plaid: {e}")
    refresh_derived()
    return {"item_id": item_id}


@route("POST", "/api/sync")
def sync(q, body):
    res = plaid.sync_all() if config.plaid_configured() else {"results": {}, "errors": {}}
    if config.plaid_configured():
        try:
            res["investments"] = investments.sync_all()
        except Exception as e:  # noqa: BLE001
            res["investments"] = {"error": str(e)}
        try:
            res["partner"] = partner.sync_all()
        except Exception as e:  # noqa: BLE001
            res["partner"] = {"error": str(e)}
    refresh_derived()
    db.set_setting("last_sync", datetime.now().isoformat(timespec="seconds"))
    return res


@route("DELETE", r"/api/plaid/items/(?P<item_id>[^/]+)")
def remove_item(q, body, item_id):
    plaid.remove_item(item_id)
    refresh_derived()
    return {"ok": True}


@route("POST", "/api/import/csv")
def import_csv(q, body):
    try:
        res = importer.import_csv(body.get("csv") or "", body.get("account_id"), bool(body.get("flip_sign")))
    except ValueError as e:
        raise ApiError(str(e))
    refresh_derived()
    return res


@route("POST", "/api/demo/load")
def demo_load(q, body):
    return demo.load()


@route("POST", "/api/demo/clear")
def demo_clear(q, body):
    demo.clear()
    refresh_derived()
    return {"ok": True}


# -------------------------------------------------------------- server ----
# Browsers enforce this on every page: scripts may only come from the app itself (and Plaid's sign-in
# widget), so even if a bank sent a booby-trapped merchant name, it could never run as code.
CSP = ("default-src 'self'; script-src 'self' https://cdn.plaid.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: https://*.plaid.com; font-src 'self' data:; connect-src 'self' https://*.plaid.com; frame-src https://*.plaid.com; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")


class Handler(BaseHTTPRequestHandler):
    server_version = "Kerdos"
    sys_version = ""
    timeout = 60   # a connection that goes quiet can't tie up the app forever

    def log_message(self, fmt, *args):  # quieter console
        if os.environ.get("FINANCE_DEBUG"):
            super().log_message(fmt, *args)

    def _host(self):
        return (self.headers.get("Host") or "").split(":")[0].lower()

    def _host_ok(self):
        # Blocks DNS-rebinding: only answer requests addressed to this computer, or to the
        # private Tailscale address you added for phone access (Accounts -> Phone access).
        host = self._host()
        return host in ("127.0.0.1", "localhost") or host in auth.allowed_hosts()

    def _remote(self):
        return self._host() not in ("127.0.0.1", "localhost")

    def _same_origin(self):
        # Browsers say where a request came from. Anything started by a different website, or by
        # another program's page on this PC (a different port), is refused before it touches data.
        site = self.headers.get("Sec-Fetch-Site")
        if site and site not in ("same-origin", "none"):
            return False
        origin = self.headers.get("Origin")
        if origin:
            o = urlparse(origin)
            port = self.server.server_address[1]
            if (o.hostname or "").lower() != self._host():
                return False
            if not self._remote() and (o.port or (443 if o.scheme == "https" else 80)) != port:
                return False
        return True

    def _send(self, status, payload, ctype="application/json", headers=None):
        data = payload if isinstance(payload, bytes) else json.dumps(payload, default=str).encode("utf-8")
        self.send_response(status)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()")
        self.end_headers()
        self.wfile.write(data)

    def _handle(self, method):
        if not self._host_ok():
            return self._send(403, {"error": "Forbidden host"})
        url = urlparse(self.path)
        if not url.path.startswith("/api/"):
            return self._static(url.path) if method == "GET" else self._send(405, {"error": "Method not allowed"})
        # Custom header = browsers won't send it cross-site without CORS approval (which we never grant).
        if method != "GET" and self.headers.get("X-Finance-Hub") != "1":
            return self._send(403, {"error": "Missing app header"})
        if not self._same_origin():
            return self._send(403, {"error": "Request came from another site"})
        q = {k: v[-1] for k, v in parse_qs(url.query).items()}
        is_auth = url.path.startswith("/api/auth/")
        # ---- password protection: everything under /api/ needs a signed-in session. This is checked
        # before a single byte of the request body is read.
        if not is_auth:
            if not auth.is_configured():
                return self._send(401, {"error": "Create a password to start using the app", "auth": "setup"})
            # Background refreshes (X-Background) don't count as activity, so an idle tab still locks
            if not auth.check_session(self._token(), touch=self.headers.get("X-Background") != "1"):
                return self._send(401, {"error": "Locked: sign in again", "auth": "locked"})
        body = {}
        if method in ("POST", "DELETE"):
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                n = -1
            if n < 0:
                return self._send(400, {"error": "Bad request"})
            if n > (16 * 1024 if is_auth else 25 * 1024 * 1024):
                return self._send(413, {"error": "Too large"})
            if n:
                try:
                    body = json.loads(self.rfile.read(n).decode("utf-8"))
                except ValueError:
                    return self._send(400, {"error": "Invalid JSON"})
                if not isinstance(body, dict):
                    return self._send(400, {"error": "Invalid request"})
        if is_auth:
            return self._auth(method, url.path, body)
        for m, rx, fn in ROUTES:
            if m != method:
                continue
            match = rx.match(url.path)
            if match:
                try:
                    args = {k: unquote(v) for k, v in match.groupdict().items()}
                    return self._send(200, fn(q, body, **args))
                except ApiError as e:
                    return self._send(e.status, {"error": str(e)})
                except db.Sealed:
                    return self._send(401, {"error": "Locked: sign in again", "auth": "locked"})
                except (KeyError, TypeError, AttributeError) as e:   # a field missing or of the wrong kind
                    traceback.print_exc()
                    return self._send(400, {"error": f"Invalid request ({type(e).__name__})"})
                except Exception as e:  # noqa: BLE001
                    traceback.print_exc()
                    return self._send(500, {"error": f"{type(e).__name__}: {e}"})
        return self._send(404, {"error": "Not found"})

    def _token(self):
        try:
            c = SimpleCookie(self.headers.get("Cookie") or "")
        except Exception:  # noqa: BLE001 - malformed cookie header
            return None
        return c[auth.COOKIE].value if auth.COOKIE in c else None

    def _session_cookie(self, token, lifetime, remember):
        v = f"{auth.COOKIE}={token}; HttpOnly; SameSite=Strict; Path=/"
        if self._remote():  # phone access always goes through Tailscale's HTTPS
            v += "; Secure"
        if remember:
            v += f"; Max-Age={int(lifetime.total_seconds())}"
        return {"Set-Cookie": v}

    def _auth(self, method, path, body):
        token = self._token()
        try:
            if method == "GET" and path == "/api/auth/status":
                return self._send(200, {"configured": auth.is_configured(),
                                        "signed_in": auth.check_session(token, touch=False),
                                        "idle_minutes": auth.idle_minutes(), "wait": auth.wait_seconds(),
                                        "min_length": auth.MIN_LENGTH, "vault": auth.vault_status(),
                                        "remote": self._remote()})
            if method == "POST" and path == "/api/auth/setup":
                if auth.is_configured():
                    return self._send(403, {"error": "A password is already set"})
                auth.set_password(body.get("password") or "")
                tok, life = auth.new_session(False)
                return self._send(200, {"ok": True}, headers=self._session_cookie(tok, life, False))
            if method == "POST" and path == "/api/auth/login":
                remember = bool(body.get("remember"))
                tok, life = auth.login(body.get("password") or "", remember)
                return self._send(200, {"ok": True}, headers=self._session_cookie(tok, life, remember))
            if method == "POST" and path == "/api/auth/logout":
                auth.logout(token)
                return self._send(200, {"ok": True},
                                  headers={"Set-Cookie": f"{auth.COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"})
            # The rest need you signed in
            if not auth.check_session(token):
                return self._send(401, {"error": "Locked: sign in again", "auth": "locked"})
            if method == "POST" and path == "/api/auth/change":
                auth.set_password(body.get("new") or "", current=body.get("current") or "")
                tok, life = auth.new_session(False)
                return self._send(200, {"ok": True}, headers=self._session_cookie(tok, life, False))
            if method == "POST" and path == "/api/auth/settings":
                mins = int(body.get("idle_minutes") or 0)
                if mins not in (0, 5, 15, 30, 60, 120):
                    raise ValueError("Pick one of the listed times")
                auth.set_idle_minutes(mins)
                return self._send(200, {"ok": True})
            if method == "POST" and path == "/api/auth/vault/enable":
                code, n = auth.enable_vault(body.get("password") or "")
                return self._send(200, {"ok": True, "recovery_code": code, "backups_encrypted": n})
            if method == "POST" and path == "/api/auth/vault/disable":
                auth.disable_vault(body.get("password") or "")
                return self._send(200, {"ok": True})
            if method == "GET" and path == "/api/auth/phone":
                return self._send(200, {"hosts": sorted(auth.allowed_hosts()), "tailscale": tailscale_info()})
            if method == "POST" and path == "/api/auth/phone":
                auth.set_allowed_hosts(body.get("hosts") or [])
                return self._send(200, {"ok": True, "hosts": sorted(auth.allowed_hosts())})
            if method == "POST" and path == "/api/auth/backup":
                return self._send(200, {"ok": True, "file": os.path.basename(db.backup_now("manual"))})
        except (ValueError, OSError, RuntimeError) as e:
            return self._send(400, {"error": str(e)})
        except (KeyError, TypeError, AttributeError):
            return self._send(400, {"error": "Invalid request"})
        return self._send(404, {"error": "Not found"})

    def _static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        try:
            full = os.path.realpath(os.path.join(STATIC, path.lstrip("/\\")))
            inside = os.path.commonpath([full, os.path.realpath(STATIC)]) == os.path.realpath(STATIC)
        except ValueError:   # different drive, odd characters
            inside = False
        if not inside or not os.path.isfile(full) or os.path.basename(full).startswith("."):
            return self._send(404, b"Not found", "text/plain")
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype.endswith("javascript"):
            ctype += "; charset=utf-8"
        with open(full, "rb") as f:
            self._send(200, f.read(), ctype)

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_DELETE(self):
        self._handle("DELETE")


def background_loop(stop):
    """Hourly: re-check alerts (dates move even without new data). Every N hours: sync banks."""
    while not stop.wait(5):
        try:
            if db.is_vault() and not db.is_open():
                stop.wait(25)
                continue  # encrypted and nobody has signed in since startup: nothing to do yet
            cfg = config.load()
            today = datetime.now().strftime("%Y-%m-%d")
            if db.get_setting("last_backup") != today:
                db.backup_now("auto")
                db.set_setting("last_backup", today)
            last = db.get_setting("last_sync")
            due = not last or datetime.fromisoformat(last) < datetime.now() - timedelta(
                hours=float(cfg.get("sync_interval_hours", 6)))
            if due and config.plaid_configured(cfg) and db.row("SELECT 1 FROM items LIMIT 1"):
                plaid.sync_all()
                try:
                    investments.sync_all()
                except Exception:  # noqa: BLE001
                    traceback.print_exc()
                try:
                    partner.sync_all()
                except Exception:  # noqa: BLE001
                    traceback.print_exc()
                db.set_setting("last_sync", datetime.now().isoformat(timespec="seconds"))
            last_check = db.get_setting("last_alert_check")
            if due or not last_check or datetime.fromisoformat(last_check) < datetime.now() - timedelta(hours=1):
                if db.row("SELECT 1 FROM accounts LIMIT 1"):
                    refresh_derived()
                db.set_setting("last_alert_check", datetime.now().isoformat(timespec="seconds"))
        except Exception:  # noqa: BLE001 - keep the loop alive
            traceback.print_exc()
        stop.wait(55)


def _one_time_merges():
    """Category combinations you asked for (Nov 2026). Runs once; undo on the Transactions page."""
    if db.get_setting("merges_v1_done"):
        return
    used = {r["category"] for r in db.rows("SELECT DISTINCT category FROM transactions")}
    custom = set(db.get_setting("custom_categories", []) or [])
    plan = [(["Utilities", "Phone & Internet"], "Utilities & Phone"),
            (["Health", "Personal Care"], "Health & Personal Care"),
            ([c for c in used | custom if c.lower().startswith("roommate")], "Transfer")]
    done = []
    for sources, target in plan:
        if any(s in used or s in custom for s in sources):
            r = categorize.merge(sources, target)
            done.append(f"{' + '.join(r['sources'])} → {target} ({r['moved']} transactions)")
    db.set_setting("merges_v1_done", True)
    if done:
        alerts.add("merges_v1", "info", "Combined categories",
                   "; ".join(done) + ". Undo any of them on the Transactions page.")


def _already_running(port):
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def tailscale_info():
    """Your PC's private Tailscale name, if Tailscale is installed and signed in."""
    import shutil
    import subprocess
    exe = shutil.which("tailscale") or r"C:\Program Files\Tailscale\tailscale.exe"
    if not os.path.exists(exe):
        return {"installed": False}
    try:
        out = subprocess.run([exe, "status", "--json"], capture_output=True, text=True, timeout=8,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        st = json.loads(out.stdout or "{}")
        dns = (st.get("Self") or {}).get("DNSName", "").rstrip(".")
        return {"installed": True, "running": st.get("BackendState") == "Running", "dns_name": dns}
    except Exception as e:  # noqa: BLE001
        return {"installed": True, "running": False, "error": str(e)}


def main():
    mimetypes.add_type("application/javascript", ".js")
    mimetypes.add_type("text/css", ".css")
    for extra in ("", ".bak"):   # encrypt any plain-text secrets left in config.json or its backup copy
        try:
            n = config.seal_file(config.CONFIG_PATH + extra)
            if n:
                print(f"Encrypted {n} secret(s) in config.json{extra} (readable only by your Windows user).")
        except OSError:
            traceback.print_exc()
    cfg = config.load()
    port = int(os.environ.get("FINANCE_PORT") or cfg.get("port", 8765))
    if _already_running(port):
        print(f"Kerdos is already running at http://localhost:{port}")
        return

    def startup_work():  # bring older data up to date with new features
        categorize.apply_alias_sets()
        _one_time_merges()
        categorize.backfill_confidence()
        categorize.recategorize_all()  # re-applies your rules and the learner
        splits.apply()
    db.on_open(lambda: threading.Thread(target=startup_work, daemon=True).start())
    if not db.is_vault():
        db.get()
    stop = threading.Event()
    threading.Thread(target=background_loop, args=(stop,), daemon=True).start()
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"Kerdos running at http://localhost:{port}  (Ctrl+C to stop)")
    if db.is_vault():
        print("Your data is encrypted: sign in once to unlock syncing and alerts.")
    print("Plaid:", "configured (" + cfg["plaid"].get("env", "sandbox") + ")" if config.plaid_configured(cfg)
          else "not configured - demo data and CSV import still work")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        httpd.server_close()
        db.save_vault()


if __name__ == "__main__":
    main()
