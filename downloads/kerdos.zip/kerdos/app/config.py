"""Loads config.json and protects bank access tokens at rest.

On Windows, Plaid access tokens are encrypted with DPAPI (CryptProtectData),
so the database file is useless if copied to another machine or user account.
"""
import base64
import ctypes
import json
import os
import sys

from . import db

CONFIG_PATH = os.path.join(db.ROOT, "config.json")

DEFAULTS = {
    "port": 8765,
    "plaid": {"client_id": "", "secret": "", "env": "sandbox"},
    "sync_interval_hours": 6,
    "notify": {
        "ntfy_url": "",
        "email": {
            "enabled": False,
            "smtp_host": "smtp.gmail.com",
            "smtp_port": 587,
            "username": "",
            "password": "",
            "to": "",
        },
    },
}


def _merge(base, extra):
    out = dict(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


# Secrets in config.json are kept encrypted on disk (Windows DPAPI: only your Windows user on this
# PC can read them). You can still paste a new secret in as plain text; it's sealed at next start.
SECRET_PATHS = (("plaid", "secret"), ("notify", "email", "password"))
SEALED = "dpapi:"
_cache = {"stamp": None, "cfg": None}


def _walk(d, path):
    for k in path[:-1]:
        d = d.get(k) if isinstance(d, dict) else None
        if not isinstance(d, dict):
            return None, None
    return d, path[-1]


def _unseal(cfg):
    for path in SECRET_PATHS:
        d, k = _walk(cfg, path)
        v = d.get(k) if d else None
        if isinstance(v, str) and v.startswith(SEALED):
            try:
                d[k] = unprotect(base64.b64decode(v[len(SEALED):]))
            except (OSError, ValueError):
                d[k] = ""   # sealed by another Windows user/PC: treat as not set
                print(f"config.json: couldn't decrypt {'.'.join(path)}. Paste the value in again as plain text.")
    return cfg


def seal_file(path=None):
    """Encrypt any plain-text secrets in config.json (or a copy of it) in place. Returns how many."""
    path = path or CONFIG_PATH
    if sys.platform != "win32" or not os.path.exists(path):
        return 0
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except (OSError, ValueError):
        return 0
    n = 0
    for sp in SECRET_PATHS:
        d, k = _walk(raw, sp)
        v = d.get(k) if d else None
        if isinstance(v, str) and v and not v.startswith(SEALED):
            d[k] = SEALED + base64.b64encode(protect(v)).decode("ascii")
            n += 1
    if n:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(raw, f, indent=2)
        os.replace(tmp, path)
        _cache["stamp"] = None
    return n


def load():
    if os.path.exists(CONFIG_PATH):
        st = os.stat(CONFIG_PATH)
        stamp = (st.st_mtime_ns, st.st_size)
        if _cache["stamp"] != stamp:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                _cache["cfg"] = _unseal(_merge(DEFAULTS, json.load(f)))
            _cache["stamp"] = stamp
        return json.loads(json.dumps(_cache["cfg"]))
    return json.loads(json.dumps(DEFAULTS))


def plaid_configured(cfg=None):
    cfg = cfg or load()
    p = cfg.get("plaid", {})
    return bool(p.get("client_id") and p.get("secret"))


# ---------------------------------------------------------------- DPAPI ----
if sys.platform == "win32":
    from ctypes import wintypes

    class _BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    def _to_blob(data):
        buf = ctypes.create_string_buffer(data, len(data))
        return _BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    def _from_blob(blob):
        out = ctypes.string_at(blob.pbData, blob.cbData)
        ctypes.windll.kernel32.LocalFree(blob.pbData)
        return out

    CRYPTPROTECT_UI_FORBIDDEN = 0x1

    def protect_bytes(data: bytes, key: bytes) -> bytes:
        """DPAPI with a secret key ("entropy"): needs this Windows user AND the key to decrypt."""
        blob_in, _k1 = _to_blob(data)
        ent, _k2 = _to_blob(key)
        blob_out = _BLOB()
        if not ctypes.windll.crypt32.CryptProtectData(
            ctypes.byref(blob_in), "finance-vault", ctypes.byref(ent), None, None,
            CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(blob_out)
        ):
            raise OSError("CryptProtectData failed")
        return _from_blob(blob_out)

    def unprotect_bytes(data: bytes, key: bytes) -> bytes:
        blob_in, _k1 = _to_blob(data)
        ent, _k2 = _to_blob(key)
        blob_out = _BLOB()
        if not ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(blob_in), None, ctypes.byref(ent), None, None,
            CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(blob_out)
        ):
            raise ValueError("Couldn't decrypt: wrong key, or this file belongs to another Windows user")
        return _from_blob(blob_out)

    def protect(plain: str) -> bytes:
        blob_in, _keep = _to_blob(plain.encode("utf-8"))
        blob_out = _BLOB()
        if not ctypes.windll.crypt32.CryptProtectData(
            ctypes.byref(blob_in), "finance-app", None, None, None, 0, ctypes.byref(blob_out)
        ):
            raise OSError("CryptProtectData failed")
        return b"DPAPI:" + _from_blob(blob_out)

    def unprotect(data: bytes) -> str:
        if not data.startswith(b"DPAPI:"):
            return _plain_unprotect(data)
        blob_in, _keep = _to_blob(data[6:])
        blob_out = _BLOB()
        if not ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)
        ):
            raise OSError("CryptUnprotectData failed (token was saved by another Windows user?)")
        return _from_blob(blob_out).decode("utf-8")

else:  # macOS/Linux: rely on file permissions of data/ (documented in README)

    def protect(plain: str) -> bytes:
        return b"B64:" + base64.b64encode(plain.encode("utf-8"))

    def unprotect(data: bytes) -> str:
        return _plain_unprotect(data)

    def protect_bytes(data: bytes, key: bytes) -> bytes:
        raise OSError("Database encryption needs Windows (DPAPI)")

    def unprotect_bytes(data: bytes, key: bytes) -> bytes:
        raise OSError("Database encryption needs Windows (DPAPI)")


def _plain_unprotect(data: bytes) -> str:
    if data.startswith(b"B64:"):
        return base64.b64decode(data[4:]).decode("utf-8")
    return data.decode("utf-8")
