"""SQLite storage. Everything lives in data/finance.db next to the app."""
import atexit
import json
import os
import sqlite3
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT, "data")
DB_PATH = os.path.join(DATA_DIR, "finance.db")

_lock = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    item_id TEXT PRIMARY KEY,
    access_token BLOB NOT NULL,
    institution TEXT,
    cursor TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    last_sync TEXT,
    error TEXT
);
CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    item_id TEXT,
    name TEXT NOT NULL,
    official_name TEXT,
    mask TEXT,
    type TEXT NOT NULL,          -- depository | credit | loan | investment | other
    subtype TEXT,
    institution TEXT,
    current_balance REAL DEFAULT 0,  -- for credit/loan: amount owed (positive)
    available_balance REAL,
    currency TEXT DEFAULT 'USD',
    is_manual INTEGER DEFAULT 0,
    is_hidden INTEGER DEFAULT 0,
    source TEXT DEFAULT 'manual',  -- plaid | csv | manual | demo
    updated_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    account_id TEXT,
    date TEXT NOT NULL,
    name TEXT NOT NULL,
    merchant TEXT,
    amount REAL NOT NULL,         -- negative = money out, positive = money in
    plaid_category TEXT,
    category TEXT,
    category_source TEXT,         -- user | rule | builtin | plaid | default
    pending INTEGER DEFAULT 0,
    notes TEXT,
    source TEXT DEFAULT 'manual'
);
CREATE INDEX IF NOT EXISTS ix_tx_date ON transactions(date);
CREATE INDEX IF NOT EXISTS ix_tx_account ON transactions(account_id);
CREATE TABLE IF NOT EXISTS rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern TEXT NOT NULL,
    category TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS liabilities (
    account_id TEXT PRIMARY KEY,
    kind TEXT,                    -- credit | student | mortgage
    apr REAL,
    minimum_payment REAL,
    next_due_date TEXT,
    last_statement_balance REAL,
    updated_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS bills (
    id TEXT PRIMARY KEY,
    merchant TEXT NOT NULL,
    display_name TEXT,
    account_id TEXT,
    category TEXT,
    avg_amount REAL,
    last_amount REAL,
    cadence_days REAL,
    cadence TEXT,
    last_date TEXT,
    next_date TEXT,
    occurrences INTEGER,
    autopay TEXT DEFAULT 'likely',  -- yes | likely | no
    status TEXT DEFAULT 'active',    -- active | ignored
    user_edited INTEGER DEFAULT 0,
    updated_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT UNIQUE NOT NULL,
    kind TEXT NOT NULL,
    severity TEXT DEFAULT 'info',   -- info | warn | danger
    title TEXT NOT NULL,
    body TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    is_read INTEGER DEFAULT 0,
    delivered INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS networth_snapshots (
    date TEXT PRIMARY KEY,
    assets REAL,
    liabilities REAL,
    net REAL
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


def data_dir():
    return os.path.dirname(DB_PATH)


def vault_path():
    """Encrypted database file (used once you turn on encryption)."""
    return DB_PATH + ".vault"


def backups_dir():
    return os.path.join(data_dir(), "backups")


def connect():
    os.makedirs(data_dir(), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


class Sealed(Exception):
    """The database is encrypted and nobody has signed in since the app started."""


_conn = None
_vault_key = None        # in memory only, while unlocked
_saved_changes = 0
_saver = None
_on_open = []            # callbacks run once the database becomes available


def is_vault():
    return os.path.exists(vault_path())


def is_open():
    return _conn is not None


def on_open(fn):
    _on_open.append(fn)


def _prepare(conn):
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    _migrate(conn)
    conn.commit()


def get():
    """Shared connection guarded by a re-entrant lock (single-user local app)."""
    global _conn
    with _lock:
        if _conn is None:
            if is_vault():
                raise Sealed("Sign in to unlock your encrypted data")
            _conn = connect()
            _prepare(_conn)
            _run_on_open()
        return _conn


def _run_on_open():
    for fn in list(_on_open):
        try:
            fn()
        except Exception:  # noqa: BLE001 - startup hooks must never block opening
            import traceback
            traceback.print_exc()


# ------------------------------------------------------------- vault ----
def _seal(raw, key):
    from . import config
    return b"FHV1" + config.protect_bytes(raw, key)


def _unseal(blob, key):
    from . import config
    if not blob.startswith(b"FHV1"):
        raise ValueError("Not a Kerdos encrypted file")
    return config.unprotect_bytes(blob[4:], key)


def _write_atomic(path, data):
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _memory_conn(raw):
    raw = bytearray(raw)
    if len(raw) > 19 and raw[18] == 2:  # file was in WAL mode; in-memory databases can't use WAL
        raw[18] = raw[19] = 1
    conn = sqlite3.connect(":memory:", check_same_thread=False)
    conn.deserialize(bytes(raw))
    _prepare(conn)
    return conn


def open_vault(key):
    """Decrypt the vault into memory. Raises if the key is wrong."""
    global _conn, _vault_key, _saved_changes
    with _lock:
        if _conn is not None:
            return
        with open(vault_path(), "rb") as f:
            raw = _unseal(f.read(), key)
        _conn = _memory_conn(raw)
        _vault_key = key
        _saved_changes = _conn.total_changes
        _start_saver()
    _run_on_open()


def save_vault(force=False):
    """Write the in-memory database back to the encrypted file if anything changed."""
    global _saved_changes
    with _lock:
        if _conn is None or _vault_key is None:
            return False
        if not force and _conn.total_changes == _saved_changes:
            return False
        raw = _conn.serialize()
        changes = _conn.total_changes
    blob = _seal(raw, _vault_key)
    path = vault_path()
    if os.path.exists(path):
        try:
            os.replace(path, path + ".prev")  # one step of undo if a write is ever interrupted
        except OSError:
            pass
    _write_atomic(path, blob)
    _saved_changes = changes
    return True


def _start_saver():
    global _saver
    if _saver:
        return

    def loop():
        while True:
            time.sleep(4)
            try:
                save_vault()
            except Exception:  # noqa: BLE001
                import traceback
                traceback.print_exc()

    _saver = threading.Thread(target=loop, daemon=True, name="vault-saver")
    _saver.start()
    atexit.register(lambda: save_vault(force=False))


def enable_vault(key):
    """Encrypt the current plain database (and existing backups). Verified before anything is deleted."""
    global _conn, _vault_key, _saved_changes
    with _lock:
        conn = get()
        conn.commit()
        raw = conn.serialize()
        counts = {t: conn.execute(f"SELECT count(*) FROM {t}").fetchone()[0] for t in ("transactions", "accounts")}
        _write_atomic(vault_path(), _seal(raw, key))
        # Prove the encrypted copy opens and holds the same data before deleting the plain file
        check = _memory_conn(_unseal(open(vault_path(), "rb").read(), key))
        for t, n in counts.items():
            if check.execute(f"SELECT count(*) FROM {t}").fetchone()[0] != n:
                os.remove(vault_path())
                raise RuntimeError("Encryption check failed; nothing was changed")
        conn.close()
        _conn, _vault_key = check, key
        _saved_changes = _conn.total_changes
        for ext in ("", "-wal", "-shm"):
            if os.path.exists(DB_PATH + ext):
                os.remove(DB_PATH + ext)
        _start_saver()
    return encrypt_backups(key)


def encrypt_backups(key):
    """Turn plain .db backups into encrypted .db.vault files (verified first)."""
    done = 0
    d = backups_dir()
    if not os.path.isdir(d):
        return 0
    for name in os.listdir(d):
        if not name.endswith(".db"):
            continue
        p = os.path.join(d, name)
        src = sqlite3.connect(p)
        raw = src.serialize()
        src.close()
        _write_atomic(p + ".vault", _seal(raw, key))
        if _unseal(open(p + ".vault", "rb").read(), key) == raw:
            os.remove(p)
            done += 1
    return done


def disable_vault():
    """Write the database back out as a normal (unencrypted) file."""
    global _conn, _vault_key
    with _lock:
        if _conn is None or _vault_key is None:
            raise Sealed("Unlock first")
        raw = bytearray(_conn.serialize())  # a serialized database is a complete database file
        raw[18] = raw[19] = 1
        _write_atomic(DB_PATH, bytes(raw))
        check = sqlite3.connect(DB_PATH)
        ok = check.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        check.close()
        if not ok:
            os.remove(DB_PATH)
            raise RuntimeError("Couldn't write the unencrypted copy; encryption stays on")
        old = vault_path()
        _conn.close()
        _conn, _vault_key = None, None
        os.replace(old, old + ".disabled")  # kept until you delete it, just in case
        get()


def backup_now(tag="auto"):
    """Save a dated backup. Encrypted data is backed up encrypted. Keeps the newest 30 automatic ones."""
    os.makedirs(backups_dir(), exist_ok=True)
    stamp = time.strftime("%Y-%m-%d")
    if is_vault():
        save_vault(force=True)
        dest = os.path.join(backups_dir(), f"{tag}-{stamp}.db.vault")
        with open(vault_path(), "rb") as f:
            _write_atomic(dest, f.read())
    else:
        dest = os.path.join(backups_dir(), f"{tag}-{stamp}.db")
        with _lock:
            out = sqlite3.connect(dest + ".tmp")
            get().backup(out)
            out.close()
        os.replace(dest + ".tmp", dest)
    autos = sorted(n for n in os.listdir(backups_dir()) if n.startswith(f"{tag}-"))
    for old in autos[:-30]:
        os.remove(os.path.join(backups_dir(), old))
    return dest


MIGRATIONS = [
    # (table, column, type)
    ("transactions", "confidence", "TEXT"),      # high | medium | low
    ("transactions", "pair_id", "TEXT"),         # other half of a transfer / card payment
    ("transactions", "pair_kind", "TEXT"),       # card_payment | transfer | investment
    ("bills", "pays_account_id", "TEXT"),        # card/loan this payment pays down
    ("bills", "autopay_reason", "TEXT"),
    ("accounts", "credit_limit", "REAL"),        # what the bank reports as the card's limit
]

EXTRA_SCHEMA = """
CREATE TABLE IF NOT EXISTS ai_guess (
    sig TEXT PRIMARY KEY,          -- merchant + direction: one guess shared by transactions that look alike
    category TEXT,                 -- NULL = the model was asked and gave nothing usable
    confidence REAL,
    reason TEXT,
    model TEXT,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    name TEXT NOT NULL,
    target REAL,
    params TEXT DEFAULT '{}',
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS goal_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    goal_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    amount REAL NOT NULL,
    note TEXT
);
CREATE INDEX IF NOT EXISTS ix_tx_pair ON transactions(pair_id);
"""


def _migrate(conn):
    for table, col, typ in MIGRATIONS:
        cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
        if col not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
    conn.executescript(EXTRA_SCHEMA)


def lock():
    return _lock


def rows(sql, params=()):
    with _lock:
        return [dict(r) for r in get().execute(sql, params).fetchall()]


def row(sql, params=()):
    with _lock:
        r = get().execute(sql, params).fetchone()
        return dict(r) if r else None


def execute(sql, params=()):
    with _lock:
        conn = get()
        cur = conn.execute(sql, params)
        conn.commit()
        return cur


def get_setting(key, default=None):
    r = row("SELECT value FROM settings WHERE key = ?", (key,))
    if not r:
        return default
    try:
        return json.loads(r["value"])
    except (TypeError, ValueError):
        return default


def set_setting(key, value):
    execute(
        "INSERT INTO settings(key, value) VALUES(?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, json.dumps(value)),
    )
