"""Undo for categorising: every sort (and the rule / learner changes it caused) can be reversed."""
from datetime import datetime

from . import db

MAX_STEPS = 30


def snapshot():
    return {r["id"]: (r["category"], r["category_source"], r["confidence"])
            for r in db.rows("SELECT id, category, category_source, confidence FROM transactions")}


def rule_state(pattern):
    r = db.row("SELECT category FROM rules WHERE pattern = ?", (pattern,))
    return r["category"] if r else None


def record(label, before, rule=None, new_category=None):
    """Store what changed since `before` so it can be put back. rule = {"pattern", "prev"}."""
    after = snapshot()
    changes = [[tid, *before[tid]] for tid, state in after.items() if tid in before and before[tid] != state]
    if not changes and not rule:
        return None
    stack = db.get_setting("undo_stack", []) or []
    stack.append({"label": label, "at": datetime.now().isoformat(timespec="seconds"), "changes": changes,
                  "rule": rule, "new_category": new_category})
    db.set_setting("undo_stack", stack[-MAX_STEPS:])
    return len(changes)


def peek():
    stack = db.get_setting("undo_stack", []) or []
    return stack[-1] if stack else None


def undo():
    stack = db.get_setting("undo_stack", []) or []
    if not stack:
        raise ValueError("Nothing to undo")
    step = stack.pop()
    with db.lock():
        conn = db.get()
        for tid, cat, src, conf in step["changes"]:
            conn.execute("UPDATE transactions SET category = ?, category_source = ?, confidence = ? WHERE id = ?",
                         (cat, src, conf, tid))
        r = step.get("rule")
        if r:
            if r.get("prev") is None:
                conn.execute("DELETE FROM rules WHERE pattern = ?", (r["pattern"],))
            else:
                conn.execute("UPDATE rules SET category = ? WHERE pattern = ?", (r["prev"], r["pattern"]))
        conn.commit()
    nc = step.get("new_category")
    if nc and not db.row("SELECT 1 FROM transactions WHERE category = ? LIMIT 1", (nc,)):
        custom = [c for c in db.get_setting("custom_categories", []) if c != nc]
        db.set_setting("custom_categories", custom)
    db.set_setting("undo_stack", stack)
    return {"label": step["label"], "restored": len(step["changes"]), "ids": [c[0] for c in step["changes"]],
            "remaining": len(stack)}
