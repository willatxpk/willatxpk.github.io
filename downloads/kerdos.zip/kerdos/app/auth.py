"""Password protection and (optional) encryption of your data.

Password
* Never stored: only a salted PBKDF2-SHA256 hash (600,000 rounds) in data/auth.json.
* Signing in creates a random session token (HttpOnly, SameSite=Strict cookie). Sessions live
  in memory: restarting the app signs everyone out.
* Idle sessions lock after `idle_minutes` (default 30) unless you chose "keep me signed in".
* Wrong guesses slow down: after 5 misses each further try waits longer (up to 15 minutes).

Encryption ("vault", opt-in)
* Your database is encrypted with a random 256-bit data key using Windows DPAPI, so it can only
  be decrypted by your Windows user AND with that key.
* The data key is stored twice, each copy locked by a key derived from (a) your password and
  (b) a one-time recovery code. Changing your password re-locks only the key, not the data.
* While the app runs and you've signed in since it started, the data is decrypted in memory
  and written back encrypted every few seconds. After a restart nothing (including syncing and
  alerts) runs until you sign in once.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from datetime import datetime, timedelta

from . import config, db

ITERATIONS = 600_000
MIN_LENGTH = 8
COOKIE = "fh_session"
SHORT_HOURS, LONG_DAYS = 12, 7
RC_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no 0/O, 1/I

_lock = threading.RLock()
_guess_lock = threading.Lock()  # one password check at a time, so a burst of parallel guesses can't outrun the lockout
_fails = {"count": 0, "until": 0.0}
_sessions = {}  # token_hash -> {"last_seen", "expires", "remember"}


# --------------------------------------------------------------- storage ----
def _path():
    return os.path.join(db.data_dir(), "auth.json")


def _load():
    p = _path()
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    # One-time move from the older location (inside the database)
    if not db.is_vault():
        try:
            old = db.get_setting("auth")
        except Exception:  # noqa: BLE001
            old = None
        if old:
            data = {"password": old, "idle_minutes": db.get_setting("auth_idle_minutes", 30)}
            _save(data)
            db.execute("DELETE FROM settings WHERE key IN ('auth', 'auth_idle_minutes')")
            return data
    return {}


def _save(data):
    os.makedirs(db.data_dir(), exist_ok=True)
    tmp = _path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)
    os.replace(tmp, _path())


def _kdf(secret, salt, iterations=ITERATIONS):
    return hashlib.pbkdf2_hmac("sha256", secret.encode("utf-8"), salt, iterations)


def _norm_code(code):
    return "".join(ch for ch in (code or "").upper() if ch in RC_ALPHABET)


# --------------------------------------------------------------- password ----
def is_configured():
    return bool(_load().get("password"))


def idle_minutes():
    return int(_load().get("idle_minutes", 30))


def set_idle_minutes(mins):
    data = _load()
    data["idle_minutes"] = int(mins)
    _save(data)


def check_password(password):
    pw = _load().get("password")
    if not pw:
        return False
    got = _kdf(password or "", bytes.fromhex(pw["salt"]), pw.get("iterations", ITERATIONS)).hex()
    return hmac.compare_digest(got, pw["hash"])


def _hash_record(password):
    salt = secrets.token_bytes(16)
    return {"salt": salt.hex(), "hash": _kdf(password, salt).hex(), "iterations": ITERATIONS}


def set_password(password, current=None):
    """First-time setup (current=None) or change (must give the current password)."""
    if len(password or "") < MIN_LENGTH:
        raise ValueError(f"Use at least {MIN_LENGTH} characters")
    data = _load()
    if data.get("password"):
        if current is None or not verify(current):
            raise ValueError("Your current password isn't right")
    if data.get("vault"):  # re-lock the data key with the new password
        key = _unwrap(data["vault"], "pw", current)
        data["vault"].update(_wrap(key, "pw", password))
    data["password"] = _hash_record(password)
    _save(data)
    with _lock:
        _sessions.clear()  # changing the password signs out everywhere
        _fails.update(count=0, until=0.0)


def wait_seconds():
    with _lock:
        return max(0, int(_fails["until"] - time.time() + 0.999))


def verify(password):
    """Check the password, counting wrong tries. Every place that accepts the password goes through
    here, one at a time, so the lockout applies however the guesses arrive."""
    with _guess_lock:
        wait = wait_seconds()
        if wait:
            raise ValueError(f"Too many wrong tries. Wait {wait} seconds.")
        if check_password(password):
            with _lock:
                _fails.update(count=0, until=0.0)
            return True
        with _lock:
            _fails["count"] += 1
            if _fails["count"] >= 5:
                _fails["until"] = time.time() + min(900, 30 * 2 ** min(10, _fails["count"] - 5))
        time.sleep(0.4)
        return False


def login(password, remember=False):
    """Returns (token, lifetime). Also unlocks encrypted data after a restart."""
    if not verify(password):
        raise ValueError("That password isn't right")
    vault = _load().get("vault")
    if vault and not db.is_open():
        db.open_vault(_unwrap(vault, "pw", password))
    return new_session(remember)


def new_session(remember=False):
    token = secrets.token_urlsafe(32)
    now = datetime.now()
    life = timedelta(days=LONG_DAYS) if remember else timedelta(hours=SHORT_HOURS)
    with _lock:
        _sessions[hashlib.sha256(token.encode()).hexdigest()] = {
            "last_seen": now, "expires": now + life, "remember": remember}
    return token, life


def check_session(token, touch=True):
    if not token:
        return False
    th = hashlib.sha256(token.encode()).hexdigest()
    now = datetime.now()
    with _lock:
        s = _sessions.get(th)
        if not s:
            return False
        idle = idle_minutes()
        if s["expires"] < now or (not s["remember"] and idle and s["last_seen"] < now - timedelta(minutes=idle)):
            _sessions.pop(th, None)
            return False
        if touch:
            s["last_seen"] = now
    if db.is_vault() and not db.is_open():
        return False  # data still sealed (shouldn't happen: sessions don't survive restarts)
    return True


def logout(token):
    if token:
        with _lock:
            _sessions.pop(hashlib.sha256(token.encode()).hexdigest(), None)


# ------------------------------------------------------------------ vault ----
def _wrap(key, which, secret):
    salt = secrets.token_bytes(16)
    wrapped = config.protect_bytes(key, _kdf(secret, salt))
    return {f"{which}_salt": salt.hex(), f"{which}_wrapped": base64.b64encode(wrapped).decode()}


def _unwrap(vault, which, secret):
    if which == "rc":
        secret = _norm_code(secret)
    try:
        return config.unprotect_bytes(base64.b64decode(vault[f"{which}_wrapped"]),
                                      _kdf(secret, bytes.fromhex(vault[f"{which}_salt"])))
    except ValueError:
        raise ValueError("That password isn't right" if which == "pw" else "That recovery code isn't right")


def vault_status():
    return {"enabled": bool(_load().get("vault")), "sealed": db.is_vault() and not db.is_open()}


def enable_vault(password):
    """Encrypt everything. Returns the recovery code (shown once)."""
    if not verify(password):
        raise ValueError("That password isn't right")
    data = _load()
    if data.get("vault"):
        raise ValueError("Encryption is already on")
    key = secrets.token_bytes(32)
    code = "-".join("".join(secrets.choice(RC_ALPHABET) for _ in range(4)) for _ in range(6))
    vault = {**_wrap(key, "pw", password), **_wrap(key, "rc", _norm_code(code)),
             "enabled_at": datetime.now().isoformat(timespec="seconds")}
    data["vault"] = vault
    _save(data)  # save the locked keys before touching the database
    try:
        n_backups = db.enable_vault(key)
    except Exception:
        data.pop("vault")
        _save(data)
        raise
    return code, n_backups


def disable_vault(password):
    if not verify(password):
        raise ValueError("That password isn't right")
    db.save_vault(force=True)
    db.disable_vault()
    data = _load()
    data.pop("vault", None)
    _save(data)


def recover(code, new_password):
    """Forgot your password? The recovery code unlocks the data key and sets a new password."""
    data = _load()
    vault = data.get("vault")
    if not vault:
        raise ValueError("Encryption isn't on: use --reset-password instead")
    if len(new_password or "") < MIN_LENGTH:
        raise ValueError(f"Use at least {MIN_LENGTH} characters")
    key = _unwrap(vault, "rc", code)
    vault.update(_wrap(key, "pw", new_password))
    data["password"] = _hash_record(new_password)
    _save(data)


def reset():
    """Emergency reset (no encryption only): removes the password."""
    data = _load()
    if data.get("vault"):
        raise ValueError("Your data is encrypted, so the password can't simply be removed. "
                         "Use:  py -3.12 main.py --recover   with your recovery code.")
    data.pop("password", None)
    _save(data)


# ---------------------------------------------------------- phone access ----
def allowed_hosts():
    """Extra host names (your Tailscale address) the app will answer to, besides localhost."""
    return set(h.lower() for h in _load().get("allowed_hosts", []))


def set_allowed_hosts(hosts):
    clean = []
    for h in hosts:
        h = (h or "").strip().lower().removeprefix("https://").removeprefix("http://").split("/")[0].split(":")[0]
        if not h:
            continue
        if not h.endswith(".ts.net"):
            raise ValueError("For safety only private Tailscale addresses (ending in .ts.net) can be added")
        clean.append(h)
    data = _load()
    data["allowed_hosts"] = sorted(set(clean))
    _save(data)
