"""Credit card rewards: a built-in list of well-known cards and what each one earns.

Banks don't pass a card's rewards terms along with its transactions, and there is no free public feed of
them, so the app carries its own list (card_catalog.json, gathered from the issuers' pages; the file says
when it was last checked). A card is recognised from the name your bank reports for the account, entirely
on this computer: nothing about your cards is sent anywhere.

A card's terms are turned into "rules" for a given quarter: an earn rate for some kinds of purchase,
sometimes with a spending cap. Rotating 5% categories are rules that only exist in their own quarter.
"""
import json
import os
import re
from collections import defaultdict
from datetime import date, timedelta

_PATH = os.path.join(os.path.dirname(__file__), "card_catalog.json")
_cache = {"mtime": None, "data": None}

# Kinds of purchase that cards reward differently. A purchase gets at most one kind; anything else is
# handled by its ordinary category.
KINDS = {
    "dining": "Dining", "groceries": "Groceries", "whole_foods": "Whole Foods", "gas": "Gas",
    "ev_charging": "EV charging", "transit": "Transit & rideshare", "flights": "Flights", "hotels": "Hotels",
    "car_rental": "Car rental", "travel_other": "Other travel", "streaming": "Streaming",
    "drugstores": "Drugstores", "amazon": "Amazon", "walmart": "Walmart", "target": "Target",
    "costco": "Costco", "wholesale_clubs": "Wholesale clubs", "paypal": "PayPal",
    "home_improvement": "Home improvement", "department_stores": "Department stores",
    "online_shopping": "Online shopping", "entertainment": "Entertainment", "fitness": "Gyms & fitness",
    "phone_internet": "Phone & internet", "utilities": "Utilities", "rent": "Rent",
}
# A rule for the kind on the right also covers the kind on the left
PARENTS = {"whole_foods": ("groceries",), "costco": ("wholesale_clubs",), "amazon": ("online_shopping",)}
PER = {"year": "a year", "quarter": "a quarter", "month": "a month", "billing_cycle": "a month"}

_RX = {k: re.compile(v, re.I) for k, v in {
    "streaming": r"netflix|spotify|hulu|disney\s*\+|disney plus|hbo|max\.com|youtube\s*(premium|tv|music)|paramount\s*\+|"
                 r"paramount plus|peacock|apple tv|apple music|prime video|siriusxm|pandora|crunchyroll|espn\s*\+|\btidal\b",
    "whole_foods": r"whole\s*foods|wholefds",
    "costco": r"costco",
    "clubs": r"sam'?s\s*club|samsclub|bj'?s wholesale",
    "walmart": r"wal-?mart|\bwm supercenter",
    "target": r"\btarget\b",
    "amazon": r"amazon|amzn",
    "paypal": r"paypal\s*\*",
    "ev": r"chargepoint|electrify america|\bevgo\b|supercharg|blink charging",
    "gas": r"\bshell\b|chevron|exxon|\bmobil\b|\barco\b|\b76\b|\bbp\b|sunoco|valero|speedway|circle k|\bwawa\b|"
           r"marathon petro|phillips 66|conoco|\bcitgo\b|texaco|gas station|\bfuel\b|\bgas\b",
    "drug": r"\bcvs\b|walgreens|rite aid|duane reade",
    "home": r"home depot|lowe'?s|ace hardware|menards",
    "transit": r"\buber\b(?!\s*\*?\s*eats)|\blyft\b|\bmetro\b|transit|parking|\btoll|fastrak|e-?zpass|amtrak|\bmta\b|"
               r"\bbart\b|caltrain|clipper|\btaxi\b|greyhound",
    "flights": r"airline|air lines|airways|delta air|united air|american air|southwest|jetblue|alaska air|spirit air|frontier air",
    "hotels": r"hotel|marriott|hilton|hyatt|\bihg\b|holiday inn|sheraton|westin|\binn\b|resort|motel",
    "car": r"hertz|\bavis\b|enterprise rent|budget rent|\bsixt\b|national car|alamo rent|rent-?a-?car",
    "fitness": r"\bgym\b|fitness|equinox|peloton|crossfit|\byoga\b|pilates|orangetheory",
    "dept": r"macy'?s|nordstrom|kohl'?s|jcpenney|dillard|bloomingdale|neiman",
    "online": r"\bebay\b|\betsy\b|chewy|wayfair|\bshein\b|\btemu\b|aliexpress",
    "rent": r"\brent\b|apartment|property mgmt|landlord|leasing",
}.items()}
_PFC_KIND = {
    "TRANSPORTATION_GAS": "gas", "TRANSPORTATION_PUBLIC_TRANSIT": "transit", "TRANSPORTATION_TAXIS_AND_RIDE_SHARES": "transit",
    "TRANSPORTATION_PARKING": "transit", "TRANSPORTATION_TOLLS": "transit", "TRANSPORTATION_BIKES_AND_SCOOTERS": "transit",
    "TRAVEL_FLIGHTS": "flights", "TRAVEL_LODGING": "hotels", "TRAVEL_RENTAL_CARS": "car_rental",
    "MEDICAL_PHARMACIES_AND_SUPPLEMENTS": "drugstores", "HOME_IMPROVEMENT_HARDWARE": "home_improvement",
    "PERSONAL_CARE_GYMS_AND_FITNESS_CENTERS": "fitness", "GENERAL_MERCHANDISE_DEPARTMENT_STORES": "department_stores",
    "GENERAL_MERCHANDISE_ONLINE_MARKETPLACES": "online_shopping",
}
ISSUER_HINTS = {"American Express": ("american express", "amex"), "Citi": ("citi", "citibank", "citicards"),
                "U.S. Bank": ("u s bank", "us bank", "usbank"), "Bank of America": ("bank of america", "bofa"),
                "Navy Federal": ("navy federal", "nfcu"), "PenFed": ("penfed", "pentagon federal")}


def kind_of(category, name, merchant, pfc):
    """Which kind of purchase a transaction is, for card-rewards purposes (None = just its category).
    Stores come first: a card network sees 'Walmart' or 'PayPal', not what you bought there."""
    text = f"{merchant or ''} {name or ''}"
    parts = (pfc or "").split("|")
    detailed = parts[1] if len(parts) > 1 else ""
    by_pfc = _PFC_KIND.get(detailed)
    gas = by_pfc == "gas" or (category == "Transportation" and bool(_RX["gas"].search(text)))
    if _RX["streaming"].search(text) and category in ("Subscriptions", "Entertainment", "Other", "Shopping"):
        return "streaming"
    if _RX["whole_foods"].search(text):
        return "whole_foods"
    if _RX["costco"].search(text):
        return "gas" if gas else "costco"
    if _RX["clubs"].search(text):
        return "gas" if gas else "wholesale_clubs"
    if _RX["walmart"].search(text):
        return "gas" if gas else "walmart"
    if _RX["target"].search(text):
        return "target"
    if _RX["amazon"].search(text):
        return "amazon"
    if _RX["paypal"].search(text):
        return "paypal"
    if _RX["ev"].search(text):
        return "ev_charging"
    if gas:
        return "gas"
    if by_pfc == "drugstores" or _RX["drug"].search(text):
        return "drugstores"
    if by_pfc == "home_improvement" or _RX["home"].search(text):
        return "home_improvement"
    if category == "Dining":
        return "dining"
    if category == "Groceries":
        return "groceries"
    if category == "Travel":
        if by_pfc in ("flights", "hotels", "car_rental"):
            return by_pfc
        if _RX["flights"].search(text):
            return "flights"
        if _RX["car"].search(text):
            return "car_rental"
        if _RX["hotels"].search(text):
            return "hotels"
        return "transit" if _RX["transit"].search(text) else "travel_other"
    if category == "Transportation":
        return "transit" if by_pfc == "transit" or _RX["transit"].search(text) else None
    if by_pfc == "fitness" or (category in ("Personal Care", "Health", "Subscriptions") and _RX["fitness"].search(text)):
        return "fitness"
    if category == "Entertainment":
        return "entertainment"
    if category == "Phone & Internet":
        return "phone_internet"
    if category == "Utilities":
        return "utilities"
    if category == "Housing":
        return "rent" if _RX["rent"].search(text) else None
    if category == "Shopping":
        if by_pfc == "department_stores" or _RX["dept"].search(text):
            return "department_stores"
        if by_pfc == "online_shopping" or _RX["online"].search(text):
            return "online_shopping"
    return None


# ------------------------------------------------------------------ the catalog
def catalog():
    try:
        m = os.path.getmtime(_PATH)
    except OSError:
        return {"checked": None, "cards": [], "by_id": {}}
    if _cache["mtime"] != m:
        with open(_PATH, encoding="utf-8") as f:
            data = json.load(f)
        data["cards"] = [c for c in data.get("cards", []) if c.get("id") and c.get("name")]
        data["by_id"] = {c["id"]: c for c in data["cards"]}
        _cache.update(mtime=m, data=data)
    return _cache["data"]


def _norm(s):
    return " ".join(re.sub(r"[^a-z0-9+]+", " ", (s or "").lower()).split())


def _account_text(account):
    return " " + _norm(f"{account.get('name') or ''} {account.get('official_name') or ''}") + " "


def _issuer_in(card, text):
    hints = ISSUER_HINTS.get(card.get("issuer"), (_norm(card.get("issuer")),))
    return any(f" {h} " in text for h in hints if h)


def match(account):
    """The catalog card this account most likely is, from the name the bank reports. Longest matching
    name wins; nothing is returned when two different cards match equally well. Short or generic names
    ("Venture", "Platinum Card") only count when the account is with that card's issuer."""
    text = _account_text(account)
    wide = text + _norm(account.get("institution")) + " "
    best, score, tie = None, 0, False
    for c in catalog()["cards"]:
        names = [(x, False) for x in list(c.get("aliases") or []) + [c["name"]]] + [(x, True) for x in c.get("aliases_issuer") or []]
        for alias, needs_issuer in names:
            a = _norm(alias)
            if len(a) < (5 if needs_issuer else 6) or f" {a} " not in text or (needs_issuer and not _issuer_in(c, wide)):
                continue
            if len(a) > score:
                best, score, tie = c, len(a), False
            elif len(a) == score and c is not best:
                tie = True
    return None if tie else best


def suggestions(account):
    """Cards from the same issuer, for when the name alone doesn't say which card it is."""
    text = _account_text(account) + _norm(account.get("institution")) + " "
    return [c["id"] for c in catalog()["cards"] if _issuer_in(c, text)]


# ------------------------------------------------------------------ quarters
def qkey(d):
    return f"{d.year}Q{(d.month - 1) // 3 + 1}"


def q_bounds(key):
    y, q = int(key[:4]), int(key[5])
    start = date(y, 3 * q - 2, 1)
    end = date(y + 1, 1, 1) - timedelta(days=1) if q == 4 else date(y, 3 * q + 1, 1) - timedelta(days=1)
    return start, end


def q_shift(key, n):
    y, q = int(key[:4]), int(key[5])
    i = y * 4 + (q - 1) + n
    return f"{i // 4}Q{i % 4 + 1}"


def year_quarters(today, n=4):
    """This quarter and the next three: the year ahead. A rotating category only counts in a quarter the
    issuer has already announced."""
    cur = qkey(today)
    return [q_shift(cur, i) for i in range(n)]


# ------------------------------------------------------------------ a card's terms as rules
def _cap_q(cap):
    """A cap as dollars of spending per quarter."""
    if not cap:
        return None
    try:
        amt = float(cap.get("amount") or 0)
    except (TypeError, ValueError):
        return None
    if amt <= 0:
        return None
    return {"year": amt / 4, "quarter": amt, "month": amt * 3, "billing_cycle": amt * 3}.get(cap.get("per"), amt)


def profile(account, entry):
    """How this account earns: from what you typed, the card you picked, or the card its name matches."""
    entry = entry or {}
    mode = entry.get("mode") or ("manual" if "base" in entry else None)
    if mode == "off":                      # you said it has no rewards: it earns nothing, and that is known
        return {"mode": "off", "card": None, "matched": None, "base": 0.0, "point_value": 1.0, "fee": 0.0, "bonus": {}, "picks": []}
    if mode == "manual":
        return {"mode": "manual", "card": None, "matched": None, "base": float(entry.get("base", 1)),
                "point_value": float(entry.get("point_value", 1)), "fee": float(entry.get("fee", 0)),
                "bonus": dict(entry.get("bonus") or {}), "picks": []}
    card, matched = None, None
    if mode == "catalog":
        card, matched = catalog()["by_id"].get(entry.get("card")), "picked"
    if not card:
        card, matched = match(account), "auto"
    if not card:
        return None
    pv = entry.get("point_value") if mode == "catalog" and entry.get("point_value") else card.get("point_value", 1)
    return {"mode": "catalog", "card": card, "matched": matched, "base": float(card.get("base", 1)),
            "point_value": float(pv), "fee": float(card.get("fee") or 0), "bonus": {},
            "picks": [k for k in (entry.get("picks") or []) if mode == "catalog"]}


def _by_kind(spend):
    out = defaultdict(float)
    for (kind, _cat), v in spend.items():
        if kind:
            out[kind] += v
            for p in PARENTS.get(kind, ()):
                out[p] += v
    return out


def top_picks(p, spend):
    """(kinds, assumed): the categories a 'top category' card is paying its high rate on. For cards where
    you choose, your saved choice; otherwise the eligible kinds this spending is highest in."""
    top = p["card"].get("top_category") if p.get("card") else None
    if not top:
        return [], False
    eligible = [k for k in top.get("eligible_kinds") or [] if k in KINDS]
    n = max(1, int(top.get("count") or 1))
    picks = [k for k in p.get("picks") or [] if k in eligible][:n]
    if picks and not top.get("auto"):
        return picks, False
    by = _by_kind(spend)
    ranked = sorted(eligible, key=lambda k: -by.get(k, 0))
    return ranked[:n], not top.get("auto")


def rules_for(p, q, spend):
    base = p["base"]
    out = []
    if p["mode"] in ("manual", "off"):
        for key, rate in p["bonus"].items():
            r = {"kinds": set(), "cats": set(), "rate": float(rate), "cap_q": None, "then": base, "why": "bonus", "exact": True}
            (r["kinds"] if key.startswith("kind:") else r["cats"]).add(key[5:] if key.startswith("kind:") else key)
            out.append(r)
        return out
    c = p["card"]

    def add(kinds, rate, cap, why):
        kinds = {k for k in kinds or [] if k in KINDS}
        if not kinds or rate is None or float(rate) <= base:
            return
        then = (cap or {}).get("then")
        out.append({"kinds": kinds, "cats": set(), "rate": float(rate), "cap_q": _cap_q(cap), "cap": cap,
                    "then": base if then is None else float(then), "why": why, "exact": False})
    for b in c.get("bonus") or []:
        add(b.get("kinds"), b.get("rate"), b.get("cap"), "bonus")
    rot = c.get("rotating") or {}
    this = (rot.get("quarters") or {}).get(q)
    if this:
        add(this.get("kinds"), rot.get("rate"), rot.get("cap"), "rotating")
    top = c.get("top_category")
    if top:
        add(top_picks(p, spend)[0], top.get("rate"), top.get("cap"), "top" if top.get("auto") else "choice")
    return out


class Valuer:
    """What one card pays per dollar on each kind of purchase in one quarter, given the spending that
    would be put on it (a cap is spread evenly over everything that shares it)."""

    def __init__(self, p, q, spend):
        self.p, self.rules = p, rules_for(p, q, spend)
        self.groups = defaultdict(float)
        for b, v in spend.items():
            i = self._pick(b)
            if i is not None and v > 0:
                self.groups[i] += v * 3

    def _pick(self, b):
        kind, cat = b
        best = None
        for i, r in enumerate(self.rules):
            hit = cat in r["cats"] or (kind and (kind in r["kinds"] or any(x in r["kinds"] for x in PARENTS.get(kind, ()))))
            if hit and (best is None or r["rate"] > self.rules[best]["rate"]):
                best = i
        return best

    def at(self, b):
        """{'rate': earned per $1, 'value': dollars back per dollar, 'why', 'capped', 'top': the uncapped rate}"""
        i = self._pick(b)
        pv = self.p["point_value"] / 100
        if i is None:
            return {"rate": self.p["base"], "value": self.p["base"] * pv, "why": None, "capped": False, "top": self.p["base"]}
        r = self.rules[i]
        rate, capped, tot = r["rate"], False, self.groups.get(i, 0)
        if r["cap_q"] and tot > r["cap_q"]:
            rate, capped = (r["rate"] * r["cap_q"] + r["then"] * (tot - r["cap_q"])) / tot, True
        return {"rate": rate, "value": rate * pv, "why": r["why"], "capped": capped, "top": r["rate"], "cap": r.get("cap")}


# ------------------------------------------------------------------ describing a card in words
def _amount(n):
    return f"${n:,.0f}"


def _rate(card, rate):
    rate = f"{float(rate):g}"
    unit = card.get("unit", "cash")
    if unit == "cash":
        return f"{rate}%"
    word = "mile" if unit == "miles" else "point"
    return f"{rate} {word if rate == '1' else word + 's'} per $1"


def _cap_text(card, cap):
    if not cap or not cap.get("amount"):
        return ""
    then = cap.get("then")
    after = f", then {_rate(card, then if then is not None else card.get('base', 1))}"
    return f" on the first {_amount(float(cap['amount']))} {PER.get(cap.get('per'), 'a ' + str(cap.get('per')))}{after}"


def _kinds_text(kinds):
    names = [KINDS[k] if k in ("whole_foods", "amazon", "walmart", "target", "costco", "paypal") else KINDS[k].lower().replace("ev ", "EV ")
             for k in kinds if k in KINDS]
    return ", ".join(names[:-1]) + (" and " if len(names) > 1 else "") + names[-1] if names else ""


def _quarter_view(card, key):
    rot = card.get("rotating") or {}
    start, end = q_bounds(key)
    this = (rot.get("quarters") or {}).get(key)
    full = (this or {}).get("label") or ""
    short = re.sub(r"\s*\([^)]*\)", "", full).strip() or _kinds_text((this or {}).get("kinds") or [])
    return {"key": key, "start": start.isoformat(), "end": end.isoformat(), "known": bool(this),
            "rate": _rate(card, rot.get("rate", 5)), "label": short, "detail": full if full != short else "",
            "counted": _kinds_text([k for k in (this or {}).get("kinds") or [] if k in KINDS]),
            "cap": _cap_text(card, rot.get("cap")).strip(), "activation": bool(rot.get("activation")),
            "source": (this or {}).get("source")}


def describe(p, today, spend):
    """Plain-language summary of a matched card, for the Debt page."""
    c = p["card"]
    lines = []
    for b in c.get("bonus") or []:
        kinds = [k for k in b.get("kinds") or [] if k in KINDS]
        if kinds and b.get("rate") is not None:
            note = f" ({b['note']})" if b.get("note") and len(b["note"]) <= 48 and not re.search(r"20\d\d", b["note"]) else ""
            lines.append(f"{_rate(c, b['rate'])} on {_kinds_text(kinds)}{_cap_text(c, b.get('cap'))}{note}")
    out = {"id": c["id"], "name": c["name"], "issuer": c.get("issuer"), "unit": c.get("unit", "cash"),
           "base_text": f"{_rate(c, c.get('base', 1))} on everything else" if (lines or c.get("rotating") or c.get("top_category"))
           else f"{_rate(c, c.get('base', 1))} on everything",
           "lines": lines, "notes": [n for n in c.get("notes") or [] if isinstance(n, str)][:8],
           "source": c.get("source") if str(c.get("source") or "").startswith("https://") else None,
           "confidence": c.get("confidence", "medium"), "point_default": c.get("point_value", 1),
           "point_note": c.get("point_value_note") or "", "quarter": None, "next": None, "choice": None}
    if c.get("rotating"):
        cur = qkey(today)
        out["quarter"] = _quarter_view(c, cur)
        nxt = _quarter_view(c, q_shift(cur, 1))
        out["next"] = nxt if nxt["known"] else None
    top = c.get("top_category")
    if top:
        picks, assumed = top_picks(p, spend)
        out["choice"] = {"rate": _rate(c, top.get("rate")), "count": max(1, int(top.get("count") or 1)),
                         "auto": bool(top.get("auto")), "assumed": assumed, "picks": picks,
                         "options": [{"kind": k, "label": KINDS[k]} for k in top.get("eligible_kinds") or [] if k in KINDS],
                         "cap": _cap_text(c, top.get("cap")).strip(), "note": top.get("note") or ""}
    return out


def listing():
    """The catalog as a short list for the 'which card is this?' picker."""
    cat = catalog()
    return {"checked": cat.get("checked"),
            "cards": sorted(({"id": c["id"], "name": c["name"], "issuer": c.get("issuer") or "Other"} for c in cat["cards"]),
                            key=lambda c: (c["issuer"].lower(), c["name"].lower()))}
