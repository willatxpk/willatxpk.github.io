"""Net worth and spending summaries."""
from collections import defaultdict
from datetime import date, timedelta

from . import categorize, db

LIABILITY_TYPES = {"credit", "loan"}


def accounts(include_hidden=True):
    q = "SELECT * FROM accounts" + ("" if include_hidden else " WHERE is_hidden = 0")
    out = db.rows(q + " ORDER BY type, institution, name")
    for a in out:
        a["is_liability"] = a["type"] in LIABILITY_TYPES
        a["signed_balance"] = -(a["current_balance"] or 0) if a["is_liability"] else (a["current_balance"] or 0)
    return out


def net_worth():
    accts = accounts(include_hidden=False)
    assets = sum(a["signed_balance"] for a in accts if not a["is_liability"])
    liabilities = -sum(a["signed_balance"] for a in accts if a["is_liability"])
    by_type = defaultdict(float)
    for a in accts:
        by_type[a["type"]] += a["signed_balance"]
    return {"assets": round(assets, 2), "liabilities": round(liabilities, 2),
            "net": round(assets - liabilities, 2), "by_type": dict(by_type)}


def snapshot(today=None):
    nw = net_worth()
    if not db.row("SELECT 1 FROM accounts LIMIT 1"):
        return nw
    db.execute(
        "INSERT INTO networth_snapshots(date, assets, liabilities, net) VALUES(?,?,?,?) "
        "ON CONFLICT(date) DO UPDATE SET assets=excluded.assets, liabilities=excluded.liabilities, net=excluded.net",
        ((today or date.today()).isoformat(), nw["assets"], nw["liabilities"], nw["net"]),
    )
    return nw


def history():
    return db.rows("SELECT * FROM networth_snapshots ORDER BY date")


def _month_start(d, back=0):
    y, m = d.year, d.month - back
    while m <= 0:
        m += 12
        y -= 1
    return date(y, m, 1)


def spending_by_month(months=12, today=None):
    today = today or date.today()
    start = _month_start(today, months - 1)
    rows = db.rows(
        "SELECT substr(date, 1, 7) AS month, category, sum(amount) AS total FROM transactions "
        "WHERE date >= ? AND pending = 0 GROUP BY month, category",
        (start.isoformat(),),
    )
    out = {}
    for i in range(months - 1, -1, -1):
        m = _month_start(today, i).strftime("%Y-%m")
        out[m] = {"month": m, "income": 0.0, "spending": 0.0, "categories": {}}
    for r in rows:
        m = out.get(r["month"])
        if not m:
            continue
        cat = r["category"] or "Other"
        if cat == "Income":
            m["income"] += r["total"]
        elif cat not in categorize.NON_SPENDING:
            spent = -r["total"]  # refunds reduce spending
            m["spending"] += spent
            m["categories"][cat] = m["categories"].get(cat, 0) + spent
    for m in out.values():
        m["income"] = round(m["income"], 2)
        m["spending"] = round(m["spending"], 2)
        m["categories"] = {k: round(v, 2) for k, v in sorted(m["categories"].items(), key=lambda kv: -kv[1])}
    return list(out.values())


def averages(full_months=3, today=None):
    """Average monthly income/spending over the last N *complete* months."""
    today = today or date.today()
    months = spending_by_month(full_months + 1, today)[:-1]
    months = [m for m in months if m["income"] or m["spending"]]
    if not months:
        return {"income": 0, "spending": 0, "essential": 0, "months": 0, "categories": {}}
    n = len(months)
    cats = defaultdict(float)
    for m in months:
        for k, v in m["categories"].items():
            cats[k] += v / n
    essential_cats = {"Housing", "Utilities", "Phone & Internet", "Groceries", "Transportation",
                      "Insurance", "Health", "Loan Payment", "Taxes", "Education"}
    return {
        "income": round(sum(m["income"] for m in months) / n, 2),
        "spending": round(sum(m["spending"] for m in months) / n, 2),
        "essential": round(sum(v for k, v in cats.items() if k in essential_cats), 2),
        "months": n,
        "categories": {k: round(v, 2) for k, v in sorted(cats.items(), key=lambda kv: -kv[1])},
    }


def cash_balance():
    r = db.row("SELECT sum(current_balance) AS s FROM accounts WHERE type = 'depository' AND is_hidden = 0")
    return round((r or {}).get("s") or 0, 2)


def recent_transactions(limit=8):
    since = (date.today() - timedelta(days=60)).isoformat()
    return db.rows(
        "SELECT t.*, a.name AS account_name FROM transactions t LEFT JOIN accounts a ON a.id = t.account_id "
        "WHERE t.date >= ? AND coalesce(t.source, '') != 'split' ORDER BY t.date DESC, t.rowid DESC LIMIT ?",
        (since, limit))
