"""Debt: what you owe on cards and loans, and what each credit card is being used for.

Card spending here means what was actually charged to each card (purchases minus refunds). It leaves out
payments to the card, interest and fees (shown on their own), and the app's own bookkeeping lines for
costs you split with someone.
"""
from collections import defaultdict
from datetime import date, timedelta

from . import cards, categorize, db, finance

NOT_PURCHASES = set(categorize.NON_SPENDING) | {"Fees & Interest"}
PERIODS = (("this", "This month"), ("last", "Last month"), ("avg", "3-month average"))


def _limit(a, manual):
    """(limit, where it came from)."""
    if manual.get(a["id"]):
        return float(manual[a["id"]]), "you"
    if a.get("credit_limit"):
        return float(a["credit_limit"]), "bank"
    if a.get("available_balance") is not None:
        lim = (a["current_balance"] or 0) + a["available_balance"]
        if lim > 0:
            return round(lim, 2), "estimated"
    return None, None


def set_limit(account_id, limit):
    a = db.row("SELECT type FROM accounts WHERE id = ?", (account_id,))
    if not a or a["type"] != "credit":
        raise ValueError("That isn't a credit card account")
    limits = db.get_setting("credit_limits", {}) or {}
    try:
        val = float(limit or 0)
    except (TypeError, ValueError):
        raise ValueError("Enter a dollar amount")
    if val <= 0:
        limits.pop(account_id, None)
    elif val > 10_000_000:
        raise ValueError("That limit looks too large")
    else:
        limits[account_id] = round(val, 2)
    db.set_setting("credit_limits", limits)


def summary(today=None, months=6):
    today = today or date.today()
    keys = [finance._month_start(today, i).strftime("%Y-%m") for i in range(months - 1, -1, -1)]
    this_m, last_m, avg_ms = keys[-1], keys[-2], keys[-4:-1]
    since = min(keys[0] + "-01", f"{today.year}-01-01")
    accts = [a for a in finance.accounts(False) if a["type"] in ("credit", "loan")]
    liabs = {r["account_id"]: r for r in db.rows("SELECT * FROM liabilities")}
    manual = db.get_setting("credit_limits", {}) or {}

    cards, cat_totals = [], {p: defaultdict(lambda: defaultdict(float)) for p, _ in PERIODS}
    for a in accts:
        if a["type"] != "credit":
            continue
        rows = db.rows("SELECT substr(date, 1, 7) AS month, substr(date, 1, 4) AS year, amount, category, name, merchant "
                       "FROM transactions WHERE account_id = ? AND pending = 0 AND date >= ? "
                       "AND coalesce(source, '') != 'split'", (a["id"], since))
        spent, paid, interest = defaultdict(float), defaultdict(float), defaultdict(float)
        cats = {p: defaultdict(float) for p, _ in PERIODS}
        merchants, interest_ytd, n_this = defaultdict(float), 0.0, 0
        for r in rows:
            cat, m = r["category"] or "Other", r["month"]
            if cat == "Fees & Interest":
                interest[m] -= r["amount"]
                if r["year"] == str(today.year):
                    interest_ytd -= r["amount"]
            elif cat == "Credit Card Payment" or (cat in categorize.NON_SPENDING and r["amount"] > 0):
                paid[m] += r["amount"]
            elif cat not in NOT_PURCHASES:
                spent[m] -= r["amount"]            # a refund (money back) lowers what was spent
                if m == this_m:
                    cats["this"][cat] -= r["amount"]
                    merchants[(r["merchant"] or r["name"] or "")[:32]] -= r["amount"]
                    n_this += r["amount"] < 0
                if m == last_m:
                    cats["last"][cat] -= r["amount"]
                if m in avg_ms:
                    cats["avg"][cat] -= r["amount"] / len(avg_ms)
        for p, _ in PERIODS:
            for c, v in cats[p].items():
                cat_totals[p][c][a["id"]] += v
        lib = liabs.get(a["id"]) or {}
        balance = a["current_balance"] or 0
        limit, limit_from = _limit(a, manual)
        avg3 = sum(spent[m] for m in avg_ms) / len(avg_ms)
        recent_interest = sum(interest[m] for m in keys[-3:])
        cards.append({
            "id": a["id"], "name": a["name"], "mask": a["mask"], "institution": a["institution"],
            "balance": round(balance, 2), "limit": limit, "limit_from": limit_from,
            "utilization": round(balance / limit * 100, 1) if limit else None,
            "apr": lib.get("apr"), "minimum_payment": lib.get("minimum_payment"), "due": lib.get("next_due_date"),
            "statement": lib.get("last_statement_balance"),
            "months": [{"month": m, "spent": round(spent[m], 2), "paid": round(paid[m], 2),
                        "interest": round(interest[m], 2)} for m in keys],
            "this_month": round(spent[this_m], 2), "last_month": round(spent[last_m], 2), "avg3": round(avg3, 2),
            "purchases_this_month": n_this,
            "top_categories": [{"name": c, "amount": round(v, 2)}
                               for c, v in sorted(cats["this"].items(), key=lambda kv: -kv[1])[:5] if v > 0],
            "top_merchants": [{"name": n, "amount": round(v, 2)}
                              for n, v in sorted(merchants.items(), key=lambda kv: -kv[1])[:4] if v > 0],
            "interest_ytd": round(interest_ytd, 2), "carrying": recent_interest > 0.5,
            "interest_per_month": round(balance * lib["apr"] / 100 / 12, 2) if lib.get("apr") and balance > 0 else None,
        })
    cards.sort(key=lambda c: -c["balance"])

    loans = []
    for a in accts:
        if a["type"] != "loan":
            continue
        lib = liabs.get(a["id"]) or {}
        bal = a["current_balance"] or 0
        loans.append({"id": a["id"], "name": a["name"], "mask": a["mask"], "institution": a["institution"],
                      "kind": lib.get("kind") or a.get("subtype"), "balance": round(bal, 2), "apr": lib.get("apr"),
                      "minimum_payment": lib.get("minimum_payment"), "due": lib.get("next_due_date"),
                      "interest_per_month": round(bal * lib["apr"] / 100 / 12, 2) if lib.get("apr") and bal > 0 else None})
    loans.sort(key=lambda l: -l["balance"])

    with_limit = [c for c in cards if c["limit"]]
    lim_total = sum(c["limit"] for c in with_limit)
    by_category = {}
    for p, _ in PERIODS:
        rows_ = [{"name": c, "total": round(sum(v.values()), 2), "cards": {k: round(x, 2) for k, x in v.items()}}
                 for c, v in cat_totals[p].items()]
        by_category[p] = sorted((r for r in rows_ if abs(r["total"]) >= 0.5), key=lambda r: -r["total"])
    card_balance, loan_balance = sum(c["balance"] for c in cards), sum(l["balance"] for l in loans)
    return {
        "today": today.isoformat(), "months": keys, "cards": cards, "loans": loans,
        "periods": [{"key": p, "label": lab} for p, lab in PERIODS], "by_category": by_category,
        "totals": {
            "card_balance": round(card_balance, 2), "loan_balance": round(loan_balance, 2),
            "debt": round(card_balance + loan_balance, 2),
            "limit": round(lim_total, 2) if with_limit else None,
            "utilization": round(sum(c["balance"] for c in with_limit) / lim_total * 100, 1) if lim_total else None,
            "this_month": round(sum(c["this_month"] for c in cards), 2),
            "last_month": round(sum(c["last_month"] for c in cards), 2),
            "avg3": round(sum(c["avg3"] for c in cards), 2),
            "interest_ytd": round(sum(c["interest_ytd"] for c in cards), 2),
            "minimums": round(sum((x.get("minimum_payment") or 0) for x in cards + loans), 2),
            "interest_per_month": round(sum((x.get("interest_per_month") or 0) for x in loans)
                                        + sum((c["interest_per_month"] or 0) for c in cards if c["carrying"]), 2),
        },
    }


# ------------------------------------------------------------------ card rewards
# What each card earns comes from the app's own list of well-known cards (see cards.py), matched to the
# name your bank reports for the account. A card that isn't on the list can be typed in by hand. Everything
# after that is arithmetic on your own last three months of card spending, taken a quarter at a time so
# rotating categories and spending caps count for what they are.
EVERYDAY = {"Groceries", "Dining", "Transportation", "Shopping", "Subscriptions", "Entertainment", "Health",
            "Travel", "Personal Care", "Gifts & Donations"}


def _num(v, lo, hi, what):
    try:
        n = float(v if v not in ("", None) else 0)
    except (TypeError, ValueError):
        raise ValueError(f"Enter a number for {what}")
    if not lo <= n <= hi:
        raise ValueError(f"{what.capitalize()} should be between {lo:g} and {hi:g}")
    return round(n, 3)


def save_rewards(account_id, body):
    a = db.row("SELECT type FROM accounts WHERE id = ?", (account_id,))
    if not a or a["type"] != "credit":
        raise ValueError("That isn't a credit card account")
    cfg = db.get_setting("card_rewards", {}) or {}
    if body.get("clear"):
        cfg.pop(account_id, None)          # back to recognising the card from its name
    elif body.get("off"):
        cfg[account_id] = {"mode": "off"}
    elif body.get("card"):
        card = cards.catalog()["by_id"].get(str(body["card"]))
        if not card:
            raise ValueError("That card isn't in the app's list")
        entry = {"mode": "catalog", "card": card["id"]}
        if body.get("point_value") not in ("", None):
            pv = _num(body["point_value"], 0, 20, "what a point is worth")
            if pv > 0 and abs(pv - float(card.get("point_value", 1))) > 1e-9:
                entry["point_value"] = pv
        top = card.get("top_category") or {}
        picks = [k for k in (body.get("picks") or []) if k in (top.get("eligible_kinds") or [])]
        if picks:
            entry["picks"] = list(dict.fromkeys(picks))[:max(1, int(top.get("count") or 1))]
        cfg[account_id] = entry
    else:
        cats = set(categorize.all_categories())
        bonus = {}
        for key, rate in (body.get("bonus") or {}).items():
            ok = (key[5:] in cards.KINDS) if key.startswith("kind:") else (key in cats and key not in NOT_PURCHASES)
            if ok and rate not in ("", None):
                bonus[key] = _num(rate, 0, 50, "the rate for " + (cards.KINDS[key[5:]] if key.startswith("kind:") else key))
        cfg[account_id] = {"mode": "manual", "base": _num(body.get("base", 1), 0, 50, "the everyday rate"),
                           "point_value": _num(body.get("point_value", 1), 0, 20, "what a point is worth"),
                           "fee": _num(body.get("fee", 0), 0, 10000, "the annual fee"), "bonus": bonus}
    db.set_setting("card_rewards", cfg)


def _buckets(where, params):
    """Average monthly purchases, keyed (kind of purchase, category)."""
    out = defaultdict(float)
    for r in db.rows("SELECT t.category, t.name, t.merchant, t.plaid_category, -t.amount AS amt FROM transactions t "
                     "JOIN accounts a ON a.id = t.account_id WHERE t.pending = 0 AND coalesce(t.source, '') != 'split' "
                     "AND " + where, params):
        cat = r["category"] or "Other"
        if cat in NOT_PURCHASES:
            continue
        out[(cards.kind_of(cat, r["name"], r["merchant"], r["plaid_category"]), cat)] += (r["amt"] or 0) / 3
    return {b: v for b, v in out.items() if v > 0.005}


def _why(card_name, at, quarter_end):
    """Why a card is the best one for something right now, in a few words."""
    if not at or not at.get("why"):
        return ""
    cap = cards._cap_text({"unit": "cash"}, at.get("cap")).strip() if at.get("cap") else ""
    capped = (" Your spending here goes past the cap, so that is the blended rate" + (" (" + cap.split(", then")[0] + ")" if cap else "") + ".") if at.get("capped") else ""
    if at["why"] == "rotating":
        return f"A rotating category on {card_name} until {quarter_end.strftime('%b')} {quarter_end.day}; it has to be activated." + capped
    if at["why"] == "top":
        return f"{card_name} pays its high rate on whatever you spend most on, and this would be it." + capped
    if at["why"] == "choice":
        return f"The category you chose on {card_name}." + capped
    return capped.strip()


def rewards(today=None):
    """What your cards earn now, and what the same purchases would earn if each kind of purchase went on
    the card that pays most for it. Monthly figures are the average of the last three full months; yearly
    figures run that spending through this quarter and the next three."""
    today = today or date.today()
    months = [finance._month_start(today, i).strftime("%Y-%m") for i in (3, 2, 1)]
    cfg = db.get_setting("card_rewards", {}) or {}
    accts = [a for a in finance.accounts(False) if a["type"] == "credit"]
    names = {a["id"]: a["name"] for a in accts}
    profiles = {a["id"]: cards.profile(a, cfg.get(a["id"])) for a in accts}
    ready = [cid for cid, p in profiles.items() if p]          # cards whose terms are known (including 'no rewards')
    # A card whose terms aren't known yet is left out altogether, rather than counted as earning nothing
    all_spend = {a["id"]: _buckets("t.account_id = ? AND substr(t.date, 1, 7) IN (?, ?, ?)", (a["id"], *months)) for a in accts}
    spend = {cid: s for cid, s in all_spend.items() if cid in ready}
    total = defaultdict(float)
    for s in spend.values():
        for b, v in s.items():
            total[b] += v
    quarters = cards.year_quarters(today, 4)
    cur = quarters[0]
    q_end = cards.q_bounds(cur)[1]
    now_v = {q: {cid: cards.Valuer(profiles[cid], q, spend[cid]) for cid in ready} for q in quarters}
    pos_v = {q: {cid: cards.Valuer(profiles[cid], q, total) for cid in ready} for q in quarters}

    def same(b, other):
        """No card of yours pays differently on these two, in any quarter."""
        return all(abs(pos_v[q][cid].at(b)["value"] - pos_v[q][cid].at(other)["value"]) < 1e-12 and
                   pos_v[q][cid].at(b)["why"] == pos_v[q][cid].at(other)["why"] for q in quarters for cid in ready)

    keys = {}

    def row_key(b):
        """The line a purchase is shown under. A kind of purchase only gets its own line when one of your
        cards treats it differently; otherwise it folds back into the wider kind, then into its category."""
        if b not in keys:
            kind, cat = b
            for parent in (cards.PARENTS.get(kind, ()) if kind else ()):
                if same(b, (parent, cat)):
                    kind = parent
                    break
            keys[b] = "cat:" + cat if not kind or same((kind, cat), (None, cat)) else kind
        return keys[b]

    # Kinds in the same category that every card treats alike share one line ("Travel", "Amazon, Target")
    home, size = {}, defaultdict(float)
    for b in sorted(total, key=lambda b: -total[b]):
        k = row_key(b)
        size[k] += total[b]
        if not k.startswith("cat:"):
            home.setdefault(k, b[1])
    merged, taken = {}, set()
    for k in sorted(home, key=lambda k: -size[k]):
        if k not in taken:
            merged[k] = [k] + [o for o in home if o != k and o not in taken and home[o] == home[k]
                               and same((k, home[k]), (o, home[k]))]
            taken.update(merged[k])
    lead_of = {m: lead for lead, members in merged.items() for m in members}
    leftover = {b[1] for b in total if row_key(b).startswith("cat:")}      # categories with purchases outside any kind line
    def _group_name(lead, ms):
        whole = home[lead] not in leftover and all(home[k] != home[lead] or k in ms for k in home)
        return home[lead] if whole else ", ".join(cards.KINDS[m] for m in ms[:3]) + (" and more" if len(ms) > 3 else "")
    group_label = {lead: _group_name(lead, ms) for lead, ms in merged.items() if len(ms) > 1}
    for b in list(keys):
        keys[b] = lead_of.get(keys[b], keys[b])
    with_kinds = {b[1] for b in total if not row_key(b).startswith("cat:")} - set(group_label.values())

    def row_label(key):
        if not key.startswith("cat:"):
            return group_label.get(key) or cards.KINDS[key]
        cat = key[4:]
        if cat not in with_kinds or cat == "Other":
            return cat
        inside = list(dict.fromkeys(b[0] for b in sorted(groups.get(key, []), key=lambda b: -total[b])))
        if inside and None not in inside and len(inside) <= 2:      # all of it is one or two known stores or kinds
            return ", ".join(cards.KINDS[k] for k in inside)
        return "Other " + cat.lower()

    groups = defaultdict(list)
    for b in total:
        groups[row_key(b)].append(b)

    def now_q(q, bs, cid=None):
        """Dollars a quarter this spending earns where it sits today."""
        return sum(3 * spend[c].get(b, 0) * now_v[q][c].at(b)["value"] for c in ([cid] if cid else ready) for b in bs if spend[c].get(b))

    def moved_q(q, bs, cid):
        """Dollars a quarter if all of it went on one card."""
        return sum(3 * total[b] * pos_v[q][cid].at(b)["value"] for b in bs)

    rows, edge = [], defaultdict(float)
    for key in sorted(groups, key=lambda k: -sum(total[b] for b in groups[k])):
        bs = groups[key]
        tot = sum(total[b] for b in bs)
        per = {cid: round(sum(s.get(b, 0) for b in bs), 2) for cid, s in spend.items()}
        per = {cid: v for cid, v in per.items() if v > 0.5}
        if tot <= 0.5 or not per:
            continue
        mostly = max(per, key=per.get)
        now_year = possible_year = 0.0
        best = best_val = nxt = nxt_val = None
        for q in quarters:
            n = now_q(q, bs)
            ranked = sorted(((moved_q(q, bs, cid), cid) for cid in ready), key=lambda x: -x[0])
            top_val, top_cid = ranked[0] if ranked else (0.0, None)
            if top_cid and mostly in ready and moved_q(q, bs, mostly) >= top_val - 1e-9:
                top_cid = mostly                      # already on a card that pays the most: nothing to change
            if top_val <= n + 1e-9:
                top_val = n                           # splitting across cards can beat one capped card: keep what you do
                top_cid = mostly if mostly in ready else top_cid
            now_year += n
            possible_year += top_val
            if top_cid:
                edge[top_cid] += top_val - (ranked[1][0] if len(ranked) > 1 else 0.0)
            if q == cur:
                best, best_val, cur_now = top_cid, top_val, n
            elif q == quarters[1]:
                nxt, nxt_val = top_cid, top_val
        main = max(bs, key=lambda b: total[b])
        at = pos_v[cur][best].at(main) if best else None
        rows.append({"key": key, "category": row_label(key), "monthly": round(tot, 2), "cards": per, "mostly": mostly, "best": best,
                     "best_rate": round(best_val / (3 * tot) * 100, 2) if best else 0,
                     "now_rate": round(cur_now / (3 * tot) * 100, 2),
                     "why": _why(names.get(best), at, q_end), "rotating": bool(at and at.get("why") == "rotating"),
                     "capped": bool(at and at.get("capped")),
                     # where it is best once this quarter's categories end, when that is a different card
                     "next": {"card": nxt, "card_name": names.get(nxt), "rate": round(nxt_val / (3 * tot) * 100, 2),
                              "start": (q_end + timedelta(days=1)).isoformat()} if nxt and best and nxt != best else None,
                     "now_year": round(now_year, 2), "possible_year": round(possible_year, 2),
                     "gain_year": round(max(0.0, possible_year - now_year), 2)})

    out_cards = []
    for a in accts:
        p = profiles[a["id"]]
        entry = cfg.get(a["id"]) or {}
        monthly = sum(all_spend[a["id"]].values())
        earned = sum(now_q(q, list(spend[a["id"]]), a["id"]) for q in quarters) if p else 0.0
        fee = p["fee"] if p else 0
        off = bool(p) and p["mode"] == "off"
        out_cards.append({
            "id": a["id"], "name": a["name"], "mask": a["mask"], "setup": bool(p) and not off, "off": off,
            "mode": p["mode"] if p else None, "matched": p["matched"] if p else None,
            "card": cards.describe(p, today, total) if p and p["mode"] == "catalog" else None,
            "suggest": cards.suggestions(a) if not p or p["mode"] != "catalog" else [],
            "base": p["base"] if p else 1, "point_value": p["point_value"] if p else 1, "fee": fee,
            "bonus": p["bonus"] if p else {},
            "monthly": round(monthly, 2), "earned_year": round(earned, 2), "net_year": round(earned - fee, 2),
            "rate_now": round(earned / (monthly * 12) * 100, 2) if monthly else 0,
            "edge_year": round(edge.get(a["id"], 0), 2)})   # what it adds over your next-best card
    now_year = sum(r["now_year"] for r in rows)
    possible_year = sum(r["possible_year"] for r in rows)
    spend_year = sum(r["monthly"] for r in rows) * 12

    # Everyday purchases paid straight from a bank account earn nothing
    bank = defaultdict(float)
    bank_possible = defaultdict(float)
    for b, v in _buckets("a.type = 'depository' AND a.is_hidden = 0 AND t.amount < 0 AND substr(t.date, 1, 7) IN (?, ?, ?)", tuple(months)).items():
        if b[1] not in EVERYDAY:
            continue
        bank[row_key(b)] += v
        bank_possible[row_key(b)] += sum(3 * v * max((pos_v[q][cid].at(b)["value"] for cid in ready), default=0) for q in quarters)
    bank_rows = sorted(({"category": row_label(k), "monthly": round(v, 2), "possible_year": round(bank_possible[k], 2)}
                        for k, v in bank.items() if v >= 5), key=lambda r: -r["monthly"])
    listing = cards.listing()
    return {
        "months": months, "cards": out_cards, "rows": rows, "ready": sum(1 for c in out_cards if c["setup"]),
        "left_out": round(sum(sum(s.values()) for cid, s in all_spend.items() if cid not in ready), 2),
        "quarter": {"key": cur, "end": q_end.isoformat()},
        "catalog": listing["cards"], "catalog_checked": listing["checked"],
        "categories": [c for c in categorize.all_categories() if c not in NOT_PURCHASES],
        "kinds": [{"key": "kind:" + k, "label": v} for k, v in cards.KINDS.items()],
        "totals": {"spend_year": round(spend_year, 2), "now_year": round(now_year, 2),
                   "possible_year": round(possible_year, 2), "gain_year": round(max(0.0, possible_year - now_year), 2),
                   "now_rate": round(now_year / spend_year * 100, 2) if spend_year else 0,
                   "possible_rate": round(possible_year / spend_year * 100, 2) if spend_year else 0,
                   "fees": round(sum(c["fee"] for c in out_cards), 2)},
        "guide": [{"key": r["key"], "category": r["category"], "card": r["best"], "card_name": names.get(r["best"]), "rate": r["best_rate"],
                   "change": r["best"] != r["mostly"], "from_name": names.get(r["mostly"]), "gain_year": r["gain_year"],
                   "why": r["why"], "rotating": r["rotating"], "mostly": r["mostly"], "next": r["next"]}
                  for r in rows if r["best"]],
        "bank": {"rows": bank_rows[:6], "monthly": round(sum(r["monthly"] for r in bank_rows), 2),
                 "possible_year": round(sum(r["possible_year"] for r in bank_rows), 2)},
    }
