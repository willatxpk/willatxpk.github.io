"""'Where should my next dollar go?' planner.

Implements the widely published order of operations for saving/investing
(starter emergency fund -> employer match -> high-interest debt -> full
emergency fund -> HSA -> Roth IRA -> max 401(k) -> taxable brokerage).
It's a rules-based educational tool, not personalised financial advice.

IRS limits change every year: update LIMITS below (source: irs.gov).
"""
import math
from datetime import date

from . import db, finance

LIMITS = {
    "year": 2026,
    "ira": 7500, "ira_catchup_50": 1100,
    "k401": 24500, "k401_catchup_50": 8000, "k401_catchup_60_63": 11250,
    "hsa_self": 4400, "hsa_family": 8750, "hsa_catchup_55": 1000,
    # Roth IRA MAGI phase-out ranges
    "roth_phaseout": {"single": (153000, 168000), "hoh": (153000, 168000),
                      "mfj": (242000, 252000), "mfs": (0, 10000)},
}

# Approximate 2026 federal brackets (taxable income, single). MFJ thresholds ~2x.
_BRACKETS_SINGLE = [(12400, .10), (50400, .12), (105700, .22), (201775, .24),
                    (256225, .32), (640600, .35), (math.inf, .37)]
_STD_DEDUCTION = {"single": 16100, "hoh": 24150, "mfj": 32200, "mfs": 16100}

DEFAULT_PROFILE = {
    "age": 30,
    "annual_income": 0,          # gross salary, before taxes
    "filing_status": "single",   # single | mfj | mfs | hoh
    "has_401k": True,
    "employer_match_pct": 4,     # employer matches up to this % of salary
    "match_rate": 100,           # ...at this rate (100 = dollar for dollar, 50 = 50 cents)
    "current_401k_pct": 0,       # what you contribute now (% of salary)
    "hsa_eligible": False,       # on a high-deductible health plan?
    "hsa_coverage": "self",      # self | family
    "roth_ira_ytd": 0,
    "hsa_ytd": 0,
    "emergency_months": 6,
    "high_interest_debt": 0,     # balances you carry month to month at >= 8% APR
    "high_interest_apr": 22,
    "risk": "moderate",          # conservative | moderate | aggressive
    "retirement_age": 65,
    "monthly_surplus_override": None,
    "has_pretax_ira_balance": False,
}


def get_profile():
    p = dict(DEFAULT_PROFILE)
    p.update(db.get_setting("profile", {}) or {})
    return p


def save_profile(data):
    p = get_profile()
    for k, default in DEFAULT_PROFILE.items():
        if k not in data:
            continue
        v = data[k]
        if isinstance(default, bool):
            v = bool(v)
        elif isinstance(default, (int, float)) or k == "monthly_surplus_override":
            v = None if v in ("", None) and k == "monthly_surplus_override" else float(v or 0)
        p[k] = v
    db.set_setting("profile", p)
    return p


def marginal_rate(income, status):
    taxable = max(0, income - _STD_DEDUCTION.get(status, 16100))
    mult = 2 if status == "mfj" else 1
    for top, rate in _BRACKETS_SINGLE:
        if taxable <= top * mult:
            return rate
    return 0.37


def roth_allowed(magi, status, base_limit):
    lo, hi = LIMITS["roth_phaseout"].get(status, LIMITS["roth_phaseout"]["single"])
    if magi <= lo:
        return base_limit
    if magi >= hi:
        return 0
    reduced = base_limit * (hi - magi) / (hi - lo)
    reduced = math.ceil(reduced / 10) * 10  # IRS rounds up to the next $10
    return max(200, min(base_limit, reduced))  # $200 floor if not fully phased out


def target_allocation(age, risk):
    stocks = 110 - age + {"conservative": -15, "moderate": 0, "aggressive": 10}.get(risk, 0)
    stocks = max(30, min(95, stocks))
    bonds = 100 - stocks
    return {
        "stocks": stocks,
        "bonds": bonds,
        "mix": [
            {"name": "US total stock market index fund", "pct": round(stocks * 0.7)},
            {"name": "International total stock market index fund", "pct": stocks - round(stocks * 0.7)},
            {"name": "Total bond market index fund", "pct": bonds},
        ],
        "notes": [
            "Low-cost broad index funds (expense ratio under ~0.10%) keep fees from eating returns.",
            "A single target-date fund (pick the year near your retirement) does this mix automatically.",
            "Put bonds in pre-tax 401(k)/IRA first; keep highest-growth stocks in the Roth; "
            "use tax-efficient index funds in a taxable account.",
        ],
    }


def future_value(monthly, years, rate=0.07, start=0.0):
    r = rate / 12
    n = int(years * 12)
    if n <= 0:
        return start
    return start * (1 + r) ** n + monthly * (((1 + r) ** n - 1) / r)


def build_plan(today=None):
    today = today or date.today()
    p = get_profile()
    avg = finance.averages(3, today)
    income = float(p["annual_income"] or 0) or avg["income"] * 12 * 1.3  # rough gross-up if unknown
    status = p["filing_status"]
    age = int(p["age"] or 30)
    mrate = marginal_rate(income, status)
    pretax_cost = 1 - mrate
    surplus = p["monthly_surplus_override"]
    surplus_source = "your override"
    if surplus in (None, ""):
        surplus = avg["income"] - avg["spending"]
        surplus_source = f"avg of last {avg['months']} full months" if avg["months"] else "no data yet"
    surplus = max(0.0, float(surplus))
    essential = avg["essential"] or avg["spending"]
    cash = finance.cash_balance()

    steps = []
    remaining = surplus

    def step(key, title, why, monthly=0.0, cost=None, status="todo", detail=None, annual=None):
        nonlocal remaining
        cost = monthly if cost is None else cost
        take = min(remaining, cost) if cost > 0 else 0
        frac = take / cost if cost else 0
        remaining -= take
        steps.append({
            "key": key, "title": title, "why": why, "detail": detail,
            "monthly": round(monthly * frac, 2), "take_home_cost": round(take, 2),
            "annual": round(annual if annual is not None else monthly * frac * 12, 2),
            "status": status if status == "done" else ("funded" if frac >= 0.999 and cost else
                                                       ("partial" if take > 0 else "waiting")),
            "full_monthly": round(monthly, 2),
        })

    # 1. Starter emergency fund
    starter = max(1000, round(essential))
    if cash < starter:
        gap = starter - cash
        step("starter_ef", f"Starter emergency fund: ${starter:,.0f}",
             "A small cash cushion keeps a surprise bill from landing on a credit card.",
             gap, detail=f"You have ${cash:,.0f} in checking/savings. This is a one-time goal; "
                         "put the money in a high-yield savings account.")
    else:
        step("starter_ef", f"Starter emergency fund: ${starter:,.0f}",
             "A small cash cushion keeps a surprise bill from landing on a credit card.", status="done",
             detail=f"Covered: ${cash:,.0f} in checking/savings.")

    # 2. Employer 401(k) match
    if p["has_401k"] and p["employer_match_pct"] > 0 and income > 0:
        need_pct = max(0, p["employer_match_pct"] - p["current_401k_pct"])
        free = income * p["employer_match_pct"] / 100 * p["match_rate"] / 100
        if need_pct > 0:
            monthly = income * need_pct / 100 / 12
            step("match", f"Raise your 401(k) to {p['employer_match_pct']:g}% to get the full match",
                 f"The match is an instant {p['match_rate']:g}% return: ${free:,.0f}/yr of free money.",
                 monthly, cost=monthly * pretax_cost,
                 detail=f"Change this in your payroll/benefits portal. It's pre-tax, so ${monthly:,.0f}/mo "
                        f"lowers take-home pay by only about ${monthly * pretax_cost:,.0f}/mo.")
        else:
            step("match", "Employer 401(k) match", f"You're already getting the full match (${free:,.0f}/yr).",
                 status="done")

    # 3. High-interest debt
    loans = db.rows("SELECT l.apr, a.current_balance, a.name FROM liabilities l JOIN accounts a "
                    "ON a.id = l.account_id WHERE l.kind != 'credit' AND l.apr >= 8 AND a.current_balance > 0")
    debt = float(p["high_interest_debt"] or 0) + sum(l["current_balance"] for l in loans)
    if debt > 0:
        names = ", ".join(l["name"] for l in loans)
        step("debt", f"Pay down ${debt:,.0f} of high-interest debt",
             f"Paying off {p['high_interest_apr']:g}%+ debt is a guaranteed {p['high_interest_apr']:g}% return; "
             "the stock market's long-run average is ~7-10%.",
             debt, detail="Avalanche method: minimums on everything, extra money to the highest APR first."
                          + (f" Includes: {names}." if names else ""))

    # 4. Full emergency fund
    ef_target = round(p["emergency_months"] * essential)
    if ef_target > 0 and cash < ef_target:
        gap = ef_target - cash
        # Small gap: just finish it. Big gap: send 60% here and keep investing with the rest.
        monthly = min(gap, remaining if gap <= remaining * 3 else remaining * 0.6)
        step("full_ef", f"Grow emergency fund to {p['emergency_months']:g} months (${ef_target:,.0f})",
             "Covers essential spending if you lose income. Splitting your surplus lets you build it "
             "while still capturing this year's tax-advantaged room.",
             monthly, detail=f"${gap:,.0f} to go. Essentials average ${essential:,.0f}/mo (housing, utilities, "
                             "groceries, transport, insurance, health, loans).")
    elif ef_target > 0:
        step("full_ef", f"Emergency fund: {p['emergency_months']:g} months (${ef_target:,.0f})",
             "Covers essential spending if you lose income.", status="done",
             detail=f"Covered: ${cash:,.0f} in cash.")

    # 5. HSA
    hsa_limit = 0
    if p["hsa_eligible"]:
        hsa_limit = LIMITS["hsa_family" if p["hsa_coverage"] == "family" else "hsa_self"] \
            + (LIMITS["hsa_catchup_55"] if age >= 55 else 0)
        monthly = hsa_limit / 12
        step("hsa", f"Health Savings Account: up to ${hsa_limit:,.0f}/yr",
             "Triple tax advantage: deductible in, grows tax-free, tax-free out for medical costs.",
             monthly, cost=monthly * pretax_cost, annual=None,
             detail=f"Room left for {LIMITS['year']}: ${max(0, hsa_limit - p['hsa_ytd']):,.0f}. Contribute "
                    "through payroll to also skip FICA tax, and invest the balance instead of leaving it in cash.")

    # 6. Roth IRA
    k401_now = income * p["current_401k_pct"] / 100
    magi = income - k401_now - (hsa_limit if p["hsa_eligible"] else 0)
    ira_base = LIMITS["ira"] + (LIMITS["ira_catchup_50"] if age >= 50 else 0)
    allowed = roth_allowed(magi, status, ira_base)
    room = max(0, allowed - p["roth_ira_ytd"])
    if allowed > 0:
        why = "Grows tax-free and withdrawals in retirement are tax-free. Contributions (not earnings) " \
              "can come back out anytime without penalty."
        if mrate >= 0.32:
            why += " At your bracket, maxing the pre-tax 401(k) first may save more tax."
        step("roth", f"Roth IRA: ${allowed:,.0f}/yr", why, allowed / 12,
             detail=(f"Your income partially phases out the Roth limit. " if allowed < ira_base else "")
             + f"Room left for {LIMITS['year']}: ${room:,.0f} (deadline: April 15, {LIMITS['year'] + 1}). "
               "Open one at a low-cost brokerage and set up an automatic monthly transfer.")
    else:
        step("roth", f"Backdoor Roth IRA: ${ira_base:,.0f}/yr",
             "Your income is above the Roth IRA limit, but a non-deductible traditional IRA contribution "
             "converted to Roth gets the same result.", ira_base / 12,
             detail=("Warning: you have pre-tax IRA money, so the pro-rata rule would make the conversion "
                     "partly taxable; talk to a tax professional first." if p["has_pretax_ira_balance"]
                     else "File IRS Form 8606 each year you do this."))

    # 7. Max the 401(k)
    if p["has_401k"] and income > 0:
        k_limit = LIMITS["k401"] + (LIMITS["k401_catchup_60_63"] if 60 <= age <= 63
                                    else LIMITS["k401_catchup_50"] if age >= 50 else 0)
        already = income * max(p["current_401k_pct"], p["employer_match_pct"]) / 100
        extra = max(0, min(k_limit, income * 0.75) - already)
        if extra > 0:
            monthly = extra / 12
            step("max401k", f"Increase 401(k) toward the ${k_limit:,.0f} limit",
                 "More tax-deferred growth. Pre-tax now, taxed when withdrawn in retirement.",
                 monthly, cost=monthly * pretax_cost,
                 detail="Each 1% of salary is about "
                        f"${income / 100 / 12:,.0f}/mo before tax. Increase a percent or two at a time.")

    # 8. Taxable brokerage
    step("taxable", "Taxable brokerage account",
         "No limits and no withdrawal rules: good for goals before retirement (house, flexibility).",
         remaining, detail="Use broad, tax-efficient index funds. Keep money you'll need within ~3 years "
                           "in a high-yield savings account or T-bills instead.")

    invest_keys = {"match", "hsa", "roth", "max401k", "taxable"}
    invested_monthly = sum(s["monthly"] for s in steps if s["key"] in invest_keys)
    years = max(0, int(p["retirement_age"]) - age)
    inv_balance = sum(a["current_balance"] or 0 for a in finance.accounts(False) if a["type"] == "investment")
    match_free = 0
    if p["has_401k"] and income:
        match_free = income * p["employer_match_pct"] / 100 * p["match_rate"] / 100 / 12
    fv = future_value(invested_monthly + match_free, years, 0.07, inv_balance)
    return {
        "profile": p,
        "limits": LIMITS,
        "inputs": {
            "surplus": round(surplus, 2), "surplus_source": surplus_source,
            "avg_income": avg["income"], "avg_spending": avg["spending"], "essential": essential,
            "cash": cash, "income_used": round(income, 2), "marginal_rate": mrate,
            "income_estimated": not p["annual_income"],
        },
        "steps": steps,
        "unallocated": round(remaining, 2),
        "allocation": target_allocation(age, p["risk"]),
        "projection": {
            "monthly": round(invested_monthly + match_free, 2), "years": years,
            "starting_balance": round(inv_balance, 2), "rate": 0.07,
            "future_value": round(fv),
            "today_dollars": round(fv / (1.03 ** years)) if years else round(fv),
        },
        "disclaimer": "Educational estimate based on common rules of thumb, not personalised financial "
                      "advice. Contribution limits are for " + str(LIMITS["year"]) + "; verify at irs.gov. "
                      "Consider a fee-only fiduciary advisor for decisions with large tax consequences.",
    }
