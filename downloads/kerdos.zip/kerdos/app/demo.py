"""Realistic fake data so you can try every feature before connecting a bank."""
import random
from datetime import date, timedelta

from . import alerts, bills, categorize, db, finance
from .bills import add_months

ACCOUNTS = [
    ("demo-chk", "Everyday Checking", "depository", "checking", "Demo Bank", "4821", 3400.00),
    ("demo-sav", "High-Yield Savings", "depository", "savings", "Demo Bank", "9932", 6200.00),
    ("demo-cc", "Rewards Visa", "credit", "credit card", "Demo Card Co", "1107", 1385.42),
    ("demo-roth", "Roth IRA", "investment", "roth", "Demo Brokerage", "5510", 14250.00),
    ("demo-401k", "Employer 401(k)", "investment", "401k", "Demo Brokerage", "7720", 38900.00),
    ("demo-loan", "Student Loan", "loan", "student", "Demo Servicer", "3302", 18450.00),
    ("demo-car", "2019 Honda Civic (est. value)", "other", "vehicle", "Manual", None, 14500.00),
]


def clear():
    with db.lock():
        conn = db.get()
        ids = [r[0] for r in conn.execute("SELECT id FROM accounts WHERE source = 'demo'")]
        for i in ids:
            conn.execute("DELETE FROM transactions WHERE account_id = ?", (i,))
            conn.execute("DELETE FROM liabilities WHERE account_id = ?", (i,))
            conn.execute("DELETE FROM bills WHERE account_id = ?", (i,))
        conn.execute("DELETE FROM accounts WHERE source = 'demo'")
        if not conn.execute("SELECT 1 FROM accounts LIMIT 1").fetchone():
            conn.execute("DELETE FROM networth_snapshots")
            conn.execute("DELETE FROM alerts")
            conn.execute("DELETE FROM bills")
            conn.execute("DELETE FROM settings WHERE key = 'bills_initialized'")
        conn.commit()


def load(today=None):
    today = today or date.today()
    clear()
    rng = random.Random(42)
    txs = []
    n = 0

    def tx(d, name, amount, acct="demo-chk"):
        nonlocal n
        if d > today:
            return
        n += 1
        txs.append((f"demo-{n}", acct, d.isoformat(), name, amount))

    start = add_months(today.replace(day=1), -12)
    # Biweekly paycheck (net of taxes and the 401k deduction)
    d = start + timedelta(days=4)
    while d <= today:
        tx(d, "ACME CORP PAYROLL DIR DEP", 2475.00 + rng.choice([0, 0, 0, 12.5]))
        d += timedelta(days=14)

    m = start
    while m <= today:
        tx(m.replace(day=1), "OAKWOOD APARTMENTS RENT ACH PPD", -1850.00)
        tx(m.replace(day=min(14, 28)), "SO CAL EDISON AUTOPAY", -round(rng.uniform(55, 140), 2))
        tx(m.replace(day=19), "SOCALGAS AUTO PAY", -round(rng.uniform(18, 65), 2))
        tx(m.replace(day=8), "VERIZON WIRELESS AUTOPAY", -85.00)
        tx(m.replace(day=22), "SPECTRUM INTERNET RECURRING", -69.99)
        tx(m.replace(day=12), "NELNET STUDENT LOAN AUTOPAY", -312.00)
        tx(m.replace(day=3), "GEICO AUTO INSURANCE AUTOPAY", -128.50)
        tx(m.replace(day=25), "TRANSFER TO HIGH-YIELD SAVINGS", -300.00)
        tx(m.replace(day=25), "TRANSFER FROM CHECKING", 300.00, "demo-sav")
        tx(m.replace(day=27), "CREDIT CARD PAYMENT AUTOPAY - REWARDS VISA", -round(rng.uniform(1150, 1650), 2))
        tx(m.replace(day=27), "AUTOPAY PAYMENT - THANK YOU", round(rng.uniform(1150, 1650), 2), "demo-cc")
        # Card subscriptions
        netflix = 15.49 if m < add_months(today.replace(day=1), -2) else 17.99  # price hike demo
        tx(m.replace(day=16), "NETFLIX.COM", -netflix, "demo-cc")
        tx(m.replace(day=5), "SPOTIFY USA", -11.99, "demo-cc")
        tx(m.replace(day=10), "PLANET FITNESS CLUB FEES", -24.99, "demo-cc")
        tx(m.replace(day=20), "APPLE.COM/BILL ICLOUD", -2.99, "demo-cc")
        tx(m.replace(day=2), "INTEREST PAYMENT", round(rng.uniform(18, 24), 2), "demo-sav")
        m = add_months(m, 1)

    # Annual subscription
    tx(add_months(today, -11).replace(day=9), "AMAZON PRIME MEMBERSHIP", -139.00, "demo-cc")

    # Day-to-day spending on the card
    shops = [
        ("TRADER JOE'S #552", 35, 120, 5), ("WHOLE FOODS MARKET", 20, 90, 3),
        ("CHIPOTLE 2231", 11, 18, 3), ("STARBUCKS STORE 10882", 5, 9, 5),
        ("DOORDASH*THAI BASIL", 25, 55, 2), ("SHELL OIL 57442", 35, 60, 3),
        ("AMAZON.COM*RT4K91", 12, 140, 4), ("TARGET 00012345", 20, 110, 2),
        ("CVS/PHARMACY #9921", 8, 45, 1), ("UBER TRIP", 12, 35, 2),
        ("AMC THEATRES", 18, 40, 1), ("BEST BUY 00234", 25, 300, 0.4),
    ]
    d = start
    while d <= today:
        for name, lo, hi, per_month in shops:
            if rng.random() < per_month / 30:
                tx(d, name, -round(rng.uniform(lo, hi), 2), "demo-cc")
        d += timedelta(days=1)
    tx(today - timedelta(days=130), "DELTA AIR LINES", -412.60, "demo-cc")
    tx(today - timedelta(days=128), "MARRIOTT HOTELS", -386.22, "demo-cc")
    tx(today - timedelta(days=40), "AMAZON.COM REFUND", 42.15, "demo-cc")

    rules = categorize.load_rules()
    with db.lock():
        conn = db.get()
        for a in ACCOUNTS:
            conn.execute(
                "INSERT INTO accounts(id, name, type, subtype, institution, mask, current_balance, "
                "available_balance, is_manual, source) VALUES(?,?,?,?,?,?,?,?,?, 'demo')",
                (a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[6] if a[2] == "depository" else None,
                 1 if a[4] == "Manual" else 0),
            )
        for tid, acct, d, name, amt in txs:
            cat, src = categorize.classify(name, None, amt, None, rules)
            conn.execute(
                "INSERT INTO transactions(id, account_id, date, name, amount, category, category_source, "
                "confidence, source) VALUES(?,?,?,?,?,?,?,?, 'demo')",
                (tid, acct, d, name, amt, cat, src, categorize.confidence(cat, src)))
        conn.execute(
            "INSERT OR REPLACE INTO liabilities(account_id, kind, apr, minimum_payment, next_due_date, "
            "last_statement_balance) VALUES('demo-loan', 'student', 5.5, 312, NULL, NULL)")
        # A year of net worth history trending upward
        nw_now = finance.net_worth()
        for i in range(52, 0, -1):
            d = today - timedelta(weeks=i)
            drift = -i * 310 + rng.uniform(-900, 900)
            assets = nw_now["assets"] + drift * 0.8
            liabs = nw_now["liabilities"] + i * 95
            conn.execute(
                "INSERT OR REPLACE INTO networth_snapshots(date, assets, liabilities, net) VALUES(?,?,?,?)",
                (d.isoformat(), round(assets, 2), round(liabs, 2), round(assets - liabs, 2)))
        conn.commit()
    finance.snapshot(today)
    if not db.get_setting("profile"):
        db.set_setting("profile", {"age": 29, "annual_income": 78000, "filing_status": "single",
                                   "has_401k": True, "employer_match_pct": 4, "match_rate": 100,
                                   "current_401k_pct": 3, "emergency_months": 6, "risk": "moderate"})
    from . import transfers
    transfers.match_all()
    alerts.run_checks(today)
    return {"transactions": len(txs), "bills": len(bills.list_bills())}
