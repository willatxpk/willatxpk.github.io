// Kerdos: Taxes. An estimate of this year's federal, Social Security/Medicare and state income tax
// from what you type in. The sums are done on the server; this page is the form and the breakdown.
"use strict";

const TAX = { timer: null };
const TAX_FIELDS = [
  ["wages", "Your pay for the year, before tax", "Gross salary or wages, before anything is taken out."],
  ["wages2", "Spouse's pay for the year", "Only used when you file jointly.", "mfj"],
  ["other_income", "Other income", "Interest, side income, short-term gains: anything taxed like pay."],
  ["ltcg", "Long-term gains and qualified dividends", "Investments held over a year. These get lower federal rates."],
  ["pretax_401k", "Pre-tax 401(k) / 403(b) contributions", "For the whole year. Roth contributions don't count."],
  ["hsa", "HSA contributions", "For the whole year."],
  ["other_adjust", "Other deductions from income", "Deductible traditional IRA, student loan interest (up to $2,500), and similar."],
  ["itemized", "Itemized deductions", "Leave at 0 to use the standard deduction, which is what most people take."],
  ["children", "Children under 17", "For the child tax credit."],
];
const TAX_PAID = [
  ["fed_withheld", "Federal tax withheld for the year", "From your pay stubs: what you expect by December. Leave 0 to skip."],
  ["state_withheld", "State tax withheld for the year", "Leave 0 to skip."],
];
const pct1 = (v) => (Math.round(v * 10) / 10).toString().replace(/\.0$/, "") + "%";

function taxForm(r) {
  const i = r.inputs;
  const num = ([key, label, hint, only]) => `<label class="field tax-field" ${only && only !== i.filing_status ? "hidden" : ""} data-only="${only || ""}">${label}
      <span class="tax-input">${key === "children" ? "" : "<i>$</i>"}<input type="number" min="0" step="${key === "children" ? 1 : 100}" inputmode="decimal" data-tax="${key}" value="${i[key] || ""}" placeholder="0"></span>
      <small class="muted">${hint}</small></label>`;
  return `<h2>Your details</h2>
    <label class="field">Filing status<select data-tax="filing_status">${r.statuses.map((s) => `<option value="${s.key}" ${s.key === i.filing_status ? "selected" : ""}>${esc(s.label)}</option>`).join("")}</select></label>
    <label class="field" style="margin-top:10px">State you live in<select data-tax="state"><option value="">Choose your state…</option>${r.states.map((s) => `<option value="${s.code}" ${s.code === i.state ? "selected" : ""}>${esc(s.name)}</option>`).join("")}</select></label>
    <h3 style="margin-top:16px">Income</h3>${TAX_FIELDS.slice(0, 4).map(num).join("")}
    <h3 style="margin-top:16px">Deductions and credits</h3>${TAX_FIELDS.slice(4).map(num).join("")}
    <label class="tax-check"><input type="checkbox" data-tax="fica" ${i.fica ? "checked" : ""}> Social Security and Medicare come out of my pay
      <small class="muted">True for most jobs. Some student stipends and fellowships don't have them.</small></label>
    <h3 style="margin-top:16px">Already paid</h3>${TAX_PAID.map(num).join("")}
    <div class="row" style="margin-top:12px"><span class="tiny muted" id="taxSaved"></span><span class="spacer"></span><button class="btn small secondary" id="taxReset">Start over from my profile</button></div>`;
}

function taxBracketTable(rows, taxable) {
  if (!rows.length) return `<div class="tiny muted">No income falls in a taxed bracket.</div>`;
  const max = Math.max(...rows.map((x) => x.amount), 1);
  return `<table class="t-tax"><thead><tr><th>Rate</th><th>On income from</th><th></th><th class="num">Taxed here</th><th class="num">Tax</th></tr></thead><tbody>
    ${rows.map((x) => `<tr><td><b>${pct1(x.rate)}</b></td><td class="tiny">${fmt(x.from)} ${x.to != null ? "to " + fmt(x.to) : "and up"}</td>
      <td class="tax-bar"><div style="width:${(x.amount / max * 100).toFixed(1)}%"></div></td><td class="num">${fmt(x.amount)}</td><td class="num">${fmt(x.tax)}</td></tr>`).join("")}</tbody></table>
    <div class="tiny muted" style="margin-top:4px">Each rate applies only to the slice of income inside its range, so ${fmt(taxable)} of taxable income is not all taxed at the top rate.</div>`;
}

function taxResults(r) {
  const f = r.federal, s = r.state, inc = r.income;
  if (!inc.gross) return `<div class="card empty">Enter your pay for the year to see the estimate.</div>`;
  const parts = [
    ["Federal income tax", f.tax, "var(--series-1)"], ["Social Security & Medicare", r.fica.total, "var(--series-7)"],
    [s ? `${s.name} income tax` : "State income tax", s ? s.tax : 0, "var(--series-2)"],
    ["Pre-tax savings", r.pretax_savings, "var(--series-4)"], ["Take-home", Math.max(0, r.take_home.year), "var(--good)"],
  ].filter((p) => p[1] > 0.5);
  const kv = (rows) => `<div class="kv">${rows.filter(Boolean).map(([k, v, cls]) => `<div>${k}</div><div class="num ${cls || ""}">${v}</div>`).join("")}</div>`;
  const owed = (label, diff) => diff == null ? "" : `<div class="tax-owed ${diff >= 0 ? "good" : "bad"}"><b>${label}: ${diff >= 0 ? "about " + fmt(diff) + " refund" : "about " + fmt(-diff) + " still owed"}</b>
      <span class="tiny">${diff >= 0 ? "More is being withheld than the estimate says you'll owe." : "Less is being withheld than the estimate says you'll owe."}</span></div>`;
  const w = r.withholding;
  return `
    <div class="grid g3">
      <div class="card stat" style="--stat-c:var(--critical)"><div class="label">Estimated tax for ${r.year}</div><div class="value">${fmt(r.total_tax)}</div>
        <div class="delta">${pct1(r.effective)} of your income</div></div>
      <div class="card stat" style="--stat-c:var(--good)"><div class="label">Take-home</div><div class="value">${fmt(r.take_home.month)}<span class="muted" style="font-size:14px">/mo</span></div>
        <div class="delta">${fmt(r.take_home.year)} a year · ${fmt(r.take_home.biweekly)} every two weeks</div></div>
      <div class="card stat"><div class="label">Tax on your next $1,000 of pay</div><div class="value">${fmt(r.next_1000.tax)}</div>
        <div class="delta">you'd keep ${fmt(r.next_1000.keep)}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><h2>Where each dollar goes</h2>
      <div class="alloc tax-split">${parts.map(([n, v, c]) => `<div style="flex:${v};background:${c}" data-tip="${esc(`<b>${esc(n)}</b><br>${fmt(v)} · ${pct1(v / inc.gross * 100)}`)}"></div>`).join("")}</div>
      <table class="t-tax" style="margin-top:8px">${parts.map(([n, v, c]) => `<tr><td><i class="cal-dot" style="background:${c}"></i> ${esc(n)}</td><td class="num">${fmt(v)}</td><td class="num muted">${pct1(v / inc.gross * 100)}</td></tr>`).join("")}
        <tr class="debt-total"><td>Total income</td><td class="num">${fmt(inc.gross)}</td><td class="num muted">100%</td></tr></table></div>
    ${w.federal != null || w.state != null ? `<div class="card" style="margin-top:16px"><h2>Refund or balance due</h2>${owed("Federal", w.federal)}${owed(s ? s.name : "State", w.state)}
      <div class="tiny muted" style="margin-top:6px">This compares what you said will be withheld with the estimate. It is only as good as those two numbers.</div></div>` : ""}
    <div class="card" style="margin-top:16px"><div class="row"><h2 style="margin:0">Federal income tax</h2><span class="spacer"></span><span class="pill">top rate ${pct1(f.marginal)}</span></div>
      ${kv([["Income", fmt(inc.gross)], inc.adjustments ? ["Pre-tax savings and other deductions from income", "−" + fmt(inc.adjustments)] : null,
        [`${f.deduction_kind === "itemized" ? "Itemized" : "Standard"} deduction`, "−" + fmt(f.deduction)], ["<b>Taxable income</b>", `<b>${fmt(f.taxable)}</b>`]])}
      <div style="margin-top:10px">${taxBracketTable(f.rows, f.ordinary_taxable)}</div>
      ${f.gain_rows.length ? `<div class="tiny" style="margin-top:8px">Long-term gains and qualified dividends: ${f.gain_rows.map((g) => `${fmt(g.amount)} at ${g.rate}%`).join(", ")} = <b>${fmt(f.gains_tax)}</b></div>` : ""}
      ${kv([f.credit ? ["Child tax credit", "−" + fmt(f.credit), "pos"] : null, ["<b>Federal income tax</b>", `<b>${fmt(f.tax)}</b>`]])}</div>
    <div class="card" style="margin-top:16px"><h2>Social Security and Medicare</h2>
      ${r.inputs.fica ? kv([["Social Security (6.2% of pay, up to the yearly cap)", fmt(r.fica.ss)], ["Medicare (1.45% of pay)", fmt(r.fica.medicare)],
        r.fica.addl ? ["Additional Medicare (0.9% on high pay)", fmt(r.fica.addl)] : null, ["<b>Total</b>", `<b>${fmt(r.fica.total)}</b>`]])
      : `<div class="tiny muted">Not included, because you said they don't come out of your pay.</div>`}</div>
    <div class="card" style="margin-top:16px">${s ? `<div class="row"><h2 style="margin:0">${esc(s.name)} income tax</h2><span class="spacer"></span><span class="pill">${s.kind === "none" ? "no tax on pay" : "top rate " + pct1(s.marginal)}</span></div>
      ${s.kind === "none" ? `<div class="tiny muted" style="margin-top:6px">${esc(s.name)} doesn't tax wages.</div>` : `
      ${kv([["Income after pre-tax savings", fmt(inc.agi)], s.deduction ? ["State standard deduction", "−" + fmt(s.deduction)] : null,
        s.exemption && !s.exemption_is_credit ? ["Personal exemptions", "−" + fmt(s.exemption)] : null, ["<b>Taxable income</b>", `<b>${fmt(s.taxable)}</b>`]])}
      <div style="margin-top:10px">${taxBracketTable(s.rows, s.taxable)}</div>
      ${kv([s.credit ? ["Personal exemption credits", "−" + fmt(s.credit), "pos"] : null, [`<b>${esc(s.name)} income tax</b>`, `<b>${fmt(s.tax)}</b>`]])}`}
      ${s.notes ? `<div class="tiny muted" style="margin-top:8px">Note for ${esc(s.name)}: ${esc(s.notes)}</div>` : ""}`
    : `<h2>State income tax</h2><div class="tiny muted">Choose your state on the left to add it.</div>`}</div>
    <p class="disclaimer">This is an estimate for planning, not a tax return and not tax advice. It uses ${r.year} federal figures${r.states_year ? ` and ${r.states_year} state tables` : ""}, and treats your state's taxable income as your federal income after pre-tax savings.
      Not included: the alternative minimum tax, the 3.8% tax on investment income for high earners, self-employment tax, credits other than the child tax credit, city and county income taxes, and state payroll taxes such as disability insurance.
      Your real return can differ; a tax preparer or your state's tax agency has the final word.</p>`;
}

PAGES.taxes = async (main) => {
  let r = await api("/api/taxes");
  main.innerHTML = `<h1>Taxes</h1><p class="sub">A running estimate of what you'll owe for ${r.year}: federal income tax, Social Security and Medicare, and your state. Change any number and it updates.</p>
    <div class="tax-wrap"><div class="card tax-form">${taxForm(r)}</div><div id="taxOut">${taxResults(r)}</div></div>`;
  const out = $("#taxOut", main), form = $(".tax-form", main);
  const read = () => {
    const body = {};
    $$("[data-tax]", form).forEach((el) => { body[el.dataset.tax] = el.type === "checkbox" ? el.checked : el.tagName === "SELECT" ? el.value : (el.value === "" ? 0 : +el.value); });
    return body;
  };
  const send = async () => {
    try {
      r = await post("/api/taxes", read());
      out.innerHTML = taxResults(r);
      $("#taxSaved", form).textContent = "Saved";
    } catch (e) { $("#taxSaved", form).textContent = ""; toast(e.message, true); }
  };
  const changed = (now) => {
    const st = $('[data-tax="filing_status"]', form).value;
    $$("[data-only]", form).forEach((el) => { if (el.dataset.only) el.hidden = el.dataset.only !== st; });
    $("#taxSaved", form).textContent = "…";
    clearTimeout(TAX.timer);
    TAX.timer = setTimeout(send, now ? 0 : 400);
  };
  form.addEventListener("input", (e) => { if (e.target.matches("[data-tax]")) changed(e.target.tagName === "SELECT" || e.target.type === "checkbox"); });
  $("#taxReset", form).onclick = async () => {
    if (!confirm("Clear what you typed here and start again from your Investing Plan profile?")) return;
    await run(() => post("/api/taxes", { reset: true }));
    PAGES.taxes(main);
  };
};
