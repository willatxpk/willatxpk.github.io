// Kerdos: Connections, Roommates, Fees & Odd Charges, What If, Weekly Check-in
"use strict";

const ago = (iso) => {
  if (!iso) return "never";
  const d = (Date.now() - new Date(iso.replace(" ", "T"))) / 864e5;
  return d < 1 / 24 ? "just now" : d < 1 ? Math.round(d * 24) + "h ago" : Math.round(d) + "d ago";
};
const LEVEL_ICON = { danger: "⚠", warn: "●", info: "ℹ" };

// =====================================================================
// CONNECTIONS (health)
// =====================================================================
PAGES.health = async (main) => {
  const h = await api("/api/health");
  const action = h.issues.filter((i) => i.level !== "info").length;
  const fixBtn = (i) => {
    if (i.fix === "reconnect" && i.item_id) return `<button class="btn small" data-relink="${esc(i.item_id)}">Reconnect</button>`;
    if (i.fix === "grant" && i.item_id) return `<button class="btn small" data-grant="${esc(i.item_id)}">Grant access</button>`;
    if (i.fix === "sync") return `<button class="btn small secondary" data-hsync>Sync now</button>`;
    if (i.fix === "accounts") return `<a class="btn small secondary" href="#accounts">Update</a>`;
    if (i.fix === "backup") return `<button class="btn small secondary" data-backup>Back up now</button>`;
    return "";
  };
  const statePill = { ok: ["var(--good)", "Healthy"], action: ["var(--critical)", "Needs you"], waiting: ["var(--warning)", "Waiting on bank"], stale: ["var(--warning)", "Behind"] };
  const invLabel = { ok: "investments ✓", needs_consent: "investments: not shared", plan: "investments: not in Plaid plan", not_ready: "investments: preparing", error: "investments: failed" };
  main.innerHTML = `
    <h1>Connections</h1><p class="sub">Is every number in the app fresh? This checks each bank connection, each account's balance and transaction feed, and the app's own syncing and backups.</p>
    <div class="card health-hero ${h.status}">
      <div class="hero-icon">${h.status === "ok" ? "✓" : h.status === "info" ? "ℹ" : "!"}</div>
      <div><div class="hero-title">${h.status === "ok" ? "Everything is up to date" : action ? `${action} thing${action > 1 ? "s" : ""} need${action > 1 ? "" : "s"} attention` : "Only small reminders"}</div>
        <div class="tiny muted">Last background sync ${esc(ago(h.last_sync))} (every ${h.sync_interval_hours}h) · last backup ${esc(h.last_backup || "never")}</div></div>
      <span class="spacer"></span><button class="btn small secondary" data-hsync>Sync now</button>
    </div>
    ${h.issues.length ? `<div class="card" style="margin-top:16px"><h2>To fix</h2>
      ${h.issues.map((i) => `<div class="alert"><div class="icon sev-${i.level}">${LEVEL_ICON[i.level]}</div>
        <div><div class="title">${esc(i.title)}</div><div class="body">${esc(i.detail)}</div></div><div>${fixBtn(i)}</div></div>`).join("")}</div>` : ""}
    <div class="card" style="margin-top:16px"><h2>Bank connections</h2>
      ${h.connections.length ? `<table><thead><tr><th>Bank</th><th>Status</th><th>Last synced</th><th></th></tr></thead><tbody>
      ${h.connections.map((c) => `<tr><td class="name">${esc(c.institution)}${c.investments ? `<div class="tiny muted">${esc(invLabel[c.investments] || c.investments)}</div>` : ""}</td>
        <td><span class="pill"><span class="dot" style="background:${statePill[c.state][0]}"></span>${statePill[c.state][1]}</span></td>
        <td class="tiny">${esc(ago(c.last_sync))}</td>
        <td class="num"><button class="btn small ${c.state === "action" ? "" : "secondary"}" data-relink="${esc(c.item_id)}">Reconnect</button></td></tr>`).join("")}</tbody></table>`
        : `<div class="empty">No banks connected. ${h.plaid_configured ? `<a href="#accounts">Connect one on Accounts.</a>` : "Set up Plaid first (see README)."}</div>`}
    </div>
    <div class="card" style="margin-top:16px"><h2>Accounts</h2>
      <table><thead><tr><th>Account</th><th>Balance updated</th><th>Newest transaction</th><th>Notes</th></tr></thead><tbody>
      ${h.accounts.map((a) => `<tr><td class="name">${esc(a.name)}<div class="tiny muted">${esc(a.institution || "")}${a.mask ? " ••" + esc(a.mask) : ""} · ${esc(a.source)}</div></td>
        <td class="tiny">${a.balance_age_days == null ? "—" : a.balance_age_days < 1 ? "today" : Math.round(a.balance_age_days) + "d ago"}</td>
        <td class="tiny">${a.last_transaction ? shortDate(a.last_transaction) + ` <span class="muted">(${a.quiet_days}d)</span>` : "—"}</td>
        <td class="tiny ${a.flags.length ? "down" : "muted"}">${a.flags.length ? esc(a.flags.join("; ")) : "✓"}</td></tr>`).join("")}</tbody></table>
    </div>`;
  $$("[data-relink]", main).forEach((b) => b.onclick = () => openPlaid({ itemId: b.dataset.relink }));
  $$("[data-grant]", main).forEach((b) => b.onclick = () => grantInvestments(b.dataset.grant));
  $$("[data-hsync]", main).forEach((b) => b.onclick = () => $("#syncBtn").click());
  $$("[data-backup]", main).forEach((b) => b.onclick = async () => { await run(() => post("/api/auth/backup"), "Backed up"); PAGES.health(main); });
};

// =====================================================================
// ROOMMATES (shared costs)
// =====================================================================
PAGES.roommates = async (main) => {
  const d = await api("/api/roommates");
  const owe = (r) => {
    const b = r.balance;
    if (Math.abs(b) < 5) return `<span class="pos">You're even</span>`;
    return b > 0 ? `<b>${esc(r.name)} owes you ${fmt(b)}</b>` : `<b>You owe ${esc(r.name)} ${fmt(-b)}</b> <span class="tiny muted">(they paid ahead)</span>`;
  };
  main.innerHTML = `
    <h1>Roommates</h1><p class="sub">When a roommate pays you back, that money is their share of rent and bills, not income. The app counts each repayment against the shared categories, so Housing and Utilities show only <b>your</b> part everywhere: This Month, Insights, goals and projections.</p>
    ${d.roommates.length ? `<div class="grid g3" style="margin-bottom:16px">
      <div class="card stat"><div class="label">Covered by roommates (12 months)</div><div class="value">${fmt(d.covered_last_year)}</div><div class="delta">no longer counted as your spending</div></div>
      <div class="card stat"><div class="label">Shared categories</div><div class="value" style="font-size:17px">${esc(d.shared_categories.join(", "))}</div></div>
      <div class="card stat"><div class="label">Roommates</div><div class="value">${d.roommates.length}</div></div></div>` : ""}
    ${d.roommates.map((r) => `<div class="card" style="margin-bottom:16px">
      <div class="row"><h2 style="margin:0">👥 ${esc(r.name)}</h2><span class="pill">${r.share}% of ${esc(r.categories.join(" + "))}</span><span class="spacer"></span>
        <button class="btn small secondary" data-edit="${esc(r.id)}">Edit</button><button class="btn small danger" data-rm="${esc(r.id)}">Remove</button></div>
      <p class="tiny muted" style="margin:6px 0 10px">Payments containing: ${r.match.map((m) => `<code>${esc(m)}</code>`).join(", ")}</p>
      <div style="font-size:17px;margin-bottom:8px">${owe(r)} <span class="tiny muted">through last month</span></div>
      <table><thead><tr><th>Month</th><th class="num">Their share</th><th class="num">They paid</th><th class="num">Running balance</th></tr></thead><tbody>
      ${r.ledger.map((l, i) => `<tr><td>${monthLong(l.month)}${i === r.ledger.length - 1 ? ' <span class="pill">so far</span>' : ""}</td>
        <td class="num">${fmt2(l.owed)}</td><td class="num">${fmt2(l.paid)}</td>
        <td class="num ${l.balance > 5 ? "down" : ""}">${Math.abs(l.balance) < 5 ? "even" : l.balance > 0 ? "they owe " + fmt2(l.balance) : "ahead " + fmt2(-l.balance)}</td></tr>`).join("")}</tbody></table>
      <p class="tiny muted" style="margin-top:8px">"Their share" is ${r.share}% of what you paid for ${esc(r.categories.join(" and "))} that month.</p>
    </div>`).join("")}
    ${d.suggestions.length ? `<div class="card" style="margin-bottom:16px"><h2>People who send you money regularly</h2>
      <p class="tiny muted" style="margin-top:-6px">Is one of these a roommate paying their share?</p>
      <table>${d.suggestions.map((s, i) => `<tr><td class="name">${esc(s.example)}<div class="tiny muted">${s.payments} payments over ${s.months} months · about ${fmt(s.per_month)}/month</div></td>
        <td class="num"><button class="btn small" data-sugg="${i}">This is a roommate</button></td></tr>`).join("")}</table></div>` : ""}
    <button class="btn" id="addRm">+ Add a roommate</button>`;
  const form = (r = {}) => {
    const dlg = $("#dlg");
    const cats = r.categories || d.default_categories;
    dlg.innerHTML = `<h2>${r.id ? "Edit" : "Add"} roommate</h2>
      <label class="field">Name<input id="rmName" value="${esc(r.name || "")}" placeholder="e.g. Jane"></label>
      <label class="field" style="margin-top:8px">Their payments show up as (comma-separated, any part of the description)
        <input id="rmMatch" value="${esc((r.match || []).join(", "))}" placeholder="e.g. zelle from jane, venmo jane"></label>
      <label class="field" style="margin-top:8px">Their share of the shared bills (%)<input id="rmShare" type="number" min="1" max="99" value="${r.share || 50}"></label>
      <div class="tiny muted" style="margin:10px 0 4px">Shared categories</div>
      <div class="merge-grid">${d.categories.filter((c) => !["Income", "Transfer", "Credit Card Payment", "Investments", "Other"].includes(c)).map((c) =>
        `<label class="row tiny"><input type="checkbox" value="${esc(c)}" ${cats.includes(c) ? "checked" : ""}> ${esc(c)}</label>`).join("")}</div>
      <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn secondary" id="rmCancel">Cancel</button><button class="btn" id="rmSave">Save</button></div>`;
    dlg.showModal();
    $("#rmCancel").onclick = () => dlg.close();
    $("#rmSave").onclick = async () => {
      const body = { id: r.id, name: $("#rmName").value, share: +$("#rmShare").value,
        match: $("#rmMatch").value.split(",").map((s) => s.trim()).filter(Boolean),
        categories: $$(".merge-grid input:checked", dlg).map((i) => i.value) };
      if (await run(() => post("/api/roommates", body), "Saved: spending updated")) { dlg.close(); PAGES.roommates(main); }
    };
  };
  $("#addRm").onclick = () => form();
  $$("[data-sugg]", main).forEach((b) => b.onclick = () => form({ match: [d.suggestions[+b.dataset.sugg].match] }));
  $$("[data-edit]", main).forEach((b) => b.onclick = () => form(d.roommates.find((r) => r.id === b.dataset.edit)));
  $$("[data-rm]", main).forEach((b) => b.onclick = async () => {
    if (!confirm("Stop splitting with this roommate? Their repayments go back to their old category.")) return;
    await run(() => del("/api/roommates/" + encodeURIComponent(b.dataset.rm)), "Removed"); PAGES.roommates(main);
  });
};

// =====================================================================
// FEES & ODD CHARGES
// =====================================================================
const LEAK_ICON = { duplicate: "⧉", interest: "%", fee: "$", price_up: "↑", unusual: "!", refund_wait: "↩" };
const LEAK_BTN = { expected: ["Expected", "secondary"], dispute: ["Dispute it", ""], cancel: ["Cancel it", ""], got_it: ["Got it back", ""], stop_tracking: ["Stop tracking", "secondary"] };
const DECIDED_TEXT = { expected: "Marked expected", cancel: "Cancelling: reminder set", resolved: "Money came back", got_it: "Got it back", stop_tracking: "Stopped tracking", dispute: "Disputing" };
function leakCard(f) {
  return `<div class="leak ${f.waiting ? "waiting" : ""}" data-leak="${esc(f.id)}">
    <div class="leak-icon k-${f.kind}">${LEAK_ICON[f.kind] || "•"}</div>
    <div><div class="title">${esc(f.title)}</div>
      <div class="tiny muted">${f.date ? shortDate(f.date) : ""}${f.account ? " · " + esc(f.account) : ""}</div>
      <div class="body">${esc(f.detail)}</div>
      ${f.waiting ? `<div class="tiny" style="margin-top:6px">⏳ Disputing since ${shortDate(f.decided_on)}. The app watches for the money to come back and closes this automatically.</div>` : ""}
      <div class="row" style="margin-top:8px">${f.waiting ? `<button class="btn small secondary" data-ldec="undo">Undo</button>`
        : f.actions.map((a) => `<button class="btn small ${LEAK_BTN[a][1]}" data-ldec="${a}">${LEAK_BTN[a][0]}</button>`).join("")}</div></div>
    <div class="amt">${fmt2(f.amount)}${f.kind === "price_up" ? '<div class="tiny muted">per charge</div>' : ""}</div></div>`;
}
async function decideLeak(id, decision) {
  const r = await run(() => post("/api/leaks/decide", { id, decision }));
  if (r && decision === "dispute") toast("Tip: contact the merchant first. If that fails, dispute it in your card's app; you usually have 60 days from the statement.");
  return r;
}
PAGES.leaks = async (main) => {
  const d = await api("/api/leaks");
  main.innerHTML = `
    <h1>Fees &amp; Odd Charges</h1><p class="sub">Money leaking out without you noticing: bank fees, card interest, double charges, price hikes and charges way bigger than usual (last 90 days). Decide each one; disputes and refunds are watched until the money comes back.</p>
    <div class="grid g3" style="margin-bottom:16px">
      <div class="card stat"><div class="label">Fees + interest, last 12 months</div><div class="value ${d.fees_last_year > 0 ? "down" : ""}">${fmt2(d.fees_last_year)}</div><div class="delta">usually avoidable or refundable</div></div>
      <div class="card stat"><div class="label">Waiting for your decision</div><div class="value">${fmt2(d.at_stake)}</div><div class="delta">${d.open.filter((f) => !f.waiting).length} items</div></div>
      <div class="card stat"><div class="label">Recovered so far</div><div class="value pos">${fmt2(d.recovered)}</div><div class="delta">refunds and disputes that paid out</div></div></div>
    <div class="card"><h2>To decide</h2>${d.open.length ? d.open.map(leakCard).join("") : `<div class="empty">Nothing odd right now ✓</div>`}</div>
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h2>Waiting for a refund?</h2>
        <p class="tiny muted" style="margin-top:-6px">Returned something or got promised a credit? Track the charge and the app tells you when the money arrives, or nudges you after ${30} days.</p>
        <input id="refQ" placeholder="Search recent charges…" style="width:100%;margin-bottom:8px"><div id="refList" class="tiny muted">Type to search, or leave empty to see the latest.</div></div>
      <div class="card"><h2>Decided</h2>${d.done.length ? `<table>${d.done.map((f) => `<tr><td class="name">${esc(f.title)}<div class="tiny muted">${esc(DECIDED_TEXT[f.decision] || f.decision)}${f.decided_on ? " · " + shortDate(f.decided_on) : ""}</div></td>
        <td class="num">${fmt2(f.amount)}</td><td class="num"><button class="btn small secondary" data-undo="${esc(f.id)}">Undo</button></td></tr>`).join("")}</table>` : `<div class="empty">Nothing yet.</div>`}</div></div>`;
  $$("[data-leak]", main).forEach((card) => $$("[data-ldec]", card).forEach((b) => b.onclick = async () => {
    if (await decideLeak(card.dataset.leak, b.dataset.ldec)) PAGES.leaks(main);
  }));
  $$("[data-undo]", main).forEach((b) => b.onclick = async () => { await decideLeak(b.dataset.undo, "undo"); PAGES.leaks(main); });
  let t;
  const search = async () => {
    const r = await api("/api/leaks/charges?q=" + encodeURIComponent($("#refQ").value));
    $("#refList").innerHTML = r.charges.length ? `<table>${r.charges.map((c) => `<tr><td class="tiny">${shortDate(c.date)}</td><td class="name">${esc(c.merchant || c.name)}<div class="tiny muted">${esc(c.account_name || "")}</div></td>
      <td class="num">${fmt2(-c.amount)}</td><td class="num"><button class="btn small secondary" data-track="${esc(c.id)}">Track</button></td></tr>`).join("")}</table>` : "No charges match.";
    $$("[data-track]", main).forEach((b) => b.onclick = async () => { await run(() => post("/api/leaks/track", { tx_id: b.dataset.track }), "Tracking: you'll get an alert when it comes back"); PAGES.leaks(main); });
  };
  $("#refQ").oninput = () => { clearTimeout(t); t = setTimeout(search, 250); };
  search();
};

// =====================================================================
// WHAT IF
// =====================================================================
const WI_PRESETS = {
  raise: { icon: "💼", label: "Get a raise", fields: [["amount", "Raise ($/year, before tax)", 5000]] },
  car: { icon: "🚗", label: "Buy a car", fields: [["price", "Price ($)", 30000], ["down", "Down payment ($)", 5000], ["apr", "Loan APR (%)", 7], ["years", "Loan length (years)", 5], ["running", "Extra insurance/gas ($/month)", 150]] },
  rent: { icon: "🏠", label: "Move apartments", fields: [["amount", "Rent change ($/month, negative = cheaper)", -300]] },
  k401: { icon: "🏦", label: "More into 401(k)", fields: [["amount", "Extra contribution ($/month)", 300]] },
  invest: { icon: "📈", label: "Invest more", fields: [["amount", "Extra investing ($/month)", 200]] },
  purchase: { icon: "🛍️", label: "Big purchase", fields: [["amount", "Cost ($, one time)", 2000]] },
  cut: { icon: "✂️", label: "Cut spending", fields: [["amount", "Less spending ($/month)", 150], ["what", "On what (just a note)", "Dining"]] },
  spending: { icon: "➕", label: "New monthly cost", fields: [["amount", "Cost ($/month)", 100], ["what", "What (just a note)", "Gym"]] },
};
const WI = { items: JSON.parse(localStorage.getItem("whatifItems") || "[]"), years: +(localStorage.getItem("whatifYears") || 10) };
const wiSave = () => { localStorage.setItem("whatifItems", JSON.stringify(WI.items)); localStorage.setItem("whatifYears", WI.years); };

PAGES.whatif = async (main) => {
  const saved = (await api("/api/whatif/saved")).saved;
  main.innerHTML = `
    <h1>What if…?</h1><p class="sub">Try a decision before you make it. Stack changes and compare your future with and without them. Starts from your real last 12 months of income and spending.</p>
    <div class="wi-presets">${Object.entries(WI_PRESETS).map(([k, p]) => `<button class="chip" data-add="${k}">${p.icon} ${esc(p.label)}</button>`).join("")}</div>
    ${saved.length ? `<div class="row tiny" style="margin:10px 0">Saved: ${saved.map((s) => `<span class="chip" data-load="${esc(s.name)}">${esc(s.name)} <b data-delsave="${esc(s.name)}" title="Delete">×</b></span>`).join("")}</div>` : ""}
    <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.6fr);margin-top:12px;align-items:start">
      <div><div id="wiItems"></div>
        <div class="card" style="margin-top:12px"><label class="field">Look ahead<select id="wiYears">${[5, 10, 20, 30].map((y) => `<option value="${y}" ${y === WI.years ? "selected" : ""}>${y} years</option>`).join("")}</select></label>
          <div class="row" style="margin-top:10px"><button class="btn small secondary" id="wiClear">Clear</button><span class="spacer"></span><button class="btn small" id="wiSaveBtn">Save scenario</button></div></div></div>
      <div id="wiOut"><div class="card empty">Pick a change above to see what it does.</div></div></div>`;
  const drawItems = () => {
    $("#wiItems").innerHTML = WI.items.map((it, i) => {
      const p = WI_PRESETS[it.kind];
      return `<div class="card wi-item" data-i="${i}"><div class="row"><b>${p.icon} ${esc(p.label)}</b><span class="spacer"></span><button class="btn small secondary" data-rmi="${i}">✕</button></div>
        <div class="grid g2" style="margin-top:6px">${p.fields.map(([f, label]) => `<label class="field">${esc(label)}<input data-f="${f}" ${f === "what" ? "" : 'type="number" step="any"'} value="${esc(it[f] ?? "")}"></label>`).join("")}
          <label class="field">Starts in (months)<input data-f="start_months" type="number" min="0" value="${it.start_months || 0}"></label></div></div>`;
    }).join("") || `<div class="card empty tiny">No changes yet.</div>`;
    $$(".wi-item", main).forEach((card) => $$("input", card).forEach((inp) => inp.oninput = () => {
      WI.items[+card.dataset.i][inp.dataset.f] = inp.dataset.f === "what" ? inp.value : inp.value === "" ? "" : +inp.value;
      wiSave(); schedule();
    }));
    $$("[data-rmi]", main).forEach((b) => b.onclick = () => { WI.items.splice(+b.dataset.rmi, 1); wiSave(); drawItems(); schedule(); });
  };
  let timer;
  const schedule = () => { clearTimeout(timer); timer = setTimeout(compute, 300); };
  const compute = async () => {
    const out = $("#wiOut");
    if (!WI.items.length) { out.innerHTML = `<div class="card empty">Pick a change above to see what it does.</div>`; return; }
    const r = await api("/api/whatif", { method: "POST", body: { items: WI.items, years: WI.years } });
    const b = r.baseline, s = r.scenario;
    const pct = (v) => v == null ? "—" : Math.round(v * 100) + "%";
    const sign = (v) => (v > 0 ? "+" : v < 0 ? "−" : "") + fmt(Math.abs(v));
    const toSeries = (pts) => pts.map((p) => ({ t: new Date(p.date + "T00:00").getTime(), v: p.net }));
    const debt = (m) => m == null ? "not within the window" : m === 0 ? "no loans" : `${Math.floor(m / 12)}y ${m % 12}m`;
    out.innerHTML = `
      ${r.negative_leftover ? `<div class="card" style="border-color:var(--critical);margin-bottom:12px"><b class="down">This plan spends more than you take home.</b> <span class="tiny">The gap would come out of savings, then investments.</span></div>` : ""}
      <div class="grid g2">
        <div class="card stat"><div class="label">Left over each month</div><div class="value ${r.leftover_change < 0 ? "down" : "pos"}">${sign(r.leftover_change)}</div>
          <div class="delta">${fmt(b.flow.leftover)} → ${fmt(s.flow.leftover)} (first-year average)</div></div>
        <div class="card stat"><div class="label">Savings rate</div><div class="value">${pct(s.save_rate)}</div><div class="delta">now ${pct(b.save_rate)}</div></div></div>
      <div class="card" style="margin-top:12px"><h2>Net worth: with vs without</h2>
        ${multiLine([{ name: "Without", label: "Without", color: "var(--muted)", dash: true, points: toSeries(b.points) },
                     { name: "With changes", label: "With changes", color: "var(--series-1)", points: toSeries(s.points) }], { H: 240, W: 640 })}
        <table style="margin-top:8px"><thead><tr><th>In</th><th class="num">Without</th><th class="num">With</th><th class="num">Difference</th></tr></thead><tbody>
        ${r.at.map((a) => `<tr><td>${a.months % 12 ? a.months + " months" : a.months / 12 + (a.months === 12 ? " year" : " years")}</td><td class="num">${fmt(a.baseline)}</td><td class="num">${fmt(a.scenario)}</td>
          <td class="num ${a.difference < 0 ? "down" : "pos"}">${sign(a.difference)}</td></tr>`).join("")}</tbody></table>
        <p class="tiny muted">Debt-free: ${debt(b.debt_free_months)} → ${debt(s.debt_free_months)}. Assumes ${Math.round(r.assumptions.annual_return * 100)}% investment returns, ${Math.round(r.assumptions.inflation * 100)}% inflation and ${Math.round(r.assumptions.raise_rate * 100)}% yearly raises (same as Insights).</p>
        ${r.notes.length ? `<ul class="tiny">${r.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>` : ""}</div>`;
    wireMultiLines(out);
  };
  $$("[data-add]", main).forEach((b) => b.onclick = () => {
    const p = WI_PRESETS[b.dataset.add];
    WI.items.push(Object.fromEntries([["kind", b.dataset.add], ...p.fields.map(([f, , v]) => [f, v]), ["start_months", 0]]));
    wiSave(); drawItems(); schedule();
  });
  $("#wiYears").onchange = (e) => { WI.years = +e.target.value; wiSave(); schedule(); };
  $("#wiClear").onclick = () => { WI.items = []; wiSave(); drawItems(); schedule(); };
  $("#wiSaveBtn").onclick = async () => {
    if (!WI.items.length) return toast("Add a change first", true);
    const name = prompt("Name this scenario:", WI.items.map((i) => WI_PRESETS[i.kind].label).join(" + "));
    if (name && await run(() => post("/api/whatif/save", { name, items: WI.items }), "Saved")) PAGES.whatif(main);
  };
  $$("[data-load]", main).forEach((c) => c.onclick = (e) => {
    if (e.target.dataset.delsave) return;
    WI.items = JSON.parse(JSON.stringify(saved.find((s) => s.name === c.dataset.load).items)); wiSave(); drawItems(); schedule();
  });
  $$("[data-delsave]", main).forEach((x) => x.onclick = async () => { await post("/api/whatif/delete", { name: x.dataset.delsave }); PAGES.whatif(main); });
  drawItems(); compute();
};

// =====================================================================
// WEEKLY CHECK-IN
// =====================================================================
PAGES.checkin = async (main) => {
  const d = await api("/api/checkin");
  const decided = new Set();
  const cats = d.categories;
  const c = d.compare;
  const total = d.big_charges.length + d.leaks.length + d.subscriptions.length + (d.budget ? 1 : 0);
  const head = d.done
    ? `<div class="card checkin-hero done"><div class="hero-icon">✓</div><div><div class="hero-title">This week's check-in is done</div>
        <div class="tiny muted">Earned ${d.done.coins} coins · ${d.streak}-week streak 🔥 · next one opens Monday</div></div></div>`
    : `<div class="card checkin-hero"><div class="hero-icon">🗓️</div><div><div class="hero-title">${total} quick decision${total === 1 ? "" : "s"} this week</div>
        <div class="tiny muted">Worth <b>${d.next_reward} coins</b>${d.streak ? ` · ${d.streak}-week streak 🔥 (keep it going for a bigger bonus)` : " · start a streak: each week in a row adds +5"}</div></div>
        <span class="spacer"></span><div class="checkin-progress"><b id="ciDone">0</b>/${total}</div></div>`;
  const section = (n, title, body) => `<div class="card ci-sec" style="margin-top:16px"><h2><span class="ci-n">${n}</span>${title}</h2>${body}</div>`;
  let n = 0;
  main.innerHTML = `<a href="#dashboard" class="back-link">← Dashboard</a><h1>Weekly check-in</h1><p class="sub">Two minutes of decisions: confirm the big stuff, deal with anything odd, and see how the week went.</p>${head}
    ${d.big_charges.length ? section(++n, "Your biggest charges this week", `<p class="tiny muted" style="margin-top:-6px">Right category? Confirming teaches the sorter too.</p>
      <table class="t-ci">${d.big_charges.map((t) => `<tr class="ci-item" data-key="tx:${esc(t.id)}"><td class="tiny" style="white-space:nowrap">${shortDate(t.date)}</td>
        <td class="name">${esc(t.merchant || t.name)}<div class="tiny muted">${esc(t.account_name || "")}</div></td><td class="num">${fmt2(-t.amount)}</td>
        <td><select class="cat-select" data-ctx="${esc(t.id)}">${cats.map((x) => `<option ${x === t.category ? "selected" : ""}>${esc(x)}</option>`).join("")}</select></td>
        <td class="num"><button class="btn small" data-ok="${esc(t.id)}">✓ Right</button></td></tr>`).join("")}</table>`) : ""}
    ${d.leaks.length ? section(++n, "Anything odd", d.leaks.map((f) => `<div class="ci-item" data-key="leak:${esc(f.id)}">${leakCard(f)}</div>`).join("")) : ""}
    ${d.subscriptions.length ? section(++n, "Still worth it?", d.subscriptions.map((s) => `<div class="row ci-item" data-key="sub:${esc(s.id)}" style="padding:8px 0;border-bottom:1px solid var(--grid)">
        <div><b>${esc(s.name)}</b><div class="tiny muted">${fmt2(s.amount)} ${esc(s.cadence)} · ${fmt(s.yearly)}/year</div></div><span class="spacer"></span>
        <button class="btn small secondary" data-sub="${esc(s.id)}" data-v="keep">Keep</button><button class="btn small" data-sub="${esc(s.id)}" data-v="cancel">Cancel it</button></div>`).join("")) : ""}
    ${d.budget ? section(++n, "One budget change", `<div class="ci-item" data-key="budget"><p>${esc(d.budget.why)}</p>
        <div class="row"><label class="field" style="max-width:220px">${esc(d.budget.category)} cap ($/month)<input id="ciCap" type="number" value="${d.budget.amount}"></label>
        <span class="spacer"></span><button class="btn small secondary" id="ciSkip">Not now</button><button class="btn small" id="ciAccept">${d.budget.goal_id ? "Lower my cap" : "Set this cap"}</button></div>
        <p class="tiny muted">Becomes a spending goal: your pet gets credit each month you stay under.</p></div>`) : ""}
    ${section(++n, "How the week went", `<div class="grid g3">
        <div class="stat"><div class="label">Last 7 days</div><div class="value">${fmt(c.this_week)}</div></div>
        <div class="stat"><div class="label">The week before</div><div class="value muted">${fmt(c.last_week)}</div><div class="delta">${c.this_week <= c.last_week ? "▼ " + fmt(c.last_week - c.this_week) + " less" : "▲ " + fmt(c.this_week - c.last_week) + " more"}</div></div>
        <div class="stat"><div class="label">A typical week</div><div class="value muted">${fmt(c.typical_week)}</div><div class="delta">${c.this_week <= c.typical_week ? "✓ under typical" : "above typical"}</div></div></div>
      ${c.movers.length ? `<table style="margin-top:10px"><thead><tr><th>Biggest changes vs a typical week</th><th class="num">This week</th><th class="num">Typical</th><th class="num"></th></tr></thead><tbody>
        ${c.movers.map((m) => `<tr><td>${esc(m.category)}</td><td class="num">${fmt(m.this_week)}</td><td class="num muted">${fmt(m.typical)}</td><td class="num ${m.diff > 0 ? "down" : "pos"}">${m.diff > 0 ? "+" : "−"}${fmt(Math.abs(m.diff))}</td></tr>`).join("")}</tbody></table>` : ""}`)}
    ${d.done ? "" : `<div class="row" style="margin:18px 0"><span class="spacer"></span><span class="tiny muted" id="ciLeft"></span><button class="btn" id="ciFinish">Finish check-in</button></div>`}
    ${d.history.length ? `<p class="tiny muted">Past check-ins: ${d.history.slice().reverse().map((h) => `${esc(h.week.replace("-W", " wk "))} (+${h.coins})`).join(" · ")}</p>` : ""}`;

  const mark = (key) => {
    decided.add(key);
    const el = $(`[data-key="${CSS.escape(key)}"]`, main);
    if (el) el.classList.add("ci-done");
    const done = $("#ciDone"); if (done) done.textContent = decided.size;
    const left = total - decided.size, lb = $("#ciLeft");
    if (lb) lb.textContent = left > 0 ? `${left} left` : "All decided 🎉";
  };
  if ($("#ciLeft")) $("#ciLeft").textContent = total ? `${total} left` : "";
  $$("[data-ok]", main).forEach((b) => b.onclick = async () => {
    const sel = $(`[data-ctx="${CSS.escape(b.dataset.ok)}"]`, main);
    if (await run(() => post("/api/transactions/" + encodeURIComponent(b.dataset.ok), { category: sel.value }))) mark("tx:" + b.dataset.ok);
  });
  $$("[data-ctx]", main).forEach((s) => s.onchange = async () => {
    if (await run(() => post("/api/transactions/" + encodeURIComponent(s.dataset.ctx), { category: s.value }), "Category updated")) mark("tx:" + s.dataset.ctx);
  });
  $$(".ci-item [data-leak]", main).forEach((card) => $$("[data-ldec]", card).forEach((b) => b.onclick = async () => {
    if (await decideLeak(card.dataset.leak, b.dataset.ldec)) mark("leak:" + card.dataset.leak);
  }));
  $$("[data-sub]", main).forEach((b) => b.onclick = async () => {
    if (await run(() => post("/api/subscriptions/" + encodeURIComponent(b.dataset.sub), { decision: b.dataset.v }),
      b.dataset.v === "cancel" ? "Reminder set to cancel before it renews" : "Kept")) mark("sub:" + b.dataset.sub);
  });
  const ca = $("#ciAccept");
  if (ca) {
    ca.onclick = async () => { if (await run(() => post("/api/checkin/budget", { category: d.budget.category, amount: +$("#ciCap").value, goal_id: d.budget.goal_id }), "Cap saved as a goal")) mark("budget"); };
    $("#ciSkip").onclick = async () => { await post("/api/checkin/budget", { category: d.budget.category, skip: true }); mark("budget"); };
  }
  const fin = $("#ciFinish");
  if (fin) fin.onclick = async () => {
    const left = total - decided.size;
    if (left > 0 && !confirm(`${left} item${left > 1 ? "s" : ""} still undecided. Finish anyway?`)) return;
    const r = await run(() => post("/api/checkin/complete", { decisions: decided.size }));
    if (!r) return;
    confetti(fin);
    toast(r.already ? "Already done this week" : `+${r.coins} coins · ${r.streak}-week streak 🔥`);
    await refreshStatus(); setTimeout(() => PAGES.checkin(main), 900);
  };
};

// =====================================================================
// Dashboard cards + nav badges
// =====================================================================
{
  const baseDash = PAGES.dashboard;
  PAGES.dashboard = async (main, params) => {
    await baseDash(main, params);
    if (!STATUS.has_data) return;
    const bits = [];
    if (STATUS.health && STATUS.health.issues) {
      bits.push(`<a class="card linkcard dash-note sev-${STATUS.health.status}" href="#health"><b>${LEVEL_ICON[STATUS.health.status] || "!"} ${STATUS.health.issues} connection issue${STATUS.health.issues > 1 ? "s" : ""}</b>
        <span class="tiny muted">Some numbers may be out of date. Tap to fix.</span></a>`);
    }
    // The weekly check-in lives here now: ready to do, or done for the week
    bits.push(STATUS.checkin_done
      ? `<a class="card linkcard dash-note dash-checkin done" href="#checkin"><b>✓ Weekly check-in done</b>
        <span class="tiny muted">${STATUS.checkin_streak ? `${STATUS.checkin_streak}-week streak 🔥 · ` : ""}next one opens Monday · tap to look back at it</span></a>`
      : `<a class="card linkcard dash-note dash-checkin" href="#checkin"><b>🗓️ Weekly check-in is ready</b>
        <span class="tiny muted">2 minutes${STATUS.checkin_streak ? ` · ${STATUS.checkin_streak}-week streak 🔥` : ""} · earns pet coins</span></a>`);
    if (!bits.length) return;
    const wrap = document.createElement("div");
    wrap.className = "dash-notes";
    wrap.innerHTML = bits.join("");
    const h1 = $("h1", main);
    (h1 && h1.nextElementSibling ? h1.nextElementSibling : main.firstChild).after(wrap);
  };
}
{
  const baseRefresh = refreshStatus;
  // eslint-disable-next-line no-global-assign
  refreshStatus = async (background = false) => {
    await baseRefresh(background);
    const hb = $("#healthBadge"), cb = $("#checkinDot");
    if (hb) { hb.hidden = !(STATUS.health && STATUS.health.issues); hb.textContent = STATUS.health ? STATUS.health.issues : ""; }
    if (cb) cb.hidden = !!STATUS.checkin_done;
  };
}

// =====================================================================
// Fees & odd charges live on the Bills & Alerts page, as its second view
// =====================================================================
{
  const billsView = PAGES.bills, feesView = PAGES.leaks;
  const hashQs = () => { const [page, qs] = location.hash.slice(1).split("?"); return page === "bills" ? qs || "" : ""; };
  PAGES.bills = async (main, qs) => {
    const fees = new URLSearchParams(qs === undefined ? hashQs() : qs).get("view") === "fees";
    if (fees) await feesView(main); else await billsView(main, qs);
    const h1 = $("h1", main);
    if (!h1) return;
    h1.textContent = "Bills & Alerts";
    let open = fees ? $$("[data-leak]:not(.waiting)", main).length : null;
    const tabs = document.createElement("div");
    tabs.className = "gr-chips view-tabs";
    const paint = () => { tabs.innerHTML = `<a class="chip ${fees ? "" : "active"}" href="#bills">Bills &amp; alerts</a>
      <a class="chip ${fees ? "active" : ""}" href="#bills?view=fees">Fees &amp; odd charges${open ? ` <b class="badge">${open}</b>` : ""}</a>`; };
    paint();
    h1.after(tabs);
    if (!fees) api("/api/leaks", { background: true }).then((d) => { open = d.open.filter((f) => !f.waiting).length; if (tabs.isConnected) paint(); }).catch(() => {});
  };
  // The old address still works, and the fees view redraws itself through here after each decision
  PAGES.leaks = async (main) => {
    if (location.hash.slice(1).split("?")[0] === "leaks") { location.replace("#bills?view=fees"); return; }
    await PAGES.bills(main, "view=fees");
  };
}
