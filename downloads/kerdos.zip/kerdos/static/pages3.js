"use strict";
// This Month (left to spend + checking forecast), Investments, subscription checkup,
// encryption / backups / phone access settings. Uses helpers from app.js and pages2.js.

const PACE_LABEL = { "on track": ["●", "On track", "var(--series-1)"], ahead: ["▲", "Spending faster than usual", "var(--warning)"],
  over: ["✕", "Over your average", "var(--critical)"] };

// =====================================================================
// THIS MONTH
// =====================================================================
PAGES.month = async (main) => {
  const [m, f] = await Promise.all([api("/api/cashflow/month"), api("/api/cashflow/forecast?days=45")]);
  const ne = m.nonessential, es = m.essential;
  const monthName = new Date(m.month + "-15").toLocaleString(undefined, { month: "long" });
  const meter = (g) => {
    const pct = g.average ? Math.min(130, g.spent / g.average * 100) : 0;
    const pace = g.average ? Math.min(100, g.expected_by_now / g.average * 100) : 0;
    return `<div class="pbar big"><div class="fill" style="width:${Math.min(100, pct)}%;background:${pct > 100 ? "var(--critical)" : "var(--series-1)"}"></div>
      <div class="pace" style="left:${pace}%" title="Where you'd be today at your usual pace"></div></div>`;
  };
  const [pi, pl, pc] = PACE_LABEL[ne.pace];
  const catRow = (r) => {
    const used = r.spent + r.pending;
    const pct = r.average ? used / r.average * 100 : (used > 0 ? 100 : 0);
    return `<tr><td>${esc(r.category)}</td>
      <td style="width:38%"><div class="pbar"><div class="fill" style="width:${Math.min(100, pct)}%;background:${pct > 100 ? "var(--critical)" : "var(--series-1)"}"></div></div></td>
      <td class="num">${fmt(used)}${r.pending ? `<div class="tiny muted">incl. ${fmt(r.pending)} pending</div>` : ""}</td>
      <td class="num muted">${fmt(r.average)}</td>
      <td class="num ${r.left < 0 ? "down" : ""}">${r.left < 0 ? "over by " + fmt(-r.left) : fmt(r.left)}</td></tr>`;
  };
  const nonEss = m.categories.filter((r) => !r.essential), ess = m.categories.filter((r) => r.essential);
  main.innerHTML = `
    <h1>${esc(monthName)} so far</h1>
    <p class="sub">Day ${m.day} of ${m.days_in_month}. Compared with your average month (last ${m.months_averaged} months). Pending charges count.</p>
    <div class="grid" style="grid-template-columns:minmax(0,1.3fr) minmax(0,1fr)">
      <div class="card hero-left">
        <div class="tiny muted">Non-essential spending left this month</div>
        <div class="hero-num ${ne.left < 0 ? "down" : ""}">${ne.left < 0 ? "−" + fmt(-ne.left) : fmt(ne.left)}</div>
        <div class="row" style="gap:16px;margin:4px 0 10px">
          <span><b>${fmt(ne.per_day)}</b><span class="muted">/day for ${m.days_left} days</span></span>
          <span class="pill"><span style="color:${pc}">${pi}</span>${pl}</span></div>
        ${meter(ne)}
        <div class="row tiny muted"><span>Spent ${fmt(ne.spent)} of your usual ${fmt(ne.average)}</span><span class="spacer"></span><span>| = usual pace for day ${m.day} (${fmt(ne.expected_by_now)})</span></div>
        <p class="tiny muted" style="margin-bottom:0">Non-essential = everything except ${m.essentials.map(esc).join(", ")}. <a href="#" id="editEss">Change</a></p>
      </div>
      <div class="card">
        <div class="tiny muted">Essentials so far (rent, groceries, bills…)</div>
        <div class="hero-num">${fmt(es.spent)}</div>
        <div class="tiny muted" style="margin-bottom:8px">of about ${fmt(es.average)} in a usual month</div>
        ${meter(es)}
        <div class="kv tiny" style="margin-top:12px">
          <div>Everything so far this month</div><div class="num">${fmt(m.total.spent)} of ~${fmt(m.total.average)}</div>
          <div>Checking now</div><div class="num">${fmt(f.start_balance || 0)}</div>
          <div>Lowest point ahead</div><div class="num ${f.lowest_overall && f.lowest_overall.balance < f.buffer ? "down" : ""}">${f.lowest_overall ? `${fmt(f.lowest_overall.balance)} on ${shortDate(f.lowest_overall.date)}` : "—"}</div>
          <div>Next paycheck</div><div class="num">${f.next_payday ? shortDate(f.next_payday) : "—"}</div></div>
      </div>
    </div>
    <div class="card" style="margin-top:16px"><div class="row"><h2 style="margin:0">Checking balance, next 45 days</h2><span class="spacer"></span>
      <span class="legend" style="margin:0"><span><i style="background:var(--series-1)"></i>Projected balance</span><span><i style="background:var(--critical)"></i>Your cushion (${fmt(f.buffer)})</span></span><a href="#" id="editBuf" class="tiny">Change</a></div>
      <div id="fcChart" style="margin-top:8px"></div>
      ${f.events.length ? `<details style="margin-top:6px"><summary class="tiny muted">${f.events.length} expected paychecks and bills</summary><table class="tiny">${f.events.map((e) =>
        `<tr><td style="white-space:nowrap">${shortDate(e.date)}</td><td class="name">${esc(e.name)}</td><td class="muted">${e.kind === "income" ? "paycheck" : (e.autopay === "no" ? "bill (pay by hand)" : "bill")}</td><td class="num ${e.amount > 0 ? "pos" : ""}">${e.amount > 0 ? "+" : ""}${fmt2(e.amount)}</td></tr>`).join("")}</table></details>` : ""}
    </div>
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h2>Non-essential, by category</h2>
        <table><thead><tr><th>Category</th><th></th><th class="num">So far</th><th class="num">Usual</th><th class="num">Left</th></tr></thead>
        <tbody>${nonEss.map(catRow).join("") || `<tr><td colspan="5" class="muted">Nothing yet</td></tr>`}</tbody></table></div>
      <div>
        <div class="card"><h2>Where it's going</h2>
          ${m.top_merchants.length ? `<table>${m.top_merchants.map((t) => `<tr><td class="name">${esc(t.who)}<div class="tiny muted">${esc(t.category)} · ${t.n}×</div></td><td class="num">${fmt2(t.total)}</td></tr>`).join("")}</table>` : `<div class="tiny muted">No non-essential spending yet this month.</div>`}</div>
        <div class="card" style="margin-top:16px"><h2>Essentials</h2>
          <table><tbody>${ess.map(catRow).join("")}</tbody></table></div>
      </div>
    </div>`;
  const box = $("#fcChart");
  const draw = () => {
    if (!f.points.length) { box.innerHTML = `<div class="empty">No checking accounts found.</div>`; return; }
    const ms = (iso) => new Date(iso + "T00:00").getTime();
    box.innerHTML = multiLine([
      { name: "Projected balance", label: "Balance", color: "var(--series-1)", points: f.points.map((p) => ({ t: ms(p.date), v: p.balance })) },
      { name: "Cushion", label: "Cushion", color: "var(--critical)", dash: true, points: [{ t: ms(f.points[0].date), v: f.buffer }, { t: ms(f.points.at(-1).date), v: f.buffer }] },
    ], { W: Math.max(320, box.clientWidth), H: 240 });
    wireMultiLines(box);
  };
  draw();
  window.onresize = () => { if (location.hash.startsWith("#month")) draw(); };
  $("#editBuf").onclick = async (e) => {
    e.preventDefault();
    const v = prompt("Keep at least this much in checking (your cushion):", f.buffer);
    if (v == null) return;
    await run(() => post("/api/cashflow/settings", { buffer: v }), "Saved"); PAGES.month(main);
  };
  $("#editEss").onclick = (e) => {
    e.preventDefault();
    const dlg = $("#dlg");
    dlg.innerHTML = `<h2>Which categories are essential?</h2><p class="tiny muted">Everything you leave unticked counts as non-essential.</p>
      <div class="grid g2" style="gap:4px">${STATUS.categories.filter((c) => !["Income", "Transfer", "Credit Card Payment", "Investments", "Other"].includes(c))
        .map((c) => `<label class="row tiny"><input type="checkbox" value="${esc(c)}" ${m.essentials.includes(c) ? "checked" : ""}> ${esc(c)}</label>`).join("")}</div>
      <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn secondary" id="essX">Cancel</button><button class="btn" id="essOk">Save</button></div>`;
    dlg.showModal();
    $("#essX").onclick = () => dlg.close();
    $("#essOk").onclick = async () => {
      const picks = $$("input[type=checkbox]:checked", dlg).map((i) => i.value);
      dlg.close();
      await run(() => post("/api/cashflow/settings", { essentials: picks }), "Saved"); PAGES.month(main);
    };
  };
};

// Dashboard: add the two headline numbers
{
  const baseDash = PAGES.dashboard;
  PAGES.dashboard = async (main, params) => {
    await baseDash(main, params);
    if (!STATUS.has_data) return;
    try {
      const m = await api("/api/cashflow/month");
      const strip = document.createElement("div");
      strip.className = "grid g2";
      strip.style.marginTop = "16px";
      strip.innerHTML = `<a class="card stat linkcard" href="#month"><div class="label">Non-essential left this month</div>
          <div class="value ${m.nonessential.left < 0 ? "down" : ""}">${m.nonessential.left < 0 ? "−" + fmt(-m.nonessential.left) : fmt(m.nonessential.left)}</div>
          <div class="delta">${fmt(m.nonessential.per_day)}/day for ${m.days_left} days · ${PACE_LABEL[m.nonessential.pace][1].toLowerCase()}</div></a>
        <a class="card stat linkcard" href="#month"><div class="label">Essentials so far this month</div><div class="value">${fmt(m.essential.spent)}</div>
          <div class="delta">of about ${fmt(m.essential.average)} in a usual month</div></a>`;
      const first = $(".grid.g4", main);
      if (first) first.after(strip);
    } catch (_) { /* dashboard still works without it */ }
  };
}

// =====================================================================
// SUBSCRIPTION CHECKUP (top of the Bills page)
// =====================================================================
{
  const baseBills = PAGES.bills;
  PAGES.bills = async (main, params) => {
    await baseBills(main, params);
    const c = await api("/api/subscriptions");
    const card = document.createElement("div");
    card.className = "card";
    card.style.margin = "16px 0";
    const FLAG = { price_up: "📈", trial: "🆓", new: "🆕", double: "⚠", duplicate: "👯", fee: "🏦" };
    card.innerHTML = `<div class="row"><h2 style="margin:0">Subscription checkup</h2><span class="spacer"></span>
        <span class="tiny muted">${fmt(c.yearly_total)}/year · ${fmt(c.monthly_total)}/month${c.to_review ? ` · <b>${c.to_review} to review</b>` : ""}</span></div>
      <p class="tiny muted" style="margin:4px 0 8px">Sorted by yearly cost. The app can't see whether you use a service, so review each one: keep it, or mark it to cancel and get a reminder 2 days before it renews. It asks again every 6 months.</p>
      ${c.subscriptions.length ? `<table>${c.subscriptions.map((s) => `<tr class="${s.decision === "cancel" ? "muted" : ""}">
        <td class="name">${esc(s.name)}${s.flags.map((f) => `<div class="tiny" style="white-space:normal">${FLAG[f.kind] || "•"} ${esc(f.text)}</div>`).join("")}
          ${s.decision === "cancel" ? `<div class="tiny down">Marked to cancel · reminder ${esc(s.remind_on || "")}</div>` : ""}</td>
        <td class="num"><b>${fmt(s.yearly)}</b>/yr<div class="tiny muted">${fmt2(s.amount)} ${esc(s.cadence)}</div></td>
        <td class="num" style="white-space:nowrap">${s.decision && !s.needs_review
          ? `<span class="tiny muted">${s.decision === "keep" ? "✓ Keeping" : "Cancelling"}</span> <button class="btn small secondary" data-sub="${esc(s.id)}" data-d="undo">Undo</button>`
          : `<button class="btn small secondary" data-sub="${esc(s.id)}" data-d="keep">Keep</button> <button class="btn small danger" data-sub="${esc(s.id)}" data-d="cancel">Cancel it</button>`}</td></tr>`).join("")}</table>`
        : `<div class="tiny muted">No recurring subscriptions found yet.</div>`}`;
    const anchor = $(".grid.g3", main);
    (anchor || $("h1", main)).after(card);
    $$("[data-sub]", card).forEach((b) => b.onclick = async () => {
      await run(() => post("/api/subscriptions/" + encodeURIComponent(b.dataset.sub), { decision: b.dataset.d }),
        b.dataset.d === "cancel" ? "Marked to cancel. You'll get a reminder before it renews." : "Saved");
      await refreshStatus(); PAGES.bills(main, params);
    });
  };
}

// =====================================================================
// INVESTMENTS
// =====================================================================
const CLASS_LABEL = { us_stocks: "US stocks", intl_stocks: "International stocks", bonds: "Bonds", cash: "Cash", crypto: "Crypto" };
const CLASS_COLOR = { us_stocks: "var(--series-1)", intl_stocks: "var(--series-3)", bonds: "var(--series-2)", cash: "var(--neutral)", crypto: "var(--series-7)" };

// Holdings table columns. `get` is what sorting uses; holdings without a value always sort last.
const HOLDING_COLS = [
  { key: "name", label: "Holding", text: true, get: (h) => (h.ticker || h.name || "").toLowerCase() },
  { key: "price", label: "Price", get: (h) => h.price_now },
  { key: "month", label: "1 month", get: (h) => h.month_pct },
  { key: "risk", label: "Risk", get: (h) => (h.risk ? h.risk.rank : null) },
  { key: "type", label: "Type", text: true, get: (h) => CLASS_LABEL[h.asset_class] || "Target-date fund" },
  { key: "value", label: "Value", get: (h) => h.value },
  { key: "gain", label: "Return $", get: (h) => h.gain },
  { key: "gain_pct", label: "Return %", get: (h) => h.gain_pct },
  { key: "fee", label: "Fee/yr", get: (h) => h.fee_dollars },
];
function invSort() {
  try { return JSON.parse(localStorage.getItem("invSort")) || { key: "value", dir: "desc" }; }
  catch (_) { return { key: "value", dir: "desc" }; }
}
function holdingsTable(hs) {
  const { key, dir } = invSort();
  const col = HOLDING_COLS.find((c) => c.key === key) || HOLDING_COLS.find((c) => c.key === "value");
  const sorted = hs.slice().sort((a, b) => {
    const x = col.get(a), y = col.get(b);
    if (x == null && y == null) return 0;
    if (x == null) return 1;
    if (y == null) return -1;
    const c = col.text ? String(x).localeCompare(String(y)) : x - y;
    return dir === "asc" ? c : -c;
  });
  const signed = (v, f) => v == null ? "—" : (v >= 0 ? "+" : "−") + f(Math.abs(v));
  const cls = (v) => v > 0 ? "pos" : v < 0 ? "down" : "";
  const head = HOLDING_COLS.map((c) => {
    const on = c.key === col.key;
    const arrow = on ? (dir === "asc" ? "▲" : "▼") : "↕";
    const hint = c.text ? (on && dir === "asc" ? "Z→A" : "A→Z") : (on && dir === "desc" ? "lowest first" : "highest first");
    return `<th class="${c.text ? "" : "num"} sortable ${on ? "sorted" : ""}" data-sortkey="${c.key}" title="Sort ${hint}" aria-sort="${on ? (dir === "asc" ? "ascending" : "descending") : "none"}">
      ${c.label} <span class="sort-arrow">${arrow}</span></th>`;
  }).join("");
  const month = (h) => {
    if (h.month_pct === undefined) return `<td class="num muted">…</td>`;   // still being looked up
    if (h.month_pct == null) return `<td class="num muted">—</td>`;
    const p = h.px;
    return `<td class="num ${cls(h.month_pct)}" data-tip="${esc(`<b>${esc(h.ticker)} · past month</b><br>A month ago ${fmt2(p.month_ago)}<br>Now ${fmt2(p.price)} (${signed(p.change, fmt2)})<br>Low ${fmt2(p.low)} · High ${fmt2(p.high)}`)}">${h.month_pct >= 0 ? "▲" : "▼"} ${Math.abs(h.month_pct).toFixed(1)}%</td>`;
  };
  const risk = (h) => h.risk === undefined ? `<td class="num muted">…</td>` : !h.risk ? `<td class="num muted">—</td>`
    : `<td class="num"><span class="risk-tag r-${esc(h.risk.level)}" data-tip="${esc(esc(h.risk.why))}">${esc(h.risk.label)}</span></td>`;
  const canChart = (h) => h.asset_class !== "cash" && /^[A-Za-z][A-Za-z0-9.\-]{0,9}$/.test(h.ticker || "");
  return `<table class="t-hold"><thead><tr>${head}</tr></thead><tbody>
    ${sorted.map((h) => `<tr ${canChart(h) ? `class="clickable" data-stock="${esc(h.ticker.toUpperCase())}" tabindex="0" title="See ${esc(h.ticker)}'s past year"` : ""}><td class="name">${esc(h.ticker || "")} <span class="muted">${esc(h.name || "")}</span></td>
      <td class="num">${h.price_now == null ? "—" : fmt2(h.price_now)}</td>${month(h)}${risk(h)}
      <td class="tiny">${esc(CLASS_LABEL[h.asset_class] || "Target-date fund")}</td>
      <td class="num">${fmt2(h.value || 0)}</td>
      <td class="num ${cls(h.gain)}">${signed(h.gain, (v) => fmt(v).replace("−", ""))}</td>
      <td class="num ${cls(h.gain_pct)}">${signed(h.gain_pct, (v) => v.toFixed(1) + "%")}</td>
      <td class="num tiny">${h.expense_ratio == null ? "—" : `${h.expense_ratio}% · ${fmt(h.fee_dollars || 0)}`}</td></tr>`).join("")}</tbody></table>
    <div class="tiny muted" style="margin-top:6px">Click a holding to see its price over the past year. Price and 1 month = the latest price and how much it moved over the past month (from Yahoo Finance, may be delayed). Risk = how bumpy it is: what kind of thing it is and how much its price has swung; hover a tag for the reason. Return = current value minus what you paid (cost basis), when your brokerage reports it. Click a column to sort; click again to flip.</div>`;
}

PAGES.investments = async (main) => {
  const s = await api("/api/investments");
  const needsConsent = s.connections.filter((c) => c.status !== "ok");
  const byAcct = {};
  s.holdings.forEach((h) => {
    (byAcct[h.account_name] = byAcct[h.account_name] || []).push(h);
    h.price_now = h.quantity ? h.value / h.quantity : null;      // from your brokerage, until live prices arrive
    h.month_pct = h.asset_class === "cash" || !h.ticker ? null : undefined;
  });
  const bar = (mix) => `<div class="alloc">${Object.keys(CLASS_LABEL).filter((k) => mix[k] > 0).map((k) =>
    `<div style="flex:${mix[k]};background:${CLASS_COLOR[k]}" data-tip="${esc(`<b>${CLASS_LABEL[k]}</b><br>${mix[k]}%`)}"></div>`).join("")}</div>`;
  main.innerHTML = `
    <h1>Investments</h1><p class="sub">What you own across your brokerage accounts, your real mix compared with your plan, and what the funds cost you each year.</p>
    ${needsConsent.length ? `<div class="banner"><h2>Connect your investment details</h2>
      <p class="tiny muted">Plaid can show holdings and exact contributions once each brokerage grants access. A Plaid window will ask you to confirm. If it says Investments isn't enabled, turn on the Investments product for your app in the Plaid dashboard (it may be billed per account) and try again.</p>
      <div class="row">${needsConsent.map((c) => `<button class="btn small" data-consent="${esc(c.item_id)}">Grant access: ${esc(c.institution || "brokerage")}</button>
        <span class="tiny muted">${c.status === "unknown" ? "not checked yet" : c.status === "plan" ? "Investments not enabled on your Plaid account" : c.status === "not_ready" ? "Plaid is still preparing data" : c.status === "needs_consent" ? "needs your OK" : "error"}</span>`).join("")}
        <button class="btn small secondary" id="invSync">Check again</button></div></div>` : ""}
    ${s.holdings.length ? `
    <div class="grid g3">
      <div class="card stat"><div class="label">Invested (with holdings detail)</div><div class="value">${fmt(s.total)}</div></div>
      <div class="card stat"><div class="label">Estimated fund fees</div><div class="value">${fmt(s.fees_per_year)}<span class="muted" style="font-size:14px">/yr</span></div>
        <div class="delta">known for ${s.fees_known_pct}% of your money</div></div>
      <div class="card stat"><div class="label">Biggest drift from plan</div><div class="value">${(() => { const [k, v] = Object.entries(s.drift).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))[0]; return `${v > 0 ? "+" : ""}${v}%`; })()}</div>
        <div class="delta">${(() => { const [k, v] = Object.entries(s.drift).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))[0]; return `${CLASS_LABEL[k]} ${v > 0 ? "above" : "below"} target`; })()}</div></div>
    </div>
    <div class="card" style="margin-top:16px"><h2>Your mix vs. your plan</h2>
      <div class="tiny muted">You now</div>${bar(s.actual)}
      <div class="tiny muted">Plan target (from your age and risk on the Investing Plan page)</div>${bar(s.target)}
      <table style="margin-top:8px">${Object.keys(CLASS_LABEL).map((k) => `<tr><td><span class="legend" style="margin:0"><span><i style="background:${CLASS_COLOR[k]}"></i>${CLASS_LABEL[k]}</span></span></td>
        <td class="num">${s.actual[k]}%</td><td class="num muted">target ${s.target[k]}%</td><td class="num ${Math.abs(s.drift[k]) >= 5 ? "down" : ""}">${s.drift[k] > 0 ? "+" : ""}${s.drift[k]}%</td></tr>`).join("")}</table>
      <p class="tiny muted">A drift of 5% or more is the usual signal to rebalance: point new contributions at what's under target rather than selling (selling in a taxable account can trigger taxes).</p></div>
    ${Object.entries(byAcct).map(([acct, hs]) => `<div class="card" style="margin-top:16px"><h2>${esc(acct)}</h2>
      <div class="holdings" data-acct="${esc(acct)}">${holdingsTable(hs)}</div></div>`).join("")}
    <p class="disclaimer">Fees use published expense ratios for common index funds (approximate; check your fund's page). Individual stocks have no fund fee. This is information, not investment advice.</p>`
    : `<div class="card empty">No holdings yet. ${s.connections.length ? "Grant access above, then click Check again." : "Connect your brokerage on the Accounts page."}</div>`}`;
  // Click a column header to sort every account's table by it; click again to flip the order
  const resort = (e) => {
    const th = e.target.closest("[data-sortkey]");
    if (!th) return;
    const k = th.dataset.sortkey, cur = invSort();
    const dir = cur.key === k ? (cur.dir === "desc" ? "asc" : "desc") : (HOLDING_COLS.find((c) => c.key === k).text ? "asc" : "desc");
    localStorage.setItem("invSort", JSON.stringify({ key: k, dir }));
    $$(".holdings", main).forEach((box) => { box.innerHTML = holdingsTable(byAcct[box.dataset.acct]); });
  };
  $$(".holdings", main).forEach((box) => { box.onclick = resort; });
  $$("[data-consent]", main).forEach((b) => b.onclick = () => grantInvestments(b.dataset.consent));
  if (s.holdings.length) {   // latest price and 1-month change, filled in once they've been looked up
    window.__invInsights = api("/api/investments/insights").catch(() => null);   // risk tags and the daily briefing
    window.__invInsights.then((ins) => {
      s.holdings.forEach((h) => { const x = ins && ins.holdings && ins.holdings[h.account_id + "|" + h.security_id]; h.risk = x ? x.risk : null; });
      $$(".holdings", main).forEach((box) => { box.innerHTML = holdingsTable(byAcct[box.dataset.acct]); });
    });
    api("/api/investments/prices").catch(() => ({})).then((px) => {
      s.holdings.forEach((h) => {
        const p = px[(h.ticker || "").toUpperCase()];
        if (h.month_pct !== undefined) return;
        h.px = p || null;
        h.month_pct = p ? p.change_pct : null;
        if (p && p.price) h.price_now = p.price;
      });
      $$(".holdings", main).forEach((box) => { box.innerHTML = holdingsTable(byAcct[box.dataset.acct]); });
    });
  }
  const sync = $("#invSync");
  if (sync) sync.onclick = async () => { sync.disabled = true; await run(() => post("/api/investments/sync"), "Checked"); PAGES.investments(main); };
};

function grantInvestments(itemId) {
  return openPlaid({ itemId, addInvestments: true });
}

// =====================================================================
// SECURITY: encryption, backups, phone access (Accounts page)
// =====================================================================
{
  const baseAcc = PAGES.accounts;
  PAGES.accounts = async (main, params) => {
    await baseAcc(main, params);
    const [a, phone] = await Promise.all([api("/api/auth/status"), api("/api/auth/phone")]);
    const card = document.createElement("div");
    card.className = "card";
    card.style.marginTop = "16px";
    const ts = phone.tailscale || {};
    card.innerHTML = `<div class="grid g3">
      <div><h3>Encrypt my data</h3>
        ${a.vault.enabled
          ? `<p class="tiny"><span class="up">✓ On.</span> Your database and backups are encrypted on disk. After a restart, nothing (not even syncing) runs until you sign in once.</p>
             <button class="btn small secondary" id="vaultOff">Turn off encryption…</button>`
          : `<p class="tiny muted">Encrypts the database and backups so the files are useless to anyone without your password, even with access to your PC. You'll get a one-time <b>recovery code</b>: without it, a forgotten password means your data can't be opened.</p>
             <button class="btn small" id="vaultOn">Turn on encryption…</button>`}</div>
      <div><h3>Backups</h3>
        <p class="tiny muted">A backup is saved automatically every day the app runs (the newest 30 are kept) in <code>data/backups</code>${a.vault.enabled ? ", encrypted" : ""}.</p>
        <button class="btn small secondary" id="backupNow">Back up now</button></div>
      <div><h3>Phone access</h3>
        ${ts.installed ? (ts.running && ts.dns_name ? `<p class="tiny">Tailscale is on. Your private address: <code>${esc(ts.dns_name)}</code></p>` : `<p class="tiny muted">Tailscale is installed but not signed in.</p>`)
          : `<p class="tiny muted">Use Tailscale (free) for private access from your iPhone. The README has the steps.</p>`}
        <p class="tiny muted">Allowed phone addresses: ${phone.hosts.length ? phone.hosts.map((h) => `<code>${esc(h)}</code>`).join(" ") : "none yet"}</p>
        <button class="btn small secondary" id="phoneAdd">${phone.hosts.length ? "Change address" : "Allow my Tailscale address"}</button></div>
    </div>`;
    main.appendChild(card);
    $("#backupNow").onclick = () => run(() => post("/api/auth/backup"), (r) => `Saved ${r.file}`);
    $("#phoneAdd").onclick = async () => {
      const v = prompt("Your PC's Tailscale address (ends in .ts.net). Leave empty to turn phone access off:", phone.hosts[0] || ts.dns_name || "");
      if (v == null) return;
      await run(() => post("/api/auth/phone", { hosts: v.trim() ? [v.trim()] : [] }), "Saved");
      PAGES.accounts(main, params);
    };
    const on = $("#vaultOn"), off = $("#vaultOff");
    if (on) on.onclick = () => askPassword("Turn on encryption", "Enter your password to encrypt your data.", async (pw) => {
      const r = await post("/api/auth/vault/enable", { password: pw });
      showRecoveryCode(r.recovery_code, r.backups_encrypted);
    });
    if (off) off.onclick = () => askPassword("Turn off encryption", "Your data will be stored unencrypted again.", async (pw) => {
      await post("/api/auth/vault/disable", { password: pw });
      toast("Encryption turned off"); PAGES.accounts(main, params);
    });
  };
}

function askPassword(title, text, action) {
  const dlg = $("#dlg");
  dlg.innerHTML = `<form><h2>${esc(title)}</h2><p class="tiny muted">${esc(text)}</p>
    <input type="text" name="username" value="finance-hub" autocomplete="username" hidden>
    <input type="password" id="apw" autocomplete="current-password" placeholder="Password" required style="width:100%">
    <div id="aerr" class="down tiny" style="margin-top:6px"></div>
    <div class="row" style="margin-top:14px"><span class="spacer"></span><button type="button" class="btn secondary" id="ax">Cancel</button><button class="btn" id="ago">Continue</button></div></form>`;
  dlg.showModal();
  $("#ax").onclick = () => dlg.close();
  $("form", dlg).onsubmit = async (e) => {
    e.preventDefault();
    $("#ago").disabled = true;
    try { await action($("#apw").value); if (dlg.open && !$("#rcode")) dlg.close(); }
    catch (ex) { $("#aerr").textContent = ex.message; $("#ago").disabled = false; }
  };
}

function showRecoveryCode(code, nBackups) {
  const dlg = $("#dlg");
  dlg.innerHTML = `<h2>🔐 Encryption is on</h2>
    <p>Write down this recovery code and keep it somewhere safe (a password manager, or on paper). It's shown <b>only once</b>.
    If you ever forget your password, it's the only way back into your data.</p>
    <div id="rcode" class="rcode">${esc(code)}</div>
    <p class="tiny muted">${nBackups ? `${nBackups} existing backup${nBackups === 1 ? " was" : "s were"} encrypted too. ` : ""}To use it: close the app and run <code>py -3.12 main.py --recover</code>.</p>
    <label class="row tiny"><input type="checkbox" id="rsaved"> I've saved my recovery code</label>
    <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn" id="rdone" disabled>Done</button></div>`;
  if (!dlg.open) dlg.showModal();
  dlg.oncancel = (e) => e.preventDefault();  // don't let Esc dismiss it by accident
  $("#rsaved").onchange = (e) => { $("#rdone").disabled = !e.target.checked; };
  $("#rdone").onclick = () => { dlg.oncancel = null; dlg.close(); route(); };
}

// =====================================================================
// MENU: five groups. On a phone each group is a bottom tab, and the pages inside the current group
// run across the top as a strip. The sidebar in index.html is the one list of what belongs where.
// =====================================================================
{
  const subnav = $("#subnav");
  const groupOf = (page) => $$(".sidebar .nav-group").find((g) => $$("a[data-page]", g).some((a) => a.dataset.page === page));
  const paintNav = () => {
    const raw = (location.hash.slice(1) || "dashboard").split("?")[0];
    const page = PAGES[raw] ? (NAV_ALIAS[raw] || raw) : "dashboard";
    const g = groupOf(page), tab = g ? g.dataset.group : "dashboard";
    $$(".tabbar a").forEach((a) => a.classList.toggle("active", a.dataset.tab === tab));
    if (!g) { subnav.hidden = true; subnav.innerHTML = ""; return; }
    subnav.hidden = false;
    subnav.innerHTML = $$("a[data-page]", g).map((a) => {
      const b = $(".badge", a), n = b && !b.hidden ? b.textContent.trim() : "";
      return `<a href="${esc(a.getAttribute("href"))}" class="${a.dataset.page === page ? "active" : ""}">${esc(a.firstChild.textContent.trim())}${n ? `<i>${esc(n)}</i>` : ""}</a>`;
    }).join("") + (tab === "settings" ? `<button type="button" data-act="sync">🔄 Sync now</button><button type="button" data-act="lock">🔒 Lock</button>` : "");
    $$("[data-act]", subnav).forEach((b) => b.onclick = () => (b.dataset.act === "sync" ? $("#syncBtn").click() : lockNow()));
    const on = $("a.active", subnav);
    if (on) subnav.scrollLeft = on.offsetLeft - (subnav.clientWidth - on.offsetWidth) / 2;
  };
  window.paintNav = paintNav;
  window.addEventListener("hashchange", paintNav);
  document.addEventListener("DOMContentLoaded", paintNav);
  // A group's heading and its phone tab carry the badge of the page inside it
  const mirror = () => {
    $$("[data-mirror]").forEach((dst) => {
      const src = document.getElementById(dst.dataset.mirror);
      const n = src && !src.hidden ? src.textContent.trim() : "";
      dst.hidden = !n; dst.textContent = +n > 99 ? "99+" : n;
    });
    paintNav();
  };
  const watch = new MutationObserver(mirror);
  ["alertBadge", "sortBadge", "healthBadge"].forEach((id) => watch.observe(document.getElementById(id), { attributes: true, childList: true, characterData: true, subtree: true }));
}

// =====================================================================
// COMBINE CATEGORIES (Transactions page)
// =====================================================================
{
  const baseTx = PAGES.transactions;
  PAGES.transactions = async (main, params) => {
    await baseTx(main, params);
    const info = await api("/api/categories");
    const card = document.createElement("div");
    card.className = "card";
    card.style.marginTop = "16px";
    const lm = info.last_merge;
    card.innerHTML = `<h2>Combine categories</h2>
      <p class="tiny muted" style="margin-top:-6px">Tick two or more categories to fold together, or one to fold into another. Every transaction, rule, bill and goal moves over, and new transactions follow. You can undo it.</p>
      <div class="merge-grid">${info.categories.map((c) => `<label class="merge-chip"><input type="checkbox" value="${esc(c.name)}"> ${esc(c.name)} <span class="muted">${c.count}</span></label>`).join("")}</div>
      <div class="row" style="margin-top:10px"><input id="mergeName" placeholder="Name for the combined category" style="min-width:240px" list="mergeNames">
        <datalist id="mergeNames">${info.categories.map((c) => `<option value="${esc(c.name)}">`).join("")}</datalist>
        <button class="btn small" id="mergeGo" disabled>Combine</button><span class="tiny muted" id="mergeHint"></span></div>
      ${lm ? `<div class="row tiny" style="margin-top:12px;padding-top:10px;border-top:1px solid var(--grid)"><span>Last combined: <b>${lm.sources.map(esc).join(" + ")}</b> → <b>${esc(lm.target)}</b> (${lm.moved} transactions, ${esc(lm.at.replace("T", " ").slice(0, 16))})</span>
        <span class="spacer"></span><button class="btn small secondary" id="unmerge">↶ Undo this</button></div>` : ""}`;
    main.appendChild(card);
    const boxes = $$(".merge-grid input", card), name = $("#mergeName"), go = $("#mergeGo"), hint = $("#mergeHint");
    const sync = () => {
      const picked = boxes.filter((b) => b.checked).map((b) => b.value);
      if (picked.length && !name.dataset.touched) name.value = picked.length === 2 ? `${picked[0]} & ${picked[1]}` : picked[0] || "";
      const target = name.value.trim();
      const sources = picked.filter((p) => p !== target);
      go.disabled = !target || !sources.length;
      hint.textContent = sources.length && target ? `${sources.join(" + ")} → ${target}` : "";
    };
    boxes.forEach((b) => b.onchange = sync);
    name.oninput = () => { name.dataset.touched = "1"; sync(); };
    go.onclick = async () => {
      const target = name.value.trim();
      const sources = boxes.filter((b) => b.checked).map((b) => b.value).filter((p) => p !== target);
      if (!confirm(`Combine ${sources.join(" + ")} into "${target}"?`)) return;
      await run(() => post("/api/categories/merge", { sources, target }), (r) => `Combined: ${r.moved} transactions moved to ${r.target}`);
      await refreshStatus(); PAGES.transactions(main, params);
    };
    const un = $("#unmerge");
    if (un) un.onclick = async () => {
      await run(() => post("/api/categories/unmerge"), (r) => `Split ${r.target} back into ${r.sources.join(", ")}`);
      await refreshStatus(); PAGES.transactions(main, params);
    };
  };
}
