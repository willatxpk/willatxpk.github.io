// Kerdos: looking after the companion. Food, water and play, thought bubbles, tricks, and paint.
// Nothing here is a chore: needs run down slowly, nothing bad happens if you're away, and health and
// growth still come only from your real goals. Caring builds a bond, which unlocks tricks and themes.
"use strict";

const PAINT_LABEL = {
  body: "Fur", belly: "Belly", cheeks: "Cheeks", eyes: "Eyes", hat: "Hat", leaf: "Leaves", flower: "Flowers", pot: "Pot",
  wall: "Walls", floor: "Floor", trim: "Trim", curtain: "Curtains", frame: "Frames", shelf: "Shelf", rug: "Rug",
  lamp: "Lamp", toy: "Toy", bed: "Bed", bowl: "Bowl",
};
const PAINT_THEMES = {
  classic: { label: "Classic", colors: {} },
  pastel: { label: "Pastel", colors: { wall: "#f7e8ef", floor: "#d8c3a5", trim: "#eccfdc", body: "#f6b6cf", belly: "#fff3f8", cheeks: "#ff8fb3", rug: "#bfe6d8", bed: "#b8a8f2", curtain: "#f8c873", lamp: "#ffe9a6", toy: "#7cc4f8", bowl: "#8ed3c2", shelf: "#c9a27e", frame: "#c9a27e", leaf: "#7fcf9a", pot: "#f6b6cf", flower: "#ffd1e3", hat: "#b8a8f2" } },
  sunset: { label: "Sunset", colors: { wall: "#ffd9b8", floor: "#a65f3c", trim: "#e2764a", body: "#ff9a5c", belly: "#ffe6cf", cheeks: "#ff5d73", rug: "#f2545b", bed: "#8b3a62", curtain: "#ffb347", lamp: "#ffd166", toy: "#ffd166", bowl: "#f2545b", shelf: "#7a3b2e", frame: "#7a3b2e", leaf: "#e08a3c", pot: "#8b3a62", flower: "#ffd166", hat: "#f2545b" } },
  forest: { label: "Forest", colors: { wall: "#dfe8d2", floor: "#6b4a2f", trim: "#4f6b3a", body: "#7fb069", belly: "#eef5dc", cheeks: "#e6a57e", rug: "#a3b18a", bed: "#588157", curtain: "#dda15e", lamp: "#fefae0", toy: "#bc6c25", bowl: "#606c38", shelf: "#5a3e28", frame: "#5a3e28", leaf: "#2f8f4e", pot: "#bc6c25", flower: "#fefae0", hat: "#bc6c25" } },
  galaxy: { label: "Galaxy", colors: { wall: "#231942", floor: "#3a2a5c", trim: "#5e548e", body: "#9f86ff", belly: "#e0d4ff", cheeks: "#ff7ad9", rug: "#5e548e", bed: "#be95c4", curtain: "#7b2cbf", lamp: "#ffd6ff", toy: "#4cc9f0", bowl: "#4cc9f0", shelf: "#3c2a66", frame: "#e0b1cb", leaf: "#4cc9f0", pot: "#7b2cbf", flower: "#ffd6ff", hat: "#4cc9f0" } },
};
const hex6 = (c) => {
  c = String(c || "").trim().toLowerCase();
  if (/^#[0-9a-f]{6}$/.test(c)) return c;
  if (/^#[0-9a-f]{3}$/.test(c)) return "#" + [...c.slice(1)].map((x) => x + x).join("");
  return "#888888";
};

function careInit(main, view, d) {
  d.colors = d.colors || {};
  const NS = "http://www.w3.org/2000/svg";
  const isPet = d.kind === "pet", who = d.name || (isPet ? "Your pet" : "Your plant");
  const st = { room: null, bubble: null, idx: 0, foods: [], painting: false, paintOpen: false, playN: 0, playT: null, colorT: null, sayT: null, wakeUntil: 0 };
  const panel = document.createElement("div");
  panel.className = "care";
  view.appendChild(panel);
  const svgNow = () => $("svg.room", view);
  const send = (body) => api("/api/companion", { method: "POST", body: { care: body } });

  // ------------------------------------------------------------ thought bubble
  function setBubble(t) {
    const room = st.room;
    if (!room) return;
    $(".thought", room.fx)?.remove();
    st.bubble = null;
    const line = $(".care-thought", panel);
    if (line) {
      line.innerHTML = t ? `💭 <b>${esc(who)}:</b> ${t.link ? `<a href="${esc(t.link)}">${esc(t.text)}</a>` : esc(t.text)}` : "";
      line.className = "care-thought tiny" + (t && t.kind === "need" ? " need" : "");
    }
    if (!t) return;
    const g = document.createElementNS(NS, "g");
    g.setAttribute("class", "thought");
    g.innerHTML = `<circle cx="-15" cy="22" r="2.2"/><circle cx="-10" cy="15" r="3.6"/><rect x="-19" y="-24" width="38" height="34" rx="15"/><text y="0" text-anchor="middle" font-size="18">${esc(t.icon)}</text>`;
    room.fx.appendChild(g);
    st.bubble = g;
    placeBubble();
  }
  function placeBubble() {
    const room = st.room, g = st.bubble;
    if (!g || !room) return;
    const [hx, hy] = room.head(room.pet);
    const x = Math.max(22, Math.min(room.W - 22, hx + room.pet.hw * 0.75 + 6)), y = Math.max(27, hy - 4);
    g.setAttribute("transform", `translate(${x.toFixed(1)} ${y.toFixed(1)})`);
    g.setAttribute("opacity", room.pet.held ? "0" : "1");
  }
  const showThought = () => {
    if (d.asleep) return setBubble({ icon: "💤", text: isPet && d.stage ? "Zzz… (fast asleep; a tap wakes it)" : "Zzz…", kind: "idle" });
    const list = d.thoughts || [];
    setBubble(list.length ? list[st.idx % list.length] : null);
  };
  // ------------------------------------------------------------ night: asleep until morning, unless you wake it
  const zzz = () => { const room = st.room; if (room) { room.puff(...room.head(room.pet), "z", "#dfe6ff", 2, 24); room.kick(); } };
  function tuck() { if (st.room) { st.room.tuckIn(); placeBubble(); zzz(); } }
  const stayUp = () => { st.wakeUntil = Date.now() + 150000; };   // awake for a couple of minutes after you do something
  function wake() {
    if (!d.asleep) { stayUp(); return false; }
    d.asleep = false;
    stayUp();
    rerender();
    say("🥱", "Mmh… is it morning already?");
    return true;
  }
  function say(icon, text) {          // something it says right now, then back to its usual thoughts
    setBubble({ icon, text, kind: "idle" });
    clearTimeout(st.sayT);
    st.sayAt = Date.now();
    st.sayT = setTimeout(showThought, 3800);
  }
  const cycle = setInterval(() => {
    if (!panel.isConnected) return clearInterval(cycle);
    const night = isNightNow(), busy = (st.room && st.room.pet.held) || st.foods.length;
    if (night !== d.night) { d.night = night; d.asleep = night; rerender(); if (night) tuck(); return; }       // dusk or dawn
    if (d.night && !d.asleep && !busy && Date.now() > st.wakeUntil) { d.asleep = true; rerender(); tuck(); return; }   // dozes off again
    if (d.asleep) return zzz();
    if (st.sayT && Date.now() - (st.sayAt || 0) < 3800) return;
    st.idx++;
    showThought();
  }, 7000);

  // ------------------------------------------------------------ the room, and re-drawing it
  function hook() {
    const room = st.room = svgNow().__room;
    if (!room) return;
    st.foods = [];
    room.on("pet", () => { if (wake()) return; play(1); trick(room); });
    room.on("toss", () => { wake(); play(1); });
    room.on("fetch", () => play(2));
    room.on("rest", (b) => { if (b.food) landed(b); });
    room.on("reach", (t) => { if (t.food) eat(t); else if (t.bowl) drink(); });
    room.on("step", placeBubble);
    showThought();
  }
  function rerender() {
    if (st.room) st.room.flush();
    const tmp = document.createElement("div");
    tmp.innerHTML = drawRoom(d);
    const svg = tmp.firstElementChild;
    svgNow().replaceWith(svg);
    svg.__room = initRoom(svg, d);
    svg.classList.toggle("painting", st.painting);
    hook();
  }

  // ------------------------------------------------------------ food, water, play
  function apply(res, quiet) {
    if (!res || !res.care) return;
    d.care = res.care; d.thoughts = res.thoughts || [];
    paintPanel();
    const r = res.result || {};
    if (r.level_up && !quiet) toast(`❤️ ${who} and you are now “${r.level_up}”${r.unlock ? ": unlocked " + r.unlock : ""}!`);
    else if (r.level_up) toast(`❤️ Now “${r.level_up}”${r.unlock ? ": unlocked " + r.unlock : ""}!`);
  }
  function dropFood(id, x) {
    if (wake()) say("😋", "Ooh… a midnight snack?");
    const room = st.room, c = d.care, f = c.foods.find((k) => k.id === id);
    if (!room || !f || st.foods.length >= 3) return;
    if ((f.fun > f.food ? c.fun : c.food) >= 95) return say("😌", isPet ? "I'm stuffed. Maybe later!" : "I've had plenty, thank you!");
    const g = document.createElementNS(NS, "g");
    g.setAttribute("class", "food-item");
    g.innerHTML = `<text text-anchor="middle" y="6" font-size="17">${esc(f.emoji)}</text>`;
    svgNow().insertBefore(g, room.fx);
    const pet = room.pet, px = pet.cx + pet.x;
    const body = room.addBody(g, { cx: 0, cy: 0, hw: 9, hh: 9 }, { bounce: 0.35, spin: false, food: f });
    const side = px > room.W / 2 ? -1 : 1;
    body.x = Math.max(14, Math.min(room.W - 14, isPet ? (x ?? px + side * (60 + Math.random() * 60)) : px));
    body.y = 12;
    body.floorY = body.homeFloor = isPet ? pet.floorY : pet.cy + pet.hh + pet.y - 32;   // a plant catches it in its pot
    body.vx = isPet ? (Math.random() - 0.5) * 60 : 0;
    st.foods.push(body);
    room.kick();
  }
  function landed(b) {
    const room = st.room;
    if (!isPet || !d.stage) return eat(b);
    if (!room.pet.target) room.goTo(b);
  }
  async function eat(b) {
    const room = st.room, f = b.food;
    if (!st.foods.includes(b)) return;
    st.foods = st.foods.filter((k) => k !== b);
    room.puff(b.cx + b.x, b.cy + b.y, isPet ? "•" : "✨", isPet ? "#c98a4b" : "#f6d046", 4, 70);
    room.removeBody(b);
    room.kick();
    let res;
    try { res = await send({ action: "feed", food: f.id }); } catch (e) { return toast(e.message, true); }
    const r = res.result || {};
    if (r.full) say("😌", isPet ? "I'm stuffed. Maybe later!" : "I've had plenty, thank you!");
    else if (r.craved) {
      room.puff(...room.head(room.pet), "♥", "#e87ba4", 6, 110);
      if (isPet) { room.pet.vy = -330; room.pet.va = 560; room.pet.rest = false; }
      toast(`${who} loved the ${f.name.toLowerCase()}! ❤️ +${r.bond}`);
    } else room.puff(...room.head(room.pet), "♥", "#e87ba4", 1);
    room.kick();
    apply(res);
    if (r.craved) say("😋", "That was exactly what I wanted!");
    const next = st.foods.find((k) => k.rest);
    if (next && isPet) st.room.goTo(next);
  }
  async function water() {
    if (d.care.egg) return;
    wake();
    if (d.care.water >= 95) return say("💧", isPet ? "My bowl is still full!" : "My soil is still nice and damp!");
    let res;
    try { res = await send({ action: "water" }); } catch (e) { return toast(e.message, true); }
    apply(res);
    if (!isPet) {
      const room = st.room, [hx, hy] = room.head(room.pet);
      for (let i = 0; i < 6; i++) room.puff(hx + (Math.random() - 0.5) * 50, hy - 8, "💧", "#6fb3f2", 1, 30);
      room.kick();
      return say("💧", "Ahh, that's better.");
    }
    rerender();                     // the bowl is full again
    const room = st.room, bowl = room.furn.bowl;
    if (!bowl) return;
    const spot = { bowl: true, rest: true, x: bowl.x, y: bowl.y, cx: bowl.bb.x + bowl.bb.width / 2, cy: bowl.bb.y + bowl.bb.height / 2, hw: bowl.bb.width / 2, hh: bowl.bb.height / 2 };
    room.puff(spot.cx + spot.x, spot.cy + spot.y - 8, "💧", "#6fb3f2", 3, 40);
    if (!room.goTo(spot)) room.kick();
  }
  function drink() {
    const room = st.room;
    room.puff(...room.head(room.pet), "💧", "#6fb3f2", 3, 50);
    room.puff(...room.head(room.pet), "♥", "#e87ba4", 1);
    room.kick();
    say("😊", "Ahh, fresh water.");
  }
  function play(n) {
    st.playN += n;
    d.care.fun = Math.min(100, d.care.fun + 8 * n);
    const bar = $('[data-need="fun"] .bar div', panel);
    if (bar) bar.style.width = d.care.fun + "%";
    clearTimeout(st.playT);
    st.playT = setTimeout(async () => {
      const n2 = st.playN;
      st.playN = 0;
      try { apply(await send({ action: "play", n: n2 }), true); } catch (_) { /* it was only a game */ }
    }, 2500);
  }
  function trick(room) {
    const have = d.care.bond.tricks, pet = room.pet;
    if (!isPet || !d.stage || !have.length || Math.random() < 0.3) return;
    const t = have[Math.floor(Math.random() * have.length)];
    if (t === "spin") { pet.vy = -300; pet.va = 620; }
    if (t === "flip") { pet.vy = -440; pet.va = -430; }
    if (t === "dance") {
      [1, -1, 1, -1].forEach((dir, i) => setTimeout(() => {
        if (pet.held || st.room !== room || !panel.isConnected) return;
        pet.vx = dir * 75; pet.vy = -170; pet.rest = false;
        room.puff(...room.head(pet), "♪", "#9085e9", 1, 30);
        room.kick();
      }, 430 * (i + 1)));
    }
  }

  // ------------------------------------------------------------ paint
  function paintKeys() {
    const seen = new Map();
    $$("[data-paint]", svgNow()).forEach((el) => {
      const k = el.dataset.paint;
      if (!seen.has(k) && PAINT_LABEL[k]) seen.set(k, hex6(el.dataset.paintValue || el.getAttribute(el.dataset.paintAttr || "fill")));
    });
    return seen;
  }
  function swatches() {
    const b = d.care.bond;
    const themes = b.themes.map((id) => `<button class="chip" data-theme="${esc(id)}">${esc(PAINT_THEMES[id]?.label || id)}</button>`).join("") +
      b.locked_themes.map((t) => `<span class="chip locked" title="Unlocks when you become “${esc(t.at)}”">🔒 ${esc(PAINT_THEMES[t.id]?.label || t.id)}</span>`).join("");
    return `<div class="tiny muted">Pick a colour for anything in the room, or press “Paint by clicking” and click the thing itself.</div>
      <div class="paint-themes"><span class="tiny muted">Themes</span>${themes}</div>
      <div class="swatches">${[...paintKeys()].map(([k, v]) => `<label class="swatch ${d.colors[k] ? "set" : ""}"><input type="color" data-key="${k}" value="${v}"><span>${PAINT_LABEL[k]}</span>${d.colors[k] ? `<button class="sw-x" data-unpaint="${k}" title="Back to the original colour">↺</button>` : ""}</label>`).join("")}</div>
      <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn small ${st.painting ? "" : "secondary"}" id="paintPick">🖌 Paint by clicking${st.painting ? ": on" : ""}</button>
        <button class="btn small secondary" id="paintReset" ${Object.keys(d.colors).length ? "" : "disabled"}>Reset all colours</button></div>`;
  }
  const saveColors = () => {
    clearTimeout(st.colorT);
    st.colorT = setTimeout(() => api("/api/companion", { method: "POST", body: { colors: d.colors } }).catch((e) => toast(e.message, true)), 400);
  };
  function wirePaint() {
    const box = $(".paint-panel", panel);
    if (!box) return;
    box.innerHTML = swatches();
    $$("input[type=color]", box).forEach((inp) => {
      inp.oninput = () => { d.colors[inp.dataset.key] = hex6(inp.value); rerender(); };
      inp.onchange = () => { d.colors[inp.dataset.key] = hex6(inp.value); rerender(); saveColors(); wirePaint(); };
    });
    $$("[data-unpaint]", box).forEach((b) => b.onclick = (e) => { e.preventDefault(); delete d.colors[b.dataset.unpaint]; rerender(); saveColors(); wirePaint(); });
    $$("[data-theme]", box).forEach((b) => b.onclick = () => { d.colors = { ...(PAINT_THEMES[b.dataset.theme]?.colors || {}) }; rerender(); saveColors(); wirePaint(); });
    $("#paintPick", box).onclick = () => { st.painting = !st.painting; svgNow().classList.toggle("painting", st.painting); wirePaint(); };
    $("#paintReset", box).onclick = () => { d.colors = {}; rerender(); saveColors(); wirePaint(); };
  }
  // Paint by clicking: while it's on, clicks in the room pick what to colour instead of grabbing it
  view.addEventListener("pointerdown", (e) => { if (st.painting && e.target.closest("svg.room")) e.stopPropagation(); }, true);
  view.addEventListener("click", (e) => {
    const svg = e.target.closest("svg.room");
    if (!st.painting || !svg) return;
    let el = e.target.closest("[data-paint]");
    if (!el) {
      const group = e.target.closest("[data-furn], .pet-move");
      el = group && $("[data-paint]", group);
    }
    let key = el && el.dataset.paint;
    if (!key) key = new DOMPoint(e.clientX, e.clientY).matrixTransform(svg.getScreenCTM().inverse()).y < 186 ? "wall" : "floor";
    const inp = $(`.paint-panel input[data-key="${key}"]`, panel);
    if (!inp) return;
    inp.focus();
    try { inp.showPicker ? inp.showPicker() : inp.click(); } catch (_) { inp.click(); }
  }, true);

  // ------------------------------------------------------------ the panel under the room
  function paintPanel() {
    const c = d.care, b = c.bond;
    const meter = (key) => { const v = c[key], [icon, label] = c.labels[key]; return `<div class="care-meter" data-need="${key}" title="${esc(label)}: ${v} out of 100"><span>${esc(icon)} ${esc(label)}</span><div class="bar"><div style="width:${v}%;background:${v >= 50 ? "var(--good)" : v >= 25 ? "var(--warning)" : "var(--critical)"}"></div></div></div>`; };
    const span = (b.next || b.points) - b.floor || 1;
    panel.innerHTML = `
      <div class="care-thought tiny"></div>
      <div class="care-meters">${meter("food")}${meter("water")}${meter("fun")}</div>
      <div class="care-tray">${c.egg ? `<span class="tiny muted">Still an egg: it hatches at level 2. Tapping it keeps it cosy.</span>`
        : c.foods.map((f) => `<button class="food-btn" data-food="${esc(f.id)}" title="${esc(f.name)}${c.craving && c.craving.id === f.id ? " (today's favourite)" : ""}"><span>${esc(f.emoji)}</span><small>${esc(f.name)}</small>${c.craving && c.craving.id === f.id ? `<i>♥</i>` : ""}</button>`).join("")
          + `<button class="food-btn water" data-water title="Fresh water"><span>💧</span><small>Water</small></button>`}</div>
      ${c.egg ? "" : `<div class="tiny muted">Tap something to drop it in, or drag it into the room. ${isPet ? "Play by petting, tossing or throwing the ball." : "Tap your plant to say hello."}</div>`}
      <div class="care-bond tiny" title="Your bond grows when you look after ${esc(who)}. It never goes down."><span>❤️ <b>${esc(b.name)}</b></span>
        <div class="bar"><div style="width:${Math.min(100, (b.points - b.floor) / span * 100)}%"></div></div><span class="muted">${b.next ? `${b.points} / ${b.next}` : "as close as can be"}</span></div>
      ${b.next_unlock ? `<div class="tiny muted">Next, at “${esc(b.next_name)}”: ${esc(b.next_unlock)}.</div>` : ""}
      <div class="row tiny care-foot"><label class="muted">Needs run down <select id="carePace" class="tiny">${c.paces.map((p) => `<option value="${esc(p.key)}" ${p.key === c.pace ? "selected" : ""}>${esc(p.label)}</option>`).join("")}</select></label>
        <span class="spacer"></span><button class="btn small ${st.paintOpen ? "" : "secondary"}" id="paintToggle">🎨 Colours</button></div>
      <div class="paint-panel" ${st.paintOpen ? "" : "hidden"}></div>`;
    $$("[data-food]", panel).forEach((btn) => {
      const id = btn.dataset.food;
      btn.addEventListener("click", (e) => { if (e.detail === 0) dropFood(id); });   // keyboard
      btn.addEventListener("pointerdown", (e) => {
        const x0 = e.clientX, y0 = e.clientY;
        let ghost = null;
        const move = (ev) => {
          if (!ghost && Math.hypot(ev.clientX - x0, ev.clientY - y0) > 8) {
            ghost = document.createElement("div");
            ghost.className = "food-ghost";
            ghost.textContent = $("span", btn).textContent;
            document.body.appendChild(ghost);
          }
          if (ghost) { ghost.style.left = ev.clientX + "px"; ghost.style.top = ev.clientY + "px"; }
        };
        const up = (ev) => {
          ["pointermove", "pointerup", "pointercancel"].forEach((n, i) => window.removeEventListener(n, i ? up : move));
          if (!ghost) return ev.type === "pointerup" ? dropFood(id) : null;   // a tap
          ghost.remove();
          const r = svgNow().getBoundingClientRect();
          if (ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom) dropFood(id, ((ev.clientX - r.left) / r.width) * 360);
        };
        window.addEventListener("pointermove", move);
        window.addEventListener("pointerup", up);
        window.addEventListener("pointercancel", up);
      });
    });
    const w = $("[data-water]", panel);
    if (w) w.onclick = water;
    $("#carePace", panel).onchange = async (e) => { try { apply(await send({ action: "pace", pace: e.target.value })); toast("Pace changed"); } catch (err) { toast(err.message, true); } };
    $("#paintToggle", panel).onclick = () => {
      st.paintOpen = !st.paintOpen;
      if (!st.paintOpen && st.painting) { st.painting = false; svgNow().classList.remove("painting"); }
      paintPanel();
    };
    if (st.paintOpen) wirePaint();
    showThought();
  }

  hook();
  paintPanel();
  if (d.asleep) tuck();
}

{
  const baseGoals = PAGES.goals;
  PAGES.goals = async (main, params) => {
    await baseGoals(main, params);
    const d = window.__goalsData, view = $(".room-view", main);
    if (!d || !d.kind || !d.care || !view || !$("svg.room", view)) return;
    careInit(main, view, d);
  };
}
