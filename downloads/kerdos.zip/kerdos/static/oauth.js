// Finishes a bank sign-in that came back through Plaid's redirect (kept in its own file so the
// page needs no inline script).
(function () {
  "use strict";
  var msg = document.getElementById("msg"), back = document.getElementById("back");
  function fail(text) { msg.textContent = text; back.hidden = false; }
  var pending = null;
  try { pending = JSON.parse(localStorage.getItem("plaidPending") || "null"); } catch (e) { pending = null; }
  if (!pending || Date.now() - pending.at > 30 * 60 * 1000) {
    fail("This sign-in has expired or was started on another device. Go back and try connecting again.");
    return;
  }
  if (!window.Plaid) { fail("Couldn't load Plaid. Check your internet connection and try again."); return; }
  function call(path, body) {
    return fetch(path, {
      method: "POST", credentials: "same-origin",
      headers: { "X-Finance-Hub": "1", "Content-Type": "application/json" },
      body: JSON.stringify(body || {})
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (!r.ok) throw new Error(d.error || ("Error " + r.status));
        return d;
      });
    });
  }
  window.Plaid.create({
    token: pending.token,
    receivedRedirectUri: window.location.href,
    onSuccess: function (publicToken, meta) {
      msg.textContent = "Connected. Saving…";
      var inst = meta && meta.institution && meta.institution.name;
      var save = pending.partner ? call("/api/partner/exchange", { public_token: publicToken, institution: inst, item_id: pending.itemId })
        : pending.addInvestments ? call("/api/investments/sync")
        : pending.itemId ? call("/api/sync")
        : call("/api/plaid/exchange", { public_token: publicToken, institution: meta && meta.institution && meta.institution.name });
      save.then(function () {
        localStorage.removeItem("plaidPending");
        location.replace(pending.partner ? "/#roommates" : pending.addInvestments ? "/#investments" : "/#accounts");
      }).catch(function (e) {
        fail("Your bank approved it, but saving failed: " + e.message + ". Sign in to Kerdos and try connecting again.");
      });
    },
    onExit: function (err) {
      localStorage.removeItem("plaidPending");
      if (err) fail(err.display_message || err.error_message || "The bank sign-in was cancelled.");
      else location.replace("/#accounts");
    }
  }).open();
})();
