// Kerdos: today's buy plan (Investments) and splitting costs with a partner (Shared Costs)
"use strict";

// =====================================================================
// TODAY'S BUY PLAN (top of the Investments page)
// =====================================================================
function sparkline(p, W = 132, H = 40) {
  if (!p || !p.points || p.points.length < 2) return `<div class="tiny muted">no price data</div>`;
  const vs = p.points.map((x) => x.v), lo = Math.min(...vs), hi = Math.max(...vs), span = hi - lo || 1;
  const xy = p.points.map((x, i) => [2 + (i / (p.points.length - 1)) * (W - 4), 4 + (1 - (x.v - lo) / span) * (H - 8)]);
  const line = xy.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`).join("");
  const color = p.change_pct >= 0 ? "var(--good)" : "var(--critical)";
  const d0 = new Date(p.points[0].t), d1 = new Date(p.points.at(-1).t);
  const day = (d) => d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  const tipHtml = `<b>${esc(p.symbol)} · past month</b><br>${day(d0)}: ${fmt2(p.month_ago)}<br>${day(d1)}: ${fmt2(p.price)}<br>Low ${fmt2(p.low)} · High ${fmt2(p.high)}`;
  return `<svg class="spark" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" data-tip="${esc(tipHtml)}" role="img" aria-label="Price over the past month">
    <path d="${line}L${xy.at(-1)[0].toFixed(1)},${H}L${xy[0][0].toFixed(1)},${H}Z" fill="${color}" opacity=".12"/>
    <path d="${line}" fill="none" stroke="${color}" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>
    <circle cx="${xy.at(-1)[0].toFixed(1)}" cy="${xy.at(-1)[1].toFixed(1)}" r="2.6" fill="${color}"/></svg>`;
}

function buyPlanHtml(b) {
  const line = (ln) => {
    const p = ln.price;
    return `<div class="buy-line">
      <div class="buy-tick" style="--c:${CLASS_COLOR[ln.asset_class] || "var(--series-4)"}" data-stock="${esc(ln.ticker)}" tabindex="0" role="button" title="See ${esc(ln.ticker)}'s past year">${esc(ln.ticker)}</div>
      <div class="buy-what"><div class="buy-name">${esc(ln.name)}</div>
        <div class="tiny muted">${esc(ln.class_name)}${ln.owned ? " · you already own this" : ""}${ln.expense_ratio != null ? ` · fee ${ln.expense_ratio}%/yr` : ""}</div>
        <div class="tiny" style="margin-top:3px">${esc(ln.why)}</div></div>
      <div class="buy-price">${p ? `${sparkline(p)}
        <div class="tiny"><b>${fmt2(p.price)}</b> <span class="${p.change_pct >= 0 ? "pos" : "down"}">${p.change_pct >= 0 ? "▲" : "▼"} ${Math.abs(p.change_pct).toFixed(1)}%</span> <span class="muted">past month</span></div>`
        : `<div class="tiny muted">Price unavailable right now</div>`}</div>
      <div class="buy-amt"><div class="tiny muted">Buy</div><b>${fmt(ln.amount)}</b>
        ${ln.shares ? `<div class="tiny muted">≈ ${ln.shares < 10 ? ln.shares.toFixed(2) : ln.shares.toFixed(1)} shares</div>` : ""}</div></div>`;
  };
  const where = b.where.length ? `<div class="tiny" style="margin-top:10px">🏦 <b>Where:</b> your <a href="#invest">Investing Plan</a> sends ${b.where.map((w) => `${fmt(w.monthly)}/mo to your ${esc(w.label)}`).join(", then ")}.</div>` : "";
  return `<div class="row"><h2 style="margin:0">Today's buy plan</h2><span class="pill">${new Date(b.date + "T00:00").toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })}</span><span class="spacer"></span>
      <label class="tiny muted row" style="gap:6px">Investing <span class="buy-dollar">$<input id="buyAmt" type="number" min="1" step="25" value="${b.amount}"></span></label>
      <select id="buyVeh" class="tiny" title="Which kind of fund to use for anything you don't already own">
        <option value="auto" ${b.vehicle === "auto" ? "selected" : ""}>What I own, else ETFs</option>
        <option value="etf" ${b.vehicle === "etf" ? "selected" : ""}>Vanguard ETFs</option>
        <option value="fund" ${b.vehicle === "fund" ? "selected" : ""}>Vanguard mutual funds</option></select></div>
    <p class="tiny muted" style="margin:6px 0 4px">${fmt(b.amount)} is ${esc(b.amount_source)}${b.custom_amount ? ` (<a href="#" id="buyReset">use my plan's amount</a>)` : ""}.
      ${b.bought_this_month ? `You've bought ${fmt(b.bought_this_month)} so far this month${b.monthly_plan ? ` of ${fmt(b.monthly_plan)} planned` : ""}.` : ""}
      ${b.mode === "rebalance" ? "New money goes to whatever is furthest below your target mix, so you rebalance without selling." : b.mode === "start" ? "No holdings found yet, so this follows your target mix." : ""}</p>
    <div class="buy-lines">${b.lines.map(line).join("")}</div>
    ${b.skipped.length ? `<div class="tiny muted" style="margin-top:8px">Nothing into ${esc(b.skipped.join(" or ").replace("International", "international").replace("Bonds", "bonds"))} today: you already hold more than your target there.</div>` : ""}
    ${where}
    ${b.vehicle === "fund" ? `<div class="tiny muted" style="margin-top:6px">Vanguard's Admiral mutual funds need $3,000 to open; the ETF versions have no minimum.</div>` : ""}
    <p class="disclaimer">${esc(b.disclaimer)}</p>`;
}

{
  const baseInv = PAGES.investments;
  PAGES.investments = async (main, params) => {
    await baseInv(main, params);
    const card = document.createElement("div");
    card.className = "card buy-card";
    card.style.marginBottom = "16px";
    card.innerHTML = `<h2 style="margin:0">Today's buy plan</h2><div class="tiny muted" style="margin-top:6px">Working it out and fetching the last month of prices…</div>`;
    const anchor = $(".banner", main) || $(".sub", main);
    anchor.after(card);
    const paint = (b) => {
      card.innerHTML = buyPlanHtml(b);
      const save = async (body) => { card.style.opacity = ".6"; try { paint(await run(() => post("/api/investments/buy", body))); } finally { card.style.opacity = ""; } };
      const amt = $("#buyAmt", card);
      amt.onchange = () => { if (+amt.value > 0) save({ amount: +amt.value }); };
      $("#buyVeh", card).onchange = (e) => save({ vehicle: e.target.value });
      const reset = $("#buyReset", card);
      if (reset) reset.onclick = (e) => { e.preventDefault(); save({ reset_amount: true }); };
    };
    growthCard(main);
    try { paint(await api("/api/investments/buy")); }
    catch (e) { card.innerHTML = `<h2 style="margin:0">Today's buy plan</h2><div class="tiny down" style="margin-top:6px">${esc(e.message)}</div>`; }
  };
}

// =====================================================================
// PARTNER COST SHARING (top of the Shared Costs page)
// =====================================================================
async function openPartnerPlaid(itemId = null) {
  const res = await run(() => post("/api/partner/link_token", { item_id: itemId, origin: location.origin }));
  if (res.redirect) localStorage.setItem("plaidPending", JSON.stringify({ token: res.link_token, itemId, partner: true, at: Date.now() }));
  else if (res.redirect_hint) showRedirectHint(res.redirect_hint);
  await run(() => loadScript("https://cdn.plaid.com/link/v2/stable/link-initialize.js"));
  window.Plaid.create({
    token: res.link_token,
    onSuccess: async (public_token, meta) => {
      localStorage.removeItem("plaidPending");
      toast("Connected · reading shared purchases…");
      await run(() => post("/api/partner/exchange", { public_token, institution: meta?.institution?.name, item_id: itemId }), "Card connected");
      await refreshStatus(); route();
    },
    onExit: (err) => { localStorage.removeItem("plaidPending"); if (err) toast(err.display_message || err.error_message || "Plaid Link closed", true); },
  }).open();
}

function partnerForm(d, main) {
  const p = d.partner || {};
  const cats = p.categories || d.default_categories;
  const dlg = $("#dlg");
  dlg.innerHTML = `<h2>${d.partner ? "Edit" : "Split costs with a partner"}</h2>
    <label class="field">Their name<input id="ptName" value="${esc(p.name || "")}" placeholder="e.g. Sam"></label>
    <label class="field" style="margin-top:8px">Your share of shared purchases (%)<input id="ptShare" type="number" min="1" max="99" value="${p.your_share || 50}"></label>
    <div class="tiny muted" style="margin:10px 0 4px">Shared by default (you can switch single purchases on or off later)</div>
    <div class="merge-grid">${d.categories.map((c) => `<label class="merge-chip"><input type="checkbox" value="${esc(c)}" ${cats.includes(c) ? "checked" : ""}> ${esc(c)}</label>`).join("")}</div>
    <label class="field" style="margin-top:10px">Start counting from<input id="ptSince" type="date" value="${esc(p.since || new Date().toISOString().slice(0, 8) + "01")}"></label>
    <label class="field" style="margin-top:8px">Payments between you show up as (optional, comma-separated)
      <input id="ptMatch" value="${esc((p.settle_match || []).join(", "))}" placeholder="e.g. zelle sam, venmo sam"></label>
    <p class="tiny muted">If you fill this in, Zelle/Venmo payments between you are counted against the tab automatically and stop showing up as income or spending.</p>
    <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn secondary" id="ptCancel">Cancel</button><button class="btn" id="ptSave">Save</button></div>`;
  dlg.showModal();
  $("#ptCancel").onclick = () => dlg.close();
  $("#ptSave").onclick = async () => {
    const body = { name: $("#ptName").value, your_share: $("#ptShare").value, since: $("#ptSince").value,
      categories: $$("input[type=checkbox]:checked", dlg).map((i) => i.value),
      settle_match: $("#ptMatch").value.split(",").map((s) => s.trim()).filter(Boolean) };
    await run(() => post("/api/partner", body), "Saved: spending updated");
    dlg.close(); PAGES.roommates(main);
  };
}

function partnerHtml(d) {
  const p = d.partner;
  if (!p) {
    return `<div class="card partner-card"><div class="row"><div class="hero-icon">💞</div>
      <div style="flex:1;min-width:220px"><div class="hero-title">Split everyday costs with your partner</div>
        <div class="tiny muted">For couples who each pay for shared things (groceries, eating out) on their own cards. Your partner connects their card, or you add what they paid by hand. The app keeps a running tab of who owes whom, and your Groceries and Dining show what the food really cost <b>you</b>.</div></div>
      <button class="btn" id="ptSetup">Set up</button></div></div>`;
  }
  const b = d.balance, n = esc(p.name);
  const even = Math.abs(b.balance) < 1;
  const headline = even ? `<span class="pos">You and ${n} are even</span>` : b.balance > 0 ? `${n} owes you <b>${fmt2(b.balance)}</b>` : `You owe ${n} <b>${fmt2(-b.balance)}</b>`;
  const total = b.you_paid + b.they_paid;
  const youPct = total ? b.you_paid / total * 100 : 50;
  const conn = d.connections.map((c) => `<span class="pill ${c.error ? "warnpill" : ""}"><span class="dot" style="background:${c.error ? "var(--critical)" : "var(--good)"}"></span>${esc(c.institution || "Card")} · ${c.error ? "needs sign-in" : "synced " + esc(ago(c.last_sync))}</span>
      ${c.error ? `<button class="btn small" data-ptrelink="${esc(c.item_id)}">Reconnect</button>` : ""}<button class="btn small danger" data-ptunlink="${esc(c.item_id)}">Disconnect</button>`).join(" ");
  return `<div class="card partner-card">
      <div class="row"><div class="hero-icon">💞</div>
        <div style="flex:1;min-width:200px"><div class="hero-title">${headline}</div>
          <div class="tiny muted">Since ${shortDate(p.since)} · you pay ${p.your_share}% of ${esc(p.categories.join(", "))}${b.settled || b.received || b.sent ? " · after settling up" : ""}</div></div>
        ${even ? "" : `<button class="btn small" id="ptSettle" title="Sets the tab back to zero">We settled up</button>`}
        ${d.settlements.length ? `<button class="btn small secondary" id="ptUnsettle" title="Undo the last 'We settled up' (${shortDate(d.settlements.at(-1).date)})">Undo settle</button>` : ""}
        <button class="btn small secondary" id="ptEdit">Edit</button></div>
      <div class="pt-split" title="Who paid for shared things"><div style="width:${youPct}%"></div><i style="left:${p.your_share}%"></i></div>
      <div class="row tiny"><span><b>You paid ${fmt(b.you_paid)}</b></span><span class="spacer"></span><span class="muted">fair split: you ${fmt(b.fair_you)} · ${n} ${fmt(b.fair_them)}</span><span class="spacer"></span><span><b>${n} paid ${fmt(b.they_paid)}</b></span></div>
      <div class="row" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--grid)">
        <span class="tiny muted">${n}'s cards:</span> ${conn || `<span class="tiny muted">none connected</span>`}
        <span class="spacer"></span>
        ${d.plaid_configured ? `<button class="btn small ${d.connections.length ? "secondary" : ""}" id="ptConnect">Connect ${n}'s card</button>` : ""}
        <button class="btn small secondary" id="ptAdd">+ Add something ${n} paid</button></div>
      <div class="tiny muted" style="margin-top:8px">🔒 ${n} signs in to their bank in Plaid's own window, so this app never sees the password. Only ${n}'s purchases in ${esc(p.categories.join(" and "))} are saved; everything else on the card is discarded, and balances are never stored.</div>
    </div>
    ${d.months.length ? `<div class="card" style="margin-top:16px"><h2>Month by month</h2>
      <table><thead><tr><th>Month</th><th class="num">You paid</th><th class="num">${n} paid</th><th class="num">Together</th><th class="num">Your cost</th></tr></thead><tbody>
      ${d.months.map((m) => `<tr><td>${monthLong(m.month)}<div class="tiny muted">${m.cats.map((c) => `${esc(c.category)} ${fmt(c.you + c.them)}`).join(" · ")}</div></td>
        <td class="num">${fmt2(m.you)}</td><td class="num">${fmt2(m.them)}</td><td class="num muted">${fmt2(m.total)}</td><td class="num"><b>${fmt2(m.your_cost)}</b></td></tr>`).join("")}</tbody></table></div>` : ""}
    <div class="card" style="margin-top:16px"><div class="row"><h2 style="margin:0">Shared purchases, last 45 days</h2><span class="spacer"></span><span class="tiny muted">Tap the switch for anything that was just for one of you</span></div>
      ${d.recent.length ? `<table class="t-pt" style="margin-top:8px">${d.recent.map((t) => `<tr class="${t.shared ? "" : "pt-off"}"><td class="tiny" style="white-space:nowrap">${shortDate(t.date)}</td>
        <td class="name">${esc(t.name)}<div class="tiny muted">${esc(t.category)} · ${t.who === "you" ? "you paid" : n + " paid"}${t.pending ? " · pending" : ""}${t.manual ? " · added by hand" : ""}</div></td>
        <td class="num">${fmt2(t.amount)}</td>
        <td class="num" style="white-space:nowrap"><button class="btn small ${t.shared ? "" : "secondary"}" data-pttog="${esc(t.id)}" data-v="${t.shared ? 0 : 1}">${t.shared ? "Shared ✓" : "Not shared"}</button>
          ${t.manual ? `<button class="btn small danger" data-ptdel="${esc(t.id)}" title="Delete this entry">✕</button>` : ""}</td></tr>`).join("")}</table>`
        : `<div class="empty">No shared purchases yet since ${shortDate(p.since)}.</div>`}
      <details style="margin-top:10px"><summary class="tiny">Share something else you paid for (tickets, a trip, a gift…)</summary>
        <div class="row" style="margin:8px 0"><input id="ptQ" placeholder="Search your recent purchases…" style="flex:1;min-width:160px"><button class="btn small secondary" id="ptFind">Search</button></div>
        <div id="ptFound"></div></details>
    </div>
    ${d.payments.length ? `<div class="card" style="margin-top:16px"><h2>Payments between you</h2>
      <table>${d.payments.map((t) => `<tr><td class="tiny" style="white-space:nowrap">${shortDate(t.date)}</td><td class="name">${esc(t.name)}</td>
        <td class="num ${t.amount > 0 ? "pos" : ""}">${t.amount > 0 ? "+" : ""}${fmt2(t.amount).replace("−", "")}</td></tr>`).join("")}</table></div>` : ""}`;
}

{
  const baseRm = PAGES.roommates;
  PAGES.roommates = async (main, params) => {
    const [, d] = await Promise.all([baseRm(main, params), api("/api/partner")]);
    const reload = () => PAGES.roommates(main, params);
    const h1 = $("h1", main), sub = $(".sub", main);
    h1.textContent = "Shared Costs";
    const oldSub = sub.innerHTML;
    sub.textContent = "Costs you share with other people, so your own numbers show only your part.";
    const box = document.createElement("div");
    box.innerHTML = `${partnerHtml(d)}<h2 class="sec-h">Roommates</h2><p class="sub">${oldSub}</p>`;
    sub.after(box);
    const on = (sel, fn) => { const el = $(sel, box); if (el) el.onclick = fn; };
    on("#ptSetup", () => partnerForm(d, main));
    on("#ptEdit", () => {
      partnerForm(d, main);
      const row = $("#ptCancel").parentElement;
      const rm = document.createElement("button");
      rm.className = "btn danger"; rm.textContent = "Stop sharing";
      rm.onclick = async () => {
        if (!confirm(`Stop sharing with ${d.partner.name}? Their card is disconnected, everything saved from it is deleted, and your spending goes back to the full amounts.`)) return;
        await run(() => del("/api/partner"), "Sharing stopped"); $("#dlg").close(); reload();
      };
      row.prepend(rm);
    });
    on("#ptSettle", async () => {
      const b = d.balance.balance;
      if (!confirm(b > 0 ? `Mark that ${d.partner.name} paid you ${fmt2(b)}? The tab goes back to zero.` : `Mark that you paid ${d.partner.name} ${fmt2(-b)}? The tab goes back to zero.`)) return;
      await run(() => post("/api/partner/settle", {}), "Settled up"); reload();
    });
    on("#ptUnsettle", async () => { await run(() => post("/api/partner/settle", { undo: true }), "Undone"); reload(); });
    on("#ptConnect", () => openPartnerPlaid());
    on("#ptAdd", () => {
      const dlg = $("#dlg"), p = d.partner;
      dlg.innerHTML = `<h2>Something ${esc(p.name)} paid for</h2>
        <label class="field">What was it?<input id="pmName" placeholder="e.g. Trader Joe's"></label>
        <div class="grid g2" style="margin-top:8px"><label class="field">Amount ($)<input id="pmAmt" type="number" min="0" step="0.01"></label>
          <label class="field">Date<input id="pmDate" type="date" value="${new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10)}"></label></div>
        <label class="field" style="margin-top:8px">Category<select id="pmCat">${[...new Set([...p.categories, ...d.categories])].map((c) => `<option>${esc(c)}</option>`).join("")}</select></label>
        <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn secondary" id="pmCancel">Cancel</button><button class="btn" id="pmSave">Add</button></div>`;
      dlg.showModal();
      $("#pmCancel").onclick = () => dlg.close();
      $("#pmSave").onclick = async () => {
        await run(() => post("/api/partner/tx", { name: $("#pmName").value, amount: $("#pmAmt").value, date: $("#pmDate").value, category: $("#pmCat").value }), "Added");
        dlg.close(); reload();
      };
    });
    $$("[data-ptrelink]", box).forEach((b) => b.onclick = () => openPartnerPlaid(b.dataset.ptrelink));
    $$("[data-ptunlink]", box).forEach((b) => b.onclick = async () => {
      if (!confirm("Disconnect this card? Purchases saved from it are deleted (entries you added by hand stay).")) return;
      await run(() => del("/api/partner/items/" + encodeURIComponent(b.dataset.ptunlink)), "Disconnected"); reload();
    });
    $$("[data-pttog]", box).forEach((b) => b.onclick = async () => {
      await run(() => post("/api/partner/toggle", { id: b.dataset.pttog, shared: b.dataset.v === "1" })); reload();
    });
    $$("[data-ptdel]", box).forEach((b) => b.onclick = async () => { await run(() => del("/api/partner/tx/" + encodeURIComponent(b.dataset.ptdel)), "Deleted"); reload(); });
    const find = async () => {
      const r = await api("/api/partner/charges?q=" + encodeURIComponent($("#ptQ", box).value.trim()));
      $("#ptFound", box).innerHTML = r.charges.length ? `<table>${r.charges.map((t) => `<tr><td class="tiny" style="white-space:nowrap">${shortDate(t.date)}</td>
        <td class="name">${esc(t.merchant || t.name)}<div class="tiny muted">${esc(t.category)}</div></td><td class="num">${fmt2(-t.amount)}</td>
        <td class="num"><button class="btn small" data-ptshare="${esc(t.id)}">Share it</button></td></tr>`).join("")}</table>` : `<div class="tiny muted">Nothing found.</div>`;
      $$("[data-ptshare]", box).forEach((b) => b.onclick = async () => { await run(() => post("/api/partner/toggle", { id: b.dataset.ptshare, shared: true }), "Shared"); reload(); });
    };
    on("#ptFind", find);
    const q = $("#ptQ", box);
    if (q) q.onkeydown = (e) => { if (e.key === "Enter") find(); };
  };
}


// =====================================================================
// MONEY IN vs. GROWTH (Investments page)
// =====================================================================
const GROWTH = { period: localStorage.getItem("growthPeriod") || "1y", account: "", data: null, geom: null };
const plusMinus = (v) => (v >= 0 ? "+" : "−") + fmt(Math.abs(v));

function growthSvg(pts, W) {
  const H = W < 520 ? 210 : 270, pl = 50, pr = 12, pt = 12, pb = 26;
  const xs = pts.map((p) => new Date(p.date + "T00:00").getTime());
  const all = pts.flatMap((p) => [p.value, p.put_in]);
  let lo = Math.min(...all), hi = Math.max(...all);
  const span = hi - lo || hi || 1;
  lo = lo > span * 1.5 ? lo - span * 0.25 : Math.min(0, lo);  // zoom in when the changes are small next to the balance
  hi += span * 0.08;
  GROWTH.geom = { W, H, pl, pr, pt, pb, lo, hi, xs };
  const x = (i) => pl + ((xs[i] - xs[0]) / (xs.at(-1) - xs[0] || 1)) * (W - pl - pr);
  const y = (v) => pt + (1 - (v - lo) / (hi - lo)) * (H - pt - pb);
  const val = (p) => p.value, put = (p) => p.put_in, base = (p) => Math.min(p.value, p.put_in);
  const line = (f) => pts.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(f(p)).toFixed(1)}`).join("");
  const back = (f) => pts.map((p, i) => `L${x(i).toFixed(1)},${y(f(p)).toFixed(1)}`).reverse().join("");
  const floor = `L${x(pts.length - 1).toFixed(1)},${H - pb}L${x(0).toFixed(1)},${H - pb}Z`;
  const marks = [];
  let lastM = pts[0].date.slice(0, 7);
  pts.forEach((p, i) => { const m = p.date.slice(0, 7); if (m !== lastM) { marks.push(i); lastM = m; } });
  const every = Math.ceil(marks.length / Math.max(2, Math.floor((W - pl - pr) / 62)));
  const label = (i) => { const m = pts[i].date.slice(0, 7); return monthName(m) + (m.endsWith("-01") ? " ’" + m.slice(2, 4) : ""); };
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Money you put in compared with market growth over time">
    ${niceTicks(lo, hi, 4).map((t) => `<line x1="${pl}" x2="${W - pr}" y1="${y(t)}" y2="${y(t)}" stroke="var(--grid)"/><text x="${pl - 8}" y="${y(t) + 4}" text-anchor="end">${compact(t)}</text>`).join("")}
    ${marks.filter((_, i) => i % every === 0).map((i) => `<text x="${x(i).toFixed(1)}" y="${H - 6}" text-anchor="middle">${label(i)}</text>`).join("")}
    <path d="${line(base)}${floor}" fill="var(--series-1)" opacity=".17"/>
    <path d="${line(val)}${back(base)}Z" fill="var(--good)" opacity=".32"/>
    <path d="${line(put)}${back(base)}Z" fill="var(--critical)" opacity=".3"/>
    <path d="${line(put)}" fill="none" stroke="var(--series-1)" stroke-width="1.6" stroke-linejoin="round"/>
    <path d="${line(val)}" fill="none" stroke="var(--text)" stroke-width="2.2" stroke-linejoin="round"/>
    <line class="xh" y1="${pt}" y2="${H - pb}" stroke="var(--muted)" stroke-dasharray="3 3" visibility="hidden"/>
    <circle class="xd-put" r="4" fill="var(--series-1)" stroke="var(--surface)" stroke-width="2" visibility="hidden"/>
    <circle class="xd-val" r="4.5" fill="var(--text)" stroke="var(--surface)" stroke-width="2" visibility="hidden"/>
    <rect x="${pl}" y="0" width="${W - pl - pr}" height="${H}" fill="transparent" class="hit"/></svg>`;
}

function drawGrowth(card) {
  const box = $(".gr-chart", card), d = GROWTH.data;
  if (!box || !d || d.points.length < 2) return;
  const pts = d.points;
  box.innerHTML = growthSvg(pts, Math.max(280, box.clientWidth));
  const svg = $("svg", box), g = GROWTH.geom, xh = $(".xh", svg), dv = $(".xd-val", svg), dp = $(".xd-put", svg), hit = $(".hit", svg);
  const y = (v) => g.pt + (1 - (v - g.lo) / (g.hi - g.lo)) * (g.H - g.pt - g.pb);
  const show = (e) => {
    const r = svg.getBoundingClientRect();
    const sx = ((e.clientX - r.left) / r.width) * g.W;
    const t = g.xs[0] + ((sx - g.pl) / (g.W - g.pl - g.pr)) * (g.xs.at(-1) - g.xs[0]);
    let best = 0;
    g.xs.forEach((v, i) => { if (Math.abs(v - t) < Math.abs(g.xs[best] - t)) best = i; });
    const px = g.pl + ((g.xs[best] - g.xs[0]) / (g.xs.at(-1) - g.xs[0] || 1)) * (g.W - g.pl - g.pr);
    const p = pts[best], gain = p.value - p.put_in;
    xh.setAttribute("x1", px); xh.setAttribute("x2", px); xh.setAttribute("visibility", "visible");
    dv.setAttribute("cx", px); dv.setAttribute("cy", y(p.value)); dv.setAttribute("visibility", "visible");
    dp.setAttribute("cx", px); dp.setAttribute("cy", y(p.put_in)); dp.setAttribute("visibility", "visible");
    tip.innerHTML = `<b>${shortDate(p.date)}, ${p.date.slice(0, 4)}</b><br>Balance ${fmt(p.value)}<br>Your money ${fmt(p.put_in)}<br><span class="${gain >= 0 ? "pos" : "down"}">Growth ${plusMinus(gain)}</span>`;
    tip.hidden = false;
    tip.style.left = Math.max(8, Math.min(e.clientX + 14, innerWidth - tip.offsetWidth - 8)) + "px";
    tip.style.top = e.clientY + 14 + "px";
  };
  const hide = () => { [xh, dv, dp].forEach((el) => el.setAttribute("visibility", "hidden")); tip.hidden = true; };
  hit.addEventListener("pointermove", show);
  hit.addEventListener("pointerdown", show);
  hit.addEventListener("pointerleave", hide);
  hit.addEventListener("pointercancel", hide);
}

function paintGrowth(card, main) {
  const d = GROWTH.data;
  const chips = d.periods.map((p) => `<button class="chip ${p.key === d.period ? "active" : ""}" data-gp="${esc(p.key)}">${esc(p.label)}</button>`).join("");
  const acct = d.accounts.length > 1 ? `<select id="grAcct" class="tiny" title="Which account to show">
      <option value="">All accounts</option>${d.accounts.map((a) => `<option value="${esc(a.id)}" ${a.id === d.account ? "selected" : ""}>${esc(a.name)}</option>`).join("")}</select>` : "";
  const head = `<div class="row"><h2 style="margin:0">Money in vs. growth</h2><span class="spacer"></span>${acct}<div class="gr-chips">${chips}</div></div>`;
  if (d.points.length < 2) {
    card.innerHTML = `${head}<div class="empty" style="margin-top:10px">No balance history to show for this period yet.</div>`;
  } else {
    const up = d.growth >= 0, added = d.net_put_in >= 0;
    const since = `${shortDate(d.start_date)}, ${d.start_date.slice(0, 4)}`;
    const notes = [];
    if (d.reinvested) notes.push(`Growth includes ${fmt(d.reinvested)} of dividends that were reinvested.`);
    if (d.unpriced_count) notes.push(`No price history for ${esc(d.unpriced.join(", "))}${d.unpriced_count > d.unpriced.length ? ` and ${d.unpriced_count - d.unpriced.length} more` : ""} (${100 - d.priced_pct}% of your money), so ${d.unpriced_count === 1 ? "it is" : "they are"} drawn flat.`);
    if (d.assumed_before === "none") notes.push("Your brokerage hasn't reported any buys or sells, so the chart assumes you held today's shares the whole time.");
    else if (d.assumed_before) notes.push(`No buys or sells are on record before ${shortDate(d.assumed_before)}, ${d.assumed_before.slice(0, 4)}, so the chart assumes your shares didn't change before then.`);
    card.innerHTML = `${head}
      <div class="ivs-head">
        <div class="ivs-stat"><span>Balance now</span><b>${fmt(d.end_value)}</b></div>
        <div class="ivs-stat"><span><i style="background:var(--series-1)"></i>Balance on ${esc(since)}</span><b>${fmt(d.start_value)}</b></div>
        <div class="ivs-stat"><span data-tip="What you bought minus what you sold.&lt;br&gt;Reinvested dividends count as growth."><i style="background:var(--series-1)"></i>${added ? "You added since" : "You took out since"}</span><b>${fmt(Math.abs(d.net_put_in))}</b></div>
        <div class="ivs-stat ${up ? "good" : "bad"}"><span><i style="background:var(${up ? "--good" : "--critical"})"></i>Market growth</span><b>${plusMinus(d.growth)}${d.growth_pct != null ? ` <small>${d.growth_pct >= 0 ? "+" : "−"}${Math.abs(d.growth_pct).toFixed(1)}%</small>` : ""}</b></div>
      </div>
      <div class="chart gr-chart"></div>
      <p class="tiny" style="margin:8px 0 0">The blue area is your own money: what was there on ${esc(since)} plus what you've ${added ? "added" : "added, minus what you took out,"} since. The ${up ? "green" : "red"} band on top is what the market ${up ? "added" : "took away"}.</p>
      ${d.movers.length ? `<div class="gr-movers"><span class="tiny muted">What moved it:</span>${d.movers.map((m) => `<span class="mv" data-tip="${esc(esc(m.name))}">${esc(m.label)} <b class="${m.gain >= 0 ? "pos" : "down"}">${plusMinus(m.gain)}</b></span>`).join("")}</div>` : ""}
      <p class="disclaimer">Rebuilt from the shares you hold today, the buys and sells your brokerage reports (up to two years back) and daily closing prices from Yahoo Finance, so it can differ a little from your brokerage's own figures. Selling counts as taking money out, even if the cash stays in the account. ${notes.join(" ")} Past growth says nothing about future growth.</p>`;
    drawGrowth(card);
  }
  $$("[data-gp]", card).forEach((b) => b.onclick = () => { GROWTH.period = b.dataset.gp; localStorage.setItem("growthPeriod", GROWTH.period); growthCard(main); });
  const sel = $("#grAcct", card);
  if (sel) sel.onchange = () => { GROWTH.account = sel.value; growthCard(main); };
}

async function growthCard(main) {
  const stats = $(".grid.g3", main);
  if (!stats) return;  // no holdings yet
  let card = $("#growthCard", main);
  if (!card) {
    card = document.createElement("div");
    card.className = "card"; card.id = "growthCard"; card.style.marginTop = "16px";
    card.innerHTML = `<h2 style="margin:0">Money in vs. growth</h2><div class="tiny muted" style="margin-top:6px">Rebuilding your balance history from your holdings and past prices…</div>`;
    stats.after(card);
  } else card.style.opacity = ".6";
  try {
    GROWTH.data = await api(`/api/investments/performance?period=${encodeURIComponent(GROWTH.period)}&account=${encodeURIComponent(GROWTH.account)}`);
    if (card.isConnected) paintGrowth(card, main);
  } catch (e) {
    card.innerHTML = `<h2 style="margin:0">Money in vs. growth</h2><div class="tiny down" style="margin-top:6px">${esc(e.message)}</div>`;
  } finally { card.style.opacity = ""; }
}
window.addEventListener("resize", () => {
  clearTimeout(GROWTH.resizeT);
  GROWTH.resizeT = setTimeout(() => { const card = $("#growthCard"); if (card) drawGrowth(card); }, 160);
});
