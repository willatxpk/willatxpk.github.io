// Kerdos: Debt. What you owe on cards and loans, and what each credit card is being used for.
"use strict";

const DEBT = { period: "this", data: null };
const CARD_COLORS = ["var(--series-1)", "var(--series-2)", "var(--series-3)", "var(--series-4)", "var(--series-5)", "var(--series-7)"];
const cardColor = (i) => CARD_COLORS[i % CARD_COLORS.length];
const cardLabel = (c) => esc(c.name) + (c.mask ? ` <span class="muted">··${esc(c.mask)}</span>` : "");
const pctText = (v) => (v == null ? "—" : (Math.round(v * 10) / 10) + "%");

function debtBars(d, W) {
  // Charged to each card per month, stacked. The total sits on top of each bar.
  const H = 240, pl = 46, pr = 8, pt = 22, pb = 28, n = d.months.length;
  const tot = d.months.map((_, i) => d.cards.reduce((s, c) => s + Math.max(0, c.months[i].spent), 0));
  const hi = Math.max(1, ...tot) * 1.08;
  const y = (v) => pt + (1 - v / hi) * (H - pt - pb);
  const slot = (W - pl - pr) / n, bw = Math.min(64, slot * 0.56);
  const bars = d.months.map((m, i) => {
    const x = pl + slot * i + (slot - bw) / 2;
    let acc = 0;
    const segs = d.cards.map((c, k) => {
      const v = Math.max(0, c.months[i].spent);
      if (v <= 0) return "";
      const y1 = y(acc + v), h = y(acc) - y1;
      acc += v;
      return `<rect x="${x.toFixed(1)}" y="${y1.toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(0.5, h - 1).toFixed(1)}" rx="2" fill="${cardColor(k)}"/>`;
    }).join("");
    const tipHtml = `<b>${esc(monthLong(m))}</b><br>` + d.cards.map((c, k) => `<span class="legend" style="display:inline;margin:0"><i style="background:${cardColor(k)}"></i></span>${esc(c.name)}: ${fmt(c.months[i].spent)}`).join("<br>") + `<br><b>Total ${fmt(tot[i])}</b>`;
    return `<g class="ivs-month ${i === n - 1 ? "partial" : ""}" data-tip="${esc(tipHtml)}"><rect class="ivs-hover" x="${(pl + slot * i).toFixed(1)}" y="${pt - 14}" width="${slot.toFixed(1)}" height="${H - pt - pb + 14}" rx="6"/>
      ${segs}<text x="${(x + bw / 2).toFixed(1)}" y="${(y(tot[i]) - 6).toFixed(1)}" text-anchor="middle" class="debt-top">${tot[i] ? compact(tot[i]) : ""}</text>
      <text class="ivs-x" x="${(x + bw / 2).toFixed(1)}" y="${H - 8}" text-anchor="middle">${monthName(m)}${i === n - 1 ? "*" : ""}</text></g>`;
  }).join("");
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Amount charged to each card per month">
    ${niceTicks(0, hi, 4).map((t) => `<line x1="${pl}" x2="${W - pr}" y1="${y(t)}" y2="${y(t)}" stroke="var(--grid)"/><text x="${pl - 8}" y="${y(t) + 4}" text-anchor="end">${compact(t)}</text>`).join("")}${bars}</svg>`;
}

function debtCard(c, i) {
  const u = c.utilization, uColor = u == null ? "var(--neutral)" : u < 30 ? "var(--good)" : u < 50 ? "var(--warning)" : "var(--critical)";
  const top = c.top_categories, max = Math.max(1, ...top.map((t) => t.amount));
  const diff = c.this_month - c.avg3;
  const kv = [
    ["Charged this month", `${fmt(c.this_month)} <span class="muted">· ${c.purchases_this_month} purchase${c.purchases_this_month === 1 ? "" : "s"}</span>`],
    ["Last month", fmt(c.last_month)],
    ["3-month average", fmt(c.avg3)],
    c.statement != null ? ["Last statement", fmt2(c.statement)] : null,
    c.minimum_payment != null ? ["Minimum payment", fmt2(c.minimum_payment)] : null,
    c.due ? ["Next due", `${shortDate(c.due)} <span class="muted">· ${whenLabel(c.due)}</span>`] : null,
    c.apr != null ? ["Purchase APR", pctText(c.apr)] : null,
    ["Interest & fees this year", `<span class="${c.interest_ytd > 0 ? "down" : ""}">${fmt2(c.interest_ytd)}</span>`],
  ].filter(Boolean);
  return `<div class="card debt-card" style="--card-c:${cardColor(i)}">
    <div class="row"><i class="debt-chip"></i><h2 style="margin:0">${cardLabel(c)}</h2><span class="spacer"></span>
      ${c.carrying ? `<span class="pill" title="Interest was charged in the last three months"><span style="color:var(--warning)">●</span>Carrying a balance</span>` : ""}</div>
    <div class="tiny muted">${esc(c.institution || "")}</div>
    <div class="debt-balance"><b>${fmt2(c.balance)}</b><span class="muted">${c.limit ? `of ${fmt(c.limit)} limit${c.limit_from === "estimated" ? " (estimated)" : ""}` : "owed"}</span>
      <a href="#" class="tiny" data-limit="${esc(c.id)}" data-name="${esc(c.name)}" data-cur="${c.limit_from === "you" ? c.limit : ""}">${c.limit ? "change limit" : "set credit limit"}</a></div>
    ${c.limit ? `<div class="pbar"><div class="fill" style="width:${Math.max(0, Math.min(100, u))}%;background:${uColor}"></div></div>
      <div class="tiny muted" style="margin-top:3px">${pctText(u)} of the limit used · ${fmt(Math.max(0, c.limit - c.balance))} available</div>` : ""}
    <div class="kv" style="margin-top:12px">${kv.map(([k, v]) => `<div>${k}</div><div class="num">${v}</div>`).join("")}</div>
    ${c.avg3 > 0 && c.this_month > 0 ? `<div class="tiny muted" style="margin-top:6px">So far this month is ${fmt(Math.abs(diff))} ${diff >= 0 ? "above" : "below"} a typical full month on this card.</div>` : ""}
    ${top.length ? `<h3 style="margin-top:14px">This month on this card</h3><div class="bar-list">${top.map((t) => `<div class="item"><span>${esc(t.name)}</span>
        <div class="track"><div class="fill" style="width:${(t.amount / max * 100).toFixed(1)}%;background:var(--card-c)"></div></div><span class="num">${fmt(t.amount)}</span></div>`).join("")}</div>
      ${c.top_merchants.length ? `<div class="tiny muted" style="margin-top:6px">Biggest: ${c.top_merchants.map((m) => `${esc(m.name)} ${fmt(m.amount)}`).join(" · ")}</div>` : ""}`
    : `<div class="tiny muted" style="margin-top:12px">Nothing charged to this card yet this month.</div>`}
    ${c.interest_per_month && c.balance > 0 ? `<div class="tiny muted" style="margin-top:8px">${c.carrying ? "At this balance, interest runs" : "If this balance were carried past the due date, interest would run"} about ${fmt2(c.interest_per_month)} a month at ${pctText(c.apr)} APR.</div>` : ""}
  </div>`;
}

function debtCategoryTable(d) {
  const rows = d.by_category[DEBT.period] || [];
  const chips = d.periods.map((p) => `<button class="chip ${p.key === DEBT.period ? "active" : ""}" data-period="${p.key}">${esc(p.label)}</button>`).join("");
  const head = `<div class="row"><h2 style="margin:0">Where card spending goes</h2><span class="spacer"></span><div class="gr-chips">${chips}</div></div>`;
  if (!rows.length) return `${head}<div class="empty" style="margin-top:10px">No card purchases in this period.</div>`;
  const colTot = d.cards.map((c) => rows.reduce((s, r) => s + (r.cards[c.id] || 0), 0));
  const all = colTot.reduce((s, v) => s + v, 0);
  return `${head}<div class="debt-scroll"><table class="t-debt" style="margin-top:8px"><thead><tr><th>Category</th>
      ${d.cards.map((c, i) => `<th class="num"><i class="cal-dot" style="background:${cardColor(i)}"></i> ${esc(c.name)}</th>`).join("")}<th class="num">All cards</th></tr></thead>
    <tbody>${rows.map((r) => `<tr><td>${esc(r.name)}</td>${d.cards.map((c) => `<td class="num ${r.cards[c.id] ? "" : "muted"}">${r.cards[c.id] ? fmt(r.cards[c.id]) : "—"}</td>`).join("")}<td class="num"><b>${fmt(r.total)}</b></td></tr>`).join("")}
      <tr class="debt-total"><td>Total</td>${colTot.map((v) => `<td class="num">${fmt(v)}</td>`).join("")}<td class="num"><b>${fmt(all)}</b></td></tr></tbody></table></div>
    <div class="tiny muted" style="margin-top:6px">Purchases minus refunds. Payments to the card, interest and fees are not counted here.</div>`;
}

PAGES.debt = async (main) => {
  const d = DEBT.data = await api("/api/debt");
  if (!d.cards.length && !d.loans.length) {
    main.innerHTML = `<h1>Credit</h1><p class="sub">What you owe, and what your credit cards are being used for.</p>
      <div class="card empty">No credit cards or loans here yet. Connect one on the <a href="#accounts">Accounts</a> page.</div>`;
    return;
  }
  const t = d.totals, uColor = t.utilization == null ? "" : t.utilization < 30 ? "pos" : t.utilization < 50 ? "" : "down";
  const diff = t.this_month - t.last_month;
  main.innerHTML = `
    <h1>Credit</h1><p class="sub">What you owe on cards and loans, and what each credit card is being used for.</p>
    <div class="grid g4">
      <div class="card stat" style="--stat-c:var(--critical)"><div class="label">Total owed</div><div class="value">${fmt(t.debt)}</div>
        <div class="delta">${fmt(t.card_balance)} on cards${t.loan_balance ? ` · ${fmt(t.loan_balance)} in loans` : ""}</div></div>
      <div class="card stat"><div class="label">Credit used</div><div class="value ${uColor}">${t.utilization == null ? "—" : pctText(t.utilization)}</div>
        <div class="delta">${t.limit ? `${fmt(t.card_balance)} of ${fmt(t.limit)} in limits` : "set a credit limit on a card below"}</div></div>
      <div class="card stat" style="--stat-c:var(--series-4)"><div class="label">Charged to cards this month</div><div class="value">${fmt(t.this_month)}</div>
        <div class="delta">last month ${fmt(t.last_month)} · typical ${fmt(t.avg3)}</div></div>
      <div class="card stat" style="--stat-c:var(--neutral)"><div class="label">Interest &amp; fees this year</div><div class="value ${t.interest_ytd > 0 ? "down" : ""}">${fmt(t.interest_ytd)}</div>
        <div class="delta">${t.minimums ? `${fmt(t.minimums)} in minimum payments due` : "charged to your cards"}</div></div>
    </div>
    ${d.cards.length ? `<div class="card" style="margin-top:16px"><div class="row"><h2 style="margin:0">Charged to each card</h2><span class="spacer"></span>
        <div class="legend" style="margin:0;flex-wrap:wrap">${d.cards.map((c, i) => `<span><i style="background:${cardColor(i)}"></i>${esc(c.name)}</span>`).join("")}</div></div>
      <div class="chart" id="debtChart" style="margin-top:8px"></div><div class="tiny muted">* this month so far</div></div>
    <div class="debt-grid">${d.cards.map(debtCard).join("")}</div>
    <div class="card" style="margin-top:16px" id="debtCats">${debtCategoryTable(d)}</div>
    <div class="card" style="margin-top:16px" id="debtRewards"><h2 style="margin:0">Card rewards</h2><div class="tiny muted" style="margin-top:6px">Working out what your cards earn…</div></div>` : ""}
    ${d.loans.length ? `<div class="card" style="margin-top:16px"><h2>Loans</h2><div class="debt-scroll"><table class="t-debt"><thead><tr><th>Loan</th><th class="num">Balance</th><th class="num">APR</th><th class="num">Minimum</th><th class="num">Next due</th><th class="num">Interest / month</th></tr></thead>
      <tbody>${d.loans.map((l) => `<tr><td class="name">${cardLabel(l)}<div class="tiny muted">${esc([l.institution, l.kind].filter(Boolean).join(" · "))}</div></td><td class="num">${fmt2(l.balance)}</td><td class="num">${pctText(l.apr)}</td>
        <td class="num">${l.minimum_payment != null ? fmt2(l.minimum_payment) : "—"}</td><td class="num">${l.due ? shortDate(l.due) : "—"}</td><td class="num">${l.interest_per_month ? "≈ " + fmt2(l.interest_per_month) : "—"}</td></tr>`).join("")}</tbody></table></div>
      <div class="tiny muted" style="margin-top:6px">Interest per month is the balance times the APR divided by twelve: a rough guide, not your lender's exact figure.</div></div>` : ""}
    <p class="disclaimer">Balances, limits, APRs and due dates come from your banks when they report them. Credit used is your balance compared with your limits, the figure lenders call utilization.</p>`;
  if ($("#debtRewards", main)) rewardsLoad($("#debtRewards", main), d);
  const draw = () => { const box = $("#debtChart", main); if (box) box.innerHTML = debtBars(d, Math.max(280, box.clientWidth)); };
  draw();
  DEBT.redraw = draw;
  const wireCats = () => $$("[data-period]", main).forEach((b) => b.onclick = () => { DEBT.period = b.dataset.period; $("#debtCats").innerHTML = debtCategoryTable(d); wireCats(); });
  wireCats();
  $$("[data-limit]", main).forEach((a) => a.onclick = async (e) => {
    e.preventDefault();
    const v = prompt(`Credit limit for ${a.dataset.name}, in dollars.\nLeave it empty to go back to what your bank reports.`, a.dataset.cur || "");
    if (v === null) return;
    await run(() => post("/api/debt/limit", { account_id: a.dataset.limit, limit: v.replace(/[$,\s]/g, "") }), "Saved");
    PAGES.debt(main);
  });
};
window.addEventListener("resize", () => { clearTimeout(DEBT.rt); DEBT.rt = setTimeout(() => { if ($("#debtChart") && DEBT.redraw) DEBT.redraw(); }, 160); });


// ---------------------------------------------------------------- card rewards: what you earn, and the best card for each kind of purchase
// Terms come from the app's own list of well-known cards, matched to the name the bank reports. Anything
// not on the list can be typed in by hand.
const REWARDS = { data: null, editing: null, picking: null };
const rwPct = (v) => (Math.round(v * 100) / 100).toString() + "%";
const rwDay = (iso) => new Date(iso + "T00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" });
const rwFull = (iso) => new Date(iso + "T00:00").toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });

function rewardsForm(c, r) {
  const bonus = Object.entries(c.mode === "manual" ? c.bonus || {} : {});
  const opts = (sel) => `<optgroup label="Kinds of purchase">${r.kinds.map((k) => `<option value="${esc(k.key)}" ${k.key === sel ? "selected" : ""}>${esc(k.label)}</option>`).join("")}</optgroup>
      <optgroup label="Your categories">${r.categories.map((k) => `<option value="${esc(k)}" ${k === sel ? "selected" : ""}>${esc(k)}</option>`).join("")}</optgroup>`;
  const row = (cat, rate) => `<div class="rw-bonus"><select data-rw-cat>${opts(cat)}</select>
      <span class="rw-x"><input type="number" data-rw-rate min="0" max="50" step="0.5" value="${rate}"> per $1</span><button class="btn small secondary" data-rw-del title="Remove this line">✕</button></div>`;
  const manual = c.mode === "manual";
  return `<div class="rw-form" data-rw-form="${esc(c.id)}">
    <div class="tiny"><a href="#" data-rw-tolist>Pick this card from the app's list instead</a></div>
    <div class="tiny muted" style="margin-top:6px">Copy these from your card's rewards page. A cash-back card that pays 1.5% is 1.5 per $1 with each point worth 1¢. A points card that pays 3 points per $1 with points worth about 1.25¢ is 3 and 1.25.</div>
    <div class="rw-fields">
      <label class="field">Earns on everything<span class="rw-x"><input type="number" data-rw="base" min="0" max="50" step="0.25" value="${manual ? c.base : 1}"> per $1</span></label>
      <label class="field">Each point is worth<span class="rw-x"><input type="number" data-rw="point_value" min="0" max="20" step="0.05" value="${manual ? c.point_value : 1}"> ¢</span></label>
      <label class="field">Annual fee<span class="rw-x">$ <input type="number" data-rw="fee" min="0" step="5" value="${manual ? c.fee : 0}"></span></label>
    </div>
    <div class="tiny muted" style="margin-top:10px">Purchases that earn more (or less) than that</div>
    <div class="rw-bonuses">${bonus.map(([k, v]) => row(k, v)).join("")}</div>
    <div class="row" style="margin-top:8px;gap:8px"><button class="btn small secondary" data-rw-add>+ Add a line</button><span class="spacer"></span>
      <button class="btn small secondary" data-rw-cancel>Cancel</button><button class="btn small" data-rw-save>Save</button></div>
    <template data-rw-row>${row("kind:dining", "")}</template></div>`;
}

// "Which card is this?": the list, with cards from the same bank first
function rewardsPicker(c, r) {
  const likely = (c.suggest || []).map((id) => r.catalog.find((k) => k.id === id)).filter(Boolean);
  const issuers = [...new Set(r.catalog.map((k) => k.issuer))];
  const opt = (k) => `<option value="${esc(k.id)}" ${c.card && c.card.id === k.id ? "selected" : ""}>${esc(k.name)}</option>`;
  const why = c.off ? "Set as a card with no rewards." : c.setup ? "" : likely.length
    ? "Your bank's name for this account doesn't say exactly which card it is. Pick it once and the app fills in what it earns."
    : "The app couldn't tell which card this is from the name your bank reports. Pick it once and the app fills in what it earns.";
  return `<div class="rw-pick" data-rw-pick="${esc(c.id)}">
    ${why ? `<div class="tiny muted">${why}</div>` : ""}
    <select data-rw-card><option value="">Choose your card…</option>
      ${likely.length ? `<optgroup label="Most likely">${likely.map(opt).join("")}</optgroup>` : ""}
      ${issuers.map((i) => `<optgroup label="${esc(i)}">${r.catalog.filter((k) => k.issuer === i).map(opt).join("")}</optgroup>`).join("")}</select>
    <div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap"><button class="btn small" data-rw-use>Use this card</button>
      ${c.setup || c.off ? `<button class="btn small secondary" data-rw-cancel>Cancel</button>` : ""}</div>
    <div class="tiny" style="margin-top:8px">Not on the list? <a href="#" data-rw-manual>Type its rates in by hand</a>${c.off ? "" : ` · <a href="#" data-rw-off>It has no rewards</a>`}${c.matched === "picked" || c.mode === "manual" || c.off ? ` · <a href="#" data-rw-auto>Recognise it from its name again</a>` : ""}</div></div>`;
}

function rewardsCatalogCard(c, r) {
  const k = c.card, q = k.quarter, ch = k.choice;
  const quarter = !q ? "" : q.known
    ? `<li class="rw-q"${q.detail ? ` title="${esc(q.detail)}"` : ""}><b>${esc(q.rate)}</b> until ${rwDay(q.end)}: ${esc(q.label)}${q.cap ? ` <span class="muted">(${esc(q.cap)})</span>` : ""}.${q.activation ? ` <span class="muted">Has to be activated each quarter.</span>` : ""}
        ${q.counted && q.counted.toLowerCase() !== (q.label || "").toLowerCase() ? `<div class="tiny muted">The app can spot these in your purchases: ${esc(q.counted)}.</div>` : !q.counted ? `<div class="tiny muted">The app can't spot these in your purchases, so they count at the everyday rate here.</div>` : ""}</li>`
    : `<li class="rw-q warn">This quarter's ${esc(q.rate)} categories aren't in the app's card list yet, so they count at the everyday rate for now.</li>`;
  const next = k.next ? `<li class="muted">From ${rwDay(k.next.start)}: ${esc(k.next.rate)} on ${esc(k.next.label)}.</li>` : "";
  const picks = ch ? ch.picks.map((p) => (ch.options.find((o) => o.kind === p) || {}).label).filter(Boolean) : [];
  const choice = !ch ? "" : ch.auto
    ? `<li><b>${esc(ch.rate)}</b> on whatever you spend most on${ch.cap ? ` <span class="muted">(${esc(ch.cap)})</span>` : ""}: for your spending that is <b>${esc(picks.join(" and ") || "nothing yet")}</b>.</li>`
    : `<li><b>${esc(ch.rate)}</b> on ${ch.count > 1 ? `${ch.count} categories` : "a category"} you choose${ch.cap ? ` <span class="muted">(${esc(ch.cap)})</span>` : ""}:
        <span class="rw-choice">${Array.from({ length: ch.count }, (_, i) => `<select data-rw-choice aria-label="Chosen category ${i + 1}">${ch.options.map((o) => `<option value="${esc(o.kind)}" ${ch.picks[i] === o.kind ? "selected" : ""}>${esc(o.label)}</option>`).join("")}</select>`).join("")}</span>
        ${ch.assumed ? `<div class="tiny warn-text">The app assumed your highest-spending ${ch.count > 1 ? "ones" : "one"}. Set what you actually picked with your bank.</div>` : ""}</li>`;
  const points = k.unit !== "cash" ? `<div class="rw-pv tiny">Each ${k.unit === "miles" ? "mile" : "point"} counted as <input type="number" data-rw-pv min="0.1" max="20" step="0.05" value="${c.point_value}"> ¢
      ${Math.abs(c.point_value - k.point_default) > 1e-9 ? `<a href="#" data-rw-pv-reset>use ${k.point_default}¢</a>` : ""}<div class="muted">${esc(k.point_note)}</div></div>` : "";
  return `<div class="rw-is" data-rw-cat-card="${esc(c.id)}">${k.name.toLowerCase() === c.name.toLowerCase() ? `<span class="tiny muted">Recognised from the name your bank reports</span>` : `<b>${esc(k.name)}</b><span class="tiny muted"> · ${c.matched === "auto" ? "recognised from the name your bank reports" : "the card you picked"}</span>`}</div>
    <ul class="rw-earn">${quarter}${next}${choice}${k.lines.map((l) => `<li>${esc(l)}</li>`).join("")}<li>${esc(k.base_text)}</li>${c.fee ? `<li>${fmt(c.fee)} annual fee</li>` : ""}</ul>${points}`;
}

function rewardsHtml(r, d) {
  const t = r.totals, color = (id) => cardColor(Math.max(0, d.cards.findIndex((c) => c.id === id)));
  const name = (id) => esc((r.cards.find((c) => c.id === id) || {}).name || "");
  const dot = (id) => `<i class="cal-dot" style="background:${color(id)}"></i>`;
  const owing = (id) => { const c = d.cards.find((x) => x.id === id); return c && c.carrying ? c : null; };   // interest is being charged on it
  const body = (c) => {
    if (REWARDS.editing === c.id) return rewardsForm(c, r);
    if (REWARDS.picking === c.id || (!c.setup && !c.off)) return rewardsPicker(c, r);
    if (c.off) return `<div class="tiny muted">Set as a card with no rewards, so purchases on it earn nothing.</div>`;
    const terms = c.mode === "catalog" ? rewardsCatalogCard(c, r)
      : `<div class="tiny muted">${c.base} per $1 on everything${Object.entries(c.bonus).map(([k, v]) => `, ${v} on ${esc(k.startsWith("kind:") ? (r.kinds.find((x) => x.key === k) || {}).label || k : k)}`).join("")} · each point worth ${c.point_value}¢${c.fee ? ` · ${fmt(c.fee)} a year` : ""} <span class="muted">(typed in by you)</span></div>`;
    const notes = c.mode === "catalog" && (c.card.notes.length || c.card.source) ? `<details class="rw-notes"><summary>Good to know about this card</summary>
        ${c.card.notes.length ? `<ul>${c.card.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>` : ""}
        <div class="tiny muted">${c.card.confidence === "high" ? "From the issuer's page" : c.card.confidence === "low" ? "Parts of this couldn't be confirmed; check against your card's own page" : "From published summaries of the issuer's terms"}${r.catalog_checked ? `, checked ${rwFull(r.catalog_checked)}` : ""}.${c.card.source ? ` <a href="${esc(c.card.source)}" target="_blank" rel="noopener noreferrer">Source</a>` : ""}</div></details>` : "";
    return `${terms}
        <div class="kv" style="margin-top:8px"><div>Earning now</div><div class="num">${fmt(c.earned_year)} a year <span class="muted">(${rwPct(c.rate_now)} back)</span></div>
          ${c.fee ? `<div>After the ${fmt(c.fee)} fee</div><div class="num ${c.net_year < 0 ? "down" : ""}">${c.net_year < 0 ? "−" : ""}${fmt(Math.abs(c.net_year))} a year</div>
          <div title="If every kind of purchase went on the card that pays most for it, this is how much more this card would earn than your next-best card on the purchases it wins.">What it adds over your other cards</div><div class="num">${fmt(c.edge_year)} a year</div>` : ""}</div>
        ${owing(c.id) && owing(c.id).interest_per_month ? `<div class="tiny down" style="margin-top:4px">Carrying a balance: interest runs about ${fmt2(owing(c.id).interest_per_month)} a month, against about ${fmt2(c.earned_year / 12)} a month in rewards.</div>` : ""}
        ${c.fee && r.ready > 1 ? `<div class="tiny muted" style="margin-top:4px">${c.edge_year >= c.fee ? `Used for the purchases it wins, it earns ${fmt(c.edge_year - c.fee)} a year more than its fee.` : `Even used for the purchases it wins, it adds ${fmt(c.fee - c.edge_year)} a year less than its fee costs. Perks the app can't see, such as travel credits or lounge access, may change that.`}</div>` : ""}${notes}`;
  };
  const cardsHtml = `<div class="rw-cards">${r.cards.map((c) => `<div class="rw-card" style="--card-c:${color(c.id)}">
      <div class="row"><b>${esc(c.name)}</b>${c.mask ? `<span class="tiny muted">··${esc(c.mask)}</span>` : ""}<span class="spacer"></span>${REWARDS.editing === c.id || REWARDS.picking === c.id || (!c.setup && !c.off) ? "" : `<a href="#" class="tiny" data-rw-change="${esc(c.id)}">${c.mode === "manual" ? "edit" : c.off ? "change" : "not this card?"}</a>`}</div>
      ${body(c)}</div>`).join("")}</div>`;
  if (!r.ready) return `<h2 style="margin:0">Card rewards</h2>
    <p class="tiny" style="margin:6px 0 10px">The app knows what ${r.catalog.length} well-known cards earn, including rotating categories, and recognises a card from the name your bank reports. Yours didn't match by name, so pick each one below. After that it shows how much your spending earns now and which card pays the most for each kind of purchase.</p>${cardsHtml}`;
  const moves = r.guide.filter((g) => (g.change || (g.next && g.next.card !== g.mostly)) && g.gain_year >= 1).sort((a, b) => b.gain_year - a.gain_year);
  const owed = [...new Set(moves.filter((g) => g.change && owing(g.card)).map((g) => g.card_name))];
  const later = (g) => g.next ? `from ${rwDay(g.next.start)} ${dot(g.next.card)} <b>${esc(g.next.card_name)}</b> pays ${rwPct(g.next.rate)}` : "";
  const missing = r.cards.filter((c) => !c.setup && !c.off).length;
  return `<div class="row"><h2 style="margin:0">Card rewards</h2><span class="spacer"></span><span class="tiny muted">based on ${r.months.map((m) => monthName(m)).join(", ")}</span></div>
    <div class="ivs-head" style="margin-top:12px">
      <div class="ivs-stat"><span>Earning now</span><b>${fmt(t.now_year)}<small> a year</small></b></div>
      <div class="ivs-stat"><span>Best card for everything</span><b>${fmt(t.possible_year)}<small> a year</small></b></div>
      <div class="ivs-stat ${t.gain_year >= 1 ? "good" : ""}"><span>Left on the table</span><b>${t.gain_year >= 1 ? "+" + fmt(t.gain_year) : fmt(0)}<small> a year</small></b></div>
      <div class="ivs-stat"><span>Back per dollar</span><b>${rwPct(t.now_rate)}<small> now · ${rwPct(t.possible_rate)} possible</small></b></div>
    </div>
    ${moves.length ? `<h3 style="margin-top:14px">Switches that would earn more</h3>${owed.length ? `<div class="tiny down rw-warn">${owed.map((n) => `<b>${esc(n)}</b>`).join(" and ")} ${owed.length === 1 ? "is" : "are"} carrying a balance, so new purchases there are charged interest from the day you make them. That costs more than the extra rewards until the balance is paid off.</div>` : ""}<div class="rw-moves">${moves.map((g) => `<div class="rw-move"><b>${esc(g.category)}</b>
        <span class="tiny">mostly on ${dot(g.mostly)} ${esc(g.from_name)}${g.change ? ` → ${dot(g.card)} <b>${esc(g.card_name)}</b> pays ${rwPct(g.rate)} back${g.rotating ? ` until ${rwDay(r.quarter.end)}` : ""}${g.next ? `, then ${later(g)}` : ""}` : `, which pays the most until ${rwDay(r.quarter.end)} (${rwPct(g.rate)}). Then ${later(g)}`}${g.why ? `<br><span class="muted">${esc(g.why)}</span>` : ""}${g.change && owing(g.card) ? ` <span class="down">(carrying a balance)</span>` : ""}</span><b class="pos">+${fmt(g.gain_year)}/yr</b></div>`).join("")}</div>`
      : `<div class="tiny pos" style="margin-top:10px"><b>Everything is already going on a card that pays the most for it.</b></div>`}
    <h3 style="margin-top:14px">Which card for what <span class="tiny muted" style="font-weight:400">right now, until ${rwDay(r.quarter.end)}</span></h3>
    <div class="debt-scroll"><table class="t-debt"><thead><tr><th>Kind of purchase</th><th class="num">You spend</th><th>Mostly on</th><th class="num">Earning</th><th>Best card</th><th class="num">Would earn</th><th class="num">Extra / year</th></tr></thead><tbody>
      ${r.rows.map((x) => `<tr><td>${esc(x.category)}</td><td class="num">${fmt(x.monthly)}<span class="muted">/mo</span></td><td>${dot(x.mostly)} ${name(x.mostly)}</td><td class="num">${rwPct(x.now_rate)}</td>
        <td>${x.best ? `${dot(x.best)} ${x.best === x.mostly ? `<span class="muted">same</span>` : `<b>${name(x.best)}</b>`}${x.rotating ? ` <span class="rw-tag" title="${esc(x.why)}">rotating</span>` : x.capped ? ` <span class="rw-tag" title="${esc(x.why)}">capped</span>` : ""}${x.next ? `<div class="tiny muted rw-later">${later(x)}</div>` : ""}` : "—"}</td><td class="num">${rwPct(x.best_rate)}</td><td class="num ${x.gain_year >= 1 ? "pos" : "muted"}">${x.gain_year >= 1 ? "+" + fmt(x.gain_year) : "—"}</td></tr>`).join("")}
      <tr class="debt-total"><td>All card spending</td><td class="num">${fmt(t.spend_year / 12)}<span class="muted">/mo</span></td><td></td><td class="num">${rwPct(t.now_rate)}</td><td></td><td class="num">${rwPct(t.possible_rate)}</td><td class="num">${t.gain_year >= 1 ? "+" + fmt(t.gain_year) : "—"}</td></tr></tbody></table></div>
    ${r.bank.monthly >= 20 && r.bank.possible_year >= 1 ? `<div class="tiny" style="margin-top:10px">About <b>${fmt(r.bank.monthly)} a month</b> of everyday spending (${r.bank.rows.slice(0, 3).map((b) => esc(b.category)).join(", ")}) is paid straight from your bank account and earns nothing. On the best card for each, that would be about <b>${fmt(r.bank.possible_year)} a year</b> in rewards.</div>` : ""}
    <h3 style="margin-top:14px">Your cards</h3>${cardsHtml}
    ${missing ? `<div class="tiny muted" style="margin-top:8px">${missing} card${missing === 1 ? " isn't" : "s aren't"} set up yet, so ${r.left_out >= 1 ? `the ${fmt(r.left_out)} a month spent on ${missing === 1 ? "it is" : "them is"}` : `${missing === 1 ? "it is" : "they are"}`} left out of everything above.</div>` : ""}
    <p class="disclaimer" style="margin-bottom:0">Card terms come from the app's own list of ${r.catalog.length} well-known cards${r.catalog_checked ? `, checked against the issuers' pages and published summaries on ${rwFull(r.catalog_checked)}` : ""}. Issuers change them, so treat your card's own rewards page as the final word. The table shows this quarter; yearly figures run your average spending over the last three full months through this quarter and the next three, with spending caps applied and rotating categories counted only for quarters the issuer has announced. It can't see sign-up bonuses, offers you add to a card, rates that depend on booking through the issuer's travel site, or how a store is coded by the card network, so real results will differ a little. Rewards only come out ahead if the balance is paid in full: interest on a carried balance costs far more than any card pays back.</p>`;
}

function rewardsPaint(card, d) {
  const r = REWARDS.data;
  card.innerHTML = rewardsHtml(r, d);
  const done = () => { REWARDS.editing = REWARDS.picking = null; rewardsPaint(card, d); };
  const send = async (body, msg) => { REWARDS.data = await run(() => post("/api/debt/rewards", body), msg || "Saved"); done(); };
  $$("[data-rw-change]", card).forEach((a) => a.onclick = (e) => {
    e.preventDefault();
    const c = r.cards.find((x) => x.id === a.dataset.rwChange);
    REWARDS.editing = c.mode === "manual" ? c.id : null;
    REWARDS.picking = c.mode === "manual" ? null : c.id;
    rewardsPaint(card, d);
  });
  $$("[data-rw-pick]", card).forEach((box) => {
    const id = box.dataset.rwPick, on = (sel, fn) => { const el = $(sel, box); if (el) el.onclick = (e) => { e.preventDefault(); fn(); }; };
    on("[data-rw-use]", () => { const v = $("[data-rw-card]", box).value; if (!v) return toast("Choose a card from the list first"); send({ account_id: id, card: v }); });
    on("[data-rw-cancel]", done);
    on("[data-rw-manual]", () => { REWARDS.picking = null; REWARDS.editing = id; rewardsPaint(card, d); });
    on("[data-rw-off]", () => send({ account_id: id, off: true }));
    on("[data-rw-auto]", () => send({ account_id: id, clear: true }));
  });
  $$("[data-rw-cat-card]", card).forEach((head) => {
    const c = r.cards.find((x) => x.id === head.dataset.rwCatCard), box = head.closest(".rw-card");
    const save = (extra) => {
      const picks = $$("[data-rw-choice]", box).map((s) => s.value);
      const pv = $("[data-rw-pv]", box);
      send({ account_id: c.id, card: c.card.id, point_value: pv ? pv.value : "", picks: c.card.choice && !c.card.choice.auto ? picks : [], ...extra });
    };
    $$("[data-rw-choice]", box).forEach((s) => s.onchange = () => {
      const all = $$("[data-rw-choice]", box).map((x) => x.value);
      if (new Set(all).size !== all.length) return toast("Pick different categories");
      save();
    });
    const pv = $("[data-rw-pv]", box);
    if (pv) pv.onchange = () => save();
    const reset = $("[data-rw-pv-reset]", box);
    if (reset) reset.onclick = (e) => { e.preventDefault(); save({ point_value: "" }); };
  });
  $$("[data-rw-form]", card).forEach((form) => {
    const wireRows = () => $$("[data-rw-del]", form).forEach((b) => b.onclick = () => b.closest(".rw-bonus").remove());
    wireRows();
    $("[data-rw-add]", form).onclick = () => {
      $(".rw-bonuses", form).appendChild($("[data-rw-row]", form).content.cloneNode(true));
      wireRows();
    };
    $("[data-rw-cancel]", form).onclick = done;
    $("[data-rw-tolist]", form).onclick = (e) => { e.preventDefault(); REWARDS.editing = null; REWARDS.picking = form.dataset.rwForm; rewardsPaint(card, d); };
    $("[data-rw-save]", form).onclick = () => {
      const body = { account_id: form.dataset.rwForm, bonus: {} };
      $$("[data-rw]", form).forEach((i) => { body[i.dataset.rw] = i.value; });
      $$(".rw-bonuses .rw-bonus", form).forEach((b) => { const v = $("[data-rw-rate]", b).value; if (v !== "") body.bonus[$("[data-rw-cat]", b).value] = v; });
      send(body);
    };
  });
}
async function rewardsLoad(card, d) {
  try { REWARDS.data = await api("/api/debt/rewards"); }
  catch (e) { card.innerHTML = `<h2 style="margin:0">Card rewards</h2><div class="tiny down" style="margin-top:6px">${esc(e.message)}</div>`; return; }
  if (card.isConnected) rewardsPaint(card, d);
}
