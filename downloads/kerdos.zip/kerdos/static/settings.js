// Kerdos: Settings. For now: the app's background. Your choice is saved with your data (so your phone
// matches) and remembered on this device so the sign-in screen has it too.
"use strict";

// Four colours each: top left, top right, bottom right, bottom left
const BG_PRESETS = {
  aurora: { label: "Aurora", colors: ["#3d8bff", "#8a6bff", "#19c08a", "#ff7a3d"], builtin: true },
  sunset: { label: "Sunset", colors: ["#ff7a3d", "#ff4f8b", "#b05cff", "#ffc13d"] },
  ocean: { label: "Ocean", colors: ["#1f8fff", "#3d5bff", "#19c7c0", "#7fe0ff"] },
  forest: { label: "Forest", colors: ["#2fa866", "#1f8a7a", "#8fbf3f", "#c9a23f"] },
  berry: { label: "Berry", colors: ["#e8528a", "#9b5cff", "#ff7ab8", "#5c7cff"] },
  slate: { label: "Slate", colors: ["#6b7a90", "#5a6478", "#8a93a6", "#9aa3b5"] },
  plain: { label: "Plain", colors: null },
  custom: { label: "Custom", colors: null },
};
const BG_STRENGTH = { subtle: ["15%", "13%", "12%", "8%"], normal: null, vivid: ["54%", "48%", "42%", "30%"] };
const BG_CORNERS = ["Top left", "Top right", "Bottom right", "Bottom left"];
const isHex = (c) => /^#[0-9a-f]{6}$/i.test(c || "");

function appearanceColors(a) {
  if (a.bg === "custom") return (a.custom || []).length === 4 && a.custom.every(isHex) ? a.custom : BG_PRESETS.aurora.colors;
  return (BG_PRESETS[a.bg] || BG_PRESETS.aurora).colors;
}
function applyAppearance(a) {
  a = a || {};
  const st = document.documentElement.style, preset = BG_PRESETS[a.bg] || BG_PRESETS.aurora;
  const colors = preset.builtin ? null : appearanceColors(a);       // the built-in look keeps its own light and dark colours
  // CSS order is tint-1 top left, tint-3 top right, tint-2 bottom right, tint-4 bottom left
  ["--tint-1", "--tint-3", "--tint-2", "--tint-4"].forEach((v, i) => (colors ? st.setProperty(v, colors[i]) : st.removeProperty(v)));
  const strength = a.bg === "plain" ? ["0%", "0%", "0%", "0%"] : BG_STRENGTH[a.intensity] || null;
  ["--mesh-a", "--mesh-b", "--mesh-c", "--mesh-d"].forEach((v, i) => (strength ? st.setProperty(v, strength[i]) : st.removeProperty(v)));
}
function rememberAppearance(a) { try { localStorage.setItem("appearance", JSON.stringify(a || {})); } catch (_) { /* private window */ } }
try { applyAppearance(JSON.parse(localStorage.getItem("appearance") || "{}")); } catch (_) { /* first visit */ }

{
  const baseRefresh = refreshStatus;
  refreshStatus = async function (...args) {
    await baseRefresh(...args);
    if (STATUS.appearance) { applyAppearance(STATUS.appearance); rememberAppearance(STATUS.appearance); }
  };
}

function bgPreview(key, a) {
  const c = key === "custom" ? appearanceColors({ bg: "custom", custom: a.custom }) : BG_PRESETS[key].colors;
  if (!c) return "background:var(--bg)";
  return `background:radial-gradient(90% 90% at 0% 0%, ${c[0]}99, transparent 62%), radial-gradient(90% 90% at 100% 0%, ${c[1]}99, transparent 62%), radial-gradient(90% 90% at 100% 100%, ${c[2]}88, transparent 62%), radial-gradient(80% 80% at 0% 100%, ${c[3]}77, transparent 62%), var(--bg)`;
}

PAGES.settings = async (main) => {
  await refreshStatus();
  const a = { bg: "aurora", intensity: "normal", custom: BG_PRESETS.aurora.colors.slice(), ...(STATUS.appearance || {}) };
  if (!BG_PRESETS[a.bg]) a.bg = "aurora";
  if (!(a.custom || []).every(isHex) || a.custom.length !== 4) a.custom = BG_PRESETS.aurora.colors.slice();
  let saveT = null;
  const save = (quiet) => {
    applyAppearance(a); rememberAppearance(a);
    clearTimeout(saveT);
    saveT = setTimeout(async () => {
      try { STATUS.appearance = await post("/api/settings/appearance", a); if (!quiet) toast("Background saved"); }
      catch (e) { toast(e.message, true); }
    }, 350);
  };
  const paint = () => {
    main.innerHTML = `
      <h1>Settings</h1><p class="sub">Make the app yours. More settings live next to the things they change; the links at the bottom take you there.</p>
      <div class="card"><h2>Background</h2>
        <div class="tiny muted">Pick a look for the colour behind every page. It also sets the colour of the buttons and the app name.</div>
        <div class="bg-tiles">${Object.entries(BG_PRESETS).map(([k, p]) => `<button class="bg-tile ${a.bg === k ? "on" : ""}" data-bg="${k}" aria-pressed="${a.bg === k}">
          <span class="bg-swatch" style="${bgPreview(k, a)}">${k === "custom" ? "🎨" : ""}</span><span>${p.label}</span></button>`).join("")}</div>
        ${a.bg === "custom" ? `<div class="bg-custom">${BG_CORNERS.map((n, i) => `<label class="swatch"><input type="color" data-corner="${i}" value="${esc(a.custom[i])}"><span>${n}</span></label>`).join("")}</div>` : ""}
        <div class="row" style="margin-top:14px;gap:8px;flex-wrap:wrap"><span class="tiny muted">Strength</span>
          <div class="gr-chips">${[["subtle", "Subtle"], ["normal", "Normal"], ["vivid", "Vivid"]].map(([k, l]) => `<button class="chip ${a.intensity === k ? "active" : ""}" data-strength="${k}" ${a.bg === "plain" ? "disabled" : ""}>${l}</button>`).join("")}</div>
          <span class="spacer"></span><button class="btn small secondary" id="bgReset">Back to the original</button></div>
      </div>
      <div class="card" style="margin-top:16px" id="aiCard"></div>
      <div class="card" style="margin-top:16px"><h2>More settings</h2>
        <div class="set-links">
          <a href="#accounts"><b>🔒 Password and auto-lock</b><span class="tiny muted">On the Accounts page, under Security</span></a>
          <a href="#bills"><b>🔔 Alerts and notifications</b><span class="tiny muted">On the Bills &amp; Alerts page</span></a>
          <a href="#health"><b>🏦 Bank connections</b><span class="tiny muted">On the Connections page</span></a>
          <a href="#goals"><b>🐾 Your companion's colours and pace</b><span class="tiny muted">On the Goals page, under the room</span></a>
          <a href="#invest"><b>🧭 Age, income and risk level</b><span class="tiny muted">On the Investing Plan page</span></a>
        </div></div>`;
    $$("[data-bg]", main).forEach((b) => b.onclick = () => { a.bg = b.dataset.bg; save(); paint(); });
    $$("[data-strength]", main).forEach((b) => b.onclick = () => { a.intensity = b.dataset.strength; save(); paint(); });
    $$("[data-corner]", main).forEach((inp) => {
      inp.oninput = () => { a.custom[+inp.dataset.corner] = inp.value; applyAppearance(a); const sw = $('[data-bg="custom"] .bg-swatch', main); if (sw) sw.style.cssText = bgPreview("custom", a); };
      inp.onchange = () => { a.custom[+inp.dataset.corner] = inp.value; save(); };
    });
    $("#bgReset", main).onclick = () => { a.bg = "aurora"; a.intensity = "normal"; save(); paint(); };
    aiSortPaint($("#aiCard", main));
  };
  paint();
};

// ---------------------------------------------------------------- sorting help from an AI model on this computer
const AISORT = { data: null, timer: null };
async function aiSortPaint(card, fresh) {
  if (!card) return;
  if (!AISORT.data || fresh) {
    try { AISORT.data = await api("/api/ai", { background: !!fresh }); }
    catch (e) { card.innerHTML = `<h2>Sorting help from a local AI model</h2><div class="tiny down">${esc(e.message)}</div>`; return; }
  }
  if (!card.isConnected) return;
  const s = AISORT.data, last = s.last;
  const when = last && last.at ? new Date(last.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "";
  const state = s.busy ? `Thinking about ${s.left || "a few"} transaction${s.left === 1 ? "" : "s"}…`
    : [s.waiting ? `${s.waiting} waiting for a second opinion` : "Nothing waiting",
       last ? (last.error ? `last run ${when} stopped early (${esc(last.error)})` : `last run ${when}: ${last.answered} of ${last.asked} answered in ${last.seconds}s`) : ""].filter(Boolean).join(" · ");
  card.innerHTML = `<h2>Sorting help from a local AI model</h2>
    <div class="tiny muted">The app sorts with your rules, built-in keywords, your bank's guess and a learner trained on your own sorts. For whatever is still unsure after that, a model running on this computer can add a second opinion. It shows on the Sort page marked 🤖 and is only a suggestion: nothing is filed until you accept it.</div>
    ${!s.ollama ? `<p class="tiny" style="margin-bottom:0"><b>Ollama isn't running on this computer</b>, so there are no second opinions for now. Start Ollama and reload this page.</p>`
      : !s.models.length ? `<p class="tiny" style="margin-bottom:0"><b>Ollama is running but has no models.</b> Install one (for example <code>ollama pull qwen2.5:3b</code> in a terminal), then reload this page.</p>`
      : `<label class="row" style="margin-top:12px;gap:8px"><input type="checkbox" id="aiOn" ${s.enabled ? "checked" : ""}> Ask the local model about transactions the app can't call</label>
        <div class="row" style="margin-top:10px;gap:10px;flex-wrap:wrap"><label class="field" style="margin:0;min-width:220px">Model
            <select id="aiModel" ${s.enabled ? "" : "disabled"}>${s.models.map((m) => `<option value="${esc(m.name)}" ${m.name === s.model ? "selected" : ""}>${esc(m.name)}${m.size_gb ? ` (${m.size_gb} GB)` : ""}</option>`).join("")}</select></label>
          <button class="btn small secondary" id="aiRun" ${s.enabled && !s.busy && s.waiting ? "" : "disabled"}>Ask it now</button>
          <span class="tiny muted">${state}</span></div>
        <p class="tiny muted" style="margin-bottom:0">It runs entirely on this computer through Ollama; nothing is sent to the internet. Your computer may slow down for a few seconds while it thinks, and the model is unloaded from memory straight after. Larger models guess better but take longer and need more memory; models you install in Ollama show up in the list.</p>`}`;
  const send = async (body, msg) => { AISORT.data = await run(() => post("/api/ai", body), msg); aiSortPaint(card); };
  const on = $("#aiOn", card), model = $("#aiModel", card), go = $("#aiRun", card);
  if (on) on.onchange = () => send({ enabled: on.checked }, on.checked ? "Second opinions on" : "Second opinions off");
  if (model) model.onchange = () => send({ model: model.value }, "Model changed");
  if (go) go.onclick = () => send({ run: true }, "Asking the local model…");
  clearTimeout(AISORT.timer);
  if (s.busy) AISORT.timer = setTimeout(() => { if (card.isConnected) aiSortPaint(card, true); }, 3000);
}
