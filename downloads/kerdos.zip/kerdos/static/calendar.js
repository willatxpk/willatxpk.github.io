// Kerdos: Calendar. Upcoming bills and paydays on a month grid, with the selected day and an agenda beside it.
"use strict";

const CAL = { selected: null };
const CAL_KIND = {
  inc: ["Money in", "A paycheck or other regular deposit expected to arrive"],
  auto: ["Autopay", "Paid automatically"],
  manual: ["Pay by hand", "You pay this one yourself"],
  debt: ["Card or loan payment", "A payment toward a card or loan"],
  paid: ["Paid", "Already paid"],
  late: ["Expected, not seen yet", "Was expected by now but hasn't shown up at your bank"],
};
function calKind(e) {
  if (e.kind === "income") return "inc";
  if (e.state === "paid") return "paid";
  if (e.state === "late") return "late";
  if (e.debt) return "debt";
  return e.autopay === "yes" || e.autopay === "likely" ? "auto" : "manual";
}
const calDate = (iso) => new Date(iso + "T00:00");
const calLong = (iso) => calDate(iso).toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });
const calAmt = (e) => (e.kind === "income" ? "+" : "") + fmt(e.amount);

function calEventRow(e) {
  const k = calKind(e);
  const bits = [CAL_KIND[k][0]];
  if (e.kind === "bill" && e.state !== "paid" && e.debt && (e.autopay === "yes" || e.autopay === "likely")) bits.push("autopay");
  if (e.pays) bits.push("to " + e.pays);
  if (e.account) bits.push((e.kind === "income" ? "into " : "from ") + e.account);
  if (e.cadence) bits.push(e.cadence);
  return `<div class="cal-row"><i class="cal-dot k-${k}"></i><div><div class="cal-row-name">${esc(e.name)}</div>
      <div class="tiny muted">${esc(bits.join(" · "))}</div></div><b class="${e.kind === "income" ? "pos" : ""}">${calAmt(e)}</b></div>`;
}

function calDayPanel(d, iso) {
  const day = d.days.find((x) => x.date === iso);
  if (!day) return "";
  const diff = dayDiff(iso);
  const when = diff === 0 ? "Today" : diff === 1 ? "Tomorrow" : diff === -1 ? "Yesterday" : diff > 0 ? `In ${diff} days` : `${-diff} days ago`;
  const out = day.events.filter((e) => e.kind === "bill" && e.state !== "paid").reduce((s, e) => s + e.amount, 0);
  return `<div class="row"><h2 style="margin:0">${esc(calLong(iso))}</h2><span class="pill">${when}</span></div>
    ${day.events.length ? `<div class="cal-list">${day.events.map(calEventRow).join("")}</div>
      ${out ? `<div class="tiny muted" style="margin-top:8px">${fmt(out)} going out this day.</div>` : ""}`
    : `<div class="tiny muted" style="margin-top:8px">Nothing expected this day.</div>`}`;
}

function calAgenda(d) {
  const days = d.days.filter((x) => x.in_month && x.date >= d.today && x.events.some((e) => e.state !== "paid"));
  if (!days.length) return `<div class="tiny muted">${d.month === d.today.slice(0, 7) ? "Nothing else expected this month." : d.month < d.today.slice(0, 7) ? "This month is over." : "Nothing expected this month yet."}</div>`;
  return days.map((x) => `<div class="cal-agenda-day" data-pick="${x.date}"><div class="cal-agenda-date ${x.date === d.today ? "today" : ""}"><b>${calDate(x.date).getDate()}</b><span>${calDate(x.date).toLocaleDateString(undefined, { weekday: "short" })}</span></div>
      <div class="cal-list">${x.events.filter((e) => e.state !== "paid").map(calEventRow).join("")}</div></div>`).join("");
}

PAGES.calendar = async (main, qs) => {
  const want = new URLSearchParams(qs || "").get("month") || "";
  const d = await api("/api/calendar" + (want ? "?month=" + encodeURIComponent(want) : ""));
  const inView = (iso) => d.days.some((x) => x.date === iso);
  if (!CAL.selected || !inView(CAL.selected) || CAL.month !== d.month) {
    const firstBusy = d.days.find((x) => x.in_month && x.events.length);
    CAL.selected = d.month === d.today.slice(0, 7) ? d.today : (firstBusy || d.days.find((x) => x.in_month)).date;
  }
  CAL.month = d.month;
  const t = d.totals, current = d.month === d.today.slice(0, 7), past = d.month < d.today.slice(0, 7);
  const cell = (x) => {
    const ev = x.events, shown = ev.slice(0, 3);
    const tipHtml = ev.length ? `<b>${esc(calLong(x.date))}</b><br>` + ev.map((e) => `${esc(e.name)} ${calAmt(e)}`).join("<br>") : "";
    return `<div class="cal-cell ${x.in_month ? "" : "out"} ${x.date === d.today ? "today" : ""} ${x.date < d.today ? "gone" : ""} ${x.date === CAL.selected ? "sel" : ""}" data-day="${x.date}" tabindex="0" role="button"
        aria-label="${esc(calLong(x.date))}${ev.length ? `, ${ev.length} item${ev.length === 1 ? "" : "s"}` : ""}" ${tipHtml ? `data-tip="${esc(tipHtml)}"` : ""}>
      <div class="cal-num"><span>${x.day === 1 ? calDate(x.date).toLocaleDateString(undefined, { month: "short" }) + " " : ""}${x.day}</span></div>
      <div class="cal-evs">${shown.map((e) => `<div class="cal-ev k-${calKind(e)}"><span>${e.state === "paid" ? "✓ " : ""}${esc(e.name)}</span><b>${calAmt(e)}</b></div>`).join("")}
        ${ev.length > 3 ? `<div class="cal-more">+${ev.length - 3} more</div>` : ""}</div>
      <div class="cal-dots">${ev.slice(0, 5).map((e) => `<i class="cal-dot k-${calKind(e)}"></i>`).join("")}</div></div>`;
  };
  const used = [...new Set(d.days.flatMap((x) => x.events.map(calKind)))];
  const paidEvents = d.days.filter((x) => x.in_month).flatMap((x) => x.events.filter((e) => e.state === "paid"));
  const biggest = paidEvents.slice().sort((p, q) => q.amount - p.amount)[0];
  const stats = past ? `
      <div class="card stat"><div class="label">Paid in this month</div><div class="value">${fmt(t.paid)}</div><div class="delta">toward your recurring bills</div></div>
      <div class="card stat" style="--stat-c:var(--series-4)"><div class="label">Biggest bill</div><div class="value">${fmt(biggest ? biggest.amount : 0)}</div><div class="delta">${biggest ? esc(biggest.name) : "none seen"}</div></div>
      <div class="card stat" style="--stat-c:var(--neutral)"><div class="label">Payments</div><div class="value">${t.paid_count}</div><div class="delta">on ${new Set(d.days.filter((x) => x.in_month && x.events.some((e) => e.state === "paid")).map((x) => x.date)).size} days</div></div>` : null;
  main.innerHTML = `
    <h1>Calendar</h1><p class="sub">Your bills and paychecks laid out by date. Upcoming ones are estimates from your history; earlier ones are what was actually paid. Tap a day to see what's due.</p>
    <div class="grid g3">${stats || `
      <div class="card stat"><div class="label">${past ? "Bills in this month" : current ? "Still to pay this month" : "Bills expected"}</div><div class="value">${fmt(past ? t.paid : t.due)}</div>
        <div class="delta">${past ? `${t.paid_count} seen` : `${t.due_count} bill${t.due_count === 1 ? "" : "s"}${t.manual_count ? ` · ${t.manual_count} to pay by hand` : ""}`}</div></div>
      <div class="card stat" style="--stat-c:var(--good)"><div class="label">Money coming in${current ? " (rest of month)" : ""}</div><div class="value">${fmt(t.income)}</div>
        <div class="delta">${t.income_count} deposit${t.income_count === 1 ? "" : "s"}</div></div>
      <div class="card stat" style="--stat-c:var(--neutral)"><div class="label">${current ? "Already paid this month" : t.late_count ? "Expected, not seen yet" : "Left after bills"}</div>
        <div class="value">${fmt(current ? t.paid : t.late_count ? t.late : t.income - t.due)}</div>
        <div class="delta">${current ? `${t.paid_count} bill${t.paid_count === 1 ? "" : "s"}${t.late_count ? ` · ${t.late_count} not seen yet` : ""}` : t.late_count ? `${t.late_count} bill${t.late_count === 1 ? "" : "s"}` : "money in minus bills"}</div></div>`}
    </div>
    <div class="cal-wrap">
      <div class="card cal-card">
        <div class="row cal-head"><button class="btn small secondary" id="calToday" ${current ? "disabled" : ""}>Today</button>
          <button class="btn small secondary cal-nav" id="calPrev" ${d.prev ? "" : "disabled"} aria-label="Previous month">‹</button>
          <button class="btn small secondary cal-nav" id="calNext" ${d.next ? "" : "disabled"} aria-label="Next month">›</button>
          <h2 style="margin:0">${esc(d.title)}</h2></div>
        <div class="cal-dow">${["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((n) => `<div>${n}</div>`).join("")}</div>
        <div class="cal-grid">${d.days.map(cell).join("")}</div>
        <div class="cal-legend tiny">${used.map((k) => `<span title="${esc(CAL_KIND[k][1])}"><i class="cal-dot k-${k}"></i>${CAL_KIND[k][0]}</span>`).join("")}</div>
      </div>
      <div class="cal-side">
        <div class="card" id="calDay">${calDayPanel(d, CAL.selected)}</div>
        <div class="card"><h2>${current ? "Coming up this month" : past ? "This month" : "Expected this month"}</h2><div class="cal-agenda">${calAgenda(d)}</div>
          <p class="tiny muted" style="margin-bottom:0">Dates and amounts are estimates from your history. Change a bill's name, autopay or status on the <a href="#bills">Bills &amp; Alerts</a> page.</p></div>
      </div>
    </div>`;
  const go = (m) => { location.hash = "#calendar" + (m ? "?month=" + m : ""); };
  $("#calPrev").onclick = () => go(d.prev);
  $("#calNext").onclick = () => go(d.next);
  $("#calToday").onclick = () => { CAL.selected = d.today; go(""); };
  const pick = (iso) => {
    CAL.selected = iso;
    $$(".cal-cell", main).forEach((c) => c.classList.toggle("sel", c.dataset.day === iso));
    $("#calDay").innerHTML = calDayPanel(d, iso);
  };
  $$(".cal-cell", main).forEach((c) => {
    c.onclick = () => pick(c.dataset.day);
    c.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(c.dataset.day); } };
  });
  $$("[data-pick]", main).forEach((r) => r.onclick = () => { pick(r.dataset.pick); if (innerWidth <= 1000) $("#calDay").scrollIntoView({ block: "nearest", behavior: "smooth" }); });
};
