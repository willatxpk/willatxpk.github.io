"use strict";
// Sort (bubble sorting), Insights (year summary + projection) and Goals (with companion).
// Uses helpers from app.js: $, $$, esc, fmt, fmt2, api, post, del, run, toast, tip, STATUS, PAGES, niceTicks, compact.

// Badges for the new tabs
{
  const baseRefresh = refreshStatus;
  refreshStatus = async function (...args) {
    await baseRefresh(...args);
    const sb = $("#sortBadge");
    if (sb) { sb.hidden = !STATUS.sort_count; sb.textContent = STATUS.sort_count > 99 ? "99+" : STATUS.sort_count; }
    const pi = $("#petIcon");
    if (pi) pi.textContent = STATUS.companion === "pet" ? "🐾" : STATUS.companion === "plant" ? "🌱" : "";
  };
}

const PCT = (v, d = 0) => (v == null ? "—" : (v * 100).toFixed(d) + "%");

// =====================================================================
// SORT: drag floating bubbles into category bins
// =====================================================================
const SORT = { raf: null, bubbles: [], queue: [], selected: null, combo: 0, sortedNow: 0, binCounts: {} };

function stopSortLoop() { if (SORT.raf) cancelAnimationFrame(SORT.raf); SORT.raf = null; }
window.addEventListener("hashchange", stopSortLoop);

PAGES.sort = async (main) => {
  stopSortLoop();
  const medium = localStorage.getItem("sortMedium") === "1";
  const teach = localStorage.getItem("sortTeach") !== "0";
  const data = await api("/api/sort" + (medium ? "?medium=1" : ""));
  SORT.queue = data.transactions.slice();
  SORT.bubbles = []; SORT.selected = null;
  SORT.sortedTotal = data.sorted_total; SORT.perCoin = data.sorts_per_coin;
  // The badge always says exactly what this page is about to show
  if (!medium) { STATUS.sort_count = data.transactions.length; const sb0 = $("#sortBadge"); if (sb0) { sb0.hidden = !STATUS.sort_count; sb0.textContent = STATUS.sort_count > 99 ? "99+" : STATUS.sort_count; } }
  // Most-used categories first; ones you rarely use sink to the bottom
  const usage = data.category_usage || {};
  const cats = STATUS.categories.filter((c) => c !== "Other")
    .map((c, i) => [c, usage[c] || 0, i]).sort((a, b) => b[1] - a[1] || a[2] - b[2]).map((x) => x[0]);
  main.innerHTML = `
    <div class="row"><div><h1>Sort</h1><p class="sub" style="margin-bottom:12px">These are the transactions the app isn't sure about. Drag each bubble into the right bin, or click a bubble then click a bin.</p></div>
      <span class="spacer"></span>
      <div class="sort-score"><div class="tiny muted">Sorted this session</div><b id="sortedNow">0</b><div id="combo" class="tiny"></div>
        <button class="btn small secondary undo-btn" id="undoBtn" ${data.undo ? "" : "disabled"} title="${data.undo ? "Undo: " + esc(data.undo) + " (Ctrl+Z)" : "Nothing to undo"}">↶ Undo</button></div></div>
    <div class="sort-stats">
      <div><span class="tiny muted">🧠 Learner</span><div class="tiny">Trained on <b id="trainedOn">${data.learner.trained_on}</b> of your sorts · auto-sorted <b>${data.learner.learned}</b> it was confident about${data.learner.learned ? ` (check them with "probably right" below)` : ""}</div>
        <div class="tiny muted" id="aiLine" style="margin-top:3px"></div></div>
      <div><span class="tiny muted">🪙 Coins for ${esc(STATUS.companion ? "your " + STATUS.companion : "your companion")}</span>
        <div class="tiny"><span id="coinProg">${data.sorted_total % data.sorts_per_coin}</span>/${data.sorts_per_coin} sorts to the next coin · <b id="coinsEarned">${data.coins_from_sorting}</b> earned from sorting</div>
        <div class="bar coinbar"><div id="coinBar" style="width:${(data.sorted_total % data.sorts_per_coin) / data.sorts_per_coin * 100}%"></div></div></div>
    </div>
    <div class="row" style="margin-bottom:10px">
      <label class="row tiny"><input type="checkbox" id="teach" ${teach ? "checked" : ""}> Teach it: sort other transactions from the same merchant the same way (now and in future)</label>
      <span class="spacer"></span>
      <label class="row tiny"><input type="checkbox" id="medium" ${medium ? "checked" : ""}> Also show "probably right" guesses (${data.counts?.medium || 0})</label>
    </div>
    <div class="arena" id="arena">
      <div class="arena-msg" id="arenaMsg"></div>
      <div class="arena-left tiny muted" id="arenaLeft"></div>
    </div>
    <div class="sel-panel" id="selPanel" hidden></div>
    <div class="bins" id="bins">${cats.map((c) => `<div class="bin" data-bin="${esc(c)}"><span class="bin-name">${esc(c)}</span><span class="bin-count" data-count="${esc(c)}"></span></div>`).join("")}
      <div class="bin other-bin" data-bin="Other" title="None of these fit. It stays as Other and the app stops asking about it."><span class="bin-name">Other</span><span class="bin-count" data-count="Other"></span></div>
      <div class="bin new-bin" data-bin="__new"><span class="bin-name">+ New category</span></div></div>`;
  $("#teach").onchange = (e) => localStorage.setItem("sortTeach", e.target.checked ? "1" : "0");
  $("#medium").onchange = (e) => { localStorage.setItem("sortMedium", e.target.checked ? "1" : "0"); PAGES.sort(main); };
  $$(".bin", main).forEach((b) => b.onclick = () => { if (SORT.selected) dropInto(SORT.selected, b); });
  $("#undoBtn").onclick = () => sortUndo(main);
  $("#sortedNow").textContent = SORT.sortedNow;
  fillArena();
  sortAiLine(data.ai);
  if (data.ai && data.ai.busy) sortAiWatch(medium);
  SORT.raf = requestAnimationFrame(tick);
};

function bubbleSize(amount) {
  return Math.round(Math.max(70, Math.min(112, 56 + Math.log10(Math.abs(amount) + 1) * 20)));
}
function shortName(t) {
  return (t.merchant || t.name).replace(/\s{2,}/g, " ").replace(/#?\d{4,}.*$/, "").slice(0, 26);
}

// The line under each bubble: the learner's guess from your own sorts, else the local AI model's, else the bank's
function sortGuess(t) {
  const s = t.suggestion;
  if (!s) return { html: `${esc(t.category)}?`, title: "The bank's guess" };
  if (s.by === "ai") return { html: `🤖 ${esc(s.category)}?`, title: "A guess from the AI model on this computer" + (s.why ? ": " + s.why : "") };
  return { html: `${esc(s.category)}? ${Math.round(s.p * 100)}%`, title: "The learner's guess from your past sorts" };
}
function sortAiLine(ai) {
  const el = $("#aiLine");
  if (!el) return;
  el.innerHTML = !ai || !ai.ollama ? "" : !ai.enabled || !ai.model ? `🤖 Local AI second opinions are off · <a href="#settings">Settings</a>`
    : ai.busy ? `🤖 <b>${esc(ai.model)}</b> is looking at ${ai.left || "a few"} of these on this computer…`
    : `🤖 Where the learner has no view, <b>${esc(ai.model)}</b> on this computer gives a second opinion · <a href="#settings">Settings</a>`;
}
// While the local model is thinking, check back; when it finishes, put its guesses on the bubbles already on screen
function sortAiWatch(medium) {
  clearTimeout(SORT.aiT);
  SORT.aiT = setTimeout(async () => {
    if (!$("#arena")) return;
    let ai;
    try { ai = await api("/api/ai", { background: true }); } catch (e) { return; }
    if (!$("#arena")) return;
    sortAiLine(ai);
    if (ai.busy) return sortAiWatch(medium);
    let fresh;
    try { fresh = await api("/api/sort" + (medium ? "?medium=1" : ""), { background: true }); } catch (e) { return; }
    const by = new Map(fresh.transactions.map((t) => [t.id, t.suggestion]));
    SORT.queue.forEach((t) => { if (by.has(t.id)) t.suggestion = by.get(t.id); });
    SORT.bubbles.forEach((b) => {
      if (!by.has(b.t.id) || b.leaving) return;
      b.t.suggestion = by.get(b.t.id);
      const g = sortGuess(b.t), el = $(".b-guess", b.el);
      if (el) { el.innerHTML = g.html; el.title = g.title; }
    });
  }, 3000);
}

function fillArena() {
  const arena = $("#arena");
  if (!arena) return;
  const W = arena.clientWidth, H = arena.clientHeight;
  const cap = Math.max(6, Math.floor(W * H / 15000));
  while (SORT.bubbles.length < cap && SORT.queue.length) {
    const t = SORT.queue.shift();
    const size = bubbleSize(t.amount);
    const el = document.createElement("div");
    el.className = "bubble" + (t.amount > 0 ? " inflow" : "") + (t.pending ? " pending" : "");
    el.style.width = el.style.height = size + "px";
    const g = sortGuess(t);
    el.innerHTML = `${t.pending ? '<div class="b-pend">pending</div>' : ""}<div class="b-name">${esc(shortName(t))}</div><div class="b-amt">${t.amount > 0 ? "+" : ""}${fmt2(t.amount).replace("−", "")}</div>
      <div class="b-guess" title="${esc(g.title)}">${g.html}</div>`;
    el.title = `${t.name}\n${t.date} · ${t.account_name || ""}`;
    arena.appendChild(el);
    const b = { t, el, size, x: Math.random() * (W - size), y: Math.random() * (H - size),
      vx: (Math.random() - 0.5) * 0.6, vy: (Math.random() - 0.5) * 0.6, phase: Math.random() * 6.28, dragging: false };
    SORT.bubbles.push(b);
    wireBubble(b);
    el.animate([{ transform: `translate(${b.x}px,${b.y}px) scale(0)` }, { transform: `translate(${b.x}px,${b.y}px) scale(1)` }], { duration: 350, easing: "cubic-bezier(.3,1.6,.6,1)" });
  }
  const left = SORT.queue.length;
  $("#arenaLeft").textContent = left ? `+${left} more waiting` : "";
  $("#arenaMsg").innerHTML = SORT.bubbles.length ? "" :
    `<div style="font-size:34px">🎉</div><b>All sorted!</b><div class="tiny muted">New uncertain transactions will float in here after each sync.</div>`;
}

function tick(now) {
  const arena = $("#arena");
  if (!arena) return stopSortLoop();
  const W = arena.clientWidth, H = arena.clientHeight;
  const bs = SORT.bubbles;
  for (let i = 0; i < bs.length; i++) {
    const a = bs[i];
    if (a.dragging || a.leaving) continue;
    // gentle wander
    a.vx += Math.cos(now / 1700 + a.phase) * 0.004;
    a.vy += Math.sin(now / 1900 + a.phase * 1.3) * 0.004;
    // soft push apart
    for (let j = i + 1; j < bs.length; j++) {
      const b = bs[j];
      if (b.dragging || b.leaving) continue;
      const dx = (b.x + b.size / 2) - (a.x + a.size / 2), dy = (b.y + b.size / 2) - (a.y + a.size / 2);
      const dist = Math.hypot(dx, dy) || 1, min = (a.size + b.size) / 2 + 4;
      if (dist < min) {
        const push = (min - dist) * 0.12, nx = dx / dist, ny = dy / dist;
        a.x -= nx * push; a.y -= ny * push; b.x += nx * push; b.y += ny * push;  // separate overlaps
        const f = 0.04;
        a.vx -= nx * f; a.vy -= ny * f; b.vx += nx * f; b.vy += ny * f;
      }
    }
    a.vx *= 0.985; a.vy *= 0.985;
    const sp = Math.hypot(a.vx, a.vy); if (sp > 1.2) { a.vx *= 1.2 / sp; a.vy *= 1.2 / sp; }
    a.x += a.vx; a.y += a.vy;
    if (a.x < 0) { a.x = 0; a.vx = Math.abs(a.vx); } if (a.x > W - a.size) { a.x = W - a.size; a.vx = -Math.abs(a.vx); }
    if (a.y < 0) { a.y = 0; a.vy = Math.abs(a.vy); } if (a.y > H - a.size) { a.y = H - a.size; a.vy = -Math.abs(a.vy); }
    a.el.style.transform = `translate(${a.x}px,${a.y}px)`;
  }
  SORT.raf = requestAnimationFrame(tick);
}

function wireBubble(b) {
  let start = null, moved = false;
  b.el.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    try { b.el.setPointerCapture(e.pointerId); } catch (_) { /* synthetic pointer */ }
    start = { x: e.clientX, y: e.clientY, bx: b.x, by: b.y }; moved = false;
  });
  b.el.addEventListener("pointermove", (e) => {
    if (!start) return;
    const dx = e.clientX - start.x, dy = e.clientY - start.y;
    if (!moved && Math.hypot(dx, dy) < 5) return;
    if (!moved) { moved = true; b.dragging = true; b.el.classList.add("dragging"); }
    b.x = start.bx + dx; b.y = start.by + dy;
    b.el.style.transform = `translate(${b.x}px,${b.y}px) scale(1.08)`;
    b.el.style.pointerEvents = "none";
    const under = document.elementFromPoint(e.clientX, e.clientY)?.closest(".bin");
    b.el.style.pointerEvents = "";
    $$(".bin").forEach((x) => x.classList.toggle("hover", x === under));
  });
  b.el.addEventListener("pointerup", (e) => {
    if (!start) return;
    start = null;
    b.el.style.pointerEvents = "none";
    const under = document.elementFromPoint(e.clientX, e.clientY)?.closest(".bin");
    b.el.style.pointerEvents = "";
    $$(".bin").forEach((x) => x.classList.remove("hover"));
    b.el.classList.remove("dragging");
    if (moved) {
      b.dragging = false;
      if (under) dropInto(b, under);
      else { // fell outside the arena? float back in
        const arena = $("#arena");
        b.x = Math.max(0, Math.min(arena.clientWidth - b.size, b.x));
        b.y = Math.max(0, Math.min(arena.clientHeight - b.size, b.y));
      }
    } else selectBubble(b);
  });
}

function selectBubble(b) {
  SORT.bubbles.forEach((x) => x.el.classList.toggle("selected", x === b && SORT.selected !== b));
  SORT.selected = SORT.selected === b ? null : b;
  const p = $("#selPanel");
  if (!SORT.selected) { p.hidden = true; return; }
  const t = b.t;
  p.hidden = false;
  p.innerHTML = `<div><b>${esc(t.merchant || t.name)}</b> <span class="muted tiny">${esc(t.name)}</span>
      <div class="tiny muted">${esc(t.date)} · ${esc(t.account_name || "")} · ${t.amount > 0 ? "money in" : "money out"} ${fmt2(Math.abs(t.amount))}</div></div>
    <span class="spacer"></span><span class="tiny muted">${$("#teach")?.checked ? `Will teach: “${esc(t.pattern)}” · ` : ""}Click a bin below, or</span>
    <button class="btn small" id="keepGuess">Use "${esc(t.suggestion ? t.suggestion.category : t.category)}"</button>`;
  $$(".bin").forEach((x) => x.classList.toggle("suggested", !!t.suggestion && x.dataset.bin === t.suggestion.category));
  $("#keepGuess").onclick = () => {
    const cat = t.suggestion ? t.suggestion.category : t.category;
    const bin = $(`.bin[data-bin="${CSS.escape(cat)}"]`);
    if (bin) dropInto(b, bin); else toast("Pick a bin for this one");
  };
}

async function dropInto(b, binEl) {
  let cat = binEl.dataset.bin;
  if (cat === "__new") {
    cat = (prompt("New category name:") || "").trim();
    if (!cat) return;
  }
  const teach = $("#teach")?.checked;
  const t = b.t;
  b.leaving = true;
  $$(".bin").forEach((x) => x.classList.remove("suggested"));
  let res;
  try {
    res = await post(`/api/transactions/${encodeURIComponent(t.id)}`, { category: cat, apply_to_merchant: !!teach, pattern: t.pattern });
  } catch (e) { b.leaving = false; toast(e.message, true); return; }
  if (!STATUS.categories.includes(cat)) { await refreshStatus(); return PAGES.sort($("#main")); }
  const target = $(`.bin[data-bin="${CSS.escape(cat)}"]`) || binEl;
  flyAway(b, target, cat, true);
  showResolved(res.resolved || [], teach ? t.pattern : null, cat);
  const ub = $("#undoBtn");
  if (ub) { ub.disabled = false; ub.title = `Undo: ${(t.merchant || t.name).slice(0, 40)} → ${cat} (Ctrl+Z)`; }
}

// Only what the server actually sorted (through your new rule or the learner) leaves the arena
function showResolved(resolved, pattern, cat) {
  if (!resolved.length) return;
  const ids = new Set(resolved.map((r) => r.id));
  SORT.queue = SORT.queue.filter((q) => !ids.has(q.id));
  let i = 0;
  resolved.forEach((r) => {
    const x = SORT.bubbles.find((bb) => bb.t.id === r.id && !bb.leaving);
    if (!x) return;
    x.leaving = true;
    const bin = $(`.bin[data-bin="${CSS.escape(r.category)}"]`);
    if (bin) setTimeout(() => flyAway(x, bin, r.category, false), 140 * ++i);
  });
  const byRule = resolved.filter((r) => r.how === "rule").length, learned = resolved.filter((r) => r.how === "learned").length;
  const parts = [];
  if (byRule) parts.push(`${byRule} more from “${pattern || "your rule"}”`);
  if (learned) parts.push(`${learned} more the learner is now sure about`);
  if (parts.length) toast(`Also sorted ${parts.join(" and ")}`);
}

function flyAway(b, binEl, cat, byYou = true) {
  b.leaving = true;
  SORT.selected = null; $("#selPanel").hidden = true;
  const arena = $("#arena").getBoundingClientRect(), br = binEl.getBoundingClientRect();
  const tx = br.left - arena.left + br.width / 2 - b.size / 2, ty = br.top - arena.top + br.height / 2 - b.size / 2;
  const anim = b.el.animate([
    { transform: `translate(${b.x}px,${b.y}px) scale(1)`, opacity: 1 },
    { transform: `translate(${tx}px,${ty}px) scale(.15)`, opacity: .4 },
  ], { duration: 420, easing: "cubic-bezier(.5,0,.8,.6)", fill: "forwards" });
  let finished = false;
  const finish = () => {
    if (finished) return;
    finished = true;
    b.el.remove();
    SORT.bubbles = SORT.bubbles.filter((x) => x !== b);
    binEl.classList.remove("pulse"); void binEl.offsetWidth; binEl.classList.add("pulse");
    SORT.binCounts[cat] = (SORT.binCounts[cat] || 0) + 1;
    const c = $(`[data-count="${CSS.escape(cat)}"]`); if (c) c.textContent = SORT.binCounts[cat];
    SORT.sortedNow++; SORT.combo++;
    $("#sortedNow").textContent = SORT.sortedNow;
    clearTimeout(SORT.comboT);
    SORT.comboT = setTimeout(() => { SORT.combo = 0; const cb = $("#combo"); if (cb) cb.textContent = ""; }, 6000);
    const cb = $("#combo");
    if (cb) cb.textContent = SORT.combo >= 3 ? `🔥 ${SORT.combo} in a row` : "";
    if (SORT.combo && SORT.combo % 10 === 0) confetti(binEl);
    if (byYou) {  // 1 coin per 10 transactions you sort yourself
      SORT.sortedTotal++;
      const prog = SORT.sortedTotal % SORT.perCoin;
      const cp = $("#coinProg"); if (cp) cp.textContent = prog;
      const bar = $("#coinBar"); if (bar) bar.style.width = prog / SORT.perCoin * 100 + "%";
      const tr = $("#trainedOn"); if (tr) tr.textContent = +tr.textContent + 1;
      if (prog === 0) {
        const ce = $("#coinsEarned"); if (ce) ce.textContent = +ce.textContent + 1;
        toast(`🪙 +1 coin for ${STATUS.companion === "plant" ? "your plant" : "your pet"}!`);
        confetti($("#coinBar") || binEl);
      }
    }
    STATUS.sort_count = Math.max(0, (STATUS.sort_count || 1) - 1);
    const sb = $("#sortBadge"); if (sb) { sb.hidden = !STATUS.sort_count; sb.textContent = STATUS.sort_count; }
    fillArena();
  };
  anim.onfinish = finish;
  setTimeout(finish, 650);  // animations can stall in a background window; never lose a sort
}

function confetti(el) {
  const r = el.getBoundingClientRect();
  const colors = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"];
  for (let i = 0; i < 26; i++) {
    const d = document.createElement("div");
    d.className = "confetti";
    d.style.background = colors[i % colors.length];
    d.style.left = r.left + r.width / 2 + "px"; d.style.top = r.top + "px";
    document.body.appendChild(d);
    const ang = Math.random() * Math.PI - Math.PI, dist = 60 + Math.random() * 90;
    d.animate([{ transform: "translate(0,0) rotate(0)", opacity: 1 },
      { transform: `translate(${Math.cos(ang) * dist}px,${Math.sin(ang) * dist + 80}px) rotate(${Math.random() * 720}deg)`, opacity: 0 }],
      { duration: 900 + Math.random() * 400, easing: "cubic-bezier(.2,.6,.4,1)" }).onfinish = () => d.remove();
  }
}

// =====================================================================
// INSIGHTS: where the money went + projection
// =====================================================================
// Fixed color per role (never by rank): see dataviz reference palette
const SLICE_COLORS = ["var(--series-2)", "var(--series-4)", "var(--series-5)", "var(--series-7)", "var(--series-8)"];
function sliceColor(s, i) {
  if (s.kind === "saved") return "var(--series-1)";
  if (s.kind === "invested") return "var(--series-3)";
  if (s.key === "other_spending") return "var(--neutral)";
  return SLICE_COLORS[i] || "var(--neutral)";
}

function donut(slices, total, size = 230) {
  const r = size / 2, ir = r * 0.62;
  let a0 = -Math.PI / 2;
  const arcs = slices.map((s, i) => {
    const frac = s.amount / total, a1 = a0 + frac * Math.PI * 2;
    const large = a1 - a0 > Math.PI ? 1 : 0;
    const p = (a, rr) => `${r + rr * Math.cos(a)},${r + rr * Math.sin(a)}`;
    const d = frac >= 0.9999
      ? `M${p(0, r)}A${r},${r} 0 1 1 ${p(Math.PI, r)}A${r},${r} 0 1 1 ${p(0, r)}M${p(0, ir)}A${ir},${ir} 0 1 0 ${p(Math.PI, ir)}A${ir},${ir} 0 1 0 ${p(0, ir)}Z`
      : `M${p(a0, r)}A${r},${r} 0 ${large} 1 ${p(a1, r)}L${p(a1, ir)}A${ir},${ir} 0 ${large} 0 ${p(a0, ir)}Z`;
    a0 = a1;
    const tipHtml = `<b>${esc(s.label)}</b><br>${fmt(s.amount)} · ${(frac * 100).toFixed(1)}% of income` +
      (s.detail ? "<br>" + s.detail.slice(0, 8).map((x) => `${esc(x.label)} ${fmt(x.amount)}`).join("<br>") : "");
    return `<path d="${d}" fill="${s.color}" stroke="var(--surface)" stroke-width="2" data-tip="${esc(tipHtml)}" class="slice"/>`;
  }).join("");
  return `<svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" role="img" aria-label="Where your income went">${arcs}</svg>`;
}

function barSeries(points, { W = 700, H = 200, key, fmtV = (v) => v, tipV = null, goal = null, color = "var(--series-1)", label = (p) => p.month,
  selected = "", attrs = null } = {}) {
  const pl = 44, pr = 8, pt = 10, pb = 24;
  const vals = points.map((p) => p[key] ?? 0);
  let lo = Math.min(0, ...vals, goal ?? 0), hi = Math.max(0.01, ...vals, goal ?? 0);
  hi *= 1.1; if (lo < 0) lo *= 1.1;
  const y = (v) => pt + (1 - (v - lo) / (hi - lo)) * (H - pt - pb);
  const gw = (W - pl - pr) / points.length, bw = Math.min(30, gw * 0.62);
  const ticks = niceTicks(lo, hi, 4);
  const bars = points.map((p, i) => {
    const v = p[key], cx = pl + gw * i + gw / 2;
    const extra = attrs ? attrs(p) : "";
    const isSel = selected && p.month === selected, dim = selected && !isSel;
    const lab = `<text x="${cx}" y="${H - 6}" text-anchor="middle" ${isSel ? 'style="fill:var(--text);font-weight:700"' : ""}>${label(p)}</text>`;
    if (v == null) return `<g ${extra}><rect x="${cx - gw / 2}" y="${pt}" width="${gw}" height="${H - pt}" fill="transparent"/>${lab}</g>`;
    const y0 = y(0), y1 = y(v), top = Math.min(y0, y1), h = Math.max(1, Math.abs(y1 - y0));
    const rnd = Math.min(4, h);
    const path = v >= 0
      ? `M${cx - bw / 2},${y0}V${top + rnd}q0,-${rnd} ${rnd},-${rnd}h${bw - 2 * rnd}q${rnd},0 ${rnd},${rnd}V${y0}Z`
      : `M${cx - bw / 2},${y0}V${top + h - rnd}q0,${rnd} ${rnd},${rnd}h${bw - 2 * rnd}q${rnd},0 ${rnd},-${rnd}V${y0}Z`;
    const op = dim ? 0.28 : (goal != null && v < goal ? 0.55 : 1);
    return `<g ${extra} data-tip="${esc(`<b>${label(p, true)}</b><br>${tipV ? tipV(p) : fmtV(v)}`)}"><rect x="${cx - gw / 2}" y="${pt}" width="${gw}" height="${H - pt}" fill="transparent"/>
      <path d="${path}" fill="${color}" opacity="${op}" ${isSel ? 'stroke="var(--text)" stroke-width="1.5"' : ""}/>${lab}</g>`;
  }).join("");
  return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img">
    ${ticks.map((t) => `<line x1="${pl}" x2="${W - pr}" y1="${y(t)}" y2="${y(t)}" stroke="var(--grid)"/><text x="${pl - 6}" y="${y(t) + 4}" text-anchor="end">${fmtV(t)}</text>`).join("")}
    ${goal != null ? `<line x1="${pl}" x2="${W - pr}" y1="${y(goal)}" y2="${y(goal)}" stroke="var(--text-2)" stroke-dasharray="4 3"/><text x="${pl + 4}" y="${y(goal) - 4}" style="fill:var(--text-2)">goal ${fmtV(goal)}</text>` : ""}
    ${bars}</svg>`;
}

function multiLine(series, { W = 760, H = 280, todayIndex = null, fmtV = compact } = {}) {
  // series: [{name, color, dash, points:[{t (ms), v}]}] — one shared y axis
  const pl = 58, pr = 96, pt = 12, pb = 26;
  const all = series.flatMap((s) => s.points);
  const t0 = Math.min(...all.map((p) => p.t)), t1 = Math.max(...all.map((p) => p.t));
  let lo = Math.min(0, ...all.map((p) => p.v)), hi = Math.max(...all.map((p) => p.v));
  hi += (hi - lo) * 0.06 || 1;
  const x = (t) => pl + (t - t0) / (t1 - t0 || 1) * (W - pl - pr);
  const y = (v) => pt + (1 - (v - lo) / (hi - lo)) * (H - pt - pb);
  const ticks = niceTicks(lo, hi, 5);
  const years = [];
  for (let yr = new Date(t0).getFullYear() + 1; yr <= new Date(t1).getFullYear(); yr++) years.push(yr);
  const step = Math.ceil(years.length / Math.max(2, Math.floor((W - pl - pr) / 60)));
  // keep end labels from colliding
  const ends = series.map((s) => ({ s, y: y(s.points.at(-1).v) })).sort((a, b) => a.y - b.y);
  for (let i = 1; i < ends.length; i++) if (ends[i].y - ends[i - 1].y < 14) ends[i].y = ends[i - 1].y + 14;
  const id = "ml" + Math.random().toString(36).slice(2, 7);
  ML_DATA[id] = { series, x, y, t0, t1, pl, pr, W, fmtV };
  return `<div class="chart" data-ml="${id}"><svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img">
    ${ticks.map((t) => `<line x1="${pl}" x2="${W - pr}" y1="${y(t)}" y2="${y(t)}" stroke="var(--grid)"/><text x="${pl - 8}" y="${y(t) + 4}" text-anchor="end">${fmtV(t)}</text>`).join("")}
    ${years.filter((_, i) => i % step === 0).map((yr) => `<text x="${x(new Date(yr, 0, 1).getTime())}" y="${H - 7}" text-anchor="middle">${yr}</text>`).join("")}
    ${todayIndex != null ? `<line x1="${x(todayIndex)}" x2="${x(todayIndex)}" y1="${pt}" y2="${H - pb}" stroke="var(--muted)" stroke-dasharray="2 3"/><text x="${x(todayIndex) + 4}" y="${pt + 10}" style="fill:var(--text-2)">today</text>` : ""}
    ${series.map((s) => `<path d="${s.points.map((p, i) => `${i ? "L" : "M"}${x(p.t).toFixed(1)},${y(p.v).toFixed(1)}`).join("")}" fill="none" stroke="${s.color}" stroke-width="2" ${s.dash ? 'stroke-dasharray="5 4"' : ""} stroke-linejoin="round"/>`).join("")}
    ${ends.map(({ s, y: ly }) => `<text x="${W - pr + 6}" y="${ly + 4}" style="fill:var(--text-2);font-size:11.5px">${esc(s.label || s.name)}</text>`).join("")}
    <line class="xh" y1="${pt}" y2="${H - pb}" stroke="var(--muted)" visibility="hidden"/>
    ${series.map((s, i) => `<circle class="xd" data-i="${i}" r="4" fill="${s.color}" stroke="var(--surface)" stroke-width="2" visibility="hidden"/>`).join("")}
    <rect class="hit" x="${pl}" y="0" width="${W - pl - pr}" height="${H}" fill="transparent"/></svg></div>`;
}
const ML_DATA = {};
function wireMultiLines(root) {
  $$("[data-ml]", root).forEach((el) => {
    const d = ML_DATA[el.dataset.ml]; if (!d) return;
    const svg = $("svg", el), hit = $(".hit", el), xh = $(".xh", el), dots = $$(".xd", el);
    hit.addEventListener("mousemove", (e) => {
      const r = svg.getBoundingClientRect();
      const sx = (e.clientX - r.left) / r.width * d.W;
      const t = d.t0 + (sx - d.pl) / (d.W - d.pl - d.pr) * (d.t1 - d.t0);
      const rows = [];
      let px = null;
      d.series.forEach((s, i) => {
        const near = s.points.reduce((b, p) => Math.abs(p.t - t) < Math.abs(b.t - t) ? p : b, s.points[0]);
        const show = Math.abs(near.t - t) < (d.t1 - d.t0) / 30;
        dots[i].setAttribute("visibility", show ? "visible" : "hidden");
        if (show) { dots[i].setAttribute("cx", d.x(near.t)); dots[i].setAttribute("cy", d.y(near.v)); px = d.x(near.t); rows.push(`<i style="background:${s.color}"></i>${esc(s.name)} <b>${fmt(near.v)}</b>`); }
      });
      if (px == null) { tip.hidden = true; return; }
      xh.setAttribute("x1", px); xh.setAttribute("x2", px); xh.setAttribute("visibility", "visible");
      tip.innerHTML = `<b>${new Date(t).toLocaleDateString(undefined, { month: "short", year: "numeric" })}</b><div class="legend" style="flex-direction:column;gap:2px;margin:4px 0 0">${rows.map((r) => `<span>${r}</span>`).join("")}</div>`;
      tip.hidden = false;
      tip.style.left = Math.min(e.clientX + 14, innerWidth - tip.offsetWidth - 8) + "px"; tip.style.top = e.clientY + 14 + "px";
    });
    hit.addEventListener("mouseleave", () => { tip.hidden = true; xh.setAttribute("visibility", "hidden"); dots.forEach((d) => d.setAttribute("visibility", "hidden")); });
  });
}

// The pie for a period: the last 12 months, or one month when you pick it
function donutBody(s, month = "") {
  const slices = s.slices.filter((x) => x.amount > 0).map((x, i) => ({ ...x, color: sliceColor(x, i) }));
  const shownTotal = Math.max(s.income, slices.reduce((a, x) => a + x.amount, 0)) || 1;
  const period = month ? "this month" : "in the last 12 months";
  if (!(s.income > 0) && !slices.length) return `<div class="empty">Nothing recorded ${period}.</div>`;
  return `<div class="period-stats">
      <span>Income <b>${fmt(s.income)}</b></span><span>Spent <b>${fmt(s.spending)}</b></span>
      <span>Invested <b>${fmt(s.invested)}</b></span><span>Savings rate <b class="${s.savings_rate < 0 ? "down" : ""}">${PCT(s.savings_rate)}</b></span></div>
    <div class="donut-wrap">
      <div style="position:relative;flex:none">${donut(slices, shownTotal)}
        <div class="donut-center"><div class="tiny muted">${month ? "Income that month" : "Income"}</div><b>${fmt(s.income)}</b></div></div>
      <table class="legend-table">${slices.map((x) => `<tr data-tip="${esc(`<b>${esc(x.label)}</b><br>${fmt(x.amount)}` +
        (x.detail ? "<br>" + x.detail.slice(0, 8).map((d) => `${esc(d.label)} ${fmt(d.amount)}`).join("<br>") : ""))}"><td><i class="sw" style="background:${x.color}"></i>${esc(x.label)}</td>
        <td class="num">${fmt(x.amount)}</td><td class="num muted">${(x.amount / shownTotal * 100).toFixed(0)}%</td></tr>`).join("")}
        ${s.saved < 0 ? `<tr><td colspan="3" class="down tiny">You spent and invested ${fmt(-s.saved)} more than you earned ${period} (drawn from savings).</td></tr>` : ""}
        ${!(s.income > 0) ? `<tr><td colspan="3" class="tiny muted">No income recorded ${period}, so percentages are of what went out.</td></tr>` : ""}
      </table></div>
    ${Object.keys(s.extra_income || {}).length ? `<p class="tiny muted">Income includes ${Object.entries(s.extra_income).map(([k, v]) => `${esc(k)} (${fmt(v)})`).join(", ")}.</p>` : ""}`;
}

PAGES.insights = async (main) => {
  const s = await api("/api/insights/summary");
  const slices = s.slices.filter((x) => x.amount > 0).map((x, i) => ({ ...x, color: sliceColor(x, i) }));
  const shownTotal = Math.max(s.income, slices.reduce((a, x) => a + x.amount, 0)) || 1;
  const kept = s.income - s.spending;
  const prefs = JSON.parse(localStorage.getItem("projPrefs") || '{"years":10,"ret":7,"infl":3,"raise":3,"extra":0,"real":false}');
  main.innerHTML = `
    <h1>Insights</h1><p class="sub">The last 12 months (${new Date(s.start + "T00:00").toLocaleDateString(undefined, { month: "short", year: "numeric" })} to today), and where your habits lead.</p>
    <div class="grid g4" style="grid-template-columns:repeat(5,minmax(0,1fr))">
      <div class="card stat"><div class="label">Income</div><div class="value">${fmt(s.income)}</div><div class="delta">${fmt(s.income / 12)}/mo avg</div></div>
      <div class="card stat"><div class="label">Spending</div><div class="value">${fmt(s.spending)}</div><div class="delta">${PCT(s.spending / (s.income || 1))} of income</div></div>
      <div class="card stat"><div class="label">Invested</div><div class="value">${fmt(s.invested)}</div><div class="delta">${PCT(s.invested / (s.income || 1))} of income${s.payroll_401k_estimate ? ` + ~${fmt(s.payroll_401k_estimate)} 401(k) from paychecks` : ""}</div></div>
      <div class="card stat"><div class="label">Kept as savings</div><div class="value ${s.saved < 0 ? "down" : ""}">${fmt(s.saved)}</div><div class="delta">${fmt(s.to_savings_accounts)} moved into savings accounts</div></div>
      <div class="card stat"><div class="label">Savings rate</div><div class="value">${PCT(s.savings_rate)}</div><div class="delta">(income − spending) ÷ income</div></div>
    </div>
    <div class="grid" style="margin-top:16px;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr)">
      <div class="card"><h2 id="donutTitle">Where your income went</h2>
        <div class="month-chips" id="monthChips">
          <button class="chip active" data-pick="">12 months</button>
          ${s.monthly.slice().reverse().map((m) => `<button class="chip" data-pick="${m.month}">${new Date(m.month + "-15").toLocaleString(undefined, { month: "short" })}${m.month.slice(0, 4) !== String(new Date().getFullYear()) ? " ’" + m.month.slice(2, 4) : ""}</button>`).join("")}
        </div>
        <div id="donutBox">${donutBody(s)}</div>
      </div>
      <div class="card"><h2>Savings rate by month</h2><div class="legend"><span><i style="background:var(--series-1)"></i>Kept that month</span><span class="muted">faded = below 20% · tap a month for its breakdown</span></div>
        <div data-sr></div>
        <details style="margin-top:8px"><summary class="tiny muted">All spending categories</summary>
          <table>${s.categories.map((c) => `<tr><td>${esc(c.label)}</td><td class="num">${fmt(c.amount)}</td><td class="num muted">${fmt(c.amount / 12)}/mo</td></tr>`).join("")}</table></details>
      </div>
    </div>
    <div class="card" style="margin-top:16px">
      <div class="row"><h2 style="margin:0">Where you're heading</h2><span class="spacer"></span>
        <label class="field" style="width:150px">Years ahead <input type="range" id="pYears" min="1" max="40" value="${prefs.years}"><span id="pYearsV" class="tiny">${prefs.years} years</span></label>
        <label class="field" style="width:96px">Return %/yr<input type="number" id="pRet" step="0.5" value="${prefs.ret}"></label>
        <label class="field" style="width:96px">Inflation %<input type="number" id="pInfl" step="0.5" value="${prefs.infl}"></label>
        <label class="field" style="width:96px">Raises %/yr<input type="number" id="pRaise" step="0.5" value="${prefs.raise}"></label>
        <label class="field" style="width:130px">Extra investing $/mo<input type="number" id="pExtra" step="50" value="${prefs.extra}"></label>
        <label class="row tiny" style="margin-top:14px"><input type="checkbox" id="pReal" ${prefs.real ? "checked" : ""}> Today's dollars</label>
      </div>
      <div id="projBox" style="margin-top:12px"></div>
    </div>`;
  const srBox = $("[data-sr]", main);
  let picked = "";
  const pickMonth = async (month) => {
    picked = month;
    $$("#monthChips .chip", main).forEach((c) => c.classList.toggle("active", c.dataset.pick === month));
    const chip = $(`#monthChips .chip[data-pick="${month}"]`, main);
    if (chip) chip.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
    drawSR();
    const box = $("#donutBox");
    box.style.opacity = ".4";
    try {
      const d = month ? await api("/api/insights/summary?month=" + month) : s;
      if (picked !== month) return;  // a newer click won
      $("#donutTitle").textContent = month
        ? `Where your income went in ${new Date(month + "-15").toLocaleString(undefined, { month: "long", year: "numeric" })}`
        : "Where your income went";
      box.innerHTML = donutBody(d, month);
    } finally { box.style.opacity = ""; }
  };
  $$("#monthChips .chip", main).forEach((c) => c.onclick = () => pickMonth(c.dataset.pick === picked ? "" : c.dataset.pick));
  srBox.addEventListener("click", (e) => {
    const g = e.target.closest("[data-month]");
    if (g) pickMonth(g.dataset.month === picked ? "" : g.dataset.month);
  });
  const drawSR = () => {
    // Clamp to ±100% so one odd month (tiny income) doesn't flatten the rest; tooltip shows the real value
    srBox.innerHTML = barSeries(s.monthly.map((m) => ({ ...m, sr: m.savings_rate == null ? null : Math.max(-100, Math.min(100, m.savings_rate * 100)) })), {
      W: Math.max(300, srBox.clientWidth), key: "sr", goal: 20, fmtV: (v) => v.toFixed(0) + "%",
      selected: picked, attrs: (p) => `data-month="${p.month}" style="cursor:pointer"`,
      tipV: (p) => `Kept ${(p.savings_rate * 100).toFixed(0)}% of ${fmt(p.income)} income<br>Spent ${fmt(p.spending)}${p.invested ? `, invested ${fmt(p.invested)}` : ""}`,
      label: (p, long) => new Date(p.month + "-15").toLocaleString(undefined, long ? { month: "long", year: "numeric" } : { month: srBox.clientWidth < 520 ? "narrow" : "short" }),
    });
  };
  drawSR();
  const readPrefs = () => ({ years: +$("#pYears").value, ret: +$("#pRet").value, infl: +$("#pInfl").value, raise: +$("#pRaise").value, extra: +$("#pExtra").value, real: $("#pReal").checked });
  let pt;
  const reload = () => { clearTimeout(pt); pt = setTimeout(async () => {
    const p = readPrefs(); localStorage.setItem("projPrefs", JSON.stringify(p));
    $("#pYearsV").textContent = p.years + " years";
    const d = await api(`/api/insights/projection?years=${p.years}&ret=${p.ret}&infl=${p.infl}&raise=${p.raise}&extra=${p.extra}`);
    drawProjection($("#projBox"), d, p.real);
  }, 150); };
  ["#pYears", "#pRet", "#pInfl", "#pRaise", "#pExtra", "#pReal"].forEach((sel) => $(sel).addEventListener("input", reload));
  reload();
  window.onresize = () => { if (location.hash.startsWith("#insights")) { drawSR(); reload(); } };
};

function drawProjection(box, d, real) {
  const ms = (iso) => new Date(iso + "T00:00").getTime();
  const defl = (p) => real ? (p.deflator || 1) : 1;
  const proj = d.points;
  const mk = (key) => proj.map((p) => ({ t: ms(p.date), v: p[key] / defl(p) }));
  const hist = d.history.map((h) => ({ t: ms(h.date), v: h.net }));
  const series = [
    { name: "Net worth (actual)", label: "History", color: "var(--series-1)", points: hist.length > 1 ? hist : [] },
    { name: "Net worth", color: "var(--series-1)", dash: true, points: mk("net") },
    { name: "Investments", color: "var(--series-3)", dash: true, points: mk("investments") },
    { name: "Cash", color: "var(--series-2)", dash: true, points: mk("cash") },
  ].filter((s) => s.points.length);
  if (proj[0].debt > 0) series.push({ name: "Debt", color: "var(--series-8)", dash: true, points: mk("debt") });
  const a = d.assumptions, last = proj.at(-1);
  const W = Math.max(320, box.clientWidth);
  const spend = proj.map((p) => ({ month: p.date.slice(0, 7), v: p.spending / defl(p) })).filter((_, i) => i % 4 === 0);
  box.innerHTML = `
    <div class="grid g4">
      <div class="stat"><div class="label">Net worth in ${a.years} yr</div><div class="value">${fmt(last.net / defl(last))}</div><div class="delta">from ${fmt(proj[0].net)} today</div></div>
      <div class="stat"><div class="label">Investments</div><div class="value">${fmt(last.investments / defl(last))}</div><div class="delta">investing ${fmt(a.investing_monthly)}/mo now</div></div>
      <div class="stat"><div class="label">Cash</div><div class="value">${fmt(last.cash / defl(last))}</div><div class="delta">leftover ${fmt(a.income_monthly - a.spending_monthly - a.investing_monthly)}/mo stays in cash</div></div>
      <div class="stat"><div class="label">Yearly spending then</div><div class="value">${fmt(last.spending / defl(last))}</div><div class="delta">${real ? "in today's dollars" : `vs ${fmt(proj[0].spending)} now (${a.inflation * 100}% inflation)`}</div></div>
    </div>
    <div class="legend" style="margin-top:12px">${series.map((s) => `<span><i style="background:${s.color}"></i>${esc(s.name)}${s.dash ? " (projected)" : ""}</span>`).join("")}</div>
    ${multiLine(series, { W, H: 300, todayIndex: ms(proj[0].date) })}
    <div class="grid g2" style="margin-top:12px">
      <div><h3>Milestones</h3>
        ${d.milestones.length ? `<ul class="tiny" style="padding-left:18px;margin:4px 0">${d.milestones.map((m) => `<li>Net worth passes <b>${fmt(m.amount)}</b> in about <b>${fmtMonths(m.months)}</b></li>`).join("")}</ul>` : `<div class="tiny muted">No round-number milestones in this window.</div>`}
        ${d.debt_free_months ? `<div class="tiny">Loans paid off in about <b>${fmtMonths(d.debt_free_months)}</b>; after that the payment adds to your savings.</div>` : ""}
      </div>
      <div class="tiny muted"><h3 style="color:var(--text)">Assumptions</h3>
        Starts from your last ${a.months_of_history} months: income ${fmt(a.income_monthly)}/mo, spending ${fmt(a.spending_monthly)}/mo, investing ${fmt(a.investing_monthly)}/mo${a.extra_monthly ? ` (incl. +${fmt(a.extra_monthly)} extra)` : ""}.
        Investments earn ${(a.annual_return * 100).toFixed(1)}%/yr; cash earns nothing. Spending rises with inflation, income with raises, and you keep investing the same share of income.
        Real markets swing a lot from year to year: treat this as a direction, not a promise.
        Raise "Extra investing" to see what moving idle cash into investments does.</div>
    </div>`;
  wireMultiLines(box);
}
const fmtMonths = (m) => m < 12 ? `${m} month${m === 1 ? "" : "s"}` : m === 12 ? "1 year" : `${(m / 12).toFixed(m % 12 ? 1 : 0)} years`;

// =====================================================================
// GOALS + companion
// =====================================================================
// Late at night the room dims and the companion sleeps (window.__forceNight overrides the clock, for trying it out)
const isNightNow = () => { if (window.__forceNight !== undefined) return !!window.__forceNight; const h = new Date().getHours(); return h >= 22 || h < 6; };
let PAINT = {};   // colours you picked for things in the room: {key: "#rrggbb"}
const paint = (key, def) => PAINT[key] || def;
function shade(hex, f) {   // f < 0 darker, f > 0 lighter
  const n = parseInt(String(hex).slice(1), 16) || 0;
  return "#" + [n >> 16, (n >> 8) & 255, n & 255].map((c) => Math.max(0, Math.min(255, Math.round(f < 0 ? c * (1 + f) : c + (255 - c) * f))).toString(16).padStart(2, "0")).join("");
}
const GOAL_STATUS = {
  done: ["✓", "Done", "var(--good)"], ahead: ["▲", "Ahead", "var(--good)"], on_track: ["●", "On track", "var(--series-1)"],
  behind: ["▼", "Behind", "var(--warning)"], missed: ["✕", "Missed", "var(--critical)"],
};
const MOOD_TEXT = {
  plant: { thriving: "Lush and growing. Your goals are on track.", content: "Healthy. A couple of goals could use attention.", thirsty: "Thirsty. Some goals are slipping; catching up waters it.", wilting: "Wilting. Most goals are behind. Small wins will perk it up." },
  pet: { thriving: "Bouncing around happily. Great month!", content: "Content. Keep it up.", thirsty: "A bit glum. Some goals are behind; hitting one cheers it up.", wilting: "Feeling down. Most goals are behind; a small win will cheer it up." },
};
const COSMETIC_LABEL = { terracotta: "Terracotta", ocean: "Ocean blue", midnight: "Midnight", ladybug: "Ladybug friend", butterfly: "Butterfly friend", snail: "Snail friend", party: "Party hat", beanie: "Cozy beanie", crown: "Tiny crown", fireflies: "Fireflies", sparkles: "Sparkles", moon: "Moonlight" };

PAGES.goals = async (main) => {
  const d = await api("/api/goals");
  window.__goalsData = d;
  if (!d.kind) return companionChooser(main);
  const xpIn = d.xp - d.level_floor, xpSpan = (d.next_level_xp ?? d.xp) - d.level_floor || 1;
  main.innerHTML = `
    <h1>Goals</h1><p class="sub">Set money goals and keep ${esc(d.name || "your " + d.kind)} happy by hitting them. Each month you meet a goal it grows; falling behind makes it ${d.kind === "plant" ? "droop" : "mopey"}.</p>
    <div class="card room-card">
      <div class="room-view">${drawRoom(d)}</div>
      <div class="room-side">
        <div class="row"><h2 style="margin:0">${esc(d.name || (d.kind === "plant" ? "Your plant" : "Your pet"))}</h2><span class="pill">Level ${d.level}</span>
          <span class="spacer"></span><span class="coins" title="Coins: you earn one for every XP point">🪙 ${d.coins}</span></div>
        <div class="tiny muted" style="margin:4px 0 8px">${esc(MOOD_TEXT[d.kind][d.mood])}</div>
        <div class="tiny muted">Earn coins by hitting goals (each XP point = 1 coin) and by sorting (1 coin per 10 sorts, ${d.coins_from_sorting} so far), then upgrade ${esc(d.name || "its")}'s home. ${d.room.owned_count} of ${d.room.total_items} items collected.</div>
        <div class="shop">${d.room.slots.map((s) => shopRow(s, d)).join("")}</div>
      </div>
    </div>
    <div class="grid" style="grid-template-columns:340px 1fr;align-items:start;margin-top:16px">
      <div class="card companion-card">
        <h2>Care &amp; progress</h2>
        <div class="meter" style="margin-top:10px"><div class="tiny row"><span>Health</span><span class="spacer"></span><span>${d.health}/100</span></div><div class="bar"><div style="width:${d.health}%;background:${d.health >= 60 ? "var(--good)" : d.health >= 35 ? "var(--warning)" : "var(--critical)"}"></div></div></div>
        <div class="meter"><div class="tiny row"><span>Growth</span><span class="spacer"></span><span>${d.next_level_xp ? `${d.xp} / ${d.next_level_xp} XP` : `${d.xp} XP · max level`}</span></div><div class="bar"><div style="width:${Math.min(100, xpIn / xpSpan * 100)}%;background:var(--series-1)"></div></div></div>
        ${d.pending_unlocks.map((u) => `<div class="unlock"><b>🎁 Level ${u.level} reward: pick one</b><div class="row" style="margin-top:6px">${u.options.map((o) => `<button class="btn small secondary" data-pick="${u.level}" data-v="${o.value}">${COSMETIC_LABEL[o.value]}</button>`).join("")}</div></div>`).join("")}
        <h3 style="margin-top:14px">Care log</h3>
        ${d.log.length ? `<div class="care-log">${d.log.map((e) => `<div class="tiny"><span style="color:${e.pass ? "var(--good-text)" : "var(--critical)"}">${e.pass ? "✓" : "✕"}</span> ${esc(e.text)}${e.xp ? ` <span class="muted">+${e.xp} XP</span>` : ""}</div>`).join("")}</div>` : `<div class="tiny muted">Nothing yet. Monthly goals are scored when each month ends.</div>`}
        <details style="margin-top:10px"><summary class="tiny muted">Rename or switch</summary>
          <div class="row" style="margin-top:6px"><input id="cName" value="${esc(d.name || "")}" placeholder="Name" style="width:140px"><button class="btn small secondary" id="cSave">Save</button>
          <button class="btn small secondary" id="cSwitch">Switch to ${d.kind === "plant" ? "pet" : "plant"}</button></div></details>
      </div>
      <div>
        ${d.goals.length ? d.goals.map((g) => goalCard(g, d)).join("") : `<div class="card empty">No goals yet. Pick one below to get started.</div>`}
        <div class="card" style="margin-top:16px"><h2>Add a goal</h2>
          <div class="row" style="flex-wrap:wrap;gap:8px">${d.presets.map((p, i) => `<button class="btn small secondary" data-preset="${i}" title="${esc(p.hint || "")}">+ ${esc(p.name)}</button>`).join("")}</div>
          <form id="goalForm" class="grid g3" style="margin-top:14px">
            <label class="field">Type<select name="kind">
              <option value="contribute">Put $ into something this year</option><option value="save_rate">Save a % of income monthly</option>
              <option value="spend_cap">Cap a category per month</option><option value="balance">Grow an account to $</option><option value="payoff">Pay off a debt</option></select></label>
            <label class="field">Name<input name="name" placeholder="optional"></label>
            <label class="field" data-f="target">Target<input name="target" type="number" step="any"></label>
            <label class="field" data-f="category" hidden>Category<select name="category">${d.categories.map((c) => `<option>${esc(c)}</option>`).join("")}</select></label>
            <label class="field" data-f="accounts" hidden>Account(s)<select name="accounts" multiple size="3">${d.accounts.map((a) => `<option value="${esc(a.id)}">${esc(a.name)} (${fmt(a.balance || 0)})</option>`).join("")}</select></label>
            <label class="field" data-f="match" hidden>Count transfers whose description contains<input name="match_text" placeholder="e.g. VANGUARD or ROTH"></label>
            <label class="field" data-f="by" hidden>By date (optional)<input name="by_date" type="date"></label>
            <div style="align-self:end"><button class="btn">Add goal</button></div>
          </form>
        </div>
      </div>
    </div>`;
  wireGoalsPage(main, d);
};

// ---------------------------------------------------------------- room shop
const SLOT_LABEL = { home: "Home", wall: "Walls", floor: "Floor", window: "Window", bed: "Bed / stand", lamp: "Lighting", shelf: "Shelf", art: "Art", buddy: "Little extra" };
function shopRow(s, d) {
  const cur = s.tiers.find((t) => t.equipped);
  const owned = s.tiers.filter((t) => t.owned);
  const n = s.next;
  let btn = `<span class="tiny muted">Fully upgraded ✨</span>`;
  if (n) {
    btn = n.locked ? `<button class="btn small secondary" disabled title="Reach level ${n.level} to unlock">🔒 ${esc(n.name)} · Lv ${n.level}</button>`
      : `<button class="btn small ${n.affordable ? "" : "secondary"}" data-buy="${n.id}" ${n.affordable ? "" : "disabled"} title="${n.affordable ? "" : `Need ${n.price - d.coins} more coins`}">⬆ ${esc(n.name)} · 🪙 ${n.price}</button>`;
  }
  const pips = s.tiers.slice(1).map((t) => `<i class="pip ${t.owned ? "on" : ""}" title="${esc(t.name)}"></i>`).join("");
  return `<div class="shop-row"><div><div class="tiny muted">${SLOT_LABEL[s.slot]} <span class="pips">${pips}</span></div>
      ${owned.length > 1 ? `<select class="tiny" data-equip>${owned.map((t) => `<option value="${t.id}" ${t.equipped ? "selected" : ""}>${esc(t.name)}</option>`).join("")}</select>` : `<div class="tiny">${esc(cur.name)}</div>`}</div>
    <div style="text-align:right">${btn}</div></div>`;
}

function drawRoom(d) {
  PAINT = d.colors || {};
  if (d.night === undefined) { d.night = isNightNow(); d.asleep = d.night; }
  const eq = d.room.equipped, has = (id) => Object.values(eq).includes(id);
  const home = eq.home, wall = eq.wall, floor = eq.floor;
  const homeBase = {
    home_corner: { wall: "#efe3cf", floor: "#c9a77c", trim: "#d9c4a3" },
    home_studio: { wall: "#e6ecef", floor: "#b98b5e", trim: "#cfd8dc" },
    home_loft: { wall: "#f3e7da", floor: "#9c6b45", trim: "#b5654a" },
    home_cottage: { wall: "#f4ecd6", floor: "#8a5a3b", trim: "#7a5a3a" },
    home_tree: { wall: "#c99a62", floor: "#7b4e2c", trim: "#5d3a1f" },
  }[home];
  const homeStyle = { wall: paint("wall", homeBase.wall), floor: paint("floor", homeBase.floor), trim: paint("trim", homeBase.trim) };
  const W = 360, H = 260, FY = 186;
  let defs = `<pattern id="pStripe" width="18" height="10" patternUnits="userSpaceOnUse"><rect width="9" height="10" fill="#000" opacity=".06"/></pattern>
    <pattern id="pFloral" width="28" height="28" patternUnits="userSpaceOnUse"><circle cx="7" cy="7" r="3" fill="#e87ba4" opacity=".45"/><circle cx="21" cy="21" r="3" fill="#6fae5a" opacity=".45"/></pattern>
    <pattern id="pPlank" width="40" height="12" patternUnits="userSpaceOnUse"><rect width="40" height="12" fill="none" stroke="#000" stroke-opacity=".12"/></pattern>
    <linearGradient id="gSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fd0f5"/><stop offset="1" stop-color="#dff0fb"/></linearGradient>
    <linearGradient id="gWin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${d.night ? "#111c47" : "#9fd0f5"}"/><stop offset="1" stop-color="${d.night ? "#3b4c8f" : "#dff0fb"}"/></linearGradient>`;
  let s = `<rect width="${W}" height="${FY}" fill="${homeStyle.wall}" data-paint="wall"/>`;
  // Each piece of furniture is its own group so it can be dragged around (room.js) and keeps its saved spot
  const spot = (d.room.layout && d.room.layout.furn) || {};
  let mark = 0;
  const open = () => { mark = s.length; };
  const close = (slot) => {
    const html = s.slice(mark), o = spot[slot] || [0, 0];
    if (html) s = s.slice(0, mark) + `<g class="furn" data-furn="${slot}" transform="translate(${+o[0] || 0} ${+o[1] || 0})">${html}</g>`;
  };
  if (wall === "wall_stripe") s += `<rect width="${W}" height="${FY}" fill="url(#pStripe)"/>`;
  if (wall === "wall_floral") s += `<rect width="${W}" height="${FY}" fill="url(#pFloral)"/>`;
  if (wall === "wall_sky") s += `<rect width="${W}" height="${FY}" fill="${paint("wall", "#1f2a55")}"/>` + [[30, 30], [80, 70], [140, 22], [210, 60], [280, 30], [330, 90], [250, 120], [60, 140]].map(([x, y], i) => `<circle class="firefly" style="animation-delay:${i * .4}s" cx="${x}" cy="${y}" r="1.8" fill="#fff"/>`).join("") + `<circle cx="300" cy="40" r="10" fill="#f3e7b4"/>`;
  if (home === "home_loft") s += `<rect x="0" y="0" width="${W}" height="${FY}" fill="none"/>` + Array.from({ length: 6 }, (_, r) => Array.from({ length: 4 }, (_, c) => `<rect x="${250 + c * 26 + (r % 2) * 13}" y="${70 + r * 18}" width="24" height="16" fill="#b5654a" opacity=".35" rx="2"/>`).join("")).join("");
  if (home === "home_cottage") s += `<rect y="0" width="${W}" height="10" fill="${homeStyle.trim}"/><rect x="0" y="0" width="10" height="${FY}" fill="${homeStyle.trim}"/><rect x="${W - 10}" y="0" width="10" height="${FY}" fill="${homeStyle.trim}"/>`;
  if (home === "home_tree") s += `<rect width="${W}" height="${FY}" fill="url(#pPlank)"/><path d="M0 0 Q 40 30 0 60 M${W} 0 Q ${W - 50} 40 ${W} 80" stroke="#4f8a3a" stroke-width="16" fill="none"/>`;
  if (home === "home_studio") s += `<line x1="180" y1="0" x2="180" y2="16" stroke="#888"/><circle cx="180" cy="20" r="6" fill="#f6d046"/>`;
  open();  // window (left)
  const win = eq.window;
  if (win !== "win_none") {
    const [x, y, w, h] = win === "win_bay" ? [22, 28, 108, 96] : win === "win_curtain" ? [30, 36, 72, 72] : [36, 44, 58, 54];
    s += `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#gWin)" stroke="${homeStyle.trim}" stroke-width="5" rx="3"/>${d.night ? `<circle cx="${x + w * .2}" cy="${y + h * .26}" r="1.3" fill="#fff"/><circle cx="${x + w * .62}" cy="${y + h * .16}" r="1" fill="#fff"/><circle cx="${x + w * .84}" cy="${y + h * .42}" r="1.2" fill="#fff"/>${win === "win_bay" ? "" : `<circle cx="${x + w * .74}" cy="${y + h * .76}" r="6" fill="#f3e7b4"/>`}` : ""}`;
    if (win === "win_bay") s += `<path d="M${x} ${y + h - 18} q30 -22 54 -6 q26 -18 54 4 V${y + h} H${x}Z" fill="#7cbf6a"/><circle cx="${x + 82}" cy="${y + 22}" r="9" fill="${d.night ? "#f3e7b4" : "#f6d046"}"/>`;
    s += `<line x1="${x + w / 2}" y1="${y}" x2="${x + w / 2}" y2="${y + h}" stroke="${homeStyle.trim}" stroke-width="3"/><line x1="${x}" y1="${y + h / 2}" x2="${x + w}" y2="${y + h / 2}" stroke="${homeStyle.trim}" stroke-width="3"/>`;
    if (win === "win_curtain" || win === "win_bay") s += `<path d="M${x - 8} ${y - 6} q10 ${h / 2} 0 ${h + 10} h14 q-6 -${h / 2} 4 -${h + 10}z" fill="${paint("curtain", "#e34948")}" opacity=".85" data-paint="curtain"/><path d="M${x + w + 8} ${y - 6} q-10 ${h / 2} 0 ${h + 10} h-14 q6 -${h / 2} -4 -${h + 10}z" fill="${paint("curtain", "#e34948")}" opacity=".85" data-paint="curtain"/><rect x="${x - 12}" y="${y - 9}" width="${w + 24}" height="4" rx="2" fill="#7a5a3a"/>`;
  }
  close("window"); open();  // art (centre wall)
  const art = eq.art;
  if (art === "art_doodle") s += `<rect x="160" y="34" width="40" height="32" fill="#fff" stroke="${paint("frame", "#7a5a3a")}" stroke-width="3" data-paint="frame" data-paint-attr="stroke"/><path d="M166 58 q8 -14 14 -4 q6 -10 14 2" stroke="#2a78d6" stroke-width="2" fill="none"/>`;
  if (art === "art_landscape") s += `<rect x="148" y="28" width="66" height="44" fill="url(#gSky)" stroke="${paint("frame", "#b07600")}" stroke-width="4" data-paint="frame" data-paint-attr="stroke"/><path d="M150 70 l18 -20 l14 12 l12 -18 l18 26z" fill="#4f8a3a"/>`;
  if (art === "art_gallery") s += `<rect x="140" y="26" width="34" height="26" fill="#fde2ea" stroke="${paint("frame", "#333333")}" stroke-width="2" data-paint="frame" data-paint-attr="stroke"/><rect x="180" y="22" width="40" height="34" fill="#dbeafe" stroke="${paint("frame", "#333333")}" stroke-width="2" data-paint="frame" data-paint-attr="stroke"/><rect x="152" y="58" width="26" height="22" fill="#fef3c7" stroke="${paint("frame", "#333333")}" stroke-width="2" data-paint="frame" data-paint-attr="stroke"/><circle cx="200" cy="39" r="7" fill="#eb6834"/><path d="M144 48 l8 -10 l8 10z" fill="#1baf7a"/>`;
  close("art"); open();  // shelf (right wall)
  const shelf = eq.shelf;
  if (shelf !== "shelf_none") {
    s += `<rect x="252" y="96" width="84" height="6" fill="${paint("shelf", "#7a5a3a")}" data-paint="shelf"/>`;
    if (shelf === "shelf_small") s += `<rect x="262" y="78" width="10" height="18" fill="#2a78d6"/><rect x="274" y="82" width="8" height="14" fill="#eb6834"/>`;
    if (shelf === "shelf_books" || shelf === "shelf_trophy") {
      s += `<rect x="252" y="62" width="84" height="5" fill="${paint("shelf", "#7a5a3a")}"/>` + ["#2a78d6", "#eb6834", "#1baf7a", "#6250d6", "#e87ba4"].map((c, i) => `<rect x="${258 + i * 9}" y="${80 - (i % 2) * 3}" width="8" height="${16 + (i % 2) * 3}" fill="${c}"/>`).join("");
    }
    if (shelf === "shelf_trophy") {
      const n = Math.max(1, Math.min(5, d.goals_done || 1));
      for (let i = 0; i < n; i++) s += `<g transform="translate(${266 + i * 15} 50)"><path d="M-5 0 h10 l-1 6 q-4 3 -8 0z" fill="#eda100"/><rect x="-1.5" y="6" width="3" height="4" fill="#eda100"/><rect x="-4" y="10" width="8" height="2" fill="#b07600"/></g>`;
    }
  }
  close("shelf");
  // floor
  s += `<rect y="${FY}" width="${W}" height="${H - FY}" fill="${homeStyle.floor}" data-paint="floor"/><rect y="${FY}" width="${W}" height="${H - FY}" fill="url(#pPlank)"/><rect y="${FY - 4}" width="${W}" height="5" fill="${homeStyle.trim}" data-paint="trim"/>`;
  open();
  if (floor === "floor_woven") s += `<rect x="110" y="${FY + 30}" width="140" height="30" rx="4" fill="${paint("rug", "#d9b382")}" data-paint="rug"/><rect x="110" y="${FY + 30}" width="140" height="30" rx="4" fill="url(#pStripe)"/>`;
  if (floor === "floor_plush") s += `<ellipse cx="180" cy="${FY + 46}" rx="92" ry="20" fill="${paint("rug", "#9fc5f8")}" data-paint="rug"/><ellipse cx="180" cy="${FY + 46}" rx="70" ry="14" fill="${PAINT.rug ? shade(PAINT.rug, .45) : "#cde2fb"}"/>`;
  if (floor === "floor_persian") s += `<rect x="96" y="${FY + 26}" width="168" height="40" rx="3" fill="${paint("rug", "#a3302f")}" data-paint="rug"/><rect x="104" y="${FY + 31}" width="152" height="30" fill="none" stroke="#eda100" stroke-width="2" stroke-dasharray="6 3"/><circle cx="180" cy="${FY + 46}" r="9" fill="#eda100" opacity=".8"/>`;
  close("floor"); open();  // lamp (right floor)
  const lamp = eq.lamp;
  if (lamp === "lamp_desk") s += `<g transform="translate(318 ${FY + 4})"><rect x="-6" y="-6" width="12" height="6" fill="#555"/><rect x="-1.5" y="-26" width="3" height="20" fill="#555"/><path d="M-12 -26 h24 l-6 -14 h-12z" fill="${paint("lamp", "#f6d046")}" data-paint="lamp"/></g>`;
  if (lamp === "lamp_floor") s += `<g transform="translate(320 ${FY + 6})"><ellipse rx="12" ry="4" fill="#555"/><rect x="-2" y="-96" width="4" height="96" fill="#555"/><path d="M-18 -96 h36 l-8 -22 h-20z" fill="${paint("lamp", "#fde68a")}" data-paint="lamp"/><ellipse cx="0" cy="-60" rx="40" ry="50" fill="${paint("lamp", "#fde68a")}" opacity=".18"/></g>`;
  if (lamp === "lamp_string") s += `<path d="M10 14 Q 90 40 180 16 Q 270 40 350 14" stroke="#555" fill="none"/>` + Array.from({ length: 11 }, (_, i) => { const x = 20 + i * 31, y = 20 + Math.sin(i / 10 * Math.PI * 2) * 8 + 6; return `<circle class="firefly" style="animation-delay:${i * .25}s" cx="${x}" cy="${y}" r="4" fill="${(PAINT.lamp ? [PAINT.lamp, shade(PAINT.lamp, .45), shade(PAINT.lamp, -.2)] : ["#f6d046", "#e87ba4", "#9fc5f8"])[i % 3]}"${i ? "" : ' data-paint="lamp"'}/>`; }).join("");
  close("lamp"); open();  // buddy (left floor)
  const buddy = eq.buddy;
  if (buddy === "buddy_ball") s += `<circle cx="62" cy="${FY + 40}" r="11" fill="${paint("toy", "#e34948")}" data-paint="toy"/><path d="M51 ${FY + 40} h22" stroke="#fff" stroke-width="3"/>`;
  if (buddy === "buddy_cactus") s += `<g transform="translate(60 ${FY + 44})"><path d="M-10 0 h20 l-3 14 h-14z" fill="${paint("toy", "#c8693f")}" data-paint="toy"/><rect x="-5" y="-30" width="10" height="30" rx="5" fill="#4f8a3a"/><rect x="-14" y="-20" width="8" height="12" rx="4" fill="#4f8a3a"/><circle cx="0" cy="-31" r="3" fill="#e87ba4"/></g>`;
  if (buddy === "buddy_fish") s += `<g transform="translate(58 ${FY + 20})"><rect x="-26" y="10" width="52" height="34" fill="#7a5a3a"/><rect x="-28" y="-26" width="56" height="36" rx="4" fill="#9fd0f5" opacity=".75" stroke="#cde2fb"/><path class="flutter-fish" d="M-8 -8 q8 -8 16 0 q-8 8 -16 0 l-6 -5 v10z" fill="${paint("toy", "#eb6834")}" data-paint="toy"/></g>`;
  close("buddy"); open();  // bed / stand (centre floor) — companion sits on it
  const bed = eq.bed;
  if (bed === "bed_box") s += `<path d="M120 ${FY + 50} h120 v-40 h-120z" fill="${paint("bed", "#c9a06a")}" data-paint="bed"/><path d="M120 ${FY + 10} l-10 -12 h120 l10 12" fill="${PAINT.bed ? shade(PAINT.bed, -.12) : "#b88d58"}"/>`;
  if (bed === "bed_cushion") s += `<ellipse cx="180" cy="${FY + 40}" rx="74" ry="18" fill="${paint("bed", "#6250d6")}" data-paint="bed"/><ellipse cx="180" cy="${FY + 34}" rx="64" ry="12" fill="${PAINT.bed ? shade(PAINT.bed, .3) : "#9085e9"}"/>`;
  if (bed === "bed_cozy") s += `<rect x="100" y="${FY + 6}" width="160" height="40" rx="8" fill="#8a5a3b"/><rect x="104" y="${FY}" width="152" height="22" rx="8" fill="#f4f1ea"/><rect x="150" y="${FY + 4}" width="110" height="20" rx="6" fill="${paint("bed", "#2a78d6")}" data-paint="bed"/><rect x="96" y="${FY - 30}" width="10" height="76" rx="3" fill="#8a5a3b"/>`;
  if (bed === "bed_canopy") s += `<rect x="96" y="${FY - 110}" width="6" height="160" fill="#7a5a3a"/><rect x="258" y="${FY - 110}" width="6" height="160" fill="#7a5a3a"/><path d="M90 ${FY - 112} h180 q-20 30 -90 30 q-70 0 -90 -30z" fill="${PAINT.bed ? shade(PAINT.bed, .3) : "#e87ba4"}" opacity=".85"/><rect x="100" y="${FY + 6}" width="160" height="40" rx="8" fill="#8a5a3b"/><rect x="104" y="${FY}" width="152" height="22" rx="8" fill="#fdf2f8"/><rect x="150" y="${FY + 4}" width="110" height="20" rx="6" fill="${paint("bed", "#d55181")}" data-paint="bed"/>`;
  close("bed"); open();  // water bowl (pets only): how full it is shows how thirsty your pet is
  if (d.kind === "pet" && d.stage > 0 && d.care) {
    const lvl = Math.max(0, Math.min(1, d.care.water / 100)), bc = paint("bowl", "#d9534f");
    s += `<g transform="translate(286 ${FY + 60})"><ellipse cx="0" cy="4" rx="24" ry="4.5" fill="#000" opacity=".12"/><path d="M-21 -9 h42 l-6 13 h-30z" fill="${bc}" data-paint="bowl"/><ellipse cx="0" cy="-9" rx="21" ry="5" fill="${shade(bc, -.22)}"/>${lvl > 0.04 ? `<ellipse cx="0" cy="${(-9 + (1 - lvl) * 2.5).toFixed(1)}" rx="${(11 + 8 * lvl).toFixed(1)}" ry="${(2.4 + 1.8 * lvl).toFixed(1)}" fill="#7cc4f8"/>` : ""}</g>`;
  }
  close("bowl");
  // companion, scaled into the room
  const comp = drawCompanion(d);
  const m = comp.match(/^<svg[^>]*class="([^"]*)"[^>]*>([\s\S]*)<\/svg>$/);
  const lift = bed === "bed_none" ? 0 : bed === "bed_box" ? 34 : bed === "bed_cushion" ? 16 : 26;
  const inner = m ? `<g class="${m[1]}">${m[2]}</g>` : "";
  const snug = d.asleep && d.kind === "pet" && d.stage > 0;   // curled up, asleep
  return `<svg viewBox="0 0 ${W} ${H}" class="room${d.night ? " night" : ""}" role="img" aria-label="${esc(d.name || "Companion")}'s room"><defs>${defs}</defs>${s}
    <g class="pet-move" data-lift="${lift}"><g transform="translate(${180 - 130 * 0.8} ${FY + 50 - lift - 245 * 0.8}) scale(0.8)">${snug ? `<g transform="translate(130 238) scale(1.16 .78) translate(-130 -238)">${inner}</g>` : inner}</g></g>${d.night ? `<rect class="room-night" width="${W}" height="${H}" fill="#0a1238" opacity=".4" pointer-events="none"/>` : ""}<g class="room-fx"></g></svg>`;
}

// What counts toward a goal, with a way to take a transaction out (or put it back) or fix its category
function goalCountedTable(g, d) {
  const row = (c, off) => {
    const cats = c.category && !d.categories.includes(c.category) ? [c.category, ...d.categories] : d.categories;
    const acts = c.entry_id ? `<a href="#" data-delentry="${c.entry_id}">remove</a>`
      : off ? `<a href="#" data-count="${g.id}" data-tx="${esc(c.id)}">count again</a>`
      : `${c.kind === "bank" ? `<select class="tiny" data-recat="${esc(c.id)}" data-goal="${g.id}" title="Change this transaction's category everywhere in the app">${cats.map((k) => `<option ${k === c.category ? "selected" : ""}>${esc(k)}</option>`).join("")}</select>` : ""}
        <a href="#" data-uncount="${g.id}" data-tx="${esc(c.id)}" title="Stop counting this toward the goal">don't count</a>`;
    return `<tr class="${off ? "goal-off" : ""}"><td style="white-space:nowrap">${shortDate(c.date)}</td><td class="name">${esc(c.name)}</td>
      <td class="muted">${esc(off ? "not counted" : c.why || "")}</td><td class="num">${fmt2(c.amount)}</td><td class="goal-acts">${acts}</td></tr>`;
  };
  return `<div class="goal-scroll"><table class="tiny t-goal">${(g.counted || []).map((c) => row(c, false)).join("")}${(g.excluded || []).map((c) => row(c, true)).join("")}</table></div>`;
}

function goalCard(g, d) {
  const [icon, label, color] = GOAL_STATUS[g.status];
  let body = "";
  if (g.kind === "contribute") {
    body = `${progressBar(g.progress_pct, g.expected / (g.target || 1))}
      <div class="row tiny"><span><b>${fmt(g.progress)}</b> of ${fmt(g.target)} this year</span><span class="spacer"></span><span class="muted">pace marker = where you'd be if spread evenly</span></div>
      <div class="tiny muted">${g.remaining > 0 ? `${fmt(g.per_month_needed)}/mo for the rest of the year finishes it.` : "Fully funded for this year 🎉"}
        ${/ira/i.test(g.name) ? ` IRA contributions for ${new Date().getFullYear()} are allowed until the April 15 tax deadline next year.` : ""}</div>
      <div class="row" style="margin-top:8px"><input type="number" step="any" placeholder="Amount" data-amt="${g.id}" style="width:110px"><input type="date" data-date="${g.id}" style="width:150px">
        <button class="btn small secondary" data-entry="${g.id}">+ Log a deposit</button><span class="tiny muted">for deposits the app can't see (e.g. straight from your brokerage)</span></div>
      ${g.diag ? `<div class="tiny goal-diag">
        <span>🔗 ${g.diag.linked.length ? "Linked to " + g.diag.linked.map(esc).join(", ") : "<b class=\"down\">Not linked to an account</b> (tap Edit to pick your Roth/IRA)"}${g.diag.repaired ? " <span class=\"up\">(re-found after a reconnect)</span>" : ""}</span>
        <span>🏦 Brokerage-reported: ${g.diag.brokerage_data ? `${g.diag.brokerage_reported} this year` : "no data from Plaid yet (Investments → Grant access)"}</span>
        <span>💸 Bank transfers to it: ${g.diag.bank_side || 0}</span></div>` : ""}
      <details style="margin-top:8px" ${!g.counted?.length || window.__goalOpen == g.id ? "open" : ""}><summary class="tiny muted">${g.counted?.length ? `Counted ${g.counted.length} deposit${g.counted.length === 1 ? "" : "s"} this year` : "Nothing counted yet"}${g.excluded?.length ? ` · ${g.excluded.length} left out by you` : ""}</summary>
        ${g.counted?.length || g.excluded?.length ? `${goalCountedTable(g, d)}
          <div class="tiny muted" style="margin-top:4px">Counted twice, or not a contribution? Use “don't count” to take a line out of this goal. Changing a category changes that transaction everywhere.</div>`
        : `<div class="tiny muted">Link the goal to your Roth account (money sent to its institution is counted automatically), set text that appears on your transfers, or log deposits by hand.</div>`}
      </details>`;
  } else if (g.kind === "save_rate" || g.kind === "spend_cap") {
    const fmtV = (v) => v == null ? "—" : g.kind === "save_rate" ? v.toFixed(0) + "%" : fmt(v);
    body = `<div class="checks">${g.checks.map((c) => `<div class="check ${c.partial ? "partial" : c.pass ? "pass" : "fail"} ${c.scored ? "" : "unscored"}" data-tip="${esc(`<b>${new Date(c.month + "-15").toLocaleString(undefined, { month: "long", year: "numeric" })}</b><br>${fmtV(c.value)}${c.partial ? " so far" : ""}<br>${c.partial ? "in progress" : c.pass ? "met" : "missed"}${c.scored ? "" : " (before this goal)"}`)}">
        <span>${new Date(c.month + "-15").toLocaleString(undefined, { month: "short" })}</span><b>${fmtV(c.value)}</b><i>${c.partial ? "…" : c.pass ? "✓" : "✕"}</i></div>`).join("")}</div>
      <div class="tiny muted" style="margin-top:6px">${g.kind === "save_rate" ? `Goal: keep ${g.target}% of income each month.` : `Goal: ${esc(g.params.category)} at or under ${fmt(g.target)} each month.`}
        ${g.scored ? ` Met ${g.passed} of ${g.scored} months${g.streak > 1 ? ` · ${g.streak}-month streak 🔥` : ""}.` : ""}</div>
      ${g.kind === "spend_cap" && (g.counted?.length || g.excluded?.length) ? `<details style="margin-top:8px" ${window.__goalOpen == g.id ? "open" : ""}><summary class="tiny muted">This month's ${esc(g.params.category)} purchases: ${g.counted.length} counted${g.excluded.length ? ` · ${g.excluded.length} left out by you` : ""}</summary>
        ${goalCountedTable(g, d)}<div class="tiny muted" style="margin-top:4px">In the wrong category? Change it here. Or use “don't count” to leave a purchase out of this goal only.</div></details>` : ""}`;
  } else {
    body = `${progressBar(g.progress_pct)}
      <div class="row tiny"><span>${g.kind === "payoff" ? `<b>${fmt(g.progress)}</b> paid of ${fmt(g.start_balance)} · ${fmt(g.remaining)} left` : `<b>${fmt(g.progress)}</b> of ${fmt(g.target)} · ${fmt(g.remaining)} to go`}</span>
      <span class="spacer"></span>${g.params.by_date ? `<span class="muted">by ${esc(g.params.by_date)}</span>` : ""}</div>`;
  }
  return `<div class="card goal" style="margin-bottom:12px">
    <div class="row"><b>${esc(g.name)}</b><span class="pill"><span style="color:${color}">${icon}</span>${label}</span><span class="spacer"></span>
      <button class="btn small secondary" data-edit="${g.id}" data-target="${g.target}" data-name="${esc(g.name)}" data-kind="${g.kind}">Edit</button>
      <button class="btn small danger" data-delgoal="${g.id}" title="Delete goal">🗑</button></div>
    <div style="margin-top:8px">${body}</div></div>`;
}
function progressBar(pct, pace) {
  return `<div class="pbar"><div class="fill" style="width:${Math.max(0, Math.min(1, pct || 0)) * 100}%"></div>${pace != null ? `<div class="pace" style="left:${Math.min(1, pace) * 100}%" title="Expected by today"></div>` : ""}</div>`;
}

function wireGoalsPage(main, d) {
  const reload = async () => { await refreshStatus(); PAGES.goals(main); };
  $$("[data-pick]", main).forEach((b) => b.onclick = async () => { await run(() => post("/api/companion", { pick_level: +b.dataset.pick, pick_value: b.dataset.v }), "Unlocked!"); reload(); });
  $$("[data-buy]", main).forEach((b) => b.onclick = async () => {
    await run(() => post("/api/companion", { buy: b.dataset.buy }), "Bought! 🎉"); reload();
  });
  $$("[data-equip]", main).forEach((s) => s.onchange = async () => { await run(() => post("/api/companion", { equip: s.value })); reload(); });
  $("#cSave").onclick = async () => { await run(() => post("/api/companion", { name: $("#cName").value }), "Saved"); reload(); };
  $("#cSwitch").onclick = async () => { await run(() => post("/api/companion", { kind: d.kind === "plant" ? "pet" : "plant" })); reload(); };
  $$("[data-delgoal]", main).forEach((b) => b.onclick = async () => { if (!confirm("Delete this goal?")) return; await run(() => del("/api/goals/" + b.dataset.delgoal), "Goal deleted"); reload(); });
  $$("[data-edit]", main).forEach((b) => b.onclick = () => {
    const dlg = $("#dlg"), k = b.dataset.kind;
    const unit = k === "save_rate" ? "Target (% of income)" : k === "spend_cap" ? "Max per month ($)" : "Target ($)";
    dlg.innerHTML = `<h2>Edit goal</h2>
      <label class="field">Name<input id="gName" value="${esc(b.dataset.name)}"></label>
      ${k === "payoff" ? "" : `<label class="field" style="margin-top:10px">${unit}<input id="gTarget" type="number" step="any" value="${b.dataset.target}"></label>
      <p class="tiny muted">If the name mentions the old target, it updates too (unless you change the name yourself).</p>`}
      ${k === "contribute" ? (() => {
        const g = d.goals.find((x) => String(x.id) === b.dataset.edit) || { params: {} };
        const linked = new Set(g.params.account_ids || []);
        const inv = d.accounts.filter((a) => a.type === "investment" || linked.has(a.id));
        return `<label class="field" style="margin-top:10px">Account(s) the money goes into
          <select id="gAccts" multiple size="${Math.min(5, Math.max(2, inv.length))}">${inv.map((a) => `<option value="${esc(a.id)}" ${linked.has(a.id) ? "selected" : ""}>${esc(a.name)}${a.subtype ? " · " + esc(a.subtype) : ""}</option>`).join("")}</select></label>
          <label class="field" style="margin-top:10px">Also count transfers whose description contains (optional)
          <input id="gMatch" value="${esc(g.params.match_text || "")}" placeholder="e.g. VANGUARD"></label>`;
      })() : ""}
      <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn secondary" id="gCancel">Cancel</button><button class="btn" id="gSave">Save</button></div>`;
    dlg.showModal();
    $("#gCancel").onclick = () => dlg.close();
    $("#gSave").onclick = async () => {
      const body = { name: $("#gName").value };
      if ($("#gTarget")) body.target = $("#gTarget").value;
      if ($("#gAccts")) {
        body.account_ids = [...$("#gAccts").selectedOptions].map((o) => o.value);
        body.match_text = $("#gMatch").value;
      }
      dlg.close();
      await run(() => post("/api/goals/" + b.dataset.edit, body), "Goal updated"); reload();
    };
  });
  $$("[data-entry]", main).forEach((b) => b.onclick = async () => {
    const id = b.dataset.entry, amt = $(`[data-amt="${id}"]`).value, dt = $(`[data-date="${id}"]`).value;
    await run(() => post(`/api/goals/${id}/entries`, { amount: amt, date: dt || undefined }), "Logged"); reload();
  });
  const keepOpen = (id) => { window.__goalOpen = id; };
  $$("[data-uncount]", main).forEach((a) => a.onclick = async (e) => { e.preventDefault(); keepOpen(a.dataset.uncount);
    await run(() => post(`/api/goals/${a.dataset.uncount}/exclude`, { id: a.dataset.tx, exclude: true }), "No longer counted toward this goal"); reload(); });
  $$("[data-count]", main).forEach((a) => a.onclick = async (e) => { e.preventDefault(); keepOpen(a.dataset.count);
    await run(() => post(`/api/goals/${a.dataset.count}/exclude`, { id: a.dataset.tx, exclude: false }), "Counted again"); reload(); });
  $$("[data-recat]", main).forEach((s) => s.onchange = async () => { keepOpen(s.dataset.goal);
    await run(() => post("/api/transactions/" + encodeURIComponent(s.dataset.recat), { category: s.value }), "Category changed"); reload(); });
  $$("[data-delentry]", main).forEach((a) => a.onclick = async (e) => { e.preventDefault(); await run(() => del("/api/goal_entries/" + a.dataset.delentry)); reload(); });
  const form = $("#goalForm");
  const sync = () => {
    const k = form.kind.value;
    const show = { target: k !== "payoff", category: k === "spend_cap", accounts: ["contribute", "balance", "payoff"].includes(k), match: k === "contribute", by: ["balance", "payoff"].includes(k) };
    Object.entries(show).forEach(([f, on]) => { $(`[data-f="${f}"]`, form).hidden = !on; });
    $(`[data-f="target"]`, form).firstChild.textContent = k === "save_rate" ? "Target %" : k === "spend_cap" ? "Max $/month" : "Target $";
  };
  form.kind.onchange = sync; sync();
  const submit = async (payload) => { await run(() => post("/api/goals", payload), "Goal added"); reload(); };
  form.onsubmit = (e) => {
    e.preventDefault();
    const k = form.kind.value;
    const params = {};
    if (k === "spend_cap") params.category = form.category.value;
    if (["contribute", "balance", "payoff"].includes(k)) params.account_ids = [...form.accounts.selectedOptions].map((o) => o.value);
    if (k === "contribute") params.match_text = form.match_text.value;
    if (form.by_date.value) params.by_date = form.by_date.value;
    submit({ kind: k, name: form.name.value, target: form.target.value, params });
  };
  $$("[data-preset]", main).forEach((b) => b.onclick = () => {
    const p = d.presets[+b.dataset.preset];
    if (p.kind === "contribute" && !p.params.account_ids.length) {
      const text = prompt(`${p.hint}\n\nText that appears on your Roth transfers (leave blank to log deposits by hand):`, "");
      if (text === null) return;
      p.params.match_text = text;
    }
    submit(p);
  });
}

function companionChooser(main) {
  main.innerHTML = `<h1>Goals</h1><p class="sub">First, adopt a companion. It grows as you hit your money goals and droops when you fall behind. Its health and growth come from your real progress. Feeding and playing are there for fun, with no penalty for being away.</p>
    <div class="grid g2" style="max-width:720px">
      ${["plant", "pet"].map((k) => `<div class="card" style="text-align:center">
        <div class="companion" style="height:200px">${drawCompanion({ kind: k, stage: 2, mood: "thriving", picks: {} })}</div>
        <h2>${k === "plant" ? "A plant" : "A pet"}</h2>
        <p class="tiny muted">${k === "plant" ? "Starts as a seed and grows into a flowering tree." : "Hatches from an egg and grows up with you."}</p>
        <input placeholder="Name it (optional)" data-name="${k}" style="width:70%;margin-bottom:8px"><br>
        <button class="btn" data-adopt="${k}">Choose ${k}</button></div>`).join("")}
    </div>`;
  $$("[data-adopt]", main).forEach((b) => b.onclick = async () => {
    await run(() => post("/api/companion", { kind: b.dataset.adopt, name: $(`[data-name="${b.dataset.adopt}"]`).value }));
    await refreshStatus(); PAGES.goals(main);
  });
}

// ---------------------------------------------------------------- companion art
function drawCompanion(d) {
  PAINT = d.colors || {};
  const pick = (slot) => Object.values(d.picks || {}).find((p) => p.slot === slot)?.value;
  const pot = { terracotta: "#c8693f", ocean: "#2f7fb8", midnight: "#3a3a63" }[pick("pot")] || "#9a7b5f";
  const moodIdx = { thriving: 0, content: 1, thirsty: 2, wilting: 3 }[d.mood] ?? 1;
  const extras = companionExtras(pick("accent"), pick("hat"), pick("glow"), d.kind);
  return d.kind === "pet" ? drawPet(d.stage, moodIdx, pot, extras, !!d.asleep) : drawPlant(d.stage, moodIdx, PAINT.pot || pot, extras);
}

function drawPlant(stage, mood, potColor, extras) {
  const leaf = PAINT.leaf ? shade(PAINT.leaf, [0, .12, .3, .45][mood]) : ["#3aa655", "#5fae4f", "#a3b04a", "#a58a4e"][mood];
  const leafDark = PAINT.leaf ? shade(leaf, -.28) : ["#23803d", "#3f8b37", "#7f8a31", "#7b6436"][mood];
  const droop = [0, 8, 22, 40][mood];
  const soil = mood >= 2 ? "#a08466" : "#5b4334";
  const stemH = [8, 40, 80, 105, 112][stage];
  const top = 200 - stemH;
  const leafAt = (y, side, size, rot) => `<g transform="translate(130 ${y}) rotate(${side * (35 + droop) + rot})">
      <path d="M0 0 C ${side * size * .5} ${-size * .55}, ${side * size} ${-size * .25}, ${side * size} 0 C ${side * size * .7} ${size * .3}, ${side * size * .3} ${size * .25}, 0 0Z" fill="${leaf}" stroke="${leafDark}" stroke-width="1.2" data-paint="leaf" data-paint-value="${PAINT.leaf || leaf}"/></g>`;
  let plant = "";
  if (stage === 0) {
    plant = `<ellipse cx="130" cy="198" rx="10" ry="6" fill="#7a5a3a"/><path d="M130 196 q -2 -10 4 -14" stroke="${leaf}" stroke-width="3" fill="none" stroke-linecap="round"/>`;
  } else {
    plant = `<path d="M130 202 C ${128 + droop * .2} ${200 - stemH * .5}, ${132 - droop * .3} ${top + 10}, ${130 + droop * .4} ${top}" stroke="${leafDark}" stroke-width="${3 + stage}" fill="none" stroke-linecap="round"/>`;
    const n = [0, 2, 4, 6, 6][stage];
    for (let i = 0; i < n; i++) plant += leafAt(200 - stemH * (0.3 + 0.6 * i / Math.max(1, n - 1)), i % 2 ? 1 : -1, 16 + stage * 3, 0);
    if (stage >= 3) {
      const r = stage === 3 ? 42 : 52;
      plant += `<g transform="translate(${130 + droop * .4} ${top - r * .55})"><circle r="${r}" fill="${leaf}" opacity=".95"/><circle cx="${-r * .45}" cy="${r * .15}" r="${r * .6}" fill="${leafDark}" opacity=".55"/><circle cx="${r * .4}" cy="${-r * .25}" r="${r * .55}" fill="${leaf}"/></g>`;
      if (stage === 4 && mood <= 1) {
        for (let i = 0; i < 7; i++) {
          const a = i * 0.9, rr = r * .7;
          plant += `<g transform="translate(${130 + droop * .4 + Math.cos(a) * rr} ${top - r * .55 + Math.sin(a) * rr * .8})">${[0, 72, 144, 216, 288].map((deg) => `<ellipse rx="3.4" ry="6" transform="rotate(${deg}) translate(0 -5)" fill="${paint("flower", "#f4a6c1")}" data-paint="flower"/>`).join("")}<circle r="2.6" fill="#f6d046"/></g>`;
        }
      }
    }
  }
  const potSvg = `<path d="M92 200 h76 l-8 46 h-60z" fill="${potColor}" data-paint="pot"/><rect x="86" y="194" width="88" height="12" rx="3" fill="${potColor}" style="filter:brightness(1.15)"/><ellipse cx="130" cy="200" rx="40" ry="5" fill="${soil}"/>`;
  return `<svg viewBox="0 0 260 260" class="${mood <= 1 ? "sway" : "slump"}" role="img" aria-label="Plant, ${["thriving", "content", "thirsty", "wilting"][mood]}">
    ${extras.back}<g class="plant-body">${plant}</g>${potSvg}${stage >= 1 ? extras.hatAt(130 + droop * .4, stage >= 3 ? top - (stage === 3 ? 42 : 52) * 1.5 : top - 4) : ""}${extras.front}</svg>`;
}

function drawPet(stage, mood, color, extras, asleep = false) {
  const body = PAINT.body || (color === "#9a7b5f" ? "#8fb7e8" : color);
  if (stage === 0) {
    return `<svg viewBox="0 0 260 260" class="wobble" role="img" aria-label="Egg">${extras.back}
      <ellipse cx="130" cy="236" rx="52" ry="8" fill="#000" opacity=".12"/>
      <path d="M130 90 C 170 90, 182 160, 178 190 C 174 222, 150 236, 130 236 C 110 236, 86 222, 82 190 C 78 160, 90 90, 130 90Z" fill="#f3ead8" stroke="#d8c9a8" stroke-width="2"/>
      <path d="M96 170 l12 -8 l10 10 l12 -10 l10 9 l12 -9 l12 8" stroke="#c8b48c" stroke-width="2.5" fill="none"/>
      ${[[110, 130], [148, 150], [124, 200]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="7" fill="${body}" opacity=".6"/>`).join("")}${extras.front}</svg>`;
  }
  const s = [1, .62, .78, .92, 1][stage];
  const sag = [0, 4, 10, 16][mood];
  const eyesY = 150 + sag * .4;
  const mouth = [
    `<path d="M118 ${172 + sag} q12 12 24 0" stroke="#2b2b2b" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    `<path d="M120 ${174 + sag} q10 6 20 0" stroke="#2b2b2b" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    `<path d="M120 ${178 + sag} q5 -4 10 0 q5 4 10 0" stroke="#2b2b2b" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    `<path d="M118 ${182 + sag} q12 -10 24 0" stroke="#2b2b2b" stroke-width="3" fill="none" stroke-linecap="round"/>`,
  ][mood];
  const mouthNow = asleep ? `<ellipse cx="130" cy="${177 + sag}" rx="4.5" ry="3.5" fill="#2b2b2b" opacity=".75"/>` : mouth;
  const eye = (x) => asleep ? `<path d="M${x - 7} ${eyesY} q7 6 14 0" stroke="#2b2b2b" stroke-width="3" fill="none" stroke-linecap="round"/>` : mood === 3
    ? `<path d="M${x - 7} ${eyesY + 2} q7 -5 14 0" stroke="#2b2b2b" stroke-width="3" fill="none"/>`
    : `<ellipse cx="${x}" cy="${eyesY}" rx="${mood === 0 ? 7 : 6}" ry="${mood === 2 ? 5 : 8}" fill="${paint("eyes", "#2b2b2b")}" data-paint="eyes"/><circle cx="${x + 2}" cy="${eyesY - 3}" r="2.2" fill="#fff"/>`;
  const tear = mood === 3 && !asleep ? `<path d="M146 ${eyesY + 8} q-4 8 0 11 q4 -3 0 -11z" fill="#6fb3f2"/>` : "";
  const ears = stage >= 2 ? `<path d="M88 ${118 + sag} l-6 -34 l26 20z" fill="${body}" style="filter:brightness(.92)"/><path d="M172 ${118 + sag} l6 -34 l-26 20z" fill="${body}" style="filter:brightness(.92)"/>` : "";
  const feet = `<ellipse cx="104" cy="230" rx="16" ry="8" fill="${body}" style="filter:brightness(.85)"/><ellipse cx="156" cy="230" rx="16" ry="8" fill="${body}" style="filter:brightness(.85)"/>`;
  const headTop = 230 - 120 * s;
  return `<svg viewBox="0 0 260 260" class="${asleep ? "snooze" : mood <= 1 ? "bounce" : "slump"}" role="img" aria-label="Pet, ${["thriving", "content", "thirsty", "wilting"][mood]}">
    ${extras.back}<ellipse cx="130" cy="238" rx="${60 * s}" ry="8" fill="#000" opacity=".12"/>
    <g transform="translate(130 230) scale(${s}) translate(-130 -230)">
      ${ears}${feet}
      <path d="M70 ${150 + sag} C 70 ${95 + sag}, 190 ${95 + sag}, 190 ${150 + sag} C 194 ${200}, 176 230, 130 230 C 84 230, 66 200, 70 ${150 + sag}Z" fill="${body}" data-paint="body"/>
      <ellipse cx="130" cy="${196 + sag * .5}" rx="34" ry="24" fill="${paint("belly", "#ffffff")}" opacity="${PAINT.belly ? ".9" : ".35"}" data-paint="belly"/>
      ${eye(112)}${eye(148)}${tear}
      <circle cx="98" cy="${168 + sag}" r="7" fill="${paint("cheeks", "#f28fb0")}" data-paint="cheeks" opacity="${mood <= 1 ? .6 : .2}"/><circle cx="162" cy="${168 + sag}" r="7" fill="${paint("cheeks", "#f28fb0")}" data-paint="cheeks" opacity="${mood <= 1 ? .6 : .2}"/>
      ${mouthNow}
    </g>${extras.hatAt(130, headTop + 6 + sag)}${extras.front}</svg>`;
}

function companionExtras(accent, hat, glow, kind) {
  const front = {
    ladybug: `<g transform="translate(${kind === "pet" ? 196 : 168} 214)"><circle r="8" fill="#d03b3b"/><path d="M0 -8 v16" stroke="#222" stroke-width="1.5"/><circle cx="-3" cy="-1" r="1.6" fill="#222"/><circle cx="3" cy="3" r="1.6" fill="#222"/><circle cy="-9" r="3.5" fill="#222"/></g>`,
    butterfly: `<g class="flutter" transform="translate(205 70)"><ellipse cx="-7" cy="0" rx="8" ry="11" fill="#e87ba4"/><ellipse cx="7" cy="0" rx="8" ry="11" fill="#6250d6"/><rect x="-1.5" y="-9" width="3" height="18" rx="1.5" fill="#333"/></g>`,
    snail: `<g transform="translate(${kind === "pet" ? 40 : 60} 222)"><path d="M-14 8 h30 q6 0 6 -6" fill="#c9b18a" stroke="#9c845c"/><circle cx="2" cy="-2" r="11" fill="#c8693f"/><path d="M2 -2 m-6 0 a6 6 0 1 1 6 6" stroke="#8a4526" fill="none" stroke-width="2"/></g>`,
  }[accent] || "";
  const back = {
    fireflies: [[40, 60], [214, 96], [60, 140], [200, 170], [120, 30]].map(([x, y], i) => `<circle class="firefly" style="animation-delay:${i * .6}s" cx="${x}" cy="${y}" r="3.5" fill="#f6d046"/>`).join(""),
    sparkles: [[44, 50], [214, 70], [34, 150], [222, 150]].map(([x, y], i) => `<path class="firefly" style="animation-delay:${i * .5}s" transform="translate(${x} ${y})" d="M0 -8 L2 -2 L8 0 L2 2 L0 8 L-2 2 L-8 0 L-2 -2Z" fill="#9fc5f8"/>`).join(""),
    moon: `<g opacity=".9"><circle cx="214" cy="46" r="20" fill="#f3e7b4"/><circle cx="222" cy="40" r="17" fill="var(--surface)"/></g>`,
  }[glow] || "";
  const hatAt = (x, y) => ({
    party: `<g transform="translate(${x} ${y})"><path d="M-14 0 L0 -34 L14 0Z" fill="${paint("hat", "#eb6834")}" data-paint="hat"/><path d="M-9 -12 h18 M-5 -22 h10" stroke="#f6d046" stroke-width="3"/><circle cy="-36" r="4" fill="#f6d046"/></g>`,
    beanie: `<g transform="translate(${x} ${y})"><path d="M-22 0 C -22 -26, 22 -26, 22 0Z" fill="${paint("hat", "#6250d6")}" data-paint="hat"/><rect x="-24" y="-4" width="48" height="8" rx="3" fill="${PAINT.hat ? shade(PAINT.hat, -.25) : "#4a3aa7"}"/><circle cy="-22" r="5" fill="#e87ba4"/></g>`,
    crown: `<g transform="translate(${x} ${y})"><path d="M-16 0 L-16 -16 L-8 -8 L0 -20 L8 -8 L16 -16 L16 0Z" fill="${paint("hat", "#eda100")}" stroke="#b07600" data-paint="hat"/><circle cy="-6" r="2.5" fill="#d03b3b"/></g>`,
  }[hat] || "");
  return { front, back, hatAt };
}

// =====================================================================
// SECURITY card on the Accounts page: change password, auto-lock time
// =====================================================================
{
  const baseAccounts = PAGES.accounts;
  PAGES.accounts = async (main, params) => {
    await baseAccounts(main, params);
    const a = await api("/api/auth/status");
    const card = document.createElement("div");
    card.className = "card";
    card.style.marginTop = "16px";
    card.innerHTML = `<h2>Security</h2>
      <div class="grid g2">
        <form id="pwForm"><h3>Change password</h3>
          <div class="grid" style="gap:8px;max-width:320px">
            <input type="text" name="username" value="finance-hub" autocomplete="username" hidden>
            <input type="password" id="pwCur" placeholder="Current password" autocomplete="current-password" required>
            <input type="password" id="pwNew" placeholder="New password" autocomplete="new-password" required minlength="${a.min_length}">
            <input type="password" id="pwNew2" placeholder="New password again" autocomplete="new-password" required>
            <button class="btn small" style="justify-self:start">Change password</button></div>
          <p class="tiny muted">Changing it signs out every other browser tab.</p></form>
        <div><h3>Auto-lock</h3>
          <label class="field" style="max-width:240px">Lock after this long with no activity
            <select id="idleSel">${[[5, "5 minutes"], [15, "15 minutes"], [30, "30 minutes"], [60, "1 hour"], [120, "2 hours"], [0, "Never (not recommended)"]]
              .map(([v, l]) => `<option value="${v}" ${a.idle_minutes === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
          <p class="tiny muted">The 🔒 Lock button in the sidebar locks it right away. Your password is stored only as a salted hash.
            The app's screens and data API need it, but <code>data/finance.db</code> itself isn't encrypted, so keep your Windows account password-protected too.</p></div>
      </div>`;
    main.appendChild(card);
    $("#idleSel").onchange = (e) => run(() => post("/api/auth/settings", { idle_minutes: +e.target.value }), "Auto-lock updated");
    $("#pwForm").onsubmit = async (e) => {
      e.preventDefault();
      if ($("#pwNew").value !== $("#pwNew2").value) return toast("The new passwords don't match", true);
      await run(() => post("/api/auth/change", { current: $("#pwCur").value, new: $("#pwNew").value }), "Password changed");
      e.target.reset();
    };
  };
}

// ---- Undo for sorting (button or Ctrl+Z on the Sort page)
async function sortUndo(main) {
  const btn = $("#undoBtn");
  if (btn) btn.disabled = true;
  try {
    const r = await post("/api/sort/undo");
    toast(`Undone: ${r.label}${r.restored > 1 ? ` (${r.restored} transactions put back)` : ""}`);
    SORT.sortedNow = Math.max(0, SORT.sortedNow - 1);
    await refreshStatus();
    PAGES.sort(main || $("#main"));
  } catch (e) {
    toast(e.message, true);
    if (btn) btn.disabled = false;
  }
}
document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z" && location.hash.startsWith("#sort")
      && !["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) {
    e.preventDefault();
    sortUndo();
  }
});
