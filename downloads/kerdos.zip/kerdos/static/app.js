"use strict";
// Kerdos front end: plain JS, no build step.

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (v, d = 0) => (v < 0 ? "−" : "") + "$" + Math.abs(v || 0).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d });
const fmt2 = (v) => fmt(v, 2);
const signed = (v) => (v >= 0 ? "+" : "−") + fmt(Math.abs(v)).replace("−", "");
const monthName = (m) => new Date(m + "-15").toLocaleString(undefined, { month: "short" });
const monthLong = (m) => new Date(m + "-15").toLocaleString(undefined, { month: "long", year: "numeric" });
const dayDiff = (iso) => Math.round((new Date(iso + "T00:00") - new Date(new Date().toDateString())) / 864e5);
const whenLabel = (iso) => { const d = dayDiff(iso); return d === 0 ? "today" : d === 1 ? "tomorrow" : d < 0 ? `${-d}d ago` : `in ${d}d`; };
const shortDate = (iso) => new Date(iso + "T00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" });

let STATUS = { categories: [] };

async function api(path, opts = {}) {
  const init = { method: opts.method || "GET", headers: { "X-Finance-Hub": "1" }, credentials: "same-origin" };
  if (opts.background) init.headers["X-Background"] = "1";  // doesn't count as activity for auto-lock
  if (opts.body !== undefined) { init.headers["Content-Type"] = "application/json"; init.body = JSON.stringify(opts.body); }
  if (init.method !== "GET" && opts.body === undefined) init.body = "{}";
  const r = await fetch(path, init);
  const data = await r.json().catch(() => ({}));
  if (r.status === 401 && data.auth && !path.startsWith("/api/auth/")) showAuth(data.auth);
  if (!r.ok) throw new Error(data.error || `Request failed (${r.status})`);
  return data;
}
const post = (p, body) => api(p, { method: "POST", body });
const del = (p) => api(p, { method: "DELETE" });

function toast(msg, err = false) {
  const t = $("#toast");
  t.textContent = msg; t.className = "toast" + (err ? " err" : ""); t.hidden = false;
  clearTimeout(toast._t); toast._t = setTimeout(() => (t.hidden = true), err ? 6000 : 2800);
}
async function run(fn, okMsg) {
  try { const r = await fn(); if (okMsg) toast(typeof okMsg === "function" ? okMsg(r) : okMsg); return r; }
  catch (e) { toast(e.message, true); throw e; }
}

// ---------------------------------------------------------------- tooltip
const tip = $("#tip");
document.addEventListener("mousemove", (e) => {
  const t = e.target.closest("[data-tip]");
  if (!t) { tip.hidden = true; return; }
  tip.innerHTML = t.dataset.tip; tip.hidden = false;
  const x = Math.min(e.clientX + 14, innerWidth - tip.offsetWidth - 8);
  tip.style.left = x + "px"; tip.style.top = (e.clientY + 14) + "px";
});

// ---------------------------------------------------------------- charts
function lineChart(points, { height = 220, key = "net", label = "Net worth", W = 760 } = {}) {
  if (points.length < 2) return `<div class="empty">Net worth history builds up as the app runs (one point per day).</div>`;
  const H = height, pl = 58, pr = 12, pt = 10, pb = 24;
  const xs = points.map((p) => new Date(p.date).getTime());
  const ys = points.map((p) => p[key]);
  let lo = Math.min(...ys), hi = Math.max(...ys);
  const pad = (hi - lo) * 0.1 || Math.abs(hi) * 0.05 || 1; lo -= pad; hi += pad;
  const x = (t) => pl + ((t - xs[0]) / (xs.at(-1) - xs[0] || 1)) * (W - pl - pr);
  const y = (v) => pt + (1 - (v - lo) / (hi - lo)) * (H - pt - pb);
  const ticks = niceTicks(lo, hi, 4);
  const path = points.map((p, i) => `${i ? "L" : "M"}${x(xs[i]).toFixed(1)},${y(p[key]).toFixed(1)}`).join("");
  const area = path + `L${x(xs.at(-1))},${H - pb}L${x(xs[0])},${H - pb}Z`;
  const months = [];
  let lastM = "";
  points.forEach((p, i) => { const m = p.date.slice(0, 7); if (m !== lastM) { months.push(i); lastM = m; } });
  const step = Math.ceil(months.length / Math.max(2, Math.floor(W / 80)));
  const id = "lc" + Math.random().toString(36).slice(2, 7);
  return `<div class="chart" data-line="${id}"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(label)} over time">
    ${ticks.map((t) => `<line x1="${pl}" x2="${W - pr}" y1="${y(t)}" y2="${y(t)}" stroke="var(--grid)"/><text x="${pl - 8}" y="${y(t) + 4}" text-anchor="end">${compact(t)}</text>`).join("")}
    ${months.filter((_, i) => i % step === 0).map((i) => `<text x="${x(xs[i])}" y="${H - 6}" text-anchor="middle">${monthName(points[i].date.slice(0, 7))}</text>`).join("")}
    <path d="${area}" fill="var(--series-1)" opacity=".08"/>
    <path d="${path}" fill="none" stroke="var(--series-1)" stroke-width="2" stroke-linejoin="round"/>
    <line class="xh" y1="${pt}" y2="${H - pb}" stroke="var(--muted)" stroke-dasharray="3 3" visibility="hidden"/>
    <circle class="xd" r="4.5" fill="var(--series-1)" stroke="var(--surface)" stroke-width="2" visibility="hidden"/>
    <rect x="${pl}" y="0" width="${W - pl - pr}" height="${H}" fill="transparent" class="hit"/>
  </svg></div>`;
  // hover wiring happens in wireLineCharts via the stored data
}
const LINE_DATA = {};
function lineChartWithData(points, opts) {
  const html = lineChart(points, opts);
  const m = html.match(/data-line="(\w+)"/);
  if (m) LINE_DATA[m[1]] = { points, key: opts?.key || "net" };
  return html;
}
function wireLineCharts(root) {
  $$("[data-line]", root).forEach((el) => {
    const { points, key } = LINE_DATA[el.dataset.line] || {};
    if (!points) return;
    const svg = $("svg", el), xh = $(".xh", el), xd = $(".xd", el), hit = $(".hit", el);
    const vb = svg.viewBox.baseVal;
    const pl = 58, pr = 12, pt = 10, pb = 24;
    const xs = points.map((p) => new Date(p.date).getTime());
    const ys = points.map((p) => p[key]);
    let lo = Math.min(...ys), hi = Math.max(...ys);
    const pad = (hi - lo) * 0.1 || Math.abs(hi) * 0.05 || 1; lo -= pad; hi += pad;
    hit.addEventListener("mousemove", (e) => {
      const r = svg.getBoundingClientRect();
      const sx = ((e.clientX - r.left) / r.width) * vb.width;
      const t = xs[0] + ((sx - pl) / (vb.width - pl - pr)) * (xs.at(-1) - xs[0]);
      let best = 0; xs.forEach((v, i) => { if (Math.abs(v - t) < Math.abs(xs[best] - t)) best = i; });
      const px = pl + ((xs[best] - xs[0]) / (xs.at(-1) - xs[0] || 1)) * (vb.width - pl - pr);
      const py = pt + (1 - (ys[best] - lo) / (hi - lo)) * (vb.height - pt - pb);
      xh.setAttribute("x1", px); xh.setAttribute("x2", px); xh.setAttribute("visibility", "visible");
      xd.setAttribute("cx", px); xd.setAttribute("cy", py); xd.setAttribute("visibility", "visible");
      const p = points[best];
      tip.innerHTML = `<b>${shortDate(p.date)}, ${p.date.slice(0, 4)}</b><br>Net worth ${fmt(p.net)}${p.assets !== undefined ? `<br><span class="muted">Assets ${fmt(p.assets)} · Debts ${fmt(p.liabilities)}</span>` : ""}`;
      tip.hidden = false;
      tip.style.left = Math.min(e.clientX + 14, innerWidth - tip.offsetWidth - 8) + "px"; tip.style.top = e.clientY + 14 + "px";
    });
    hit.addEventListener("mouseleave", () => { xh.setAttribute("visibility", "hidden"); xd.setAttribute("visibility", "hidden"); tip.hidden = true; });
  });
}
// Charts are drawn at their real pixel width so text stays readable.
const CHARTS = {};
let chartSeq = 0;
function chartSlot(kind, data, opts = {}) {
  const id = "c" + ++chartSeq;
  CHARTS[id] = { kind, data, opts };
  const legend = "";
  return `${legend}<div data-chart="${id}"></div>`;
}
function drawCharts(root = document) {
  $$("[data-chart]", root).forEach((el) => {
    const c = CHARTS[el.dataset.chart];
    if (!c) return;
    const W = Math.max(280, el.clientWidth);
    el.innerHTML = c.kind === "line" ? lineChartWithData(c.data, { ...c.opts, W }) : groupedBars(c.data, W);
    if (c.kind === "line") wireLineCharts(el);
  });
}
let resizeT;
window.addEventListener("resize", () => { clearTimeout(resizeT); resizeT = setTimeout(() => drawCharts(), 150); });

function niceTicks(lo, hi, n) {
  const span = hi - lo, raw = span / n, mag = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => s >= raw) || raw;
  const out = []; for (let v = Math.ceil(lo / step) * step; v <= hi; v += step) out.push(v);
  return out;
}
const compact = (v) => (v < 0 ? "−" : "") + "$" + (Math.abs(v) >= 1e6 ? (Math.abs(v) / 1e6).toFixed(1) + "M" : Math.abs(v) >= 1e3 ? +(Math.abs(v) / 1e3).toFixed(Math.abs(v) < 1e4 ? 1 : 0) + "k" : Math.round(Math.abs(v)));

function groupedBars(months, W = 760) {
  // Income vs spending per month. The amount left over (or overspent) sits above each pair.
  const H = 262, pl = 46, pr = 10, pt = 30, pb = 38;
  const hi = Math.max(1, ...months.flatMap((m) => [m.income, m.spending])) * 1.05;
  const ticks = niceTicks(0, hi, 4);
  const y = (v) => pt + (1 - v / hi) * (H - pt - pb);
  const gw = (W - pl - pr) / months.length, bw = Math.max(7, Math.min(30, gw / 3.2));
  const now = new Date(), cur = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const lw = Math.min(54, gw - 4);
  const bars = months.map((m, i) => {
    const cx = pl + gw * i + gw / 2, net = m.income - m.spending, partial = m.month === cur;
    const tipHtml = `<b>${monthLong(m.month)}${partial ? " (so far)" : ""}</b><br>Income ${fmt(m.income)}<br>Spending ${fmt(m.spending)}<br>${net >= 0 ? "Left over" : "Overspent"} ${fmt(Math.abs(net))}`;
    const bar = (v, x, fill) => {
      const h = Math.max(0, H - pb - y(v)), r = Math.min(6, bw / 2, h);
      return h <= 0 ? "" : `<path d="M${x},${H - pb}V${H - pb - h + r}q0,${-r} ${r},${-r}h${bw - 2 * r}q${r},0 ${r},${r}V${H - pb}Z" fill="${fill}"/>`;
    };
    const top = Math.min(y(m.income), y(m.spending));
    const pill = (m.income || m.spending) ? `<g class="ivs-net ${net >= 0 ? "pos" : "neg"}"><rect x="${cx - lw / 2}" y="${top - 23}" width="${lw}" height="17" rx="8.5"/>
      <text x="${cx}" y="${top - 11}" text-anchor="middle">${net >= 0 ? "+" : "−"}${compact(Math.abs(net))}</text></g>` : "";
    return `<g data-tip="${esc(tipHtml)}" class="ivs-month ${partial ? "partial" : ""}"><rect x="${cx - gw / 2}" y="0" width="${gw}" height="${H}" fill="transparent"/>
      <rect class="ivs-hover" x="${cx - gw / 2 + 3}" y="${pt - 26}" width="${gw - 6}" height="${H - pb - pt + 30}" rx="8"/>
      ${bar(m.income, cx - bw - 1.5, "url(#ivsInc)")}${bar(m.spending, cx + 1.5, "url(#ivsSpend)")}${pill}
      <text class="ivs-x" x="${cx}" y="${H - 20}" text-anchor="middle">${monthName(m.month)}</text>
      ${partial ? `<text x="${cx}" y="${H - 7}" text-anchor="middle" style="font-size:10px">so far</text>` : ""}</g>`;
  }).join("");
  const full = months.filter((m) => m.month !== cur && (m.income || m.spending));
  const avg = (k) => full.length ? full.reduce((t, m) => t + m[k], 0) / full.length : 0;
  const inc = avg("income"), sp = avg("spending"), saved = inc - sp;
  const head = `<div class="ivs-head">
    <div class="ivs-stat"><span><i style="background:var(--series-1)"></i>Income</span><b>${fmt(inc)}</b></div>
    <div class="ivs-stat"><span><i style="background:var(--series-2)"></i>Spending</span><b>${fmt(sp)}</b></div>
    <div class="ivs-stat ${saved >= 0 ? "good" : "bad"}"><span>${saved >= 0 ? "Left over" : "Overspent"}</span><b>${saved >= 0 ? "+" : "−"}${fmt(Math.abs(saved))}</b></div>
    ${inc > 0 ? `<div class="ivs-stat"><span>Savings rate</span><b>${Math.round(saved / inc * 100)}%</b></div>` : ""}
    <span class="spacer"></span><span class="tiny muted">${full.length ? `monthly average, last ${full.length} full month${full.length === 1 ? "" : "s"}` : ""}</span></div>`;
  return `${head}<div class="chart"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Income and spending by month">
    <defs><linearGradient id="ivsInc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--series-1)"/><stop offset="1" style="stop-color:var(--series-1);stop-opacity:.6"/></linearGradient>
      <linearGradient id="ivsSpend" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--series-2)"/><stop offset="1" style="stop-color:var(--series-2);stop-opacity:.6"/></linearGradient></defs>
    ${ticks.map((t) => `<line x1="${pl}" x2="${W - pr}" y1="${y(t)}" y2="${y(t)}" stroke="var(--grid)" ${t ? 'stroke-dasharray="3 4"' : ""}/><text x="${pl - 8}" y="${y(t) + 4}" text-anchor="end">${compact(t)}</text>`).join("")}
    ${bars}</svg></div>`;
}

function barList(entries, { total, onClick } = {}) {
  if (!entries.length) return `<div class="empty">No spending yet.</div>`;
  const max = Math.max(...entries.map((e) => e[1]));
  total = total || entries.reduce((s, e) => s + e[1], 0);
  return `<div class="bar-list">${entries.map(([k, v]) => `<div class="item" ${onClick ? `style="cursor:pointer" data-cat="${esc(k)}"` : ""}
      data-tip="${esc(`<b>${esc(k)}</b><br>${fmt2(v)} · ${(100 * v / total).toFixed(0)}% of spending`)}">
      <div class="name" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(k)}</div>
      <div class="track"><div class="fill" style="width:${Math.max(0.5, 100 * v / max)}%"></div></div>
      <div class="num">${fmt(v)}</div></div>`).join("")}</div>`;
}

// ---------------------------------------------------------------- shared bits
const SEV_ICON = { danger: "⚠", warn: "●", info: "ℹ" };
function alertRow(a) {
  return `<div class="alert sev-${a.severity} ${a.is_read ? "" : "unread"}">
    <div class="icon" aria-label="${a.severity}">${SEV_ICON[a.severity] || "•"}</div>
    <div><div class="title">${esc(a.title)}</div><div class="body">${esc(a.body)}</div>
      <div class="tiny muted">${esc(a.created_at.replace("T", " ").slice(0, 16))} UTC</div></div>
    <div>${a.is_read ? "" : `<button class="btn small secondary" data-read="${a.id}" title="Dismiss" aria-label="Dismiss">✕</button>`}</div></div>`;
}
function wireAlertButtons(root, reload) {
  $$("[data-read]", root).forEach((b) => b.onclick = async () => { await post("/api/alerts/read", { id: +b.dataset.read }); refreshStatus(); reload(); });
}
const AUTOPAY_LABEL = { yes: "Autopay", likely: "Likely autopay", no: "Manual pay", unknown: "Due (check autopay)" };

function onboarding() {
  return `<div class="banner">
    <h2>Get started</h2>
    <p class="muted" style="margin-top:-6px">Connect a bank through Plaid, import a CSV export from your bank, or explore with demo data first.</p>
    <div class="row">
      <button class="btn" id="obDemo">Load demo data</button>
      <a class="btn secondary" href="#accounts" style="text-decoration:none">Connect a bank / import CSV</a>
    </div></div>`;
}

// ---------------------------------------------------------------- pages
const PAGES = {};

PAGES.dashboard = async (main) => {
  const d = await api("/api/dashboard");
  const thisMonth = d.months.at(-1), avg = d.averages;
  const upcomingTotal = d.upcoming.reduce((s, b) => s + (b.avg_amount || 0), 0);
  const cats = Object.entries(thisMonth.categories);
  const avgCats = Object.entries(avg.categories);
  main.innerHTML = `
    <h1>Dashboard</h1><p class="sub">${new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</p>
    ${STATUS.has_data ? "" : onboarding()}
    <div class="grid g4">
      <div class="card stat"><div class="label">Net worth</div><div class="value">${fmt(d.net_worth.net)}</div>
        <div class="delta">${d.net_worth_change_30d == null ? "&nbsp;" : `<span class="${d.net_worth_change_30d >= 0 ? "up" : "down"}">${d.net_worth_change_30d >= 0 ? "▲" : "▼"} ${signed(d.net_worth_change_30d)}</span> last 30 days`}</div></div>
      <div class="card stat"><div class="label">Spent in ${monthLong(thisMonth.month).split(" ")[0]}</div><div class="value">${fmt(thisMonth.spending)}</div>
        <div class="delta">${avg.months ? `avg ${fmt(avg.spending)}/mo (last ${avg.months} months)` : "&nbsp;"}</div></div>
      <div class="card stat"><div class="label">Avg monthly surplus</div><div class="value ${avg.income - avg.spending < 0 ? "down" : ""}">${fmt(avg.income - avg.spending)}</div>
        <div class="delta">income ${fmt(avg.income)} − spending ${fmt(avg.spending)}</div></div>
      <div class="card stat"><div class="label">Bills due next 14 days</div><div class="value">${fmt(upcomingTotal)}</div>
        <div class="delta">${d.upcoming.length} payment${d.upcoming.length === 1 ? "" : "s"}${d.upcoming.length ? ", " + d.upcoming.filter((b) => b.autopay !== "no").length + " on autopay" : ""}</div></div>
    </div>
    ${STATUS.has_data ? kindStrip(d.accounts || []) : ""}
    <div class="grid g3" style="margin-top:16px">
      <div class="card span2"><h2>Net worth</h2>${chartSlot("line", d.history)}</div>
      <div class="card"><div class="row"><h2>Upcoming bills</h2><span class="spacer"></span><a href="#bills" class="tiny">All bills →</a></div>
        ${d.upcoming.length ? `<table>${d.upcoming.slice(0, 7).map((b) => `<tr><td class="name" title="${esc(b.display_name)}">${esc(b.display_name)}<div class="tiny muted">${esc(AUTOPAY_LABEL[b.autopay])} · ${esc(b.account_name || "")}</div></td>
          <td class="num">${fmt2(b.avg_amount)}<div class="tiny muted">${shortDate(b.next_date)} · ${whenLabel(b.next_date)}</div></td></tr>`).join("")}</table>` : `<div class="empty">Nothing due in the next 2 weeks.</div>`}
      </div>
    </div>
    <div class="grid g3" style="margin-top:16px">
      <div class="card span2"><h2>Income vs spending</h2>${chartSlot("bars", d.months)}</div>
      <div class="card"><div class="row"><h2>Alerts</h2><span class="spacer"></span><a href="#bills" class="tiny">All alerts →</a></div>
        ${d.alerts.length ? d.alerts.slice(0, 4).map(alertRow).join("") : `<div class="empty">✓ Nothing new. Dismissed alerts stay on the Bills &amp; Alerts page.</div>`}</div>
    </div>
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><div class="tabs"><button class="btn small" data-ct="month">This month</button><button class="btn small secondary" data-ct="avg">3-month average</button></div>
        <div id="catBox">${barList(cats, { onClick: true })}</div></div>
      <div class="card"><div class="row"><h2>Recent transactions</h2><span class="spacer"></span><a href="#transactions" class="tiny">All →</a></div>
        <table>${d.recent.map((t) => `<tr><td class="name">${esc(t.merchant || t.name)}<div class="tiny muted">${shortDate(t.date)} · ${esc(t.category)}</div></td><td class="num ${t.amount > 0 ? "pos" : ""}">${t.amount > 0 ? "+" : ""}${fmt2(t.amount).replace("−", "")}</td></tr>`).join("")}</table></div>
    </div>`;
  drawCharts(main);
  wireAlertButtons(main, () => PAGES.dashboard(main));
  const wireCats = () => $$("#catBox [data-cat]").forEach((el) => el.onclick = () => { location.hash = `transactions?category=${encodeURIComponent(el.dataset.cat)}&month=${thisMonth.month}`; });
  wireCats();
  $$("[data-ct]", main).forEach((b) => b.onclick = () => {
    $$("[data-ct]", main).forEach((x) => x.classList.toggle("secondary", x !== b));
    $("#catBox").innerHTML = barList(b.dataset.ct === "month" ? cats : avgCats, { onClick: true }); wireCats();
  });
  const ob = $("#obDemo"); if (ob) ob.onclick = loadDemo;
};

PAGES.transactions = async (main, params) => {
  const q = new URLSearchParams(params);
  const [data, accts, rules, pendData] = await Promise.all([api("/api/transactions?" + q), api("/api/accounts"), api("/api/rules"),
    api("/api/transactions?pending=1&limit=200")]);
  const cats = STATUS.categories;
  const opt = (v, label, sel) => `<option value="${esc(v)}" ${sel ? "selected" : ""}>${esc(label)}</option>`;
  const txs = data.transactions, pend = pendData.transactions;
  const spend = txs.filter((t) => t.amount < 0 && !["Transfer", "Credit Card Payment", "Investments", "Income"].includes(t.category)).reduce((s, t) => s - t.amount, 0);
  const pendTotal = pend.filter((t) => t.amount < 0).reduce((s, t) => s - t.amount, 0);
  main.innerHTML = `
    <h1>Transactions</h1><p class="sub">Change a category and choose whether to remember it for that merchant. Rules re-sort past and future transactions.</p>
    <div class="card pending-card" style="margin-bottom:16px">
      <div class="row"><h2 style="margin:0">Pending <span class="pill">${pend.length}</span></h2><span class="spacer"></span>
        ${pend.length ? `<span class="tiny muted">${fmt2(pendTotal)} on its way out</span>` : ""}</div>
      <p class="tiny muted" style="margin:4px 0 8px">Charges your bank hasn't finalized yet. Sort them now and the category carries over when they post. Pending charges don't count toward spending totals until then.</p>
      ${pend.length ? `<table class="t-pend">${pend.map((t) => `<tr><td class="tiny" style="white-space:nowrap">${shortDate(t.date)}</td>
        <td class="name" title="${esc(t.name)}">${esc(t.merchant || t.name)}</td><td class="tiny muted">${esc(t.account_name || "")}</td>
        <td><select class="cat-select" data-tx="${esc(t.id)}">${cats.map((c) => opt(c, c, c === t.category)).join("")}${opt("__new", "+ New category…")}</select>
          ${t.category_source === "user" ? '<span class="tiny muted" title="Set by you">✎</span>' : ""}</td>
        <td class="num ${t.amount > 0 ? "pos" : ""}">${t.amount > 0 ? "+" : ""}${fmt2(t.amount).replace("−", "")}</td></tr>`).join("")}</table>`
        : `<div class="tiny muted">Nothing pending right now. New card swipes usually show up here within a day.</div>`}
    </div>
    <div class="card"><div class="row" style="margin-bottom:10px">
      <select id="fMonth">${opt("", "All months")}${data.months.map((m) => opt(m, monthLong(m), q.get("month") === m)).join("")}</select>
      <select id="fCat">${opt("", "All categories")}${cats.map((c) => opt(c, c, q.get("category") === c)).join("")}</select>
      <select id="fAcct">${opt("", "All accounts")}${accts.accounts.map((a) => opt(a.id, a.name, q.get("account") === a.id)).join("")}</select>
      <input id="fQ" placeholder="Search…" value="${esc(q.get("q") || "")}" style="width:180px">
      <span class="spacer"></span><span class="muted tiny">${txs.length}${txs.length >= 300 ? "+" : ""} shown · spending ${fmt2(spend)}</span>
    </div>
    ${txs.length ? `<table class="t-tx"><thead><tr><th>Date</th><th>Description</th><th>Account</th><th>Category</th><th class="num">Amount</th></tr></thead><tbody>
      ${txs.map((t) => `<tr><td class="tiny" style="white-space:nowrap">${shortDate(t.date)}${t.pending ? ' <span class="pill">pending</span>' : ""}</td>
        <td class="name" title="${esc(t.name)}">${esc(t.merchant || t.name)}${t.merchant ? `<div class="tiny muted">${esc(t.name)}</div>` : ""}${t.shares && t.shares.length ? `<div class="tiny muted">👥 Roommate's share: ${t.shares.map((x) => `${esc(x.category)} ${fmt2(x.amount)}`).join(", ")} (<a href="#roommates">details</a>)</div>` : ""}</td>
        <td class="tiny muted">${esc(t.account_name || "")}</td>
        <td><select class="cat-select" data-tx="${esc(t.id)}">${cats.map((c) => opt(c, c, c === t.category)).join("")}${opt("__new", "+ New category…")}</select>
          ${t.category_source === "user" ? '<span class="tiny muted" title="Set by you">✎</span>' : ""}</td>
        <td class="num ${t.amount > 0 ? "pos" : ""}">${t.amount > 0 ? "+" : ""}${fmt2(t.amount).replace("−", "")}</td></tr>`).join("")}</tbody></table>`
      : `<div class="empty">No transactions match.</div>`}
    </div>
    <div class="card" style="margin-top:16px"><h2>Category rules</h2>
      <p class="muted tiny" style="margin-top:-6px">If a transaction's description contains the text, it gets that category. Your rules beat the built-in ones.</p>
      <div class="row" style="margin-bottom:10px"><input id="rPat" placeholder="Text to match, e.g. costco"><select id="rCat">${cats.map((c) => opt(c, c)).join("")}</select><button class="btn small" id="rAdd">Add rule</button></div>
      ${rules.rules.length ? `<table>${rules.rules.map((r) => `<tr><td>contains <code>${esc(r.pattern)}</code></td><td>→ ${esc(r.category)}</td><td class="num"><button class="btn small danger" data-delrule="${r.id}">Remove</button></td></tr>`).join("")}</table>` : `<div class="muted tiny">No custom rules yet.</div>`}
    </div>`;
  const apply = () => {
    const p = new URLSearchParams();
    [["month", "#fMonth"], ["category", "#fCat"], ["account", "#fAcct"], ["q", "#fQ"]].forEach(([k, s]) => { const v = $(s).value.trim(); if (v) p.set(k, v); });
    location.hash = "transactions" + (p.toString() ? "?" + p : "");
  };
  ["#fMonth", "#fCat", "#fAcct"].forEach((s) => $(s).onchange = apply);
  $("#fQ").onkeydown = (e) => { if (e.key === "Enter") apply(); };
  $$("[data-tx]", main).forEach((sel) => sel.onchange = async () => {
    const t = txs.find((x) => x.id === sel.dataset.tx) || pend.find((x) => x.id === sel.dataset.tx);
    let cat = sel.value;
    if (cat === "__new") { cat = (prompt("New category name:") || "").trim(); if (!cat) { sel.value = t.category; return; } }
    const choice = await askApplyRule(t, cat);
    if (!choice) { sel.value = t.category; return; }
    await run(() => post(`/api/transactions/${encodeURIComponent(t.id)}`, { category: cat, apply_to_merchant: choice.all, pattern: choice.pattern }),
      () => choice.all ? "Rule saved and applied to past transactions" : "Category updated");
    await refreshStatus(); PAGES.transactions(main, params);
  });
  $("#rAdd").onclick = async () => {
    await run(() => post("/api/rules", { pattern: $("#rPat").value, category: $("#rCat").value }), "Rule added");
    PAGES.transactions(main, params);
  };
  $$("[data-delrule]", main).forEach((b) => b.onclick = async () => { await run(() => del("/api/rules/" + b.dataset.delrule), "Rule removed"); PAGES.transactions(main, params); });
};

function guessPattern(t) {
  const s = (t.merchant || t.name).toLowerCase().replace(/[#*].*$/, "").replace(/\b\d+\b/g, "").replace(/\s+/g, " ").trim();
  return s.split(" ").slice(0, 3).join(" ");
}
function askApplyRule(t, cat) {
  return new Promise((resolve) => {
    const dlg = $("#dlg");
    dlg.innerHTML = `<h2>Categorize as ${esc(cat)}</h2>
      <p class="muted" style="margin-top:-4px">${esc(t.merchant || t.name)}</p>
      <label class="row" style="margin:12px 0"><input type="radio" name="scope" value="one" checked> Just this transaction</label>
      <label class="row"><input type="radio" name="scope" value="all"> All transactions containing</label>
      <input id="dlgPat" value="${esc(guessPattern(t))}" style="width:100%;margin:6px 0 16px">
      <div class="row"><span class="spacer"></span><button class="btn secondary" id="dlgCancel">Cancel</button><button class="btn" id="dlgOk">Save</button></div>`;
    dlg.showModal();
    $("#dlgPat").oninput = () => { $('input[value="all"]', dlg).checked = true; };
    $("#dlgCancel").onclick = () => { dlg.close(); resolve(null); };
    dlg.oncancel = () => resolve(null);
    $("#dlgOk").onclick = () => { const all = $('input[value="all"]', dlg).checked; dlg.close(); resolve({ all, pattern: $("#dlgPat").value }); };
  });
}

PAGES.bills = async (main) => {
  const [b, a] = await Promise.all([api("/api/bills"), api("/api/alerts")]);
  const active = b.bills.filter((x) => x.status === "active"), ignored = b.bills.filter((x) => x.status !== "active");
  const row = (x) => `<tr>
    <td class="name" title="${esc(x.display_name)}">${esc(x.display_name)}
      <div class="tiny muted">${x.stale && x.status === "active" ? '<span class="pill warnpill" title="The expected charge is well overdue. Remove it if you no longer pay this.">⚠ looks stopped</span> ' : ""}${esc(x.category)} · ${esc(x.cadence)}${x.occurrences ? ` · seen ${x.occurrences}×` : ""}${x.pays_account_name && !x.id.startsWith("liab:") ? ` · pays down ${esc(x.pays_account_name)}` : ""}</div></td>
    <td class="num">${fmt2(x.avg_amount)}${x.last_amount && Math.abs(x.last_amount - x.avg_amount) > 0.5 ? `<div class="tiny muted">last ${fmt2(x.last_amount)}</div>` : ""}</td>
    <td style="white-space:nowrap">${x.next_date ? `${shortDate(x.next_date)} <span class="tiny muted">${whenLabel(x.next_date)}</span>` : "—"}</td>
    <td class="tiny">${esc(x.account_name || "")}${x.account_mask ? ` ••${esc(x.account_mask)}` : ""}</td>
    <td><select data-autopay="${esc(x.id)}">${["yes", "likely", "no", "unknown"].map((v) => `<option value="${v}" ${x.autopay === v ? "selected" : ""}>${AUTOPAY_LABEL[v]}</option>`).join("")}</select>
      ${x.autopay_reason ? `<div class="tiny muted" style="max-width:220px;white-space:normal">${esc(x.autopay_reason)}</div>` : ""}</td>
    <td class="num">${x.status === "active"
      ? `<button class="btn small danger" data-ignore="${esc(x.id)}" data-to="dismissed" data-name="${esc(x.display_name)}" title="Remove this suggestion">🗑 Remove</button>`
      : `<button class="btn small secondary" data-ignore="${esc(x.id)}" data-to="active">Restore</button>`}</td></tr>`;
  const unread = a.alerts.filter((x) => !x.is_read).length;
  main.innerHTML = `
    <h1>Bills &amp; Alerts</h1><p class="sub">Recurring payments are found automatically from your history. You'll get an alert before each autopay, when it goes through, if the price changes, if an expected charge is missing, and if the paying account looks too low.</p>
    <div class="grid g3">
      <div class="card stat"><div class="label">Recurring bills</div><div class="value">${active.length}</div><div class="delta">${fmt(b.monthly_total)}/mo total</div></div>
      <div class="card stat"><div class="label">On autopay</div><div class="value">${fmt(b.autopay_monthly_total)}</div><div class="delta">per month</div></div>
      <div class="card stat"><div class="label">Due next 7 days</div><div class="value">${fmt(active.filter((x) => x.next_date && dayDiff(x.next_date) >= 0 && dayDiff(x.next_date) <= 7).reduce((s, x) => s + x.avg_amount, 0))}</div>
        <div class="delta">${active.filter((x) => x.next_date && dayDiff(x.next_date) >= 0 && dayDiff(x.next_date) <= 7).length} payments</div></div>
    </div>
    <div class="card" style="margin-top:16px"><h2>Recurring payments</h2>
      ${active.length ? `<table class="t-bills"><thead><tr><th>Bill</th><th class="num">Amount</th><th>Next</th><th>Paid from</th><th>Autopay?</th><th></th></tr></thead><tbody>${active.map(row).join("")}</tbody></table>`
        : `<div class="empty">No recurring payments detected yet. Detection needs at least 2–3 months of history.</div>`}
      ${ignored.length ? `<details style="margin-top:10px"><summary class="muted tiny">${ignored.length} removed suggestion${ignored.length === 1 ? "" : "s"} (won't come back unless you restore them)</summary><table>${ignored.map(row).join("")}</table></details>` : ""}
    </div>
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><div class="row"><h2>Alerts</h2><span class="spacer"></span>${unread ? `<button class="btn small secondary" id="readAll">Dismiss all (${unread})</button>` : ""}</div>
        ${a.alerts.length ? a.alerts.slice(0, 40).map(alertRow).join("") : `<div class="empty">No alerts yet.</div>`}</div>
      <div class="card"><h2>Alert settings</h2>
        <div class="grid g2">
          <label class="field">Warn me this many days before an autopay
            <select id="daysAhead">${[1, 2, 3, 5, 7].map((n) => `<option ${STATUS.alert_days_ahead == n ? "selected" : ""}>${n}</option>`).join("")}</select></label>
          <label class="field">Push to phone/email
            <select id="minSev"><option value="info">All alerts</option><option value="warn">Warnings and up</option><option value="danger">Only urgent (low balance)</option></select></label>
        </div>
        <h3 style="margin-top:16px">Phone &amp; email delivery</h3>
        <div class="kv"><div>Phone push (ntfy)</div><div>${STATUS.notify.ntfy ? '<span class="up">✓ on</span>' : "off"}</div><div>Email</div><div>${STATUS.notify.email ? '<span class="up">✓ on</span>' : "off"}</div></div>
        ${STATUS.last_delivery_error ? `<p class="down tiny">Last delivery error: ${esc(STATUS.last_delivery_error)}</p>` : ""}
        <p class="muted tiny">Alerts always show here. To also get them on your phone, install the free <b>ntfy</b> app, subscribe to a long random topic name, and put <code>"ntfy_url": "https://ntfy.sh/your-topic"</code> in <code>config.json</code>. Email works with any SMTP account (for Gmail, use an App Password). Then restart the app.</p>
        <button class="btn small secondary" id="testPush">Send test alert</button>
      </div>
    </div>`;
  $("#minSev").value = STATUS.push_min_severity;
  wireAlertButtons(main, () => PAGES.bills(main));
  const ra = $("#readAll"); if (ra) ra.onclick = async () => { await post("/api/alerts/read", {}); await refreshStatus(); PAGES.bills(main); };
  $$("[data-autopay]", main).forEach((s) => s.onchange = () => run(() => post(`/api/bills/${encodeURIComponent(s.dataset.autopay)}`, { autopay: s.value }), "Saved"));
  $$("[data-ignore]", main).forEach((btn) => btn.onclick = async () => {
    if (btn.dataset.to === "dismissed" && !confirm(`Remove "${btn.dataset.name}" from your bills? It won't be suggested again, and its alerts stop. You can restore it from the removed list.`)) return;
    await run(() => post(`/api/bills/${encodeURIComponent(btn.dataset.ignore)}`, { status: btn.dataset.to }), btn.dataset.to === "dismissed" ? "Removed" : "Restored");
    await refreshStatus(); PAGES.bills(main);
  });
  $("#daysAhead").onchange = async (e) => { await run(() => post("/api/alerts/settings", { alert_days_ahead: +e.target.value }), "Saved"); await refreshStatus(); PAGES.bills(main); };
  $("#minSev").onchange = async (e) => { await run(() => post("/api/alerts/settings", { push_min_severity: e.target.value }), "Saved"); await refreshStatus(); };
  $("#testPush").onclick = () => run(() => post("/api/alerts/test"), "Test alert sent");
};

PAGES.networth = async (main) => {
  const d = await api("/api/networth");
  const groups = [["depository", "Cash"], ["investment", "Investments"], ["other", "Other assets"], ["credit", "Credit cards"], ["loan", "Loans"]];
  const first = d.history[0], last = d.history.at(-1);
  main.innerHTML = `
    <h1>Net Worth</h1><p class="sub">Everything you own minus everything you owe. Add things like a car or home as manual accounts on the Accounts page.</p>
    <div class="grid g3">
      <div class="card stat"><div class="label">Net worth</div><div class="value">${fmt(d.current.net)}</div>
        <div class="delta">${first && last && first !== last ? `<span class="${last.net - first.net >= 0 ? "up" : "down"}">${signed(last.net - first.net)}</span> since ${shortDate(first.date)}, ${first.date.slice(0, 4)}` : "&nbsp;"}</div></div>
      <div class="card stat"><div class="label">Assets</div><div class="value">${fmt(d.current.assets)}</div><div class="delta">&nbsp;</div></div>
      <div class="card stat"><div class="label">Debts</div><div class="value">${fmt(d.current.liabilities)}</div><div class="delta">&nbsp;</div></div>
    </div>
    <div class="card" style="margin-top:16px"><h2>Net worth over time</h2>${chartSlot("line", d.history, { height: 260 })}</div>
    <div class="grid g2" style="margin-top:16px">
      ${[["Assets", groups.slice(0, 3)], ["Debts", groups.slice(3)]].map(([title, gs]) => `<div class="card"><h2>${title}</h2>
        ${gs.map(([type, label]) => { const list = d.accounts.filter((a) => a.type === type); if (!list.length) return "";
          const total = list.reduce((s, a) => s + Math.abs(a.signed_balance), 0);
          return `<h3 class="row" style="margin-top:10px">${label}<span class="spacer"></span><span class="num">${fmt(total)}</span></h3>
          <table>${list.map((a) => `<tr><td class="name">${esc(a.name)}<div class="tiny muted">${esc(a.institution || "")}${a.mask ? " ••" + esc(a.mask) : ""}</div></td><td class="num">${fmt2(Math.abs(a.signed_balance))}</td></tr>`).join("")}</table>`; }).join("") || `<div class="empty">None</div>`}
      </div>`).join("")}
    </div>`;
  drawCharts(main);
};

PAGES.invest = async (main) => {
  const plan = await api("/api/plan");
  const p = plan.profile, inp = plan.inputs;
  const field = (k, label, type = "number", extra = "") => `<label class="field">${label}<input name="${k}" type="${type}" value="${esc(p[k] ?? "")}" ${extra}></label>`;
  const sel = (k, label, opts) => `<label class="field">${label}<select name="${k}">${opts.map(([v, l]) => `<option value="${v}" ${String(p[k]) === String(v) ? "selected" : ""}>${l}</option>`).join("")}</select></label>`;
  const chk = (k, label) => `<label class="row" style="font-size:13px;flex-wrap:nowrap;align-items:flex-start;margin-top:4px"><input type="checkbox" name="${k}" ${p[k] ? "checked" : ""}> ${label}</label>`;
  const statusPill = { done: ["✓ Done", "var(--good)"], funded: ["In your plan", "var(--series-1)"], partial: ["Partly funded", "var(--series-1)"], waiting: ["Next, when money frees up", "var(--muted)"] };
  const al = plan.allocation;
  const allocColors = ["var(--series-1)", "var(--series-3)", "var(--series-2)"];
  main.innerHTML = `
    <h1>Investing Plan</h1><p class="sub">Where your next dollar should go, in priority order, sized to what you actually have left over each month.</p>
    <div class="grid" style="grid-template-columns: 330px 1fr; align-items:start">
      <form class="card" id="profile"><h2>About you</h2>
        <div class="grid g2">
          ${field("age", "Age")}${field("retirement_age", "Retire at")}
          <div class="span2">${field("annual_income", "Gross annual income ($)", "number", 'step="1000"')}</div>
          <div class="span2">${sel("filing_status", "Tax filing status", [["single", "Single"], ["mfj", "Married filing jointly"], ["mfs", "Married filing separately"], ["hoh", "Head of household"]])}</div>
        </div>
        <h3 style="margin-top:14px">Workplace retirement plan</h3>
        ${chk("has_401k", "I have a 401(k)/403(b)")}
        <div class="grid g2" style="margin-top:6px">${field("current_401k_pct", "I contribute (%)", "number", 'step="0.5"')}${field("employer_match_pct", "Employer matches up to (%)", "number", 'step="0.5"')}
          ${field("match_rate", "Match rate (%)", "number", 'step="25"')}</div>
        <h3 style="margin-top:14px">Other accounts</h3>
        ${chk("hsa_eligible", "I'm on an HSA-eligible (high-deductible) health plan")}
        <div class="grid g2" style="margin-top:6px">${sel("hsa_coverage", "HSA coverage", [["self", "Self-only"], ["family", "Family"]])}${field("hsa_ytd", `HSA put in ${plan.limits.year} ($)`)}
          ${field("roth_ira_ytd", `Roth IRA put in ${plan.limits.year} ($)`)}</div>
        ${chk("has_pretax_ira_balance", "I have money in a traditional/rollover IRA")}
        <h3 style="margin-top:14px">Safety net &amp; debt</h3>
        <div class="grid g2">${field("emergency_months", "Emergency fund (months)", "number", 'step="1" min="1" max="12"')}
          ${field("high_interest_debt", "Card debt I carry ($)")}${field("high_interest_apr", "Its APR (%)")}
          ${sel("risk", "Risk comfort", [["conservative", "Conservative"], ["moderate", "Moderate"], ["aggressive", "Aggressive"]])}
          <div class="span2">${field("monthly_surplus_override", `Monthly amount to plan with ($) <span class="muted">blank = use ${fmt(inp.avg_income - inp.avg_spending)} from your data</span>`, "number", 'placeholder="auto"')}</div></div>
        ${plan.card_balances > 0 ? `<p class="tiny muted">Your cards show ${fmt(plan.card_balances)} right now. If you pay the full statement each month, leave "card debt I carry" at 0.</p>` : ""}
        <button class="btn" style="margin-top:12px;width:100%">Update plan</button>
      </form>
      <div>
        <div class="grid g3">
          <div class="card stat"><div class="label">Planning with</div><div class="value">${fmt(inp.surplus)}<span class="muted" style="font-size:14px">/mo</span></div><div class="delta">${esc(inp.surplus_source)}</div></div>
          <div class="card stat"><div class="label">Cash on hand</div><div class="value">${fmt(inp.cash)}</div><div class="delta">${(inp.cash / (inp.essential || 1)).toFixed(1)} months of essentials</div></div>
          <div class="card stat"><div class="label">Tax bracket (est.)</div><div class="value">${Math.round(inp.marginal_rate * 100)}%</div><div class="delta">${inp.income_estimated ? "income guessed from deposits; enter it for accuracy" : "federal marginal rate"}</div></div>
        </div>
        <div class="card" style="margin-top:16px"><h2>Your next-dollar plan</h2>
          ${plan.steps.map((s, i) => `<div class="step ${s.status}"><div class="n">${s.status === "done" ? "✓" : i + 1}</div>
            <div><b>${esc(s.title)}</b> <span class="pill"><span class="dot" style="background:${statusPill[s.status][1]}"></span>${statusPill[s.status][0]}</span>
              <div class="why">${esc(s.why)}</div>${s.detail ? `<div class="detail">${esc(s.detail)}</div>` : ""}</div>
            <div class="amt">${s.status === "done" ? "" : s.monthly > 0 ? `<b>${fmt(s.monthly)}</b><span class="muted">/mo</span>${Math.abs(s.take_home_cost - s.monthly) > 1 ? `<div class="tiny muted">costs ~${fmt(s.take_home_cost)} take-home</div>` : ""}` : s.full_monthly > 0 ? `<span class="tiny muted">wants ${fmt(s.full_monthly)}/mo</span>` : ""}</div></div>`).join("")}
          ${plan.unallocated > 1 ? `<p class="muted">Unallocated: ${fmt(plan.unallocated)}/mo</p>` : ""}
        </div>
        <div class="grid g2" style="margin-top:16px">
          <div class="card"><h2>What to invest in</h2>
            <div class="muted tiny">Suggested mix for age ${p.age}, ${esc(p.risk)} risk: ${al.stocks}% stocks / ${al.bonds}% bonds</div>
            <div class="alloc">${al.mix.filter((m) => m.pct > 0).map((m, i) => `<div style="flex:${m.pct};background:${allocColors[i]}" data-tip="${esc(`<b>${m.name}</b><br>${m.pct}%`)}"></div>`).join("")}</div>
            <table>${al.mix.map((m, i) => `<tr><td><span class="legend" style="margin:0"><span><i style="background:${allocColors[i]}"></i>${esc(m.name)}</span></span></td><td class="num">${m.pct}%</td></tr>`).join("")}</table>
            <ul class="tiny muted" style="padding-left:18px;margin-bottom:0">${al.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul></div>
          <div class="card"><h2>Where this could lead</h2>
            <div class="stat"><div class="value">${fmt(plan.projection.future_value)}</div>
            <div class="delta">by age ${p.retirement_age} (≈ ${fmt(plan.projection.today_dollars)} in today's dollars)</div></div>
            <p class="tiny muted">Assumes ${fmt(plan.projection.monthly)}/mo into investments (including employer match) on top of today's ${fmt(plan.projection.starting_balance)}, earning ${(plan.projection.rate * 100).toFixed(0)}%/yr for ${plan.projection.years} years, 3% inflation. Real returns vary a lot year to year.</p>
            <h3>${plan.limits.year} limits used</h3>
            <div class="kv tiny"><div>Roth / traditional IRA</div><div>${fmt(plan.limits.ira)} (+${fmt(plan.limits.ira_catchup_50)} if 50+)</div>
              <div>401(k) employee</div><div>${fmt(plan.limits.k401)} (+${fmt(plan.limits.k401_catchup_50)} if 50+)</div>
              <div>HSA</div><div>${fmt(plan.limits.hsa_self)} self / ${fmt(plan.limits.hsa_family)} family</div></div></div>
        </div>
        <p class="disclaimer">${esc(plan.disclaimer)}</p>
      </div>
    </div>`;
  $("#profile").onsubmit = async (e) => {
    e.preventDefault();
    const body = {};
    $$("input, select", e.target).forEach((el) => { body[el.name] = el.type === "checkbox" ? el.checked : el.value; });
    await run(() => post("/api/profile", body), "Plan updated");
    PAGES.invest(main);
  };
};

const KIND_OPTIONS = [
  ["depository|checking", "Cash · checking"], ["depository|savings", "Cash · savings"], ["depository|money market", "Cash · money market / CD"],
  ["investment|roth", "Investment · Roth IRA"], ["investment|ira", "Investment · traditional IRA"], ["investment|401k", "Investment · 401(k)/403(b)"],
  ["investment|hsa", "Investment · HSA"], ["investment|brokerage", "Investment · brokerage"], ["investment|crypto exchange", "Investment · crypto"],
  ["credit|credit card", "Credit card"], ["loan|student", "Loan · student"], ["loan|auto", "Loan · auto"], ["loan|mortgage", "Loan · mortgage"], ["loan|loan", "Loan · other"],
  ["other|vehicle", "Other asset · vehicle"], ["other|home", "Other asset · home"], ["other|other", "Other asset"],
];
function kindOf(a) {
  const exact = `${a.type}|${(a.subtype || "").toLowerCase()}`;
  if (KIND_OPTIONS.some(([v]) => v === exact)) return exact;
  if (a.type === "depository" && /cd|cash management/.test(a.subtype || "")) return "depository|money market";
  if (a.type === "investment" && /roth/i.test(a.subtype || "")) return "investment|roth";
  return { depository: "depository|checking", investment: "investment|brokerage", credit: "credit|credit card", loan: "loan|loan", other: "other|other" }[a.type];
}
function kindTotals(accts) {
  const t = { Cash: 0, Investments: 0, "Credit cards": 0, Loans: 0, "Other assets": 0 };
  accts.filter((a) => !a.is_hidden).forEach((a) => { t[{ depository: "Cash", investment: "Investments", credit: "Credit cards", loan: "Loans", other: "Other assets" }[a.type]] += a.current_balance || 0; });
  return t;
}
function kindStrip(accts) {
  const t = kindTotals(accts);
  return `<div class="grid g4" style="grid-template-columns:repeat(5,minmax(0,1fr));margin-top:16px">${Object.entries(t).map(([k, v]) =>
    `<div class="card stat" style="padding:12px 14px"><div class="label">${k}</div><div class="value" style="font-size:20px">${(k === "Credit cards" || k === "Loans") && v ? "−" : ""}${fmt(v)}</div></div>`).join("")}</div>`;
}

PAGES.accounts = async (main) => {
  const d = await api("/api/accounts");
  const typeLabel = { depository: "Cash", credit: "Credit card", loan: "Loan", investment: "Investment", other: "Other asset" };
  main.innerHTML = `
    <h1>Accounts</h1><p class="sub">Connect banks with Plaid, import CSV files, or track things by hand. Set each account's kind so totals, the plan and goals count it correctly.</p>
    ${d.accounts.length ? kindStrip(d.accounts) + '<div style="height:16px"></div>' : ""}
    <div class="grid g2">
      <div class="card"><h2>Bank connections</h2>
        ${STATUS.plaid_configured ? `<p class="tiny muted" style="margin-top:-6px">Plaid mode: <b>${esc(STATUS.plaid_env)}</b>${STATUS.plaid_env === "sandbox" ? " (test banks only; use user_good / pass_good)" : ""}</p>` : `<p class="muted">Plaid isn't set up yet. Add your free Plaid keys to <code>config.json</code> and restart; see README.md. Until then, CSV import and manual accounts work.</p>`}
        ${d.items.length ? `<table>${d.items.map((i) => `<tr><td>${esc(i.institution || "Bank")}<div class="tiny ${i.error ? "down" : "muted"}">${i.error ? "Needs attention: " + esc(i.error) : "Synced " + esc((i.last_sync || "never").replace("T", " "))}</div></td>
          <td class="num">${i.error ? `<button class="btn small" data-relink="${esc(i.item_id)}">Reconnect</button> ` : ""}<button class="btn small danger" data-unlink="${esc(i.item_id)}">Disconnect</button></td></tr>`).join("")}</table>` : ""}
        <button class="btn" id="connect" style="margin-top:10px" ${STATUS.plaid_configured ? "" : "disabled"}>+ Connect a bank</button>
      </div>
      <div class="card"><h2>Import a CSV</h2>
        <p class="tiny muted" style="margin-top:-6px">Download transactions from your bank's website as CSV. Needs Date, Description and Amount (or Debit/Credit) columns. Re-importing the same file won't create duplicates.</p>
        <div class="grid g2"><label class="field">Into account<select id="csvAcct">${d.accounts.filter((a) => a.source !== "plaid").map((a) => `<option value="${esc(a.id)}">${esc(a.name)}</option>`).join("")}<option value="__new">+ New account…</option></select></label>
          <label class="field">File<input type="file" id="csvFile" accept=".csv,text/csv"></label></div>
        <label class="row tiny" style="margin:8px 0"><input type="checkbox" id="csvFlip"> Purchases show as positive numbers in this file (common for credit cards)</label>
        <button class="btn small" id="csvGo">Import</button>
      </div>
    </div>
    <div class="card" style="margin-top:16px"><h2>All accounts</h2>
      ${d.accounts.length ? `<table class="t-accts"><thead><tr><th>Account</th><th>Kind</th><th class="num">Balance</th><th>APR</th><th></th></tr></thead><tbody>
      ${d.accounts.map((a) => `<tr style="${a.is_hidden ? "opacity:.5" : ""}"><td class="name">${esc(a.name)}<div class="tiny muted">${esc(a.institution || "")}${a.mask ? " ••" + esc(a.mask) : ""} · ${esc(a.source)}</div></td>
        <td><select data-kind="${esc(a.id)}" class="cat-select">${KIND_OPTIONS.map(([v, l]) => `<option value="${v}" ${v === kindOf(a) ? "selected" : ""}>${l}</option>`).join("")}</select></td>
        <td class="num">${a.source === "plaid" ? fmt2(a.current_balance) : `<input data-bal="${esc(a.id)}" type="number" step="0.01" value="${a.current_balance}" style="width:120px;text-align:right">`}${a.is_liability ? '<div class="tiny muted">owed</div>' : ""}</td>
        <td>${a.is_liability ? `<input data-apr="${esc(a.id)}" type="number" step="0.1" value="${a.liability?.apr ?? ""}" placeholder="%" style="width:70px">` : ""}</td>
        <td class="num" style="white-space:nowrap"><button class="btn small secondary" data-hide="${esc(a.id)}" data-v="${a.is_hidden ? 0 : 1}">${a.is_hidden ? "Show" : "Hide"}</button>
          ${a.source !== "plaid" ? `<button class="btn small danger" data-delacct="${esc(a.id)}">Delete</button>` : ""}</td></tr>`).join("")}</tbody></table>` : `<div class="empty">No accounts yet.</div>`}
    </div>
    <div class="grid g2" style="margin-top:16px">
      <form class="card" id="manual"><h2>Add a manual account</h2>
        <p class="tiny muted" style="margin-top:-6px">For a home, car, a 401(k) you can't connect, a personal loan, etc. Update the balance here when it changes.</p>
        <div class="grid g2"><label class="field">Name<input name="name" required placeholder="e.g. Home (Zillow estimate)"></label>
          <label class="field">Type<select name="type">${Object.entries(typeLabel).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></label>
          <label class="field">Balance / value ($)<input name="balance" type="number" step="0.01" required></label>
          <label class="field">APR % (debts only)<input name="apr" type="number" step="0.1"></label></div>
        <button class="btn small" style="margin-top:10px">Add account</button></form>
      <div class="card"><h2>Demo data</h2>
        <p class="tiny muted" style="margin-top:-6px">A year of realistic made-up accounts and transactions to try every feature. Clearing removes only demo accounts.</p>
        <div class="row"><button class="btn small secondary" id="demoLoad">${STATUS.has_demo ? "Reload" : "Load"} demo data</button>${STATUS.has_demo ? `<button class="btn small danger" id="demoClear">Remove demo data</button>` : ""}</div>
        <h3 style="margin-top:16px">Privacy</h3>
        <p class="tiny muted">Everything is stored only on this computer in <code>data/finance.db</code>. The app listens on localhost only. Bank access tokens are encrypted with your Windows login (DPAPI). Your bank password never touches this app; Plaid handles sign-in.</p></div>
    </div>`;
  $("#connect").onclick = () => plaidLink();
  $$("[data-relink]", main).forEach((b) => b.onclick = () => plaidLink(b.dataset.relink));
  $$("[data-unlink]", main).forEach((b) => b.onclick = async () => {
    if (!confirm("Disconnect this bank? Its accounts and transactions will be removed from this app.")) return;
    await run(() => del("/api/plaid/items/" + encodeURIComponent(b.dataset.unlink)), "Disconnected"); await refreshStatus(); PAGES.accounts(main);
  });
  $$("[data-bal]", main).forEach((i) => i.onchange = () => run(() => post("/api/accounts/" + encodeURIComponent(i.dataset.bal), { balance: i.value }), "Balance saved"));
  $$("[data-kind]", main).forEach((s) => s.onchange = async () => {
    const [type, subtype] = s.value.split("|");
    await run(() => post("/api/accounts/" + encodeURIComponent(s.dataset.kind), { type, subtype }), "Saved");
    PAGES.accounts(main);
  });
  $$("[data-apr]", main).forEach((i) => i.onchange = () => run(() => post("/api/accounts/" + encodeURIComponent(i.dataset.apr), { apr: i.value }), "APR saved"));
  $$("[data-hide]", main).forEach((b) => b.onclick = async () => { await run(() => post("/api/accounts/" + encodeURIComponent(b.dataset.hide), { is_hidden: +b.dataset.v })); PAGES.accounts(main); });
  $$("[data-delacct]", main).forEach((b) => b.onclick = async () => {
    if (!confirm("Delete this account and all its transactions from the app?")) return;
    await run(() => del("/api/accounts/" + encodeURIComponent(b.dataset.delacct)), "Deleted"); await refreshStatus(); PAGES.accounts(main);
  });
  $("#manual").onsubmit = async (e) => {
    e.preventDefault();
    await run(() => post("/api/accounts", Object.fromEntries(new FormData(e.target))), "Account added");
    await refreshStatus(); PAGES.accounts(main);
  };
  $("#csvGo").onclick = async () => {
    const f = $("#csvFile").files[0];
    if (!f) return toast("Choose a CSV file first", true);
    let acct = $("#csvAcct").value;
    if (acct === "__new") {
      const name = (prompt("Name for the new account (e.g. 'Chase Checking'):") || "").trim();
      if (!name) return;
      const isCard = confirm("Is this a credit card? (OK = credit card, Cancel = bank account)");
      acct = (await run(() => post("/api/accounts", { name, type: isCard ? "credit" : "depository", balance: 0 }))).id;
    }
    const res = await run(async () => post("/api/import/csv", { account_id: acct, csv: await f.text(), flip_sign: $("#csvFlip").checked }),
      (r) => `Imported ${r.imported} transactions${r.skipped ? `, skipped ${r.skipped} (duplicates or blank)` : ""}`);
    if (res) { await refreshStatus(); PAGES.accounts(main); }
  };
  $("#demoLoad").onclick = loadDemo;
  const dc = $("#demoClear"); if (dc) dc.onclick = async () => { await run(() => post("/api/demo/clear"), "Demo data removed"); await refreshStatus(); PAGES.accounts(main); };
};

// ---------------------------------------------------------------- plaid link
function loadScript(src) {
  return new Promise((res, rej) => { if ($(`script[src="${src}"]`)) return res(); const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = () => rej(new Error("Couldn't load Plaid Link (are you online?)")); document.head.appendChild(s); });
}
// Opens Plaid. From your Tailscale (HTTPS) address it uses Plaid's redirect sign-in: banks like
// Vanguard send you back to /oauth.html, which finishes the connection. Elsewhere it uses a pop-up.
async function openPlaid({ itemId = null, addInvestments = false } = {}) {
  const res = await run(() => post("/api/plaid/link_token", { item_id: itemId, add_investments: addInvestments, origin: location.origin }));
  if (res.redirect) {
    localStorage.setItem("plaidPending", JSON.stringify({ token: res.link_token, itemId, addInvestments, at: Date.now() }));
  } else if (res.redirect_hint) {
    showRedirectHint(res.redirect_hint);
  }
  await run(() => loadScript("https://cdn.plaid.com/link/v2/stable/link-initialize.js"));
  window.Plaid.create({
    token: res.link_token,
    onSuccess: async (public_token, meta) => {
      localStorage.removeItem("plaidPending");
      if (addInvestments) { toast("Access granted · loading holdings…"); await run(() => post("/api/investments/sync")); }
      else if (itemId) { toast("Reconnected · syncing…"); await run(() => post("/api/sync")); }
      else { toast("Connected · importing transactions…"); await run(() => post("/api/plaid/exchange", { public_token, institution: meta?.institution?.name }), "Bank connected"); }
      await refreshStatus(); route();
    },
    onExit: (err) => {
      localStorage.removeItem("plaidPending");
      if (err) toast(err.display_message || err.error_message || "Plaid Link closed", true);
    },
  }).open();
}
const plaidLink = (itemId) => openPlaid({ itemId });

function showRedirectHint(uri) {
  if (sessionStorage.getItem("redirectHintShown")) return;
  sessionStorage.setItem("redirectHintShown", "1");
  const dlg = $("#dlg");
  dlg.innerHTML = `<h2>Make bank sign-ins more reliable</h2>
    <p class="tiny">Some banks (Vanguard especially) can get stuck when they sign you in through a pop-up window. Plaid has a sturdier way, but it needs one setting in your Plaid account first:</p>
    <ol class="tiny"><li>Open <b>dashboard.plaid.com</b> → <b>Developers → API</b> (or Team Settings → API).</li>
      <li>Under <b>Allowed redirect URIs</b>, add exactly:<div class="rcode" style="font-size:13px">${esc(uri)}</div></li>
      <li>Save, then try connecting again from this same address.</li></ol>
    <p class="tiny muted">For now the pop-up will open as usual.</p>
    <div class="row"><span class="spacer"></span><button class="btn" id="hintOk">OK</button></div>`;
  dlg.showModal();
  $("#hintOk").onclick = () => dlg.close();
}

async function loadDemo() {
  await run(() => post("/api/demo/load"), (r) => `Demo loaded: ${r.transactions} transactions, ${r.bills} bills found`);
  await refreshStatus(); route();
}

// ---------------------------------------------------------------- shell
async function refreshStatus(background = false) {
  STATUS = await api("/api/status", { background });
  const b = $("#alertBadge");
  b.hidden = !STATUS.unread_alerts; b.textContent = STATUS.unread_alerts;
  const last = STATUS.items.map((i) => i.last_sync).filter(Boolean).sort().at(-1);
  $("#syncInfo").textContent = STATUS.items.length ? (last ? "Last sync " + last.replace("T", " ").slice(5, 16) : "Not synced yet") : "No banks connected";
}

const NAV_ALIAS = { checkin: "dashboard", leaks: "bills" };   // a page with no menu entry lights up the one it is reached from
async function route() {
  const [page, qs] = (location.hash.slice(1) || "dashboard").split("?");
  const name = PAGES[page] ? page : "dashboard";
  const at = NAV_ALIAS[name] || name;
  $$(".sidebar a[data-page]").forEach((a) => a.classList.toggle("active", a.dataset.page === at));
  $$(".sidebar .nav-group").forEach((g) => g.classList.toggle("open", $$("a[data-page]", g).some((a) => a.dataset.page === at)));
  if (window.paintNav) window.paintNav();
  const main = $("#main");
  try { await PAGES[name](main, qs || ""); }
  catch (e) { main.innerHTML = `<div class="card"><h2>Something went wrong</h2><p class="down">${esc(e.message)}</p></div>`; }
}

$("#syncBtn").onclick = async (e) => {
  e.target.disabled = true; e.target.textContent = "Syncing…";
  try {
    const r = await run(() => post("/api/sync"));
    const errs = Object.entries(r.errors || {});
    toast(errs.length ? `Sync issues: ${errs.map(([k, v]) => k + ": " + v).join("; ")}` : "Up to date", !!errs.length);
    await refreshStatus(); route();
  } finally { e.target.disabled = false; e.target.textContent = "Sync now"; }
};
window.addEventListener("hashchange", () => { if (!AUTH_SHOWN) route(); });
setInterval(() => { if (!AUTH_SHOWN) refreshStatus(true).catch(() => {}); }, 60000);

// ---------------------------------------------------------------- password protection
let AUTH_SHOWN = false;
function showAuth(mode, info = {}) {
  AUTH_SHOWN = true;
  $(".shell").hidden = true;  // nothing from your finances stays on screen while locked
  $("#main").innerHTML = "";
  let el = $("#authScreen");
  if (!el) { el = document.createElement("div"); el.id = "authScreen"; document.body.appendChild(el); }
  const setup = mode === "setup";
  el.innerHTML = `<form class="auth-card" autocomplete="on">
    <div class="auth-icon">${setup ? "🔐" : "🔒"}</div>
    <h1>${setup ? "Protect Kerdos" : "Kerdos is locked"}</h1>
    <p class="muted">${setup ? `Create a password. You'll need it every time you open the app, and after it's been idle a while. There's no "forgot password" email: if you lose it, see the README for the reset command.`
      : "Enter your password to continue."}</p>
    <input type="text" name="username" value="finance-hub" autocomplete="username" hidden>
    <input id="authPw" type="password" placeholder="Password" autocomplete="${setup ? "new-password" : "current-password"}" required minlength="${info.min_length || 8}">
    ${setup ? `<input id="authPw2" type="password" placeholder="Type it again" autocomplete="new-password" required>
      <div class="tiny muted">At least ${info.min_length || 8} characters. A short phrase is easier to remember than random symbols.</div>`
      : `<label class="row tiny"><input type="checkbox" id="authRemember"> Keep me signed in on this computer for 7 days (no auto-lock)</label>`}
    <div id="authErr" class="down tiny"></div>
    <button class="btn" id="authGo">${setup ? "Create password" : "Unlock"}</button></form>`;
  el.hidden = false;
  setTimeout(() => $("#authPw")?.focus(), 50);
  $("form", el).onsubmit = async (e) => {
    e.preventDefault();
    const err = $("#authErr"), btn = $("#authGo");
    err.textContent = "";
    if (setup && $("#authPw").value !== $("#authPw2").value) { err.textContent = "The two passwords don't match"; return; }
    btn.disabled = true;
    try {
      await api(setup ? "/api/auth/setup" : "/api/auth/login", { method: "POST",
        body: { password: $("#authPw").value, remember: !!$("#authRemember")?.checked } });
      el.hidden = true; el.innerHTML = "";
      AUTH_SHOWN = false;
      $(".shell").hidden = false;
      await refreshStatus(); route();
    } catch (ex) { err.textContent = ex.message; btn.disabled = false; $("#authPw").select(); }
  };
}

async function lockNow() {
  await api("/api/auth/logout", { method: "POST" }).catch(() => {});
  showAuth("locked");
}

async function boot() {
  // Wait until every script (the later page files wrap the earlier ones) has loaded before drawing anything
  if (document.readyState === "loading") await new Promise((r) => document.addEventListener("DOMContentLoaded", r, { once: true }));
  const a = await api("/api/auth/status");
  if (!a.configured) return showAuth("setup", a);
  if (!a.signed_in) return showAuth("locked", a);
  await refreshStatus(); route();
}
{
  const foot = $(".sidebar-foot");
  const b = document.createElement("button");
  b.className = "btn small secondary"; b.id = "lockBtn"; b.textContent = "🔒 Lock"; b.title = "Lock the app now";
  b.onclick = lockNow;
  foot.insertBefore(b, foot.firstChild.nextSibling);
}
boot();
