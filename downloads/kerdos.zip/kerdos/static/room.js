// Kerdos: the companion's room is a toy. Pick up your pet and toss it, pet it, throw its ball,
// and drag the furniture where you like. Positions are saved with the companion.
"use strict";

function initRoom(svg, d) {
  const W = 360, H = 260, FY = 186, G = 1100;
  const eq = d.room.equipped;
  const layout = JSON.parse(JSON.stringify(d.room.layout || {}));
  layout.furn = layout.furn || {};
  const fx = $(".room-fx", svg), petG = $(".pet-move", svg);
  if (!petG || !fx) return;
  const lift = +petG.dataset.lift || 0;
  const pt = (e) => new DOMPoint(e.clientX, e.clientY).matrixTransform(svg.getScreenCTM().inverse());
  const clamp = (v, lo, hi) => (lo > hi ? 0 : Math.max(lo, Math.min(hi, v)));
  let saveT = null;
  const snapshot = () => {   // where everything is right now
    const out = { furn: {} };
    Object.entries(furn).forEach(([k, f]) => { if (f.x || f.y) out.furn[k] = [Math.round(f.x), Math.round(f.y)]; });
    out.pet = [Math.round(pet.x), Math.round(pet.y), Math.round(pet.floorY)];
    if (ball) out.ball = [Math.round(ball.x), Math.round(ball.y), Math.round(ball.floorY)];
    d.room.layout = out;
    return out;
  };
  const sendLayout = () => api("/api/companion", { method: "POST", body: { layout: snapshot() }, background: true }).catch(() => {});
  const save = () => { clearTimeout(saveT); saveT = setTimeout(() => { saveT = null; sendLayout(); }, 500); };
  const flush = () => { if (saveT) { clearTimeout(saveT); saveT = null; sendLayout(); } else snapshot(); };   // before the room is redrawn
  // Other code (pet care) listens for what happens in here: pet, toss, fetch, rest, reach, step
  const listeners = {};
  const emit = (name, ...args) => (listeners[name] || []).forEach((fn) => fn(...args));

  // ------------------------------------------------------------ furniture
  const isBall = eq.buddy === "buddy_ball";
  const furn = {};
  $$("[data-furn]", svg).forEach((g) => {
    const slot = g.dataset.furn;
    if (slot === "buddy" && isBall) return;
    g.removeAttribute("transform");
    const bb = g.getBBox(), o = layout.furn[slot] || [0, 0];
    const f = furn[slot] = { g, bb, x: +o[0] || 0, y: +o[1] || 0, wall: ["window", "art", "shelf"].includes(slot) || (slot === "lamp" && eq.lamp === "lamp_string") };
    placeF(f);
    g.addEventListener("pointerdown", (e) => dragFurn(e, f, slot));
  });
  function placeF(f) {
    const b = f.bb, bottom = b.y + b.height;
    f.x = clamp(f.x, -b.x, W - b.x - b.width);
    f.y = f.wall ? clamp(f.y, -b.y, FY - 3 - bottom) : clamp(f.y, FY + 6 - bottom, H - bottom);
    f.g.setAttribute("transform", `translate(${f.x.toFixed(1)} ${f.y.toFixed(1)})`);
  }
  function depthSort() {  // floor pieces nearer the front are drawn on top
    ["lamp", "buddy", "bed", "bowl"].map((k) => furn[k]).filter((f) => f && !f.wall)
      .sort((a, b) => (a.bb.y + a.bb.height + a.y) - (b.bb.y + b.bb.height + b.y))
      .forEach((f) => svg.insertBefore(f.g, ball ? ball.g : petG));
  }
  function dragFurn(e, f, slot) {
    e.preventDefault();
    const p0 = pt(e), x0 = f.x, y0 = f.y, px0 = pet.x, py0 = pet.y, riding = slot === "bed" && pet.onBed && pet.rest;
    try { f.g.setPointerCapture(e.pointerId); } catch (_) { /* fine without it */ }
    f.g.classList.add("dragging");
    const move = (ev) => {
      const p = pt(ev);
      f.x = x0 + p.x - p0.x; f.y = y0 + p.y - p0.y;
      placeF(f);
      if (riding) { pet.x = px0 + f.x - x0; pet.y = py0 + f.y - y0; draw(pet); }
    };
    const up = () => {
      f.g.removeEventListener("pointermove", move);
      f.g.classList.remove("dragging");
      depthSort();
      [pet, ball].forEach((b) => { if (b && !b.held) { b.rest = false; } });  // anything left floating drops
      kick(); save();
    };
    f.g.addEventListener("pointermove", move);
    f.g.addEventListener("pointerup", up, { once: true });
    f.g.addEventListener("pointercancel", up, { once: true });
  }

  // ------------------------------------------------------------ things you can throw
  const y0 = FY + 50 - lift - 196, toRoom = (x, y) => [76 + 0.8 * x, y0 + 0.8 * y];
  function petBox() {
    let top, bottom, hw;
    if (d.kind === "pet") {
      const s = [1, 0.62, 0.78, 0.92, 1][d.stage] || 1;
      if (!d.stage) { top = 90; bottom = 236; hw = 50; } else { top = 230 - 120 * s - (d.stage >= 2 ? 30 * s : 0); bottom = 236; hw = 62 * s; }
    } else {
      const stem = [8, 40, 80, 105, 112][d.stage] || 8, r = d.stage >= 3 ? (d.stage === 3 ? 42 : 52) : 0;
      top = 200 - stem - r * 1.5; bottom = 246; hw = Math.max(44, r);
    }
    const [cx, ty] = toRoom(130, top), [, by] = toRoom(130, bottom);
    return { cx, cy: (ty + by) / 2, hw: hw * 0.8, hh: (by - ty) / 2 };
  }
  const mk = (g, box, o) => Object.assign({ g, x: 0, y: 0, vx: 0, vy: 0, a: 0, va: 0, q: 0, rest: false, held: false, onBed: false }, box, o);
  const isPet = d.kind === "pet";
  const pet = mk(petG, petBox(), { bounce: isPet ? 0.55 : 0.22, spin: isPet, name: "pet" });
  const homeBottom = pet.cy + pet.hh;          // where it sits on its bed at the bed's original spot
  const floorLine = homeBottom + lift;          // where it stands on the bare floor
  pet.floorY = pet.homeFloor = floorLine;
  let ball = null;
  if (isBall) {
    const g = $('[data-furn="buddy"]', svg);
    g.removeAttribute("transform");
    const bb = g.getBBox();
    ball = mk(g, { cx: bb.x + bb.width / 2, cy: bb.y + bb.height / 2, hw: bb.width / 2, hh: bb.height / 2 }, { bounce: 0.74, spin: true, name: "ball" });
    ball.floorY = ball.homeFloor = ball.cy + ball.hh;
    svg.insertBefore(g, petG);
    const o = layout.ball;
    if (o) { ball.x = +o[0] || 0; ball.y = +o[1] || 0; ball.floorY = clamp(+o[2] || ball.floorY, FY + 14, H - 4); }
  }
  if (layout.pet) { pet.x = +layout.pet[0] || 0; pet.y = +layout.pet[1] || 0; pet.floorY = clamp(+layout.pet[2] || floorLine, FY + 18, H - 4); }
  const bodies = [pet, ball].filter(Boolean);

  function draw(b) {
    const fy = b.cy + b.hh;
    b.g.setAttribute("transform", `translate(${b.x.toFixed(1)} ${b.y.toFixed(1)}) rotate(${b.a.toFixed(1)} ${b.cx} ${b.cy})` +
      (b.q > 0.005 ? ` translate(${b.cx} ${fy}) scale(${1 + b.q} ${1 - b.q}) translate(${-b.cx} ${-fy})` : ""));
  }
  function groundFor(b) {
    let gy = b.floorY;
    b.overBed = false;
    const bed = furn.bed;
    if (b === pet && bed) {
      const c = b.cx + b.x, x0 = bed.bb.x + bed.x + bed.bb.width * 0.1, x1 = bed.bb.x + bed.x + bed.bb.width * 0.9;
      const top = homeBottom + bed.y;
      if (c > x0 && c < x1 && b.cy + b.hh + b.y <= top + 8) { gy = Math.min(gy, top); b.overBed = true; }
    }
    return gy;
  }
  function limit(b) {
    b.x = clamp(b.x, b.hw - b.cx, W - b.hw - b.cx);
    b.y = Math.max(b.y, b.hh - b.cy);
  }

  // little effects: hearts, stars, leaves
  const parts = [];
  function puff(x, y, glyph, color, n = 1, spread = 60) {
    for (let i = 0; i < n; i++) {
      const el = document.createElementNS("http://www.w3.org/2000/svg", "text");
      el.textContent = glyph; el.setAttribute("fill", color); el.setAttribute("font-size", 13 + Math.random() * 6); el.setAttribute("text-anchor", "middle");
      fx.appendChild(el);
      parts.push({ el, x: x + (Math.random() - 0.5) * 14, y, vx: (Math.random() - 0.5) * spread, vy: -40 - Math.random() * 50, life: 1 });
    }
  }
  const head = (b) => [b.cx + b.x, b.cy - b.hh + b.y - 4];

  function step(dt) {
    let active = parts.length > 0;
    for (const b of bodies) {
      if (b.q > 0) { b.q = Math.max(0, b.q - dt * 1.4); active = true; }
      if (b.held) { active = true; continue; }
      if (b.rest) {
        if (b.spin && b !== ball) {  // stand back up
          const t = Math.round(b.a / 360) * 360;
          if (Math.abs(b.a - t) > 0.5) { b.a += (t - b.a) * Math.min(1, dt * 9); active = true; } else b.a = t;
        }
        draw(b);
        continue;
      }
      active = true;
      b.vy += G * dt;
      b.x += b.vx * dt; b.y += b.vy * dt; b.a += b.va * dt;
      if (b.cx + b.x - b.hw < 0) { b.x = b.hw - b.cx; b.vx = Math.abs(b.vx) * b.bounce; b.va *= -0.5; }
      if (b.cx + b.x + b.hw > W) { b.x = W - b.hw - b.cx; b.vx = -Math.abs(b.vx) * b.bounce; b.va *= -0.5; }
      if (b.cy + b.y - b.hh < 0) { b.y = b.hh - b.cy; b.vy = Math.abs(b.vy) * b.bounce; }
      const gy = groundFor(b);
      if (b.cy + b.y + b.hh >= gy) {
        b.y = gy - b.cy - b.hh;
        if (b.vy > 90) {
          const hit = b.vy;
          b.q = Math.min(0.28, hit / 2200);
          b.vy = -hit * b.bounce; b.vx *= 0.82;
          if (b.spin) b.va = b.vx * (b === ball ? 180 / Math.PI / b.hw : 1.6);
          if (b === pet && hit > 520) puff(...head(b), isPet ? "✦" : "🍃", isPet ? "#f6d046" : "#4f8a3a", 3, 90);
        } else {
          b.vy = 0;
          b.vx *= Math.max(0, 1 - dt * (b === ball ? 1.6 : 7));
          if (b === ball) b.va = b.vx * 180 / Math.PI / b.hw; else b.va = 0;
          if (b.spin && b !== ball) { const t = Math.round(b.a / 360) * 360; b.a += (t - b.a) * Math.min(1, dt * 9); }
          if (Math.abs(b.vx) < 6) {
            b.vx = 0; b.va = 0; b.rest = true; b.onBed = !!b.overBed;
            if (b === ball && ball.thrown && canFetch() && !pet.target) { pet.target = ball; ball.thrown = false; }
            if (b === pet && pet.target) hopToTarget();
            if (b === pet || b === ball) save();
            emit("rest", b);
          }
        }
      }
      draw(b);
    }
    if (pet.rest && pet.target && !pet.held && pet.target.rest) { hopToTarget(); active = true; }
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      p.life -= dt * 0.9; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 30 * dt;
      if (p.life <= 0) { p.el.remove(); parts.splice(i, 1); continue; }
      p.el.setAttribute("x", p.x.toFixed(1)); p.el.setAttribute("y", p.y.toFixed(1)); p.el.setAttribute("opacity", Math.min(1, p.life * 1.6).toFixed(2));
    }
    emit("step");
    return active;
  }
  const canFetch = () => isPet && d.stage > 0;
  function hopToTarget() {   // the ball, a bit of food, or a spot such as the water bowl
    const t = pet.target;
    const dx = (t.cx + t.x) - (pet.cx + pet.x), gap = pet.hw + t.hw - 4;
    if (Math.abs(dx) <= gap + 6) {      // got it
      pet.target = null;
      if (t === ball) {                 // a happy boop
        puff(...head(pet), "♥", "#e87ba4", 2);
        ball.vx = Math.sign(dx || 1) * 90; ball.vy = -190; ball.rest = false;
        emit("fetch");
      } else emit("reach", t);
      return;
    }
    pet.floorY = clamp(t.cy + t.hh + t.y + 6, FY + 18, H - 4);
    pet.vx = Math.sign(dx) * Math.min(190, 70 + (Math.abs(dx) - gap) * 2.2);
    pet.vy = -210; pet.rest = false; pet.onBed = false;
  }

  let raf = null, last = 0;
  function loop(now) {
    raf = null;
    if (!svg.isConnected) return;
    const dt = Math.min(0.032, (now - last) / 1000 || 0.016);
    last = now;
    if (step(dt)) raf = requestAnimationFrame(loop);
  }
  function kick() { if (!raf) { last = performance.now(); raf = requestAnimationFrame(loop); } }

  function grab(e, b) {
    e.preventDefault(); e.stopPropagation();
    const p0 = pt(e), ox = b.x - p0.x, oy = b.y - p0.y, t0 = performance.now();
    let moved = 0, trail = [{ x: p0.x, y: p0.y, t: t0 }];
    b.held = true; b.rest = false; b.vx = b.vy = b.va = 0; b.onBed = false;
    if (b === pet) pet.target = null;
    try { b.g.setPointerCapture(e.pointerId); } catch (_) { /* fine without it */ }
    b.g.classList.add("dragging");
    const move = (ev) => {
      const p = pt(ev), prev = trail.at(-1);
      moved += Math.hypot(p.x - prev.x, p.y - prev.y);
      trail.push({ x: p.x, y: p.y, t: performance.now() });
      if (trail.length > 6) trail.shift();
      b.x = p.x + ox; b.y = p.y + oy;
      limit(b);
      b.y = Math.min(b.y, H - 4 - b.cy - b.hh);
      const a = trail[0], dtt = (trail.at(-1).t - a.t) / 1000 || 0.016;
      if (b !== ball) b.a += (clamp((p.x - a.x) / dtt * 0.045, -28, 28) - b.a) * 0.3;   // dangle as it's carried
      draw(b);
    };
    const up = () => {
      b.g.removeEventListener("pointermove", move);
      b.g.classList.remove("dragging");
      b.held = false;
      const now = performance.now(), a = trail.find((s) => now - s.t < 120) || trail.at(-1), z = trail.at(-1);
      const dtt = Math.max(0.016, (z.t - a.t) / 1000);
      b.vx = clamp((z.x - a.x) / dtt, -1500, 1500); b.vy = clamp((z.y - a.y) / dtt, -1500, 1500);
      if (now - z.t > 90) b.vx = b.vy = 0;        // held still before letting go
      const speed = Math.hypot(b.vx, b.vy), bottom = b.cy + b.hh + b.y;
      if (moved < 4 && now - t0 < 350) {           // a tap: pet it / nudge the ball
        if (b === pet) { puff(...head(b), isPet ? "♥" : "✿", "#e87ba4", 3); b.vy = -230; emit("pet"); }
        else { b.vx = (Math.random() - 0.5) * 320; b.vy = -260; b.thrown = true; }
      } else {
        // set down gently on the floor: it stays where you put it. Thrown or dropped from the air: it lands.
        b.floorY = (speed < 140 && bottom >= FY + 18) ? clamp(bottom, FY + 18, H - 4) : b.homeFloor;
        if (b.spin) b.va = b.vx * (b === ball ? 2.4 : 0.9);
        if (b === ball) b.thrown = true;
        if (b === pet && speed > 900) puff(...head(b), "!", "#eb6834", 1, 10);
        if (b === pet && speed > 250) emit("toss", speed);
      }
      b.rest = false;
      kick();
    };
    b.g.addEventListener("pointermove", move);
    b.g.addEventListener("pointerup", up, { once: true });
    b.g.addEventListener("pointercancel", up, { once: true });
    kick();
  }
  bodies.forEach((b) => { limit(b); draw(b); b.g.addEventListener("pointerdown", (e) => grab(e, b)); });
  depthSort();
  kick();   // anything saved in mid-air settles

  return {
    step, pet, ball, furn, fx, W, H, FY, puff, head, kick, snapshot, flush,
    on(name, fn) { (listeners[name] = listeners[name] || []).push(fn); },
    addBody(g, box, o) { const b = mk(g, box, o); b.floorY = b.homeFloor = FY + 40; bodies.push(b); return b; },   // e.g. food dropped in
    removeBody(b) { const i = bodies.indexOf(b); if (i >= 0) bodies.splice(i, 1); b.g.remove(); if (pet.target === b) pet.target = null; },
    goTo(t) { if (!canFetch() || pet.held) return false; pet.target = t; kick(); return true; },
    tuckIn() {   // asleep: on its bed if it has one, otherwise wherever it is on the floor
      const bed = furn.bed;
      pet.target = null; pet.vx = pet.vy = pet.va = 0; pet.a = 0;
      if (bed) { pet.x = bed.x; pet.y = bed.y; pet.onBed = true; } else pet.y = pet.floorY - pet.cy - pet.hh;
      limit(pet); pet.rest = true; draw(pet);
    },
    reset() {
      Object.values(furn).forEach((f) => { f.x = f.y = 0; placeF(f); });
      [pet, ball].forEach((b) => { if (b) { b.x = b.y = b.a = b.vx = b.vy = b.va = 0; b.rest = false; b.floorY = b.homeFloor; } });
      pet.target = null;
      depthSort(); kick(); save();
    },
  };
}

{
  const baseGoals = PAGES.goals;
  PAGES.goals = async (main, params) => {
    await baseGoals(main, params);
    const svg = $(".room-view svg.room", main);
    if (!svg) return;
    const d = window.__goalsData;
    if (!d || !d.kind) return;
    const room = svg.__room = initRoom(svg, d);
    const hint = document.createElement("div");
    hint.className = "row tiny muted room-hint";
    const who = d.name || (d.kind === "plant" ? "your plant" : "your pet");
    hint.innerHTML = `<span>🖐 Pick up ${esc(who)} and toss ${d.kind === "plant" ? "it (gently!)" : "it around"}, or tap to ${d.kind === "plant" ? "say hi" : "pet it"}. Drag the furniture to rearrange.${d.room.equipped.buddy === "buddy_ball" && d.kind === "pet" ? " Throw the ball and it'll fetch." : ""}</span>
      <span class="spacer"></span><button class="btn small secondary" id="roomReset">↺ Tidy up</button>`;
    svg.parentElement.appendChild(hint);
    $("#roomReset", hint).onclick = () => { const s = $(".room-view svg.room", main); if (s && s.__room) s.__room.reset(); };
  };
}
