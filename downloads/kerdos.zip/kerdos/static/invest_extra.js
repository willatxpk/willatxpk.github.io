// Kerdos: Investments extras. Click any holding for its price chart, a risk tag on every holding,
// and a daily briefing of facts about what you hold. Nothing here tells you to buy or sell.
"use strict";

const STOCK = { period: "1y", data: null, geom: null };
const STOCK_PERIODS = [["1m", "1 month", 31], ["3m", "3 months", 92], ["6m", "6 months", 183], ["1y", "1 year", 366], ["2y", "2 years", 9999]];
const arrowPct = (v, d = 1) => v == null ? "—" : `<span class="${v >= 0 ? "pos" : "down"}">${v >= 0 ? "▲" : "▼"} ${Math.abs(v).toFixed(d)}%</span>`;
const riskTag = (r, suffix = "") => r ? `<span class="risk-tag r-${esc(r.level)}" data-tip="${esc(esc(r.why))}">${esc(r.label)}${suffix}</span>` : "";

// ---------------------------------------------------------------- one holding's price chart
function stockPoints() {
  const all = STOCK.data.points, days = STOCK_PERIODS.find((p) => p[0] === STOCK.period)[2];
  const from = new Date(Date.now() - days * 864e5).toISOString().slice(0, 10);
  const pts = all.filter((p) => p[0] >= from);
  return pts.length >= 2 ? pts : all.slice(-2);
}
function stockSvg(pts, W, avgCost) {
  const H = W < 480 ? 210 : 260, pl = 50, pr = 12, pt = 12, pb = 26;
  const xs = pts.map((p) => new Date(p[0] + "T00:00").getTime()), vs = pts.map((p) => p[1]);
  let lo = Math.min(...vs), hi = Math.max(...vs);
  const showCost = avgCost && avgCost > lo * 0.6 && avgCost < hi * 1.4;
  if (showCost) { lo = Math.min(lo, avgCost); hi = Math.max(hi, avgCost); }
  const pad = (hi - lo) * 0.08 || hi * 0.05 || 1;
  lo -= pad; hi += pad;
  STOCK.geom = { W, H, pl, pr, pt, pb, lo, hi, xs };
  const x = (i) => pl + ((xs[i] - xs[0]) / (xs.at(-1) - xs[0] || 1)) * (W - pl - pr);
  const y = (v) => pt + (1 - (v - lo) / (hi - lo)) * (H - pt - pb);
  const line = pts.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p[1]).toFixed(1)}`).join("");
  const up = vs.at(-1) >= vs[0], color = up ? "var(--good)" : "var(--critical)";
  const marks = [];
  let last = pts[0][0].slice(0, 7);
  pts.forEach((p, i) => { const m = p[0].slice(0, 7); if (m !== last) { marks.push(i); last = m; } });
  const every = Math.ceil(marks.length / Math.max(2, Math.floor((W - pl - pr) / 62)));
  const short = pts.length < 45;   // a month or so: label a few days instead of months
  const dayMarks = short ? pts.map((_, i) => i).filter((i) => i % Math.ceil(pts.length / 5) === 0) : [];
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Price over time">
    ${niceTicks(lo, hi, 4).map((t) => `<line x1="${pl}" x2="${W - pr}" y1="${y(t)}" y2="${y(t)}" stroke="var(--grid)"/><text x="${pl - 8}" y="${y(t) + 4}" text-anchor="end">${compact(t)}</text>`).join("")}
    ${short ? dayMarks.map((i) => `<text x="${x(i).toFixed(1)}" y="${H - 6}" text-anchor="middle">${shortDate(pts[i][0])}</text>`).join("")
      : marks.filter((_, i) => i % every === 0).map((i) => `<text x="${x(i).toFixed(1)}" y="${H - 6}" text-anchor="middle">${monthName(pts[i][0].slice(0, 7))}${pts[i][0].slice(5, 7) === "01" ? " ’" + pts[i][0].slice(2, 4) : ""}</text>`).join("")}
    <path d="${line}L${x(pts.length - 1).toFixed(1)},${H - pb}L${x(0).toFixed(1)},${H - pb}Z" fill="${color}" opacity=".12"/>
    ${showCost ? `<line x1="${pl}" x2="${W - pr}" y1="${y(avgCost).toFixed(1)}" y2="${y(avgCost).toFixed(1)}" stroke="var(--series-4)" stroke-dasharray="5 4" stroke-width="1.4"/>
      <text x="${W - pr - 4}" y="${(y(avgCost) - 5).toFixed(1)}" text-anchor="end" class="st-cost">what you paid, ${fmt2(avgCost)}</text>` : ""}
    <path d="${line}" fill="none" stroke="${color}" stroke-width="2.2" stroke-linejoin="round"/>
    <line class="xh" y1="${pt}" y2="${H - pb}" stroke="var(--muted)" stroke-dasharray="3 3" visibility="hidden"/>
    <circle class="xd" r="4.5" fill="${color}" stroke="var(--surface)" stroke-width="2" visibility="hidden"/>
    <rect x="${pl}" y="0" width="${W - pl - pr}" height="${H}" fill="transparent" class="hit"/></svg>`;
}
function drawStock(dlg) {
  const d = STOCK.data, box = $(".st-chart", dlg);
  if (!d || !box) return;
  const pts = stockPoints(), change = (pts.at(-1)[1] - pts[0][1]) / pts[0][1] * 100;
  box.innerHTML = stockSvg(pts, Math.max(260, box.clientWidth), d.position && d.position.avg_cost);
  $(".st-change", dlg).innerHTML = `${arrowPct(change)} <span class="muted">over ${STOCK_PERIODS.find((p) => p[0] === STOCK.period)[1]}, from ${fmt2(pts[0][1])}</span>`;
  const svg = $("svg", box), g = STOCK.geom, xh = $(".xh", svg), xd = $(".xd", svg), hit = $(".hit", svg);
  const show = (e) => {
    const r = svg.getBoundingClientRect(), sx = ((e.clientX - r.left) / r.width) * g.W;
    const t = g.xs[0] + ((sx - g.pl) / (g.W - g.pl - g.pr)) * (g.xs.at(-1) - g.xs[0]);
    let best = 0;
    g.xs.forEach((v, i) => { if (Math.abs(v - t) < Math.abs(g.xs[best] - t)) best = i; });
    const px = g.pl + ((g.xs[best] - g.xs[0]) / (g.xs.at(-1) - g.xs[0] || 1)) * (g.W - g.pl - g.pr);
    const py = g.pt + (1 - (pts[best][1] - g.lo) / (g.hi - g.lo)) * (g.H - g.pt - g.pb);
    xh.setAttribute("x1", px); xh.setAttribute("x2", px); xh.setAttribute("visibility", "visible");
    xd.setAttribute("cx", px); xd.setAttribute("cy", py); xd.setAttribute("visibility", "visible");
    const since = (pts[best][1] - pts[0][1]) / pts[0][1] * 100;
    tip.innerHTML = `<b>${shortDate(pts[best][0])}, ${pts[best][0].slice(0, 4)}</b><br>${fmt2(pts[best][1])}<br>${arrowPct(since)} <span class="muted">since the start</span>`;
    tip.hidden = false;
    tip.style.left = Math.max(8, Math.min(e.clientX + 14, innerWidth - tip.offsetWidth - 8)) + "px";
    tip.style.top = e.clientY + 14 + "px";
  };
  const hide = () => { xh.setAttribute("visibility", "hidden"); xd.setAttribute("visibility", "hidden"); tip.hidden = true; };
  hit.addEventListener("pointermove", show); hit.addEventListener("pointerdown", show);
  hit.addEventListener("pointerleave", hide); hit.addEventListener("pointercancel", hide);
}
async function openStock(ticker) {
  const dlg = $("#dlg");
  dlg.classList.add("wide");
  dlg.innerHTML = `<h2 style="margin:0">${esc(ticker)}</h2><div class="tiny muted" style="margin:8px 0 60px">Fetching its price history…</div>`;
  const done = () => { dlg.classList.remove("wide"); tip.hidden = true; };
  dlg.addEventListener("close", done, { once: true });
  if (!dlg.open) dlg.showModal();
  let d;
  try { d = STOCK.data = await api("/api/investments/stock?ticker=" + encodeURIComponent(ticker)); }
  catch (e) { dlg.innerHTML = `<h2 style="margin:0">${esc(ticker)}</h2><p class="down">${esc(e.message)}</p><div class="row"><span class="spacer"></span><button class="btn secondary" id="stClose">Close</button></div>`; $("#stClose").onclick = () => dlg.close(); return; }
  const s = d.stats || {}, p = d.position;
  const pos52 = s.high52 > s.low52 ? Math.max(0, Math.min(100, (s.price - s.low52) / (s.high52 - s.low52) * 100)) : 50;
  const fact = (label, value, hint) => `<div class="st-fact" ${hint ? `title="${esc(hint)}"` : ""}><span>${label}</span><b>${value}</b></div>`;
  dlg.innerHTML = `
    <div class="row"><h2 style="margin:0">${esc(d.ticker)}</h2>${riskTag(d.risk, " risk")}<span class="spacer"></span><button class="btn small secondary" id="stClose">Close</button></div>
    <div class="tiny muted">${esc(d.name || "")}${d.expense_ratio != null ? ` · fund fee ${d.expense_ratio}% a year` : ""}</div>
    <div class="st-price"><b>${fmt2(s.price)}</b><span class="st-change tiny"></span></div>
    <div class="gr-chips">${STOCK_PERIODS.map(([k, l]) => `<button class="chip ${k === STOCK.period ? "active" : ""}" data-sp="${k}">${l}</button>`).join("")}</div>
    <div class="chart st-chart"></div>
    <div class="st-facts">
      ${fact("Past day", arrowPct(s.d1))}${fact("Past month", arrowPct(s.m1))}${fact("Past 3 months", arrowPct(s.m3))}${fact("Past year", arrowPct(s.y1))}
      ${fact("Typical yearly swing", s.vol == null ? "—" : s.vol.toFixed(0) + "%", "How much the price has bounced around, scaled to a year. Higher means a bumpier ride.")}
      ${fact("Biggest drop this year", s.drawdown == null ? "—" : "−" + s.drawdown.toFixed(0) + "%", "The largest fall from a high point to a later low in the past year.")}
    </div>
    ${d.market ? `<div class="tiny st-vs">For comparison, the whole US stock market (${esc(d.market.ticker)}) over the same year: ${arrowPct(d.market.y1)}, a typical swing of ${d.market.vol == null ? "—" : d.market.vol.toFixed(0) + "%"} and a biggest drop of ${d.market.drawdown == null ? "—" : "−" + d.market.drawdown.toFixed(0) + "%"}.</div>` : ""}
    <div class="st-range"><span class="tiny muted">One-year low ${fmt2(s.low52)}</span><div class="st-track"><i style="left:${pos52.toFixed(1)}%"></i></div><span class="tiny muted">high ${fmt2(s.high52)}</span></div>
    ${p ? `<div class="st-pos"><b>You hold ${p.shares.toLocaleString(undefined, { maximumFractionDigits: 3 })} shares, worth ${fmt2(p.value)}</b>
      <span class="tiny">${p.cost ? `You paid ${fmt2(p.cost)}${p.avg_cost ? ` (${fmt2(p.avg_cost)} a share)` : ""}, so you are ${p.gain >= 0 ? "up" : "down"} <b class="${p.gain >= 0 ? "pos" : "down"}">${fmt2(Math.abs(p.gain))}</b>.` : "Your brokerage doesn't report what you paid."} ${esc(p.accounts.join(", "))}</span></div>` : ""}
    ${d.risk ? `<div class="tiny muted" style="margin-top:8px">Why ${esc(d.risk.label.toLowerCase())} risk: ${esc(d.risk.why)}</div>` : ""}
    <details class="st-notes" ${d.note && (d.note.why || d.note.exit) ? "open" : ""}><summary>My notes on ${esc(d.ticker)}${d.note && d.note.updated ? ` <span class="muted">· saved ${shortDate(d.note.updated)}</span>` : ""}</summary>
      <label class="field">Why I own it<textarea id="stWhy" rows="2" maxlength="600" placeholder="What made you buy it, in a sentence or two.">${esc((d.note || {}).why || "")}</textarea></label>
      <label class="field" style="margin-top:8px">What would change my mind<textarea id="stExit" rows="2" maxlength="600" placeholder="What would have to happen for you to sell or stop adding.">${esc((d.note || {}).exit || "")}</textarea></label>
      <div class="row" style="margin-top:8px"><span class="tiny muted">Written while calm, read back when the price is moving. The app shows this note when one of your review rules is triggered.</span><span class="spacer"></span><button class="btn small" id="stSave">Save notes</button></div></details>
    <p class="disclaimer" style="margin-bottom:0">Prices are daily closes from Yahoo Finance and may be delayed. How something did over the past year says nothing reliable about the next one.</p>`;
  $("#stClose").onclick = () => dlg.close();
  $("#stSave").onclick = async () => {
    d.note = await run(() => post("/api/investments/note", { ticker: d.ticker, why: $("#stWhy").value, exit: $("#stExit").value }), "Notes saved");
    if ($("#rulesCard")) rulesLoad($("#rulesCard"));
  };
  $$("[data-sp]", dlg).forEach((b) => b.onclick = () => { STOCK.period = b.dataset.sp; $$("[data-sp]", dlg).forEach((x) => x.classList.toggle("active", x === b)); drawStock(dlg); });
  drawStock(dlg);
}
document.addEventListener("click", (e) => {
  if (e.target.closest("a, button, select, input, th")) return;      // those do their own thing
  const el = e.target.closest("[data-stock]");
  if (el && el.dataset.stock) openStock(el.dataset.stock);
});
document.addEventListener("keydown", (e) => {
  if ((e.key === "Enter" || e.key === " ") && e.target.matches && e.target.matches("[data-stock][tabindex]")) { e.preventDefault(); openStock(e.target.dataset.stock); }
});

// ---------------------------------------------------------------- today's briefing and the risk mix
function briefingHtml(ins) {
  const when = new Date(ins.date + "T00:00").toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });
  const levels = ins.risk_levels.filter((l) => ins.risk_mix[l.key] > 0.5);
  return `<div class="row"><h2 style="margin:0">Today's briefing</h2><span class="pill">${esc(when)}</span><span class="spacer"></span>
      ${ins.as_of ? `<span class="tiny muted">prices as of ${shortDate(ins.as_of)}</span>` : ""}</div>
    <div class="brief-list">${ins.briefing.map((b) => `<div class="brief-item ${esc(b.tone || "")}" ${b.ticker ? `data-stock="${esc(b.ticker)}" tabindex="0" role="button" title="See ${esc(b.ticker)}'s past year"` : ""}>
      <span class="brief-icon">${esc(b.icon)}</span><div><b>${esc(b.title)}</b><div class="tiny muted">${esc(b.text)}</div></div></div>`).join("")}</div>
    ${levels.length && ins.total ? `<div class="tiny muted" style="margin-top:12px">Your money by risk level</div>
      <div class="alloc risk-mix">${levels.map((l) => `<div class="r-${l.key}" style="flex:${ins.risk_mix[l.key]}" data-tip="${esc(`<b>${l.label} risk</b><br>${fmt(ins.risk_mix[l.key])} · ${(ins.risk_mix[l.key] / ins.total * 100).toFixed(0)}%`)}"></div>`).join("")}</div>
      <div class="legend" style="flex-wrap:wrap;margin:0">${levels.map((l) => `<span><i class="r-${l.key}"></i>${l.label} ${(ins.risk_mix[l.key] / ins.total * 100).toFixed(0)}%</span>`).join("")}</div>` : ""}
    <p class="disclaimer" style="margin-bottom:0">${esc(ins.note)} Click anything with a ticker to see its past year.</p>`;
}
{
  const baseInv = PAGES.investments;
  PAGES.investments = async (main, params) => {
    await baseInv(main, params);
    if (!$(".grid.g3", main) || !window.__invInsights) return;       // no holdings to talk about
    const card = document.createElement("div");
    card.className = "card brief-card";
    card.style.marginBottom = "16px";
    card.innerHTML = `<h2 style="margin:0">Today's briefing</h2><div class="tiny muted" style="margin-top:6px">Reading today's prices…</div>`;
    ($(".banner", main) || $(".sub", main)).after(card);
    const ins = await window.__invInsights;
    if (!card.isConnected) return;
    if (!ins || !ins.briefing) return card.remove();
    card.innerHTML = briefingHtml(ins);
    const rules = document.createElement("div");
    rules.className = "card rules-card";
    rules.id = "rulesCard";
    rules.style.marginBottom = "16px";
    rules.innerHTML = `<h2 style="margin:0">Your rules</h2><div class="tiny muted" style="margin-top:6px">Checking what you hold against your rules…</div>`;
    card.after(rules);
    rulesLoad(rules);
  };
}


// ---------------------------------------------------------------- your own rules, checked daily, and a stress test
const RULES = { data: null, editing: false, scenario: null };
const RULE_ICON = { ok: ["✓", "ok"], breach: ["!", "breach"], review: ["?", "review"] };

function rulesEditor(r) {
  const row = (x) => {
    const [before, after] = x.text.split("{v}");
    return `<div class="rule-edit"><label class="rule-on"><input type="checkbox" data-rule-on="${x.key}" ${x.on ? "checked" : ""} aria-label="Use this rule"></label>
      <div><div>${esc(before)}<input type="number" data-rule-v="${x.key}" value="${x.value}" min="${x.min}" max="${x.max}" step="${x.key === "fee_max" ? 0.05 : 1}">${esc(after)}</div>
        <div class="tiny muted">${esc(x.about)}</div></div></div>`;
  };
  return `<div class="rule-edits">${r.rules.map(row).join("")}</div>
    <div class="row" style="margin-top:12px;gap:8px"><span class="tiny muted">Tick the rules you want, set each number, then save.</span><span class="spacer"></span>
      ${r.adopted ? `<button class="btn small secondary" id="rulesCancel">Cancel</button>` : ""}<button class="btn small" id="rulesSave">${r.adopted ? "Save my rules" : "Use these as my rules"}</button></div>`;
}
function rulesResults(r) {
  const res = r.results;
  if (!res.length) return `<div class="tiny muted" style="margin-top:10px">No rules are switched on. Use “Edit my rules” to turn some on.</div>`;
  const need = res.filter((x) => x.status !== "ok").length;
  return `<div class="tiny" style="margin-top:8px">${need ? `<b>${need} of your ${res.length} rules ${need === 1 ? "needs" : "need"} a look today.</b>` : `<b class="pos">All ${res.length} of your rules are met today.</b>`}</div>
    <div class="rule-list">${res.map((x) => `<div class="rule-row ${RULE_ICON[x.status][1]}"><i>${RULE_ICON[x.status][0]}</i><div>
      <div class="tiny muted">${esc(x.rule)}</div><b>${esc(x.headline)}</b>
      ${x.lines.map((l) => `<div class="tiny">${esc(l)}</div>`).join("")}
      ${x.items.length ? `<div class="rule-items">${x.items.map((it) => `<div class="rule-item" ${it.ticker ? `data-stock="${esc(it.ticker)}" tabindex="0" role="button" title="See ${esc(it.ticker)}'s past year and your notes"` : ""}><b>${esc(it.label)}</b>
        <span class="tiny">${esc(it.text)}${it.your_note ? `<br><span class="muted">Your note: “${esc(it.your_note)}”</span>` : x.status === "review" && it.ticker ? `<br><span class="muted">No note yet: click to write down why you own it.</span>` : ""}</span></div>`).join("")}</div>` : ""}</div></div>`).join("")}</div>`;
}
function stressHtml(r) {
  if (!r.stress.length) return "";
  const cur = r.stress.find((x) => x.key === RULES.scenario) || r.stress[0];
  return `<h3 style="margin-top:16px">What a bad stretch could do</h3>
    <div class="gr-chips">${r.stress.map((x) => `<button class="chip ${x.key === cur.key ? "active" : ""}" data-scn="${esc(x.key)}">${esc(x.label)}</button>`).join("")}</div>
    <div class="stress-out"><div><div class="tiny muted">${esc(cur.about)}</div>
      <div class="stress-big"><b class="down">−${fmt(Math.abs(cur.change))}</b><span class="muted">${Math.abs(cur.pct).toFixed(1)}% of your investments · ${fmt(r.total)} becomes ${fmt(cur.after)}</span></div></div>
      ${cur.rows.length ? `<table class="t-tax">${cur.rows.map((x) => `<tr><td>${esc(x.name)}</td><td class="num muted">${x.move > 0 ? "+" : x.move < 0 ? "−" : ""}${Math.abs(x.move)}%</td><td class="num ${x.change < 0 ? "down" : x.change > 0 ? "pos" : ""}">${x.change < 0 ? "−" : x.change > 0 ? "+" : ""}${fmt(Math.abs(x.change))}</td></tr>`).join("")}</table>` : ""}</div>
    <div class="tiny muted">An illustration using rough past results for whole markets, not a forecast. Individual companies can fall much further than the market they're in.</div>`;
}
function rulesPaint(card) {
  const r = RULES.data, editing = RULES.editing || !r.adopted;
  card.innerHTML = `<div class="row"><h2 style="margin:0">Your rules</h2>${r.adopted ? `<span class="pill">checked ${shortDate(r.date)}</span>` : ""}<span class="spacer"></span>
      ${r.adopted && !editing ? `<button class="btn small secondary" id="rulesEdit">Edit my rules</button>` : ""}</div>
    ${!r.adopted ? `<p class="tiny" style="margin:8px 0 10px">The app won't tell you what to buy or sell. What it can do is hold you to rules <b>you</b> choose: you set them once, and every day it measures your holdings against them and works out what it would take to be back inside each one. The numbers below are common rules of thumb to start from, not written for you. Change any of them, switch rules on or off, then save.</p>` : ""}
    ${editing ? rulesEditor(r) : rulesResults(r)}
    ${r.adopted && !editing ? stressHtml(r) : ""}
    <p class="disclaimer" style="margin-bottom:0">${esc(r.note || "")}</p>`;
  const send = async (body, msg) => { RULES.data = await run(() => post("/api/investments/rules", body), msg); RULES.editing = false; rulesPaint(card); };
  const save = $("#rulesSave", card);
  if (save) save.onclick = () => {
    const rules = {};
    r.rules.forEach((x) => { rules[x.key] = { on: $(`[data-rule-on="${x.key}"]`, card).checked, value: $(`[data-rule-v="${x.key}"]`, card).value }; });
    send({ rules, adopt: true }, "Your rules are saved");
  };
  const cancel = $("#rulesCancel", card);
  if (cancel) cancel.onclick = () => { RULES.editing = false; rulesPaint(card); };
  const edit = $("#rulesEdit", card);
  if (edit) edit.onclick = () => { RULES.editing = true; rulesPaint(card); };
  $$("[data-scn]", card).forEach((b) => b.onclick = () => { RULES.scenario = b.dataset.scn; rulesPaint(card); });
}
async function rulesLoad(card) {
  try { RULES.data = await api("/api/investments/rules"); }
  catch (e) { card.innerHTML = `<h2 style="margin:0">Your rules</h2><div class="tiny down" style="margin-top:6px">${esc(e.message)}</div>`; return; }
  if (!card.isConnected) return;
  if (!RULES.data.total) return card.remove();
  rulesPaint(card);
}
