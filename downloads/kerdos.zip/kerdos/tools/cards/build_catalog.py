"""Merge the researched card files into app/card_catalog.json after checking every field the app relies on."""
import io, json, os, re, sys
SP = os.path.dirname(os.path.abspath(__file__)).replace("\\", "/") + "/"
ROOT = os.path.dirname(os.path.dirname(SP.rstrip("/"))) + "/"
sys.path.insert(0, ROOT)
from app import cards as C

PERS = {"year", "quarter", "month", "billing_cycle"}
problems, warns, out, seen, checked = [], [], [], set(), []


def num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def check_cap(cid, cap, where):
    if cap is None:
        return None
    if not isinstance(cap, dict) or not num(cap.get("amount")) or cap.get("per") not in PERS:
        problems.append(f"{cid}: bad cap in {where}: {cap}")
        return None
    c = {"amount": cap["amount"], "per": cap["per"]}
    if num(cap.get("then")):
        c["then"] = cap["then"]
    return c


def kinds(cid, ks, where):
    good = [k for k in ks or [] if k in C.KINDS]
    bad = [k for k in ks or [] if k not in C.KINDS]
    if bad:
        warns.append(f"{cid}: unknown kinds dropped in {where}: {bad}")
    return good


for fn in [a for a in sys.argv[1:] if a.endswith(".json")]:
    data = json.load(io.open(SP + fn, encoding="utf-8"))
    checked.append(str(data.get("checked") or ""))
    for c in data["cards"]:
        cid = c.get("id")
        if not cid or not re.fullmatch(r"[a-z0-9-]{3,60}", cid) or cid in seen:
            problems.append(f"bad or duplicate id: {cid}")
            continue
        seen.add(cid)
        if not c.get("name") or not c.get("issuer") or c.get("unit") not in ("cash", "points", "miles"):
            problems.append(f"{cid}: name/issuer/unit")
            continue
        if not num(c.get("base")) or not num(c.get("fee")) or not num(c.get("point_value")) or not 0 < c["point_value"] <= 5 or not 0 <= c["base"] <= 10:
            problems.append(f"{cid}: base/fee/point_value {c.get('base')} {c.get('fee')} {c.get('point_value')}")
            continue
        card = {"id": cid, "issuer": c["issuer"], "name": c["name"],
                "aliases": [a.lower() for a in c.get("aliases") or [] if isinstance(a, str) and len(a) >= 6],
                "fee": c["fee"], "unit": c["unit"], "base": c["base"], "point_value": c["point_value"],
                "point_value_note": str(c.get("point_value_note") or "")[:200], "bonus": [], "rotating": None, "top_category": None,
                "notes": [str(n)[:900] for n in c.get("notes") or [] if isinstance(n, str)][:10],
                "source": c.get("source") if str(c.get("source") or "").startswith("https://") else None,
                "confidence": c.get("confidence") if c.get("confidence") in ("high", "medium", "low") else "medium"}
        for i, b in enumerate(c.get("bonus") or []):
            ks = kinds(cid, b.get("kinds"), f"bonus[{i}]")
            if not num(b.get("rate")) or not 0 < b["rate"] <= 30:
                problems.append(f"{cid}: bonus[{i}] rate {b.get('rate')}")
                continue
            if not ks:
                warns.append(f"{cid}: bonus[{i}] has no usable kinds ({b.get('rate')} / {b.get('note')}); kept as a note")
                card["notes"].append(f"{C._rate(card, b['rate'])}: {b.get('note') or 'a category the app cannot spot in your purchases'}")
                continue
            card["bonus"].append({"kinds": ks, "rate": b["rate"], "cap": check_cap(cid, b.get("cap"), f"bonus[{i}]"), "note": str(b.get("note") or "")[:160]})
        rot = c.get("rotating")
        if rot:
            if not num(rot.get("rate")):
                problems.append(f"{cid}: rotating rate")
            else:
                qs = {}
                for key, q in (rot.get("quarters") or {}).items():
                    if not re.fullmatch(r"20\d\dQ[1-4]", key) or not isinstance(q, dict):
                        problems.append(f"{cid}: quarter key {key}")
                        continue
                    qs[key] = {"kinds": kinds(cid, q.get("kinds"), key), "label": str(q.get("label") or "")[:300],
                               "source": q.get("source") if str(q.get("source") or "").startswith("https://") else None}
                card["rotating"] = {"rate": rot["rate"], "cap": check_cap(cid, rot.get("cap"), "rotating"),
                                    "activation": bool(rot.get("activation")), "quarters": qs}
        top = c.get("top_category")
        if top:
            ks = kinds(cid, top.get("eligible_kinds"), "top_category")
            if not num(top.get("rate")) or not ks:
                warns.append(f"{cid}: top_category unusable; kept as a note")
                card["notes"].append(f"Pays {top.get('rate')} on a chosen or top category the app cannot work out. {top.get('note') or ''}".strip())
            else:
                card["top_category"] = {"rate": top["rate"], "cap": check_cap(cid, top.get("cap"), "top_category"), "eligible_kinds": ks,
                                        "count": int(top.get("count") or 1), "auto": bool(top.get("auto")), "note": str(top.get("note") or "")[:200]}
        out.append(card)

# Tidy-ups after research: plain issuer names, and short or generic names that only count at that issuer
ISSUER_ONLY = {"capital-one-quicksilver": ["quicksilver"], "capital-one-savor": ["savor"], "capital-one-venture": ["venture"],
               "citi-strata": ["strata"], "amex-platinum": ["the platinum card", "platinum card from american express"],
               "capital-one-platinum": ["platinum mastercard"], "citi-simplicity": ["simplicity"],
               "citi-aadvantage-platinum-select": ["platinum select"], "wells-fargo-attune": ["attune"], "us-bank-smartly": ["smartly"],
               "navy-federal-cashrewards": ["cashrewards", "cash rewards"], "us-bank-cash-plus": ["cash+", "cash plus"],
               "discover-it-student-cash-back": ["student cash back"], "discover-it-student-chrome": ["student chrome"]}
DROP = {"platinum card", "platinum mastercard", "simplicity", "platinum select", "attune", "smartly", "cashrewards", "cash+",
        "student cash back", "student chrome"}
for c in out:
    c["issuer"] = re.sub(r"\s*\(.*?\)", "", c["issuer"]).strip()
    c["aliases"] = [x for x in c["aliases"] if x not in DROP]
    c["aliases_issuer"] = ISSUER_ONLY.get(c["id"], [])
    if c["id"].startswith("bilt-") and c["point_value"] > 1:
        c["point_value_note"] = ("Counted at 1 cent. " + c["point_value_note"]).strip()
        c["point_value"] = 1.0
missing = set(ISSUER_ONLY) - {c["id"] for c in out}
if missing:
    problems.append(f"ISSUER_ONLY ids not found: {missing}")

# Aliases must not make one account name match two different cards equally well
for a in out:
    for b in out:
        if a["id"] < b["id"]:
            shared = {C._norm(x) for x in a["aliases"] + [a["name"]]} & {C._norm(x) for x in b["aliases"] + [b["name"]]}
            if shared:
                warns.append(f"alias shared by {a['id']} and {b['id']}: {sorted(shared)}")
print(len(out), "cards;", len(problems), "problems;", len(warns), "warnings")
for p in problems:
    print("PROBLEM", p)
for w in warns:
    print("warn", w)
if "dry" in sys.argv or (problems and "force" not in sys.argv):
    sys.exit(1)
out.sort(key=lambda c: (c["issuer"].lower(), c["name"].lower()))
# "checked" is the oldest full check among the source files; a quarter-only refresh does not move it
json.dump({"checked": min(c for c in checked if c) if any(checked) else None, "cards": out}, io.open(ROOT + "app/card_catalog.json", "w", encoding="utf-8", newline="\n"), indent=1, ensure_ascii=False)
print("wrote card_catalog.json")
