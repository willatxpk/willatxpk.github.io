# Starts Kerdos quietly (no window) every time you sign in to Windows.
# It adds one shortcut to your Startup folder; nothing system-wide changes.
# To undo: run uninstall_autostart.ps1 (or delete "Kerdos.lnk" from shell:startup).
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$pyw = (& py -3.12 -c "import sys, os; print(os.path.join(os.path.dirname(sys.executable), 'pythonw.exe'))").Trim()
if (-not (Test-Path $pyw)) { throw "Couldn't find pythonw.exe for Python 3.12" }

$startup = [Environment]::GetFolderPath("Startup")
$lnkPath = Join-Path $startup "Kerdos.lnk"
$oldLnk = Join-Path $startup "Finance Hub.lnk"
if (Test-Path $oldLnk) { Remove-Item $oldLnk }
$oldUrl = Join-Path $here "Open Finance Hub.url"
if (Test-Path $oldUrl) { Remove-Item $oldUrl }
$shell = New-Object -ComObject WScript.Shell
$lnk = $shell.CreateShortcut($lnkPath)
$lnk.TargetPath = $pyw
$lnk.Arguments = "`"$here\main.py`" --quiet"
$lnk.WorkingDirectory = $here
$lnk.Description = "Kerdos (runs in the background; open http://localhost:8765)"
$lnk.WindowStyle = 7
$lnk.Save()

# A clickable shortcut to open the app, next to the app files
$url = Join-Path $here "Open Kerdos.url"
Set-Content -Path $url -Value "[InternetShortcut]`r`nURL=http://localhost:8765/" -Encoding ASCII

# Start it now too (it exits on its own if it's already running)
Start-Process -FilePath $pyw -ArgumentList "`"$here\main.py`" --quiet" -WorkingDirectory $here -WindowStyle Hidden
Write-Output "Installed: Kerdos will start in the background when you sign in to Windows."
Write-Output "Startup shortcut: $lnkPath"
Write-Output "Open the app any time: http://localhost:8765 (or double-click 'Open Kerdos' in $here)"
