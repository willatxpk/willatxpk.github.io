"""Start Kerdos:  py -3.12 main.py   then open http://localhost:8765"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.server import main  # noqa: E402

def _quiet_logging():
    """Running without a console window (pythonw): send output to data/app.log."""
    log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    os.makedirs(log_dir, exist_ok=True)
    log = os.path.join(log_dir, "app.log")
    if os.path.exists(log) and os.path.getsize(log) > 2_000_000:
        os.replace(log, log + ".old")
    f = open(log, "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = f
    # Timestamps make it clear later whether the app stopped normally or crashed
    import atexit
    import faulthandler
    from datetime import datetime
    print(f"\n=== started {datetime.now():%Y-%m-%d %H:%M:%S} (pid {os.getpid()}) ===")
    atexit.register(lambda: print(f"=== stopped normally {datetime.now():%Y-%m-%d %H:%M:%S} ==="))
    faulthandler.enable(file=f)  # writes a trace here if Python itself crashes


if __name__ == "__main__":
    if sys.stdout is None or "--quiet" in sys.argv:
        _quiet_logging()
    if "--reset-password" in sys.argv:
        from app import auth
        try:
            auth.reset()
            print("Password removed. Start the app and it will ask you to create a new one.")
            print("(Your accounts, transactions and settings are unchanged.)")
        except ValueError as e:
            print(e)
    elif "--recover" in sys.argv:
        import getpass
        from app import auth
        code = input("Recovery code: ")
        pw = getpass.getpass("New password: ")
        if pw != getpass.getpass("New password again: "):
            print("Passwords don't match; nothing changed.")
        else:
            try:
                auth.recover(code, pw)
                print("Done. Sign in with your new password.")
            except ValueError as e:
                print(e)
    else:
        main()
