"""Ticker Tycoon server: serves the game and proxies real-world data the browser can't fetch directly.

GET  /api/news            recent business/markets headlines from several public RSS feeds (cached 5 min)
GET  /api/quotes?symbols=  last price, recent daily closes and annualized volatility from Yahoo (cached 10 min)
POST /__playtest/<name>    saves a playtest result to playtest/logs/<name>.json

Usage: py -3 server.py [port]   (default 8793)
"""
import http.server, functools, json, math, os, sys, time, re
import urllib.request, urllib.parse
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.abspath(__file__))
LOGS = os.path.join(ROOT, "playtest", "logs")
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8793
UA = {"User-Agent": "Mozilla/5.0 (TickerTycoon game)"}

FEEDS = [
    ("CNBC", "https://www.cnbc.com/id/100003114/device/rss/rss.html"),
    ("CNBC", "https://www.cnbc.com/id/10001147/device/rss/rss.html"),
    ("CNBC", "https://www.cnbc.com/id/20910258/device/rss/rss.html"),
    ("CNBC", "https://www.cnbc.com/id/19854910/device/rss/rss.html"),
    ("MarketWatch", "https://feeds.content.dowjones.io/public/rss/mw_topstories"),
    ("MarketWatch", "https://feeds.content.dowjones.io/public/rss/mw_marketpulse"),
    ("BBC", "https://feeds.bbci.co.uk/news/business/rss.xml"),
    ("BBC", "https://feeds.bbci.co.uk/news/technology/rss.xml"),
]

_cache = {}


def cached(key, ttl, fn):
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    val = fn()
    _cache[key] = (time.time(), val)
    return val


def fetch(url, timeout=8):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
        return r.read()


def strip_html(s):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", s or "")).strip()


def read_feed(source, url):
    items = []
    try:
        root = ET.fromstring(fetch(url))
    except Exception as e:
        print(f"feed failed {url}: {e}", file=sys.stderr)
        return items
    for it in root.iter("item"):
        title = strip_html(it.findtext("title"))
        if not title:
            continue
        try:
            ts = parsedate_to_datetime(it.findtext("pubDate")).timestamp()
        except Exception:
            ts = time.time()
        items.append({
            "title": title,
            "link": (it.findtext("link") or "").strip(),
            "desc": strip_html(it.findtext("description"))[:400],
            "source": source,
            "time": int(ts * 1000),
        })
    return items


def news():
    with ThreadPoolExecutor(8) as ex:
        lists = list(ex.map(lambda f: read_feed(*f), FEEDS))
    seen, out = set(), []
    for item in sorted((i for l in lists for i in l), key=lambda i: -i["time"]):
        key = re.sub(r"\W+", "", item["title"].lower())[:80]
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return {"fetched": int(time.time() * 1000), "items": out[:150]}


def quote(sym):
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}?range=3mo&interval=1d"
    try:
        d = json.loads(fetch(url))["chart"]["result"][0]
        closes = [c for c in d["indicators"]["quote"][0]["close"] if c]
        rets = [math.log(b / a) for a, b in zip(closes, closes[1:])]
        mean = sum(rets) / len(rets)
        vol = math.sqrt(sum((r - mean) ** 2 for r in rets) / (len(rets) - 1) * 252)
        return sym, {"price": d["meta"]["regularMarketPrice"], "closes": [round(c, 2) for c in closes[-30:]],
                     "vol": round(vol, 3), "asOf": d["meta"].get("regularMarketTime", 0) * 1000}
    except Exception as e:
        print(f"quote failed {sym}: {e}", file=sys.stderr)
        return sym, None


def quotes(symbols):
    with ThreadPoolExecutor(8) as ex:
        return {s: q for s, q in ex.map(quote, symbols) if q}


class Handler(http.server.SimpleHTTPRequestHandler):
    def send_json(self, obj):
        body = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path, _, query = self.path.partition("?")
        if path == "/api/news":
            return self.send_json(cached("news", 300, news))
        if path == "/api/quotes":
            syms = [s for s in urllib.parse.parse_qs(query).get("symbols", [""])[0].upper().split(",")
                    if re.fullmatch(r"[A-Z.\-]{1,6}", s)][:40]
            return self.send_json(cached("q:" + ",".join(syms), 600, lambda: quotes(syms)))
        return super().do_GET()

    def do_POST(self):
        if not self.path.startswith("/__playtest/"):
            return self.send_error(404)
        name = "".join(c for c in self.path.rsplit("/", 1)[-1] if c.isalnum() or c in "-_") or "result"
        os.makedirs(LOGS, exist_ok=True)
        with open(os.path.join(LOGS, f"{name}.json"), "wb") as f:
            f.write(self.rfile.read(int(self.headers.get("Content-Length", 0))))
        self.send_response(204)
        self.end_headers()

    def log_message(self, fmt, *args):
        if "/api/" in str(args[0] if args else ""):
            super().log_message(fmt, *args)


if __name__ == "__main__":
    print(f"Ticker Tycoon on http://127.0.0.1:{PORT}")
    http.server.ThreadingHTTPServer(("127.0.0.1", PORT), functools.partial(Handler, directory=ROOT)).serve_forever()
