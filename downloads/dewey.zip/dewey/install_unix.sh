#!/usr/bin/env bash
# Dewey installer for macOS and Linux:   bash install_unix.sh
#
# 1. Creates a private Python environment (.venv) with the requirements.
# 2. Runs the setup wizard (if not done yet).
# 3. Optionally adds a login/reboot entry so Dewey runs in the background.
set -euo pipefail
cd "$(dirname "$0")"
DIR="$(pwd)"

PY=""
for candidate in python3 python; do
  if command -v "$candidate" >/dev/null 2>&1 && \
     "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'; then
    PY="$candidate"; break
  fi
done
if [ -z "$PY" ]; then
  echo "Python 3.10+ not found. Install it (python.org, Homebrew or your package manager) and run this again."
  exit 1
fi

echo "Creating the Python environment (.venv)..."
[ -d .venv ] || "$PY" -m venv .venv
.venv/bin/python -m pip install --disable-pip-version-check -q -r requirements.txt

[ -f config.json ] || .venv/bin/python dewey.py --setup
if [ ! -f config.json ]; then
  echo "Setup was not completed; run install_unix.sh again when ready."
  exit 1
fi

if [ "$(uname)" = "Darwin" ]; then
  PLIST="$HOME/Library/LaunchAgents/com.dewey.digest.plist"
  read -r -p "Start Dewey automatically at login (launchd)? [Y/n] " yn
  if [ "${yn:-Y}" != "n" ] && [ "${yn:-Y}" != "N" ]; then
    mkdir -p "$(dirname "$PLIST")"
    cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.dewey.digest</string>
  <key>ProgramArguments</key><array>
    <string>$DIR/.venv/bin/python</string><string>$DIR/dewey.py</string><string>--serve</string>
  </array>
  <key>WorkingDirectory</key><string>$DIR</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
</dict></plist>
EOF
    launchctl unload "$PLIST" 2>/dev/null || true
    launchctl load "$PLIST"
    echo "Dewey started (launchd). To remove: launchctl unload $PLIST && rm $PLIST"
  fi
else
  read -r -p "Start Dewey automatically at boot (crontab @reboot)? [Y/n] " yn
  if [ "${yn:-Y}" != "n" ] && [ "${yn:-Y}" != "N" ]; then
    LINE="@reboot cd $DIR && $DIR/.venv/bin/python dewey.py --serve >/dev/null 2>&1"
    ( crontab -l 2>/dev/null | grep -v 'dewey.py --serve' ; echo "$LINE" ) | crontab -
    nohup .venv/bin/python dewey.py --serve >/dev/null 2>&1 &
    echo "Dewey started; it will also start at every boot. To remove: crontab -e and delete the dewey line."
  fi
fi

echo
echo "Reading list and buttons: http://localhost:8377"
echo "Preview a digest now:     .venv/bin/python dewey.py --preview   (opens preview.html)"
echo "Optional free AI summaries: install Ollama (https://ollama.com), then: ollama pull qwen2.5:3b"
