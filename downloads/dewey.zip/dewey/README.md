# Dewey 📚

**A daily email of the new research papers that matter to you**, ranked by
how closely they match your interests and the papers you already like. It
runs on your own computer, is free, and needs no account beyond an email
address to send from.

Each morning Dewey scans the day's arXiv announcement and recent articles in
your field's journals, and emails you:

- ⭐ **Paper of the Day**: the most impactful new paper in your broad field.
- **Top picks**: the best matches for your interests, with abstracts.
- 🔭 **Blindspot**: five notable results from selective journals just
  outside your usual areas.
- 📚 **Learn**: pick any topic to learn from the ground up and get one of
  its most-cited foundational papers each day.
- **More from arXiv / journals**: compact lists of everything else relevant.
- 🔖 **Your reading list**, grouped by category.

Every paper has one-click buttons:

| Button | What it does |
|---|---|
| ✨ Summarize | A short summary plus "why it may matter to you", written by a free AI model running on your computer ([Ollama](https://ollama.com), optional). For arXiv papers it reads the introduction and conclusions too. |
| ♡ Like | The paper becomes a reference point; similar papers rank higher. |
| 🔖 Read later | Saves it to your reading list. |
| 👎 Not relevant | Similar papers rank lower. |
| ➕ Add a paper | Paste an arXiv ID/link, DOI, journal link or title to add your own finds. |

Buttons work on the computer running Dewey (they talk to a small local web
server at `http://localhost:8377`, which only accepts connections from that
computer).

## Install

You need **Python 3.10+** ([python.org](https://www.python.org/downloads/))
and an email account Dewey can send from. For Gmail, create an
[app password](https://myaccount.google.com/apppasswords) (requires 2-step
verification).

**Windows:** download or clone this repository, then right-click
`install_windows.ps1` → *Run with PowerShell*. Or in PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File install_windows.ps1
```

**macOS / Linux:**

```bash
bash install_unix.sh
```

The installer creates a private Python environment, runs the **setup
wizard**, and sets Dewey to start in the background when you log in.

### The setup wizard

`python dewey.py --setup` asks for:

1. **Email:** where to send the digest and how to send it (the password goes
   into `secrets.env`, which stays on your computer).
2. **Your field:** physical sciences, life sciences, computing & AI, or
   earth & space. This picks suggested keywords, arXiv categories and journals.
3. **Up to 20 keywords** from a menu, plus any of your own.
4. **arXiv categories** to scan in full each day.
5. **A short description of your research.** This matters most for ranking.
6. **Optional:** researchers to follow, a 📚 topic to learn, and whether to
   favour experimental papers over theory.
7. **Optional: import your library.** Point it at your **Zotero** library
   (choose which folders) or a **.bib** file. Those papers become "liked",
   so Dewey learns what you care about from day one.

Run it again any time, or import later:

```bash
python dewey.py --import-zotero        # choose Zotero folders
python dewey.py --import-bib refs.bib
```

## Everyday use

```bash
python dewey.py --preview      # build preview.html now, send nothing
python dewey.py                # build and send now
python dewey.py --test-email   # check your email settings
python dewey.py --stats        # which sections your likes come from
python dewey.py --serve        # run daily (the installer starts this for you)
```

(Use `.venv\Scripts\python.exe` on Windows or `.venv/bin/python` on
macOS/Linux, or activate the environment first.)

- **Reading list, add papers, change learning topic:**
  <http://localhost:8377>
- **Settings:** `config.json` (keywords, journals, thresholds, categories,
  delivery time). See below.
- **Logs:** `digest.log`.

If the computer is asleep at delivery time, the digest is sent within a
minute of waking (up to `catch_up_hours`, default 12).

## Free AI summaries (optional)

Install [Ollama](https://ollama.com) and download a small model:

```bash
ollama pull qwen2.5:3b
```

The ✨ Summarize button then works, privately and for free. Summaries take
about 15–60 seconds on a laptop and are saved. Small local models can get
details wrong; treat them as triage. Choose another model with
`summaries.ollama_model` in `config.json`.

## How ranking works

- **Keywords:** your keywords (from `topics`) matched in titles and
  abstracts, plurals included.
- **Similarity:** text similarity to your research description and to
  your liked papers (the average of the 3 closest, so one chance overlap
  isn't enough).
- **👎 papers** lower the score of papers clearly similar to them.
- **Followed authors** are matched on first initial + surname, so "Jane Doe"
  matches "J. Doe" and "Jane A. Doe".
- **Experiment vs theory:** each paper is labelled 🧪 / 📐 from its wording.
  If you chose to favour experiments, theory papers rank lower and never
  become Top picks.
- **Paper of the Day:** new papers have no citations yet, so impact is judged
  by journal tier (`paper_of_the_day.tiers`).

## Configuration reference (`config.json`)

| Setting | Meaning |
|---|---|
| `recipient`, `delivery_time`, `timezone` | Where and when the email goes. |
| `topics` | Keyword rules: `any` (match any), `require_any` (also need one of these), `exclude`. |
| `interest_profile` | Paragraphs describing your research (most important for ranking). |
| `arxiv_feed_categories` | arXiv categories scanned in full daily. |
| `journal_watchlist` | Journal name → ISSN; every recent article is considered. |
| `follow_authors` | Names whose papers are always included (if related to your interests). |
| `learning_track.name` | Topic for 📚 Learn (also changeable at localhost:8377). |
| `reading_list_categories` | Reading-list groups: `name`, `any` terms, optional `kind`. |
| `digest.*` | Section sizes and inclusion thresholds. |
| `ranking.*` | Score weights, 👎 strength, experiment/theory factors. |
| `blindspot.*`, `paper_of_the_day.*` | Journals, fields and tiers for those sections. |

## Data sources and limits

- [arXiv](https://arxiv.org) (daily RSS feed and API) and
  [OpenAlex](https://openalex.org) (journals, abstracts, citation counts).
  OpenAlex has a free daily request allowance; results are cached for 12 hours
  so test runs cost nothing, and a free OpenAlex API key (set
  `OPENALEX_API_KEY` in `secrets.env`) raises the limit.
- Some publishers (e.g. APS) don't share abstracts with OpenAlex; those papers
  are ranked by title only.
- The experiment/theory labels are keyword heuristics and sometimes wrong.
  The label is shown so you can see its judgement.

## Privacy

Everything runs locally. Your settings, liked papers, reading list and
history stay in this folder (`config.json`, `secrets.env`, `liked.txt`,
`digest.sqlite3`), and `.gitignore` keeps them out of git. Dewey contacts only
arXiv, OpenAlex, your email provider and (optionally) your local Ollama.

## License

MIT. See [LICENSE](LICENSE).
