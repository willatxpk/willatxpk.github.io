# Dewey installer for Windows.
#
# Right-click > "Run with PowerShell", or in PowerShell:
#   powershell -ExecutionPolicy Bypass -File install_windows.ps1
#
# 1. Creates a private Python environment (.venv) with the requirements.
# 2. Runs the setup wizard (if not done yet).
# 3. Registers a Task Scheduler task that starts Dewey hidden at login,
#    so the digest is sent daily and the email buttons work.

$ErrorActionPreference = "Stop"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $dir

# Find Python 3.10 or newer.
$python = $null
foreach ($candidate in @(@("py", "-3"), @("python"), @("python3"))) {
    $exe = $candidate[0]
    $extra = @($candidate | Select-Object -Skip 1)
    try {
        $version = & $exe @extra -c "import sys; print(sys.version_info >= (3, 10))" 2>$null
        if ($version -eq "True") { $python = $candidate; break }
    } catch {}
}
if (-not $python) {
    Write-Host "Python 3.10+ not found. Install it from https://www.python.org/downloads/ (tick 'Add python.exe to PATH') and run this again." -ForegroundColor Red
    exit 1
}

Write-Host "Creating the Python environment (.venv)..."
$exe = $python[0]
$extra = @($python | Select-Object -Skip 1)
if (-not (Test-Path ".venv")) { & $exe @extra -m venv .venv }
& ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt

if (-not (Test-Path "config.json")) {
    & ".venv\Scripts\python.exe" dewey.py --setup
}
if (-not (Test-Path "config.json")) {
    Write-Host "Setup was not completed; run install_windows.ps1 again when ready." -ForegroundColor Yellow
    exit 1
}

Write-Host "Registering the 'Dewey digest' startup task..."
$action = New-ScheduledTaskAction -Execute "$dir\.venv\Scripts\pythonw.exe" -Argument "dewey.py --serve" -WorkingDirectory $dir
$trigger = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 5 -RestartInterval (New-TimeSpan -Minutes 5) -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName "Dewey digest" -Description "Dewey daily paper digest ($dir)" -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
Start-ScheduledTask -TaskName "Dewey digest"

Write-Host ""
Write-Host "Dewey is installed and running." -ForegroundColor Green
Write-Host "  Reading list and buttons: http://localhost:8377"
Write-Host "  Preview a digest now:     .venv\Scripts\python.exe dewey.py --preview  (opens preview.html)"
Write-Host "  Logs:                     digest.log"
Write-Host "  Optional free AI summaries: install Ollama (https://ollama.com), then run: ollama pull qwen2.5:3b"
Write-Host "  To uninstall: Unregister-ScheduledTask -TaskName 'Dewey digest'  (then delete this folder)"
