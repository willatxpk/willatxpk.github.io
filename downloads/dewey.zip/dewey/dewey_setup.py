"""
Dewey setup wizard and library import.

    python dewey.py --setup          # first-time setup (asks questions)
    python dewey.py --import-zotero  # learn from your Zotero library
    python dewey.py --import-bib FILE.bib

Everything personal is written to config.json, secrets.env and liked.txt,
which are git-ignored.
"""

import getpass
import json
import re
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import dewey

# ------------------------------------------------------------
# Field presets: suggested keywords, arXiv categories, journals
# ------------------------------------------------------------
#
# Journal values are Paper-of-the-Day tiers (3 = Nature/Science level,
# 2 = top specialist journals, 1 = strong broad journals, 0 = watch only).
# ISSNs are looked up on OpenAlex during setup.

DOMAINS = {
    "Physical sciences": {
        "arxiv": [
            "quant-ph", "cond-mat.mes-hall", "cond-mat.mtrl-sci",
            "cond-mat.str-el", "cond-mat.supr-con", "cond-mat.quant-gas",
            "physics.optics", "physics.atom-ph", "physics.app-ph",
            "hep-ph", "hep-th", "gr-qc", "nucl-ex", "physics.chem-ph",
        ],
        "journals": {
            "Nature": 3, "Science": 3, "Nature Physics": 2,
            "Nature Photonics": 2, "Nature Materials": 2,
            "Nature Nanotechnology": 2, "Physical Review X": 2,
            "PRX Quantum": 2, "Physical Review Letters": 1,
            "Nature Communications": 1, "Science Advances": 1,
            "Optica": 1, "Nano Letters": 1, "Physical Review B": 0,
            "Physical Review A": 0, "Physical Review Applied": 0,
        },
        "fields": ["Physics and Astronomy", "Materials Science",
                   "Chemistry", "Engineering"],
        "keywords": [
            "quantum computing", "quantum networks", "quantum sensing",
            "quantum optics", "quantum error correction",
            "superconducting qubits", "trapped ions", "neutral atoms",
            "Rydberg atoms", "quantum dots", "color centers",
            "rare-earth ions", "quantum simulation", "cold atoms",
            "photonic crystals", "nanophotonics", "metasurfaces",
            "optomechanics", "topological materials", "2D materials",
            "graphene", "superconductivity", "magnetism", "spintronics",
            "ultrafast optics", "lasers", "plasmonics", "semiconductors",
        ],
    },
    "Life sciences": {
        "arxiv": ["q-bio.BM", "q-bio.GN", "q-bio.NC", "q-bio.QM",
                  "q-bio.CB", "q-bio.MN", "physics.bio-ph"],
        "journals": {
            "Nature": 3, "Science": 3, "Cell": 3,
            "Nature Biotechnology": 2, "Nature Methods": 2,
            "Nature Genetics": 2, "Nature Medicine": 2, "Neuron": 2,
            "Nature Neuroscience": 2,
            "Proceedings of the National Academy of Sciences": 1,
            "Nature Communications": 1, "eLife": 1, "Science Advances": 1,
        },
        "fields": ["Biochemistry, Genetics and Molecular Biology",
                   "Neuroscience", "Immunology and Microbiology",
                   "Agricultural and Biological Sciences", "Medicine"],
        "keywords": [
            "CRISPR", "gene editing", "single-cell sequencing",
            "protein structure", "protein design", "cryo-EM",
            "structural biology", "genomics", "epigenetics",
            "synaptic plasticity", "neural circuits", "immunology",
            "cancer biology", "microbiome", "stem cells", "organoids",
            "drug discovery", "systems biology", "evolution", "aging",
            "ecology", "metabolism",
        ],
    },
    "Computing & AI": {
        "arxiv": ["cs.LG", "cs.AI", "cs.CL", "cs.CV", "cs.RO", "stat.ML",
                  "cs.CR", "cs.DS", "cs.DC", "cs.SE"],
        "journals": {
            "Nature": 3, "Science": 3, "Nature Machine Intelligence": 2,
            "Proceedings of the National Academy of Sciences": 1,
            "Nature Communications": 1, "Science Advances": 1,
            "Journal of Machine Learning Research": 1,
        },
        "fields": ["Computer Science", "Mathematics", "Engineering",
                   "Decision Sciences"],
        "keywords": [
            "large language models", "reinforcement learning",
            "diffusion models", "computer vision", "robotics",
            "interpretability", "AI safety", "graph neural networks",
            "optimization", "federated learning",
            "natural language processing", "speech recognition",
            "recommender systems", "causal inference", "AI for science",
            "quantum machine learning", "cryptography",
            "distributed systems", "compilers", "theory of computation",
        ],
    },
    "Earth & space": {
        "arxiv": ["astro-ph.GA", "astro-ph.CO", "astro-ph.EP",
                  "astro-ph.HE", "astro-ph.SR", "astro-ph.IM",
                  "physics.ao-ph", "physics.geo-ph"],
        "journals": {
            "Nature": 3, "Science": 3, "Nature Astronomy": 2,
            "Nature Geoscience": 2, "Nature Climate Change": 2,
            "The Astrophysical Journal": 1,
            "Monthly Notices of the Royal Astronomical Society": 1,
            "Astronomy and Astrophysics": 1,
            "Geophysical Research Letters": 1, "Nature Communications": 1,
        },
        "fields": ["Earth and Planetary Sciences", "Physics and Astronomy",
                   "Environmental Science"],
        "keywords": [
            "exoplanets", "galaxy formation", "cosmology", "dark matter",
            "gravitational waves", "black holes", "stellar evolution",
            "star formation", "planetary science", "astrobiology",
            "cosmic microwave background", "radio astronomy",
            "transients", "climate modeling", "oceanography",
            "seismology", "atmospheric chemistry", "glaciology",
            "remote sensing", "volcanology",
        ],
    },
}

MAX_KEYWORDS = 20


# ------------------------------------------------------------
# Small console helpers
# ------------------------------------------------------------

def ask(prompt, default=""):
    suffix = f" [{default}]" if default else ""
    answer = input(f"{prompt}{suffix}: ").strip()
    return answer or default


def ask_yes(prompt, default=True):
    answer = ask(prompt + (" (Y/n)" if default else " (y/N)")).lower()
    return default if not answer else answer.startswith("y")


def pick_numbers(text, count):
    """'1, 3-5, 9' -> [0, 2, 3, 4, 8] (valid, unique, in order)."""
    chosen = []
    for part in re.split(r"[,\s]+", text.strip()):
        if re.fullmatch(r"\d+-\d+", part):
            low, high = map(int, part.split("-"))
            numbers = range(low, high + 1)
        elif part.isdigit():
            numbers = [int(part)]
        else:
            continue
        for number in numbers:
            if 1 <= number <= count and number - 1 not in chosen:
                chosen.append(number - 1)
    return chosen


def show_menu(items, columns=2):
    width = max(len(item) for item in items) + 8
    for start in range(0, len(items), columns):
        print("  " + "".join(
            f"{index + 1:3d}. {items[index]:<{width - 5}}"
            for index in range(start, min(start + columns, len(items)))
        ))


# ------------------------------------------------------------
# Journals: names -> ISSN via OpenAlex
# ------------------------------------------------------------

def resolve_journal(name):
    """
    ISSN-L for a journal name. OpenAlex often has several records for
    one journal (old series, renamed titles); pick the matching record
    that published the most papers recently, i.e. the live one.
    """
    try:
        data = dewey.get(
            "https://api.openalex.org/sources",
            params={"search": name, "filter": "type:journal",
                    "per_page": 10,
                    "select": "display_name,issn_l,counts_by_year",
                    "mailto": dewey.CFG.get("recipient", "")},
            timeout=30, attempts=2,
        ).json()
    except Exception as exc:  # network trouble: skip this journal
        print(f"    could not look up {name!r}: {exc}")
        return None

    def recent_works(record):
        years = sorted(record.get("counts_by_year") or [],
                       key=lambda c: c["year"], reverse=True)[:2]
        return sum(c.get("works_count", 0) for c in years)

    results = [
        r for r in data.get("results", [])
        if r.get("issn_l") and recent_works(r)
    ]
    wanted = dewey.normalize(name)

    # 1. An exact (punctuation-insensitive) name match still publishing.
    exact = [r for r in results
             if dewey.normalize(r["display_name"]) == wanted]
    # 2. Otherwise a record whose name repeats the wanted name, e.g.
    #    "Physical review. B./Physical review. B" (but never a longer
    #    title such as "Nature Communications" for "Nature").
    repeated = [
        r for r in results
        if set(dewey.normalize(r["display_name"]).split())
        == set(wanted.split())
    ]
    best = max(exact or repeated or [None], key=lambda r: recent_works(r)
               if r else 0)
    return best["issn_l"] if best else None


# ------------------------------------------------------------
# Library import (Zotero / BibTeX) -> liked.txt
# ------------------------------------------------------------

ARXIV_IN_TEXT = re.compile(
    r"(?:arxiv[:./ ]*|abs/|pdf/)(\d{4}\.\d{4,5})", re.I
)


def find_zotero_database():
    """zotero.sqlite in the usual places, or None."""
    home = Path.home()
    candidates = [home / "Zotero" / "zotero.sqlite"]

    for profiles in [
        home / "AppData/Roaming/Zotero/Zotero/Profiles",
        home / "Library/Application Support/Zotero/Profiles",
        home / ".zotero/zotero",
    ]:
        for prefs in profiles.glob("*/prefs.js"):
            match = re.search(
                r'"extensions\.zotero\.dataDir",\s*"([^"]+)"',
                prefs.read_text(encoding="utf-8", errors="replace"),
            )
            if match:
                candidates.insert(
                    0, Path(match.group(1).replace("\\\\", "\\"))
                    / "zotero.sqlite"
                )

    return next((path for path in candidates if path.exists()), None)


def open_zotero_copy(path):
    """Read a copy: Zotero keeps its database locked while open."""
    folder = Path(tempfile.mkdtemp(prefix="dewey-zotero-"))
    for file in path.parent.glob(path.name + "*"):
        shutil.copy(file, folder / file.name)
    return sqlite3.connect(
        f"file:{folder / path.name}?mode=ro", uri=True
    )


def zotero_collections(db):
    """[(collection id, 'Parent / Child' path)] sorted by path."""
    rows = db.execute(
        "SELECT collectionID, collectionName, parentCollectionID "
        "FROM collections"
    ).fetchall()
    info = {cid: (name, parent) for cid, name, parent in rows}

    def path(cid):
        names = []
        while cid:
            name, cid = info[cid]
            names.append(name)
        return " / ".join(reversed(names))

    return sorted(((cid, path(cid)) for cid in info), key=lambda x: x[1])


def zotero_items(db, collection_ids=None):
    """Papers (title, DOI, arXiv ID, abstract) in the given collections
    and their sub-collections, or the whole library if None."""
    def field(item, name):
        row = db.execute(
            "SELECT v.value FROM itemData d JOIN fields f USING(fieldID) "
            "JOIN itemDataValues v USING(valueID) "
            "WHERE d.itemID=? AND f.fieldName=?", (item, name),
        ).fetchone()
        return row[0] if row else ""

    items = [i for (i,) in db.execute(
        "SELECT i.itemID FROM items i JOIN itemTypes t USING(itemTypeID) "
        "WHERE t.typeName IN ('journalArticle','preprint','conferencePaper',"
        "'report','thesis','bookSection') "
        "AND i.itemID NOT IN (SELECT itemID FROM deletedItems)"
    )]

    if collection_ids is not None:
        wanted = set(collection_ids)
        children = {}
        for cid, parent in db.execute(
            "SELECT collectionID, parentCollectionID FROM collections"
        ):
            children.setdefault(parent, []).append(cid)
        stack = list(wanted)
        while stack:
            for child in children.get(stack.pop(), []):
                if child not in wanted:
                    wanted.add(child)
                    stack.append(child)
        members = {i for (i, c) in db.execute(
            "SELECT itemID, collectionID FROM collectionItems"
        ) if c in wanted}
        items = [i for i in items if i in members]

    papers = []
    for item in items:
        doi = field(item, "DOI").strip().lower()
        text = " ".join(
            [field(item, "url"), field(item, "extra"),
             field(item, "archiveID"), doi]
        )
        match = ARXIV_IN_TEXT.search(text)
        arxiv_id = match.group(1) if match else ""
        if doi.startswith("10.48550/arxiv."):
            arxiv_id, doi = doi.split("arxiv.", 1)[1], ""
        papers.append({
            "title": field(item, "title"), "doi": doi,
            "arxiv": arxiv_id, "abstract": field(item, "abstractNote"),
        })
    return papers


def bib_items(path):
    """Papers from a .bib file (DOI / arXiv eprint + title)."""
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    papers = []
    for chunk in re.split(r"\n\s*@", "\n" + text)[1:]:
        flat = re.sub(r"\s*\n\s*", " ", chunk)
        title = re.search(r"\btitle\s*=\s*[{\"](.+?)[}\"]\s*,", flat, re.I)
        doi = re.search(r"\bdoi\s*=\s*[{\"]([^}\"]+)", flat, re.I)
        arxiv = (re.search(r"eprint\s*=\s*[{\"](\d{4}\.\d{4,5})", flat)
                 or re.search(r"arxiv\.org/abs/(\d{4}\.\d{4,5})", flat))
        abstract = re.search(r"\babstract\s*=\s*[{\"](.+?)[}\"]\s*,", flat,
                             re.I)
        papers.append({
            "title": re.sub(r"[{}$\\]", "", title.group(1)) if title else "",
            "doi": doi.group(1).strip().lower() if doi else "",
            "arxiv": arxiv.group(1) if arxiv else "",
            "abstract": abstract.group(1) if abstract else "",
        })
    return papers


def add_to_liked(papers, source):
    """Append papers to liked.txt; store their abstracts for ranking."""
    dewey.initialize_database()
    liked_path = dewey.BASE / dewey.CFG.get("liked_file", "liked.txt")
    if not liked_path.exists():
        liked_path.write_text(
            "# Papers you like: one arXiv ID or DOI per line.\n"
            "# New papers similar to these rank higher. Lines starting "
            "with # are ignored.\n", encoding="utf-8",
        )

    existing = set(dewey.liked_identifiers())
    lines, seeds = [], []

    for paper in papers:
        if paper["arxiv"]:
            key, ident = "arxiv:" + paper["arxiv"], paper["arxiv"]
        elif paper["doi"]:
            doi = paper["doi"].rstrip(".,;")
            if doi.startswith("10.48550/arxiv."):
                key = "arxiv:" + doi.split("arxiv.", 1)[1]
                ident = key[6:]
            else:
                key, ident = "doi:" + doi, doi
        else:
            continue
        if key in existing:
            continue
        existing.add(key)
        title = re.sub(r"\s+", " ", paper["title"])[:120]
        lines.append(f"{ident}  # {title}")
        if paper["abstract"]:
            seeds.append((key, paper["title"] + " " + paper["abstract"]))

    if lines:
        with liked_path.open("a", encoding="utf-8") as handle:
            handle.write(f"\n# Imported from {source}\n"
                         + "\n".join(lines) + "\n")
        with sqlite3.connect(dewey.DATABASE) as db:
            db.executemany(
                "INSERT OR REPLACE INTO seed_cache VALUES (?, ?)", seeds
            )

    print(f"  Added {len(lines)} papers to liked.txt "
          f"({len(seeds)} with abstracts; the rest are fetched on the "
          "next run).")
    return len(lines)


def import_zotero_interactive(path=None):
    path = Path(path) if path else find_zotero_database()
    if not path or not path.exists():
        path = Path(ask("Path to zotero.sqlite (Zotero > Settings > "
                        "Advanced > Files and Folders)"))
        if not path.exists():
            print("  Not found; skipping the Zotero import.")
            return 0

    db = open_zotero_copy(path)
    collections = zotero_collections(db)
    print(f"\nZotero library: {path}")

    if collections:
        print("Folders (sub-folders are included with their parent):")
        show_menu([name for _, name in collections], columns=1)
        answer = ask("Which folders describe your current research? "
                     "Numbers like 1,3-5, or 'all'", "all")
        if answer.lower() == "all":
            chosen = None
        else:
            chosen = [collections[i][0]
                      for i in pick_numbers(answer, len(collections))]
    else:
        chosen = None

    papers = zotero_items(db, chosen)
    print(f"  {len(papers)} papers found.")
    return add_to_liked(papers, "Zotero")


# ------------------------------------------------------------
# The wizard
# ------------------------------------------------------------

def write_secrets(values):
    path = dewey.BASE / "secrets.env"
    lines = ["# Dewey email settings. Keep this file private; it is "
             "git-ignored."]
    lines += [f"{key}={value}" for key, value in values.items() if value]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_setup():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:
        pass

    print("\n=== Dewey setup ===")
    print("A daily email of new papers ranked for you. Press Enter to "
          "accept a [default].\n")

    if dewey.CONFIG_PATH.exists() and not ask_yes(
        "config.json already exists. Start over and replace it?", False
    ):
        print("Keeping your existing setup.")
        return

    cfg = json.loads(dewey.TEMPLATE_PATH.read_text(encoding="utf-8"))

    # 1. Email
    print("1) Email")
    cfg["recipient"] = ask("Send the digest to which email address?")
    gmail = ask_yes("Send it from a Gmail account? (needs a Gmail app "
                    "password: myaccount.google.com/apppasswords)")
    secrets = {
        "SMTP_HOST": "smtp.gmail.com" if gmail else ask("SMTP server"),
        "SMTP_PORT": "465" if gmail else ask("SMTP port", "465"),
    }
    secrets["SMTP_USER"] = ask("Sender email address", cfg["recipient"])
    secrets["SMTP_FROM"] = secrets["SMTP_USER"]
    secrets["SMTP_PASSWORD"] = getpass.getpass(
        "Sender password / app password (typing is hidden): "
    ).strip()
    key = ask("Optional free OpenAlex API key for a higher daily limit "
              "(openalex.org; Enter to skip)")
    if key:
        secrets["OPENALEX_API_KEY"] = key
    write_secrets(secrets)

    # 2. Field
    print("\n2) Your broad field")
    domains = list(DOMAINS)
    show_menu(domains, columns=1)
    domain = DOMAINS[domains[
        (pick_numbers(ask("Choose one", "1"), len(domains)) or [0])[0]
    ]]

    # 3. Keywords
    print(f"\n3) Keywords to follow (up to {MAX_KEYWORDS})")
    show_menu(domain["keywords"])
    chosen = [domain["keywords"][i] for i in pick_numbers(
        ask("Numbers of the ones you want, like 1,4,7-9"),
        len(domain["keywords"]),
    )]
    extra = ask("Your own keywords, comma-separated (optional)")
    chosen += [k.strip() for k in extra.split(",") if k.strip()]
    keywords = list(dict.fromkeys(chosen))[:MAX_KEYWORDS]
    if not keywords:
        print("  No keywords chosen; you can add topics in config.json "
              "later.")
    cfg["topics"] = [
        {"name": k, "any": [k], "require_any": [], "exclude": []}
        for k in keywords
    ]
    cfg["reading_list_categories"] = [
        {"name": k[:1].upper() + k[1:], "any": [k]} for k in keywords
    ] + cfg["reading_list_categories"]

    # 4. arXiv categories
    print("\n4) arXiv categories to scan in full every day")
    show_menu(domain["arxiv"], columns=3)
    picks = pick_numbers(ask("Numbers (Enter for the first three)",
                             "1-3"), len(domain["arxiv"]))
    cfg["arxiv_feed_categories"] = [domain["arxiv"][i] for i in picks]

    # 5. Description of your research
    print("\n5) Describe your research in a sentence or three. This "
          "matters most for ranking: write it like an abstract.")
    description = ask("Your research (optional)")
    cfg["interest_profile"] = ([description] if description else []) + [
        f"Research on {k}." for k in keywords
    ]

    # 6. Journals
    print("\n6) Looking up journals for your field on OpenAlex…")
    for name, tier in domain["journals"].items():
        issn = resolve_journal(name)
        if issn:
            cfg["journal_watchlist"][name] = issn
            if tier:
                cfg["paper_of_the_day"]["tiers"][name] = tier
    print(f"  Watching {len(cfg['journal_watchlist'])} journals "
          "(edit journal_watchlist in config.json to change).")
    cfg["blindspot"]["journals"] = [
        name for name, tier in domain["journals"].items()
        if tier >= 1 and name in cfg["journal_watchlist"]
    ]
    cfg["blindspot"]["fields"] = domain["fields"]

    # 7. Extras
    print("\n7) Optional extras")
    authors = ask("Researchers to follow, comma-separated (optional)")
    cfg["follow_authors"] = [a.strip() for a in authors.split(",")
                             if a.strip()]
    topic = ask("📚 A topic to learn from the ground up, one foundational "
                "paper a day (optional)")
    cfg["learning_track"]["name"] = topic
    if ask_yes("Favour experimental papers over theory papers?", False):
        cfg["ranking"]["kind_factors"] = {
            "experiment": 1.15, "mixed": 1.0, "theory": 0.4}
        cfg["digest"]["top_picks_exclude_kinds"] = ["theory"]

    # 8. Delivery time
    print("\n8) Delivery")
    while True:
        zone = ask("Your time zone (IANA name)", cfg["timezone"])
        try:
            ZoneInfo(zone)
            cfg["timezone"] = zone
            break
        except (ZoneInfoNotFoundError, ValueError):
            print("  Unknown time zone; examples: Europe/London, "
                  "America/New_York, Asia/Tokyo.")
    cfg["delivery_time"] = ask("Send the digest at (24h HH:MM)",
                               cfg["delivery_time"])

    dewey.CONFIG_PATH.write_text(
        json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    dewey.CFG.clear()
    dewey.CFG.update(cfg)
    print("\nSaved config.json and secrets.env.")

    # 9. Library import
    print("\n9) Learn from papers you already have (optional)")
    if find_zotero_database() and ask_yes("Import from your Zotero "
                                          "library?"):
        import_zotero_interactive()
    else:
        bib = ask("Path to a .bib file to import (Enter to skip)")
        if bib and Path(bib).exists():
            add_to_liked(bib_items(bib), Path(bib).name)

    # 10. Test
    if ask_yes("\nSend a test email now?"):
        dewey.load_secrets()
        try:
            dewey.send(f"{dewey.APP_NAME} test email",
                       "<p>Your Dewey email connection works.</p>",
                       "Your Dewey email connection works.")
            print("  Test email sent. Check your inbox.")
        except Exception as exc:
            print(f"  Sending failed: {exc}\n  Fix secrets.env, then run "
                  "python dewey.py --test-email")

    print("\nDone! Next:\n"
          "  python dewey.py --preview   (build preview.html without "
          "sending)\n"
          "  python dewey.py --serve     (run daily; the installer sets "
          "this up to start at login)\n")
