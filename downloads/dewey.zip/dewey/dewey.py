import argparse
import datetime as dt
import email.utils
import hashlib
import hmac
import html
import html.parser
import http.server
import json
import logging
import logging.handlers
import math
import os
import re
import secrets
import smtplib
import socket
import sqlite3
import threading
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

from collections import Counter
from functools import lru_cache
from email.message import EmailMessage
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

# ============================================================
# Configuration
# ============================================================

APP_NAME = "Dewey"
BASE = Path(__file__).resolve().parent
CONFIG_PATH = BASE / "config.json"
TEMPLATE_PATH = BASE / "config.template.json"


def load_config():
    """config.json, or the template until `python dewey.py --setup` ran."""
    path = CONFIG_PATH if CONFIG_PATH.exists() else TEMPLATE_PATH
    return json.loads(path.read_text(encoding="utf-8"))


CFG = load_config()
CFG.setdefault("recipient", "")


def digest_title():
    return CFG.get("digest_title") or f"{APP_NAME} paper digest"


def load_secrets():
    """
    Read KEY=VALUE lines from secrets.env next to this script.
    Real environment variables take precedence over the file.
    """
    # Notepad on Windows silently saves "secrets.env" as
    # "secrets.env.txt" when file extensions are hidden.
    path = next(
        (
            candidate
            for candidate in [
                BASE / "secrets.env",
                BASE / "secrets.env.txt",
            ]
            if candidate.exists()
        ),
        None,
    )

    if path is None:
        return

    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()

        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        os.environ.setdefault(
            key.strip(), value.strip().strip("'\"")
        )


load_secrets()

UTC = dt.timezone.utc
DATABASE = BASE / "digest.sqlite3"

NS = {
    "a": "http://www.w3.org/2005/Atom",
    "x": "http://arxiv.org/schemas/atom",
    "o": "http://a9.com/-/spec/opensearch/1.1/",
    "dc": "http://purl.org/dc/elements/1.1/",
}

SESSION = requests.Session()
SESSION.headers["User-Agent"] = (
    f"{APP_NAME}Digest/1.0 (mailto:{CFG.get('recipient') or 'unknown'})"
)

PAGE_SIZE = 200
MAX_PAGES = int(CFG.get("max_pages_per_query", 100))

DEFAULT_BOOST_TERMS = []


# ============================================================
# Text processing
# ============================================================

ION_NAMES = {
    "Er": "erbium",
    "Yb": "ytterbium",
    "Eu": "europium",
    "Pr": "praseodymium",
    "Nd": "neodymium",
    "Tm": "thulium",
    "Ce": "cerium",
    "Ho": "holmium",
    "Dy": "dysprosium",
    "Sm": "samarium",
    "Tb": "terbium",
    "Gd": "gadolinium",
}

_SYMBOLS = "|".join(ION_NAMES)

# 171Yb, ^{171}Yb, $^{171}$Yb
ISOTOPE_PATTERN = re.compile(
    r"\b\d{2,3}\}?\$?\s*(" + _SYMBOLS + r")\b"
)
# Er3+, Er^{3+}, Er$^{3+}$, "Er 3 +" (spaced, as some sources write
# it), Yb:YVO4, Er-doped
ION_PATTERN = re.compile(
    r"\b(" + _SYMBOLS + r")"
    r"(?=\s?\$?\^?\{?\(?[23]\s?\+|:\s*[A-Z]|[- ]doped)"
)


def expand_ion_symbols(text):
    """Spell out rare-earth ion notation so it matches element names."""
    text = ISOTOPE_PATTERN.sub(
        lambda m: " " + ION_NAMES[m.group(1)] + " ", text
    )
    return ION_PATTERN.sub(
        lambda m: ION_NAMES[m.group(1)] + " ", text
    )


def clean_text(value):
    """Remove XML/HTML markup and collapse whitespace."""
    text = html.unescape(str(value or ""))
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


@lru_cache(maxsize=100_000)
def normalize(value):
    text = expand_ion_symbols(clean_text(value)).lower()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def keyword_hits(text, terms):
    """
    Find distinct normalized phrases, not occurrence counts.
    A trailing plural (s/es) still counts as a hit, matching
    the stemming that arXiv's own search applies.
    """
    padded = " " + normalize(text) + " "
    hits = set()

    for term in terms:
        normalized_term, pattern = term_pattern(term)

        if pattern and pattern.search(padded):
            hits.add(normalized_term)

    return hits


@lru_cache(maxsize=None)
def term_pattern(term):
    normalized_term = normalize(term)

    if not normalized_term:
        return normalized_term, None

    return normalized_term, re.compile(
        " " + re.escape(normalized_term) + "(?:s|es)? "
    )


def active_topics():
    return [
        topic
        for topic in CFG["topics"]
        if topic.get("enabled", True)
    ]


def search_terms():
    return sorted({
        str(term).strip()
        for topic in active_topics()
        for term in topic.get("any", [])
        if str(term).strip()
    })


# ============================================================
# Similarity to the interest profile (TF-IDF, no dependencies)
# ============================================================

STOPWORDS = set("""
a about above after also among an and any are as at be been both but by
can could do does due each either et for from further has have here how
however i if in into is it its may more most much new not of on one only
or other our over present show shown shows such than that the their them
then there these they this those through thus to two under up upon use
used using via was we well were what when where which while with within
without would
""".split())


def stem(word):
    if len(word) > 4 and word.endswith("ies"):
        return word[:-3] + "y"
    if len(word) > 3 and word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


@lru_cache(maxsize=20_000)
def tokens(text):
    words = [
        stem(word)
        for word in normalize(text).split()
        if word not in STOPWORDS
        and len(word) > 1
        and not word.isdigit()
    ]
    return words + [
        first + " " + second
        for first, second in zip(words, words[1:])
    ]


class InterestProfile:
    """
    Cosine similarity between a paper and the interest profile.

    Each interest_profile entry is its own seed and a paper scores
    its best match, so a strong match to one interest is not diluted
    by the others. Liked papers (liked.txt) score as the mean of the
    LIKED_TOP_K closest ones: with many liked papers, a single chance
    overlap should not be enough. Liked papers known only by title are
    skipped, since a few words match too much at random.

    IDF is fitted on the day's candidate pool so common words in
    physics abstracts carry little weight.
    """

    LIKED_TOP_K = 3
    LIKED_MIN_WORDS = 40

    def __init__(self, profile_texts, corpus_texts, liked_texts=(),
                 disliked_texts=()):
        seed_tokens = [tokens(text) for text in profile_texts if text]
        liked_tokens = [
            tokens(text)
            for text in liked_texts
            if len(text.split()) >= self.LIKED_MIN_WORDS
        ]
        # 👎 papers: same rules as liked ones, used as a penalty.
        disliked_tokens = [
            tokens(text)
            for text in disliked_texts
            if len(text.split()) >= self.LIKED_MIN_WORDS
        ]
        documents = seed_tokens + liked_tokens + disliked_tokens + [
            tokens(text) for text in corpus_texts
        ]

        frequency = Counter()
        for document in documents:
            frequency.update(set(document))

        total = len(documents)
        self.idf = {
            term: math.log((total + 1) / (count + 1)) + 1
            for term, count in frequency.items()
        }

        self.seeds = [
            vector
            for vector in map(self.vector, seed_tokens)
            if vector
        ]
        self.liked = [
            vector
            for vector in map(self.vector, liked_tokens)
            if vector
        ]
        self.disliked = [
            vector
            for vector in map(self.vector, disliked_tokens)
            if vector
        ]

    def vector(self, document_tokens):
        counts = Counter(document_tokens)
        return self.unit({
            term: (1 + math.log(count)) * self.idf.get(term, 1.0)
            for term, count in counts.items()
        })

    @staticmethod
    def unit(vector):
        norm = math.sqrt(sum(v * v for v in vector.values()))
        if not norm:
            return {}
        return {term: v / norm for term, v in vector.items()}

    def similarity(self, text):
        vector = self.vector(tokens(text))

        def cosine(seed):
            return sum(
                weight * vector.get(term, 0.0)
                for term, weight in seed.items()
            )

        best = max(map(cosine, self.seeds), default=0.0)

        if self.liked:
            closest = sorted(map(cosine, self.liked), reverse=True)[
                :self.LIKED_TOP_K
            ]
            best = max(best, sum(closest) / len(closest))

        return best

    def dislike_similarity(self, text):
        """Mean similarity to the closest 👎 papers (0 if none)."""
        if not self.disliked:
            return 0.0

        vector = self.vector(tokens(text))
        closest = sorted(
            (
                sum(weight * vector.get(term, 0.0)
                    for term, weight in seed.items())
                for seed in self.disliked
            ),
            reverse=True,
        )[:self.LIKED_TOP_K]
        return sum(closest) / len(closest)


# ============================================================
# Relevance scoring and admission
# ============================================================

# ------------------------------------------------------------
# Experiment vs theory, from the abstract's wording
# ------------------------------------------------------------
#
# Experiments say "we demonstrate/measure/fabricate" and report
# measured numbers with units; theory and architecture papers talk
# about frameworks, bounds, simulations, resource requirements and
# roadmaps. A rough heuristic: the label is shown in the email so
# misjudgements are visible.

EXPERIMENT_CUES = [
    (r"\bwe (experimentally |also |further |then |here |now )?"
     r"(demonstrate|observe|measure|realize|realise|fabricate|implement"
     r"|report (the |a )?(first )?(observation|demonstration|realization"
     r"|measurement))(?! that)", 2.5),
    # "we demonstrate that …" is also used for theory results.
    (r"\bwe (experimentally |also |here )?demonstrate that", 1.5),
    (r"\bexperimental(ly)? (demonstrat|realiz|observ|verif|confirm)", 1),
    (r"\bmeasured\b", 1), (r"\bfabricat", 1),
    (r"\bgrown\b|\bgrowth\b|\bepitax|\bnucleation\b", 1),
    (r"\bspectroscop", 0.5),
    (r"\bcryogenic|\bcryostat|\bdilution refrigerator", 1),
    # Hardware the authors themselves use or build.
    (r"\b(we|our) (employ|use|operate|build|built|construct)\w* (a |an |the )?"
     r"(\w+[ -]){0,3}(source|setup|set-up|apparatus|laser|detectors?"
     r"|memory|memories|cavity|chip|sensor)", 2),
    (r"\bodmr\b|\boptically detected magnetic resonance", 1.5),
    (r"\b(performance|operation) of (a|an|the|our) (\w+[ -]){0,4}"
     r"(memory|source|sensor|device|node|laser|detector)", 1),
    (r"\blasers?\b|\bdetectors?\b", 0.5),
]
THEORY_CUES = [
    (r"\b(roadmap|vision|perspective|review|survey|tutorial|overview)\b", 2),
    (r"\barchitectures?\b", 1),
    (r"\bresource (estimat|requirement|overhead|cost)", 1.5),
    (r"\brequirements?\b", 0.5), (r"\bfeasibility\b", 1),
    (r"\btheor(y|etical|etically)\b", 1), (r"\banalytic", 1),
    (r"\btheorem|\bwe prove\b", 2),
    (r"\bwe (propose|derive|introduce|develop|present) (a|an|the)\b", 1.5),
    (r"\bproposals?\b", 1), (r"\bnumerical(ly)?\b", 1), (r"\bsimulat", 1),
    (r"\bframework\b|\bformalism\b", 1), (r"\bscheme\b|\bprotocol\b", 0.5),
    (r"\bbounds?\b", 1), (r"\bwe (analy[sz]e|study|investigate|discuss|estimate)\b", 0.5),
    (r"\bclifford\b|\bpauli\b|\bcomplexity\b|\bdecoders?\b", 1),
    (r"\bcompil|\bmagic[- ]state|\bgate counts?\b"
     r"|\bmodel of quantum computation", 1.5),
    (r"\bmachine learning|\breinforcement learning|\bneural networks?"
     r"|\binverse[- ]design|\bdigital twins?", 1.5),
    (r"\bcomsol\b|\bfdtd\b|\bfinite[- ]element|\bproposed (sensor|biosensor|structure|device|design)", 1.5),
]
MEASURED_NUMBER = re.compile(
    r"\d[\d.,]*\s?(\(\d+\))?\s?(mhz|ghz|khz|thz|hz|nm|µm|μm|mm|mk|ms|µs|μs"
    r"|ns|ps|fs|db|mw|µw|nw|%)"
)
KIND_LABELS = {"experiment": "🧪 experiment", "theory": "📐 theory"}


def paper_kind(text):
    """'experiment', 'theory' or 'mixed' from an abstract's wording."""
    text = text.lower()
    experiment = sum(w for p, w in EXPERIMENT_CUES if re.search(p, text))
    # Numbers with units only count alongside first-hand experimental
    # wording; simulated designs quote numbers too.
    if experiment:
        experiment += min(1.5, 0.5 * len(MEASURED_NUMBER.findall(text)))
    theory = sum(w for p, w in THEORY_CUES if re.search(p, text))

    # Experimental (or mixed) needs real first-hand evidence; without
    # it, any theory cue makes it theory. No cues at all: unlabelled.
    if experiment >= 1.5:
        return "experiment" if experiment - theory >= 1.5 else "mixed"
    if theory > 0:
        return "theory"
    return ""


TITLE_EXPERIMENT = re.compile(
    r"^(observation|demonstration|realization|realisation|experimental"
    r"|measurement|direct (observation|measurement|imaging))\b"
    r"|\b(fabricat|grown|growth)",
    re.I,
)
TITLE_THEORY = re.compile(
    r"\b(theory|theoretical|model|models|modeling|framework|scheme|proposal"
    r"|towards|toward|bounds?|digital twins?|description|protocols?|roadmap"
    r"|perspective|review|limits|optimi[sz]ation|optimal|architectures?"
    r"|simulations?|algorithms?|codes|decoding|inverse design"
    r"|machine learning|neural networks?)\b",
    re.I,
)


def title_kind(title):
    """Fallback for papers without an abstract: clear title cues only."""
    if TITLE_EXPERIMENT.search(title):
        return "experiment"
    if TITLE_THEORY.search(title):
        return "theory"
    return ""


def author_key(name):
    """
    (first initial, surname): papers write the same person as
    "Jane A. Doe", "J. A. Doe" or "Jane Doe".
    """
    parts = [
        part for part in normalize(name).split()
        if part not in {"jr", "sr", "ii", "iii"}
    ]
    return (parts[0][0], parts[-1]) if len(parts) >= 2 else None


def followed_author_keys():
    return [
        (name, author_key(name))
        for name in CFG.get("follow_authors", [])
        if author_key(name)
    ]


def matches(paper, profile):
    """
    Apply topic rules and attach a transparent relevance score.

    Score:
      min(max_keyword_score,
          title_weight × distinct title phrases
          + abstract_weight × additional abstract-only phrases
          + topic_bonus × matching topics)
      + similarity_weight × similarity to the interest profile
        (minus a penalty if close to papers marked 👎 Not relevant)
      + author_bonus if a followed author is on the paper

    A paper is admitted if its similarity reaches
    digest.min_similarity, or if it matches a topic and is at
    least slightly similar (digest.min_keyword_similarity), which
    drops off-field papers that merely share a phrase.
    """
    title = paper.get("title", "")
    abstract = paper.get("abstract", "")
    combined = title + " " + abstract

    matched_topics = []
    title_keywords = set()
    abstract_keywords = set()

    for topic in active_topics():
        if not keyword_hits(combined, topic.get("any", [])):
            continue

        if topic.get("require_any") and not keyword_hits(
            combined, topic["require_any"]
        ):
            continue

        if keyword_hits(combined, topic.get("exclude", [])):
            continue

        matched_topics.append(topic["name"])

        terms = topic.get("any", []) + topic.get("require_any", [])
        title_keywords.update(keyword_hits(title, terms))
        abstract_keywords.update(keyword_hits(abstract, terms))

    ranking = CFG.get("ranking", {})
    boost_terms = ranking.get("boost_terms", DEFAULT_BOOST_TERMS)

    title_keywords.update(keyword_hits(title, boost_terms))
    abstract_keywords.update(keyword_hits(abstract, boost_terms))

    abstract_only = abstract_keywords - title_keywords

    similarity = profile.similarity(combined)

    # 👎 penalty: only for papers clearly close to a rejected one
    # (above dislike_floor); everything shares a little vocabulary.
    disliked = profile.dislike_similarity(combined)
    penalty = float(ranking.get("dislike_weight", 2)) * max(
        0.0, disliked - float(ranking.get("dislike_floor", 0.03))
    )
    similarity -= penalty

    settings = CFG.get("digest", {})
    min_similarity = float(settings.get("min_similarity", 0.07))
    min_keyword_similarity = float(
        settings.get("min_keyword_similarity", 0.03)
    )

    # Followed authors count only on papers at least slightly related
    # to your interests, so a namesake in another field isn't boosted.
    paper_authors = {
        author_key(name) for name in paper.get("authors", "").split(", ")
    }
    followed = [
        name
        for name, key in followed_author_keys()
        if key in paper_authors
    ] if similarity >= float(
        settings.get("follow_min_similarity", 0.04)
    ) else []

    paper["topics"] = matched_topics
    paper["matched_keywords"] = sorted(
        title_keywords | abstract_keywords
    )
    paper["followed_authors"] = followed
    paper["similarity"] = similarity
    paper["dislike_penalty"] = penalty
    keyword_score = (
        float(ranking.get("title_weight", 2)) * len(title_keywords)
        + float(ranking.get("abstract_weight", 1)) * len(abstract_only)
        + float(ranking.get("topic_bonus", 3)) * len(matched_topics)
    )
    # The abstract decides; the title only when the abstract is missing
    # or gives no signal either way.
    paper["kind"] = (
        abstract.strip() and paper_kind(combined)
    ) or title_kind(title)
    paper["score"] = (
        min(keyword_score, float(ranking.get("max_keyword_score", 10)))
        + float(ranking.get("similarity_weight", 60)) * similarity
        + float(ranking.get("author_bonus", 5)) * bool(followed)
    ) * float(
        # Favour experimental work over theory/architecture papers.
        ranking.get("kind_factors", {}).get(paper["kind"], 1.0)
    )
    paper["ranking_basis"] = (
        "Title + abstract" if abstract.strip() else "Title only"
    )

    return bool(
        followed
        or similarity >= min_similarity
        or (matched_topics and similarity >= min_keyword_similarity)
    )


def date_sort_value(paper):
    """Use a consistent numeric date for ranking tie-breaks."""
    value = paper.get("date", "")

    try:
        if "T" in value:
            parsed = dt.datetime.fromisoformat(
                value.replace("Z", "+00:00")
            )
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=UTC)
            return parsed.timestamp()

        parts = value.split("-")

        if not parts or not parts[0].isdigit():
            return 0

        year = int(parts[0])
        month = int(parts[1]) if len(parts) > 1 else 1
        day = int(parts[2]) if len(parts) > 2 else 1

        return dt.datetime(year, month, day, tzinfo=UTC).timestamp()

    except (ValueError, TypeError, OverflowError):
        return 0


def rank_key(paper):
    return (
        paper.get("score", 0),
        len(paper.get("topics", [])),
        date_sort_value(paper),
    )


# ============================================================
# HTTP requests
# ============================================================

def get(url, params=None, timeout=60, attempts=5):
    """Retry temporary failures; raise if retrieval stays broken."""
    last_error = None

    for attempt in range(attempts):
        try:
            response = SESSION.get(url, params=params, timeout=timeout)

            if response.status_code in {429, 500, 502, 503, 504}:
                last_error = requests.HTTPError(
                    f"HTTP {response.status_code} from {url}",
                    response=response,
                )

                # A quota that resets much later is not worth
                # waiting for; fail fast and report it instead.
                wait = max(
                    int(value)
                    for value in [
                        response.headers.get("Retry-After", ""),
                        response.headers.get("X-RateLimit-Reset", ""),
                        "0",
                    ]
                    if value.isdigit()
                )
                if response.status_code == 429 and wait > 120:
                    raise RuntimeError(
                        f"rate limit reached at {url.split('/')[2]}; "
                        f"resets in about {wait // 60} minutes"
                    )

                if attempt < attempts - 1:
                    delay = min(60, 3 * (2 ** attempt))

                    retry_after = response.headers.get(
                        "Retry-After", ""
                    )
                    if retry_after.isdigit():
                        delay = min(120, max(delay, int(retry_after)))

                    logging.warning(
                        "HTTP %s; retrying in %s seconds",
                        response.status_code, delay
                    )
                    time.sleep(delay)

                continue

            response.raise_for_status()
            return response

        except (requests.Timeout, requests.ConnectionError) as exc:
            last_error = exc

            if attempt < attempts - 1:
                delay = min(60, 3 * (2 ** attempt))
                logging.warning(
                    "Request failed: %s; retrying in %s seconds",
                    exc, delay
                )
                time.sleep(delay)

    raise RuntimeError(
        f"Source unavailable after {attempts} attempts: {url}"
    ) from last_error


# ============================================================
# arXiv retrieval
# ============================================================

def arxiv_key(raw_id):
    """Stable delivery key; versioned only when revisions are on."""
    base_id = re.sub(r"v\d+$", "", raw_id)
    version_match = re.search(r"v\d+$", raw_id)

    version = (
        version_match.group()
        if version_match and CFG.get("include_arxiv_revisions", False)
        else ""
    )

    return base_id, f"arxiv:{base_id}{version}"


def arxiv_feed():
    """
    Today's full announcement for the configured categories, in one
    request. Every paper is returned; ranking decides what to keep.
    """
    categories = CFG.get("arxiv_feed_categories", [])

    if not categories:
        return

    allowed = {"new", "cross"}
    if CFG.get("include_arxiv_revisions", False):
        allowed |= {"replace", "replace-cross"}

    response = get(
        "https://rss.arxiv.org/rss/" + "+".join(categories),
        timeout=90,
    )
    root = ET.fromstring(response.content)

    counts = Counter()

    for item in root.iter("item"):
        kind = item.findtext("x:announce_type", "", NS).strip()
        counts[kind] += 1

        if kind not in allowed:
            continue

        description = item.findtext("description", "")
        id_match = re.search(r"arXiv:(\S+)", description)

        if not id_match:
            continue

        base_id, key = arxiv_key(id_match.group(1))

        try:
            date = email.utils.parsedate_to_datetime(
                item.findtext("pubDate", "")
            ).isoformat()
        except (TypeError, ValueError):
            date = ""

        yield {
            "key": key,
            "source": "arXiv",
            "arxiv_id": base_id,
            "title": clean_text(item.findtext("title", "")),
            "abstract": clean_text(
                description.split("Abstract:", 1)[-1]
            ),
            "authors": ", ".join(
                clean_text(creator.text)
                for creator in item.findall("dc:creator", NS)
            ),
            "url": "https://arxiv.org/abs/" + base_id,
            "doi": "",
            "date": date,
            "journal": "",
        }

    logging.info(
        "arXiv feed: %s",
        ", ".join(f"{n} {kind}" for kind, n in counts.items())
        or "empty (no announcement today)",
    )


def arxiv_search(start, end):
    """
    Keyword search over the whole lookback window. Catches papers
    from days the digest did not run or the feed was missed.
    """
    terms = search_terms()

    if not terms:
        return

    escaped_terms = [
        term.replace("\\", "\\\\").replace('"', '\\"')
        for term in terms
    ]

    include_revisions = CFG.get("include_arxiv_revisions", False)
    datefield = (
        "lastUpdatedDate" if include_revisions else "submittedDate"
    )

    query = "(" + " OR ".join(
        f'(ti:"{term}" OR abs:"{term}")' for term in escaped_terms
    ) + ")"
    query += (
        f" AND {datefield}:["
        f"{start.strftime('%Y%m%d%H%M')} TO "
        f"{end.strftime('%Y%m%d%H%M')}]"
    )

    offset = 0
    page = 0
    seen_entries = set()

    while True:
        page += 1

        if page > MAX_PAGES:
            raise RuntimeError(
                "arXiv page safety limit reached. Narrow the "
                "query/date window or increase max_pages_per_query."
            )

        time.sleep(3)

        response = get(
            "https://export.arxiv.org/api/query",
            params={
                "search_query": query,
                "start": offset,
                "max_results": PAGE_SIZE,
                "sortBy": datefield,
                "sortOrder": "descending",
            },
            timeout=90,
        )

        root = ET.fromstring(response.content)
        entries = root.findall("a:entry", NS)

        total_text = root.findtext("o:totalResults", None, NS)
        total = int(total_text) if total_text is not None else None

        logging.info(
            "arXiv search page %d: %d entries, total=%s",
            page, len(entries), total
        )

        if not entries:
            if total is not None and offset < total:
                raise RuntimeError(
                    "arXiv returned an unexpectedly empty page "
                    "before the reported end of results."
                )
            break

        page_ids = set()

        for entry in entries:
            identifier = entry.findtext("a:id", "", NS)

            if "/api/errors" in identifier:
                raise RuntimeError(
                    entry.findtext("a:summary", "arXiv API error", NS)
                )

            page_ids.add(identifier)

            if identifier in seen_entries:
                continue

            base_id, key = arxiv_key(
                identifier.rsplit("/abs/", 1)[-1]
            )

            yield {
                "key": key,
                "source": "arXiv",
                "arxiv_id": base_id,
                "title": clean_text(entry.findtext("a:title", "", NS)),
                "abstract": clean_text(
                    entry.findtext("a:summary", "", NS)
                ),
                "authors": ", ".join(
                    author.findtext("a:name", "", NS)
                    for author in entry.findall("a:author", NS)
                ),
                "url": "https://arxiv.org/abs/" + base_id,
                "doi": entry.findtext("x:doi", "", NS).strip().lower(),
                "date": entry.findtext("a:published", "", NS),
                "updated": entry.findtext("a:updated", "", NS),
                "journal": "",
            }

        if not page_ids - seen_entries:
            raise RuntimeError(
                "arXiv returned a repeated/non-progressing page."
            )

        seen_entries.update(page_ids)
        offset += len(entries)

        if total is not None:
            if offset >= total:
                break
        elif len(entries) < PAGE_SIZE:
            break


# ============================================================
# Journal retrieval (OpenAlex)
# ============================================================

OPENALEX_FIELDS = (
    "id,doi,title,publication_date,primary_location,"
    "abstract_inverted_index,authorships,primary_topic"
)


def reconstruct_abstract(index):
    if not index:
        return ""

    positions = {}

    for word, offsets in index.items():
        for offset in offsets:
            positions[int(offset)] = word

    return " ".join(positions[offset] for offset in sorted(positions))


REFRESH_CACHE = False


def cached_json(url, params):
    """
    GET a JSON API response, reusing a stored copy for
    openalex_cache_hours. OpenAlex meters requests per day, so
    repeated test runs on the same day cost nothing after the first.
    Returns (data, came_from_cache).
    """
    hours = float(CFG.get("openalex_cache_hours", 12))
    key = url + "?" + urllib.parse.urlencode(sorted(
        (name, value) for name, value in params.items()
        if name != "api_key"
    ))
    now = dt.datetime.now(UTC)

    if hours > 0 and not REFRESH_CACHE:
        with sqlite3.connect(DATABASE) as db:
            row = db.execute(
                "SELECT fetched_at, body FROM http_cache WHERE key=?",
                (key,),
            ).fetchone()

        if row and now - dt.datetime.fromisoformat(row[0]) < dt.timedelta(
            hours=hours
        ):
            return json.loads(row[1]), True

    body = get(url, params=params, timeout=90).content

    if hours > 0:
        with sqlite3.connect(DATABASE) as db:
            db.execute(
                "INSERT OR REPLACE INTO http_cache VALUES (?, ?, ?)",
                (key, now.isoformat(), body),
            )
            # Keep the cache small: drop anything older than 2 days.
            db.execute(
                "DELETE FROM http_cache WHERE fetched_at < ?",
                ((now - dt.timedelta(days=2)).isoformat(),),
            )

    return json.loads(body), False


def openalex_works(filters):
    """
    Page through an OpenAlex /works query. Numbered pages work without
    an API key (cursor paging needs one) and reach 10,000 results,
    far more than a week of any watchlist.
    """
    params = {
        "filter": filters,
        "select": OPENALEX_FIELDS,
        "per_page": PAGE_SIZE,
        "mailto": CFG["recipient"],
    }

    api_key = os.environ.get("OPENALEX_API_KEY")
    if api_key:
        params["api_key"] = api_key

    last_page = min(MAX_PAGES, 10_000 // PAGE_SIZE)

    for page in range(1, last_page + 1):
        data, cached = cached_json(
            "https://api.openalex.org/works", {**params, "page": page}
        )

        results = data.get("results", [])
        total = data.get("meta", {}).get("count") or 0

        logging.info(
            "OpenAlex page %d: %d records, total=%s%s",
            page, len(results), total, " (cached)" if cached else "",
        )

        yield from results

        if not results or page * PAGE_SIZE >= total:
            return

    logging.warning(
        "OpenAlex query has more than %d results; only the first %d "
        "were read. Narrow the journal list or date window.",
        last_page * PAGE_SIZE, last_page * PAGE_SIZE,
    )


def journal_paper(work, journal_names):
    doi = (work.get("doi") or "").lower()
    doi = doi.replace("https://doi.org/", "").strip()

    source = (work.get("primary_location") or {}).get("source") or {}
    journal = next(
        (
            journal_names[issn]
            for issn in source.get("issn") or []
            if issn in journal_names
        ),
        source.get("display_name") or "",
    )

    return {
        "key": f"doi:{doi}" if doi else "openalex:" + work["id"],
        "source": "Journal",
        "doi": doi,
        "title": clean_text(work.get("title") or ""),
        "abstract": clean_text(
            reconstruct_abstract(work.get("abstract_inverted_index"))
        ),
        "authors": ", ".join(
            (authorship.get("author") or {}).get("display_name") or ""
            for authorship in work.get("authorships") or []
        ),
        "date": work.get("publication_date") or "Unknown",
        "url": ("https://doi.org/" + doi) if doi else work["id"],
        "journal": journal,
        # OpenAlex's subject tags, used by the Blindspot section.
        "field": ((work.get("primary_topic") or {}).get("field") or {}).get(
            "display_name", ""
        ),
        "subfield": (
            (work.get("primary_topic") or {}).get("subfield") or {}
        ).get("display_name", ""),
    }


def journals(end):
    """
    Two OpenAlex queries, both limited to recent publication dates:
      1. every article in the journal watchlist (ranked locally),
      2. exact-phrase search for topic terms across all journals.
    """
    since = (
        end - dt.timedelta(days=float(CFG.get("journal_recent_days", 14)))
    ).date().isoformat()
    window = f"from_publication_date:{since},type:article"

    watchlist = CFG.get("journal_watchlist", {})
    journal_names = {issn: name for name, issn in watchlist.items()}

    queries = []

    if watchlist:
        queries.append(
            "primary_location.source.issn:"
            + "|".join(watchlist.values()) + "," + window
        )

    terms = [
        term.replace('"', "").replace(",", " ")
        for term in search_terms()
    ]
    if terms:
        queries.append(
            "title_and_abstract.search:"
            + " OR ".join(f'"{term}"' for term in terms)
            + ",primary_location.source.type:journal," + window
        )

    for filters in queries:
        for work in openalex_works(filters):
            yield journal_paper(work, journal_names)


# ============================================================
# Interest profile seeds (liked.txt)
# ============================================================

ARXIV_ID_PATTERN = re.compile(
    r"(\d{4}\.\d{4,5}|[a-z\-]+(?:\.[A-Z]{2})?/\d{7})(?:v\d+)?"
)
DOI_PATTERN = re.compile(r"10\.\d{4,9}/\S+")


def line_identifier(line):
    """'doi:…' / 'arxiv:…' for one liked.txt line; '' if blank/comment."""
    line = line.split("#", 1)[0].strip()

    if not line:
        return ""

    doi = DOI_PATTERN.search(line)
    arxiv_id = ARXIV_ID_PATTERN.search(line)

    if doi and "arxiv" not in doi.group().lower():
        return "doi:" + doi.group().lower().rstrip(".,;")
    if arxiv_id:
        return "arxiv:" + arxiv_id.group(1)

    logging.warning("liked.txt: unrecognised line %r", line)
    return ""


def liked_identifiers():
    path = BASE / CFG.get("liked_file", "liked.txt")

    if not path.exists():
        return []

    return [
        identifier
        for identifier in map(
            line_identifier, path.read_text(encoding="utf-8").splitlines()
        )
        if identifier
    ]


def fetch_seed_texts(identifiers):
    """Look up title + abstract for liked papers not yet cached."""
    texts = {}

    arxiv_ids = [i[6:] for i in identifiers if i.startswith("arxiv:")]
    dois = [i[4:] for i in identifiers if i.startswith("doi:")]

    if arxiv_ids:
        root = ET.fromstring(get(
            "https://export.arxiv.org/api/query",
            params={
                "id_list": ",".join(arxiv_ids),
                "max_results": len(arxiv_ids),
            },
            timeout=60,
        ).content)

        for entry in root.findall("a:entry", NS):
            base_id, _ = arxiv_key(
                entry.findtext("a:id", "", NS).rsplit("/abs/", 1)[-1]
            )
            texts["arxiv:" + base_id] = clean_text(
                entry.findtext("a:title", "", NS) + " "
                + entry.findtext("a:summary", "", NS)
            )

    # A DOI lookup failure should not discard the arXiv results.
    try:
        for batch_start in range(0, len(dois), 50):
            batch = dois[batch_start:batch_start + 50]

            for work in openalex_works("doi:" + "|".join(batch)):
                paper = journal_paper(work, {})
                texts["doi:" + paper["doi"]] = (
                    paper["title"] + " " + paper["abstract"]
                )
    except (RuntimeError, requests.RequestException, ValueError) as exc:
        logging.warning("Could not look up liked DOIs: %s", exc)

    return texts


def profile_texts():
    profile = CFG.get("interest_profile", [])
    return [profile] if isinstance(profile, str) else list(profile)


def liked_texts():
    """Title + abstract of every paper in liked.txt (cached)."""
    identifiers = liked_identifiers()

    if not identifiers:
        return []

    with sqlite3.connect(DATABASE) as db:
        cached = dict(db.execute(
            "SELECT id, text FROM seed_cache"
        ).fetchall())

    missing = [i for i in identifiers if i not in cached]

    if missing:
        try:
            fetched = fetch_seed_texts(missing)
        except (RuntimeError, requests.RequestException, ET.ParseError) as exc:
            logging.warning("Could not fetch liked papers: %s", exc)
            fetched = {}

        with sqlite3.connect(DATABASE) as db:
            db.executemany(
                "INSERT OR REPLACE INTO seed_cache VALUES (?, ?)",
                fetched.items(),
            )

        cached.update(fetched)

        for identifier in missing:
            if identifier not in fetched:
                logging.warning(
                    "liked.txt: no metadata found for %s", identifier
                )

    liked = [cached[i] for i in identifiers if i in cached]
    logging.info(
        "Liked papers: %d of %d with text (%d with an abstract)",
        len(liked),
        len(identifiers),
        sum(
            len(text.split()) >= InterestProfile.LIKED_MIN_WORDS
            for text in liked
        ),
    )
    return liked


# ============================================================
# Like / Read-later buttons (local web server)
# ============================================================
#
# Each button links to a small web server on this computer, e.g.
# http://localhost:8377/save?key=arxiv:2610.06961&sig=...
# One click applies the action and shows a confirmation page.
# The server runs alongside --serve (or alone with --buttons),
# listens only on 127.0.0.1, and every link carries a signature
# so other web pages cannot trigger actions by guessing URLs.

ACTION_LABELS = {
    "summary": "✨ Summarize",
    "like": "♡ Like",
    "save": "🔖 Read later",
    "done": "✓ Done",
    # Shown instead of like/save when already liked/saved; one click undoes.
    "unlike": "♥ Liked",
    "unsave": "🔖 Saved",
    "dislike": "👎 Not relevant",
    "undislike": "👎 Marked not relevant",
}
ACTION_RESULTS = {
    "like": "♥ Liked. Similar papers will rank higher.",
    "save": "🔖 Saved to your reading list.",
    "done": "✓ Marked as read and removed from your reading list.",
    "unlike": "Removed from your liked papers.",
    "unsave": "Removed from your reading list.",
    "dislike": "👎 Noted. Similar papers will rank lower.",
    "undislike": "Removed from your not-relevant papers.",
}

FEEDBACK_LOCK = threading.Lock()


def button_port():
    return int(CFG.get("button_port", 8377))


@lru_cache(maxsize=1)
def button_secret():
    """Per-installation key for signing button links."""
    with sqlite3.connect(DATABASE) as db:
        row = db.execute(
            "SELECT value FROM settings WHERE key='button_secret'"
        ).fetchone()

        if row:
            return row[0]

        value = secrets.token_hex(16)
        db.execute(
            "INSERT INTO settings VALUES ('button_secret', ?)", (value,)
        )
        return value


def signature(action, key):
    return hmac.new(
        button_secret().encode(),
        f"{action}:{key}".encode(),
        hashlib.sha256,
    ).hexdigest()[:20]


def feedback_link(action, paper):
    return (
        f"http://localhost:{button_port()}/{action}?"
        + urllib.parse.urlencode({
            "key": paper["key"],
            "sig": signature(action, paper["key"]),
        })
    )


def remember_papers(papers):
    """Keep metadata of shown papers so buttons can refer to them."""
    with sqlite3.connect(DATABASE) as db:
        db.executemany(
            "INSERT OR REPLACE INTO paper_info VALUES (?, ?)",
            [
                (
                    paper["key"],
                    json.dumps({
                        field: paper.get(field, "")
                        for field in [
                            "title", "url", "authors", "source",
                            "journal", "arxiv_id", "doi", "date",
                            "abstract", "section", "rank",
                        ]
                    }),
                )
                for paper in papers
            ],
        )


def paper_info(db, key):
    row = db.execute(
        "SELECT info FROM paper_info WHERE key=?", (key,)
    ).fetchone()

    if row:
        return json.loads(row[0])

    # Details not stored (yet): the link can still be built from the ID.
    url = (
        "https://arxiv.org/abs/" + key[6:] if key.startswith("arxiv:")
        else "https://doi.org/" + key[4:] if key.startswith("doi:")
        else ""
    )
    return {"title": key, "url": url}


LOOKUP_FAILED = {}  # key -> time of last failed lookup


def lookup_papers(keys):
    """
    Fetch title, link and abstract for papers the bot never stored:
    one arXiv request and one OpenAlex request per batch, without
    long retries, since a page is waiting on the result.
    """
    found = []
    arxiv_ids = [key[6:] for key in keys if key.startswith("arxiv:")]
    dois = [key[4:] for key in keys if key.startswith("doi:")]

    # OpenAlex first, also for arXiv papers (via their 10.48550 DOIs):
    # with an API key it is more reliable than arXiv's own API.
    try:
        names = {
            issn: name
            for name, issn in CFG.get("journal_watchlist", {}).items()
        }
        lookups = dois + ["10.48550/arxiv." + aid for aid in arxiv_ids]

        for start in range(0, len(lookups), 50):
            for work in openalex_works(
                "doi:" + "|".join(lookups[start:start + 50])
            ):
                paper = journal_paper(work, names)

                if paper["doi"].startswith("10.48550/arxiv."):
                    base_id = paper["doi"].split("arxiv.", 1)[1]
                    found.append({
                        **paper,
                        "key": "arxiv:" + base_id,
                        "source": "arXiv",
                        "arxiv_id": base_id,
                        "url": "https://arxiv.org/abs/" + base_id,
                        "journal": "",
                    })
                else:
                    found.append({**paper, "key": "doi:" + paper["doi"]})
    except (RuntimeError, requests.RequestException, ValueError) as exc:
        logging.warning("OpenAlex lookup failed: %s", exc)

    found_keys = {paper["key"] for paper in found}
    arxiv_ids = [
        aid for aid in arxiv_ids if "arxiv:" + aid not in found_keys
    ]

    try:
        if arxiv_ids:
            root = ET.fromstring(get(
                "https://export.arxiv.org/api/query",
                params={
                    "id_list": ",".join(arxiv_ids),
                    "max_results": len(arxiv_ids),
                },
                timeout=20,
                attempts=2,
            ).content)

            for entry in root.findall("a:entry", NS):
                base_id, key = arxiv_key(
                    entry.findtext("a:id", "", NS).rsplit("/abs/", 1)[-1]
                )
                if not entry.findtext("a:title", "", NS):
                    continue
                found.append({
                    "key": "arxiv:" + base_id,
                    "source": "arXiv",
                    "arxiv_id": base_id,
                    "title": clean_text(entry.findtext("a:title", "", NS)),
                    "abstract": clean_text(
                        entry.findtext("a:summary", "", NS)
                    ),
                    "authors": ", ".join(
                        author.findtext("a:name", "", NS)
                        for author in entry.findall("a:author", NS)
                    ),
                    "url": "https://arxiv.org/abs/" + base_id,
                    "date": entry.findtext("a:published", "", NS),
                })
    except (RuntimeError, requests.RequestException, ET.ParseError) as exc:
        logging.warning("arXiv lookup failed: %s", exc)

    return found


def ensure_paper_info(keys):
    """Look up and store details for any keys without stored info."""
    with sqlite3.connect(DATABASE) as db:
        missing = [
            key for key in keys
            if not db.execute(
                "SELECT 1 FROM paper_info WHERE key=?", (key,)
            ).fetchone()
            # Don't hammer a busy source: retry a failure after an hour.
            and time.time() - LOOKUP_FAILED.get(key, 0) > 3600
        ]

    if not missing:
        return

    found = lookup_papers(missing)
    if found:
        remember_papers(found)

    found_keys = {paper["key"] for paper in found}
    for key in missing:
        if key not in found_keys:
            LOOKUP_FAILED[key] = time.time()


def liked_key(key):
    """Paper key in the form liked.txt uses (no arXiv version)."""
    return re.sub(r"v\d+$", "", key) if key.startswith("arxiv:") else key


def paper_states():
    """(liked, saved, disliked) keys right now, for button states."""
    with sqlite3.connect(DATABASE) as db:
        saved = {
            key for (key,) in db.execute(
                "SELECT key FROM reading_list WHERE done_at IS NULL"
            )
        }
        disliked = {key for (key,) in db.execute("SELECT key FROM disliked")}
    return set(liked_identifiers()), saved, disliked


def disliked_texts():
    """Title + abstract of every paper marked 👎 Not relevant."""
    with sqlite3.connect(DATABASE) as db:
        return [text for (text,) in db.execute("SELECT text FROM disliked")]


def unlike(key):
    """Remove a paper's line(s) from liked.txt."""
    path = BASE / CFG.get("liked_file", "liked.txt")

    if not path.exists():
        return "This paper isn't in your liked papers."

    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    kept = [
        line for line in lines if line_identifier(line) != liked_key(key)
    ]

    if len(kept) == len(lines):
        return "This paper isn't in your liked papers."

    path.write_text("".join(kept), encoding="utf-8")
    return ACTION_RESULTS["unlike"]


def liked_line(key, info):
    """liked.txt entry for a paper key, or None if it has no ID."""
    if key.startswith("arxiv:"):
        identifier = re.sub(r"v\d+$", "", key[6:])
    elif key.startswith("doi:"):
        identifier = key[4:]
    else:
        return None

    title = re.sub(r"\s+", " ", info.get("title", ""))[:120]
    return f"{identifier}  # {title}"


def like(db, key, info):
    """Append to liked.txt and seed the ranking with the paper's text."""
    line = liked_line(key, info)

    if line is None:
        return "This paper has no arXiv ID or DOI, so it cannot be liked."

    # Same form as liked_identifiers(): no arXiv version.
    liked_key = (
        re.sub(r"v\d+$", "", key) if key.startswith("arxiv:") else key
    )

    if liked_key in liked_identifiers():
        return "♥ Already liked."

    liked_path = BASE / CFG.get("liked_file", "liked.txt")
    existing = (
        liked_path.read_text(encoding="utf-8")
        if liked_path.exists()
        else ""
    )

    with liked_path.open("a", encoding="utf-8") as handle:
        if existing and not existing.endswith("\n"):
            handle.write("\n")
        handle.write(line + "\n")

    # The digest already had the text; seed the ranking with it
    # directly instead of fetching it again (title only when the
    # source had no abstract).
    if info.get("title") and info["title"] != key:
        db.execute(
            "INSERT OR REPLACE INTO seed_cache VALUES (?, ?)",
            (liked_key, info["title"] + " " + info.get("abstract", "")),
        )

    return ACTION_RESULTS["like"]


def apply_action(action, key):
    """Apply one button click; return (paper info, message)."""
    now = dt.datetime.now(UTC).isoformat()

    # Papers clicked in an older email or preview may not be stored yet.
    ensure_paper_info([key])

    with FEEDBACK_LOCK, sqlite3.connect(DATABASE) as db:
        info = paper_info(db, key)

        if action == "like":
            message = like(db, key, info)
        elif action == "dislike":
            db.execute(
                "INSERT OR REPLACE INTO disliked VALUES (?, ?, ?)",
                (
                    key,
                    info.get("title", "") + " " + info.get("abstract", ""),
                    now,
                ),
            )
            message = ACTION_RESULTS["dislike"]
        elif action == "undislike":
            db.execute("DELETE FROM disliked WHERE key=?", (key,))
            message = ACTION_RESULTS["undislike"]
        elif action == "unlike":
            message = unlike(key)
        elif action == "save":
            db.execute(
                "INSERT INTO reading_list (key, saved_at) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET done_at=NULL",
                (key, now),
            )
            message = ACTION_RESULTS["save"]
        else:  # done / unsave
            db.execute(
                "UPDATE reading_list SET done_at=? WHERE key=?",
                (now, key),
            )
            message = ACTION_RESULTS[action]

        # Only real changes count toward "since the last digest".
        if message == ACTION_RESULTS[action]:
            db.execute(
                "INSERT INTO feedback_log VALUES (?, ?, ?)",
                (now, action, key),
            )

    _STATE_CACHE[0] = 0.0  # show the new state on the next page
    write_reading_list(reading_list())
    logging.info("Button: %s %s", action, key)
    return info, message


def feedback_since(timestamp):
    """Counts of button clicks since the given ISO time."""
    with sqlite3.connect(DATABASE) as db:
        return Counter(dict(db.execute(
            "SELECT action, COUNT(*) FROM feedback_log "
            "WHERE at > ? GROUP BY action",
            (timestamp or "",),
        ).fetchall()))


def reading_list():
    """Saved papers not yet marked done, oldest first."""
    with sqlite3.connect(DATABASE) as db:
        rows = db.execute(
            "SELECT key, saved_at FROM reading_list "
            "WHERE done_at IS NULL ORDER BY saved_at"
        ).fetchall()

    # Fill in titles/links for papers saved before they were stored.
    ensure_paper_info([key for key, _ in rows])

    with sqlite3.connect(DATABASE) as db:
        return [
            {**paper_info(db, key), "key": key, "saved_at": saved_at}
            for key, saved_at in rows
        ]


def reading_category(paper):
    """
    First matching reading_list_categories entry (config.json): a
    category matches if any of its terms appears in the title/abstract
    and, if it sets "kind", the paper has that experiment/theory label.
    """
    title = paper.get("title", "")
    text = title + " " + paper.get("abstract", "")
    kind = (
        paper.get("abstract", "").strip() and paper_kind(text)
    ) or title_kind(title)

    for category in CFG.get("reading_list_categories", []):
        if category.get("kind") and category["kind"] != kind:
            continue
        if not category.get("any") or keyword_hits(text, category["any"]):
            return category["name"]

    return "Other"


def group_reading_list(papers):
    """[(category, papers)] in the configured category order."""
    groups = {}
    for paper in papers:
        groups.setdefault(reading_category(paper), []).append(paper)

    order = [c["name"] for c in CFG.get("reading_list_categories", [])]
    order += ["Other"]
    return [(name, groups[name]) for name in order if name in groups]


def write_reading_list(papers):
    lines = ["# Reading list", ""]

    for category, group in group_reading_list(papers):
        lines.extend([f"## {category} ({len(group)})", ""])
        for paper in group:
            lines.append(
                f"- [{paper.get('title', paper['key'])}]"
                f"({paper.get('url', '')}) "
                f"— saved {paper['saved_at'][:10]}"
            )
        lines.append("")

    if not papers:
        lines.append("Nothing saved. Use 🔖 Read later in the digest.")

    (BASE / "reading_list.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def page(title, content):
    return (
        "<!DOCTYPE html><html><head><meta charset='utf-8'>"
        f"<title>{html.escape(title)}</title></head>"
        "<body style='font-family:Arial,sans-serif;max-width:720px;"
        "margin:40px auto;padding:0 16px;line-height:1.45;color:#222'>"
        + content
        + "</body></html>"
    )


def reading_list_items_html(saved, heading_tag="h3"):
    """Reading list grouped by category (email and local page)."""
    parts = []

    for category, group in group_reading_list(saved):
        parts.append(
            f"<{heading_tag} style='margin:20px 0 4px;font-size:15px;"
            f"color:#444'>{html.escape(category)} "
            f"<span style='color:#888;font-weight:normal'>({len(group)})"
            f"</span></{heading_tag}>"
        )
        for paper in group:
            parts.append(
                "<div style='margin:8px 0 12px'>"
                f"<a href='{html.escape(paper.get('url', ''), quote=True)}'>"
                f"{html.escape(paper.get('title', paper['key']))}</a>"
                f"<div style='color:#666;font-size:13px'>saved "
                f"{html.escape(paper['saved_at'][:10])}</div>"
                + buttons(paper, ("summary", "done", "like"))
                + "</div>"
            )

    return "".join(parts)


# ------------------------------------------------------------
# ➕ Add your own papers to the reading list
# ------------------------------------------------------------

ARXIV_URL = re.compile(
    r"arxiv\.org/(?:abs|pdf|html)/([a-z\-]+(?:\.[A-Z]{2})?/\d{7}|\d{4}\.\d{4,5})",
    re.I,
)
NATURE_URL = re.compile(r"nature\.com/articles/([A-Za-z0-9.\-]+)", re.I)


def parse_paper_reference(text):
    """
    'arxiv:…' or 'doi:…' for a pasted arXiv ID/link, DOI/doi.org link
    or journal link that contains a DOI; None if it looks like a title.
    """
    text = text.strip()

    match = ARXIV_URL.search(text)
    if match:
        return "arxiv:" + match.group(1)

    bare = re.fullmatch(
        r"(?:arxiv:\s*)?(\d{4}\.\d{4,5})(?:v\d+)?", text, re.I
    )
    if bare:
        return "arxiv:" + bare.group(1)

    match = NATURE_URL.search(text)
    if match:
        return "doi:10.1038/" + match.group(1).lower()

    match = DOI_PATTERN.search(text)
    if match:
        doi = match.group().lower()
        # Journal links often continue after the DOI.
        doi = re.split(r"[?#]|/(?:abstract|full|fulltext|pdf|epdf)\b", doi)[0]
        doi = doi.rstrip(".,;)/")
        if doi.startswith("10.48550/arxiv."):
            return "arxiv:" + doi.split("arxiv.", 1)[1]
        return "doi:" + doi

    return None


def search_by_title(text):
    """Best OpenAlex match for a pasted paper title, or None."""
    params = {
        "filter": "title.search:" + text.replace(",", " "),
        "per_page": 1,
        "select": OPENALEX_FIELDS,
        "mailto": CFG["recipient"],
    }
    api_key = os.environ.get("OPENALEX_API_KEY")
    if api_key:
        params["api_key"] = api_key

    try:
        data, _ = cached_json("https://api.openalex.org/works", params)
    except (RuntimeError, requests.RequestException, ValueError) as exc:
        logging.warning("Title search failed: %s", exc)
        return None

    for work in data.get("results", []):
        names = {
            issn: name
            for name, issn in CFG.get("journal_watchlist", {}).items()
        }
        paper = journal_paper(work, names)
        if paper["doi"].startswith("10.48550/arxiv."):
            base_id = paper["doi"].split("arxiv.", 1)[1]
            paper.update({
                "key": "arxiv:" + base_id, "source": "arXiv",
                "arxiv_id": base_id, "journal": "",
                "url": "https://arxiv.org/abs/" + base_id,
            })
        return paper

    return None


def add_papers(text):
    """
    Add each pasted line (ID, link or title) to the reading list.
    Returns [(key, info, note)] for what was added, [(None, None, error)]
    for lines that could not be identified.
    """
    results = []
    now = dt.datetime.now(UTC).isoformat()

    for line in text.splitlines()[:20]:
        line = line.strip()
        if not line:
            continue

        key = parse_paper_reference(line)
        note = ""

        if key:
            ensure_paper_info([key])
        elif len(line.split()) >= 3:
            paper = search_by_title(line)
            if not paper:
                results.append((None, None, f"No paper found for “{line}”."))
                continue
            remember_papers([paper])
            key = paper["key"]
            note = "Matched by title; check it's the right paper."
        else:
            results.append((
                None, None,
                f"“{line}” isn't an arXiv ID, DOI, link or full title.",
            ))
            continue

        with FEEDBACK_LOCK, sqlite3.connect(DATABASE) as db:
            db.execute(
                "INSERT INTO reading_list (key, saved_at) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET done_at=NULL",
                (key, now),
            )
            # You found it yourself: don't show it again as new.
            db.execute("INSERT OR IGNORE INTO sent VALUES (?, ?)", (key, now))
            db.execute(
                "INSERT INTO feedback_log VALUES (?, ?, ?)", (now, "save", key)
            )
            info = paper_info(db, key)

        if info.get("title") == key:
            note = (
                "Saved; title and details will appear once the lookup "
                "service responds."
            )
        results.append((key, info, note))
        logging.info("Added to reading list: %s", key)

    _STATE_CACHE[0] = 0.0
    write_reading_list(reading_list())
    return results


def add_form_html():
    return (
        "<form method='post' action='/add' style='margin:12px 0 24px;"
        "padding:12px 14px;background:#f5f7fa;border:1px solid #dde3ea;"
        "border-radius:8px'>"
        "<div style='font-weight:bold;margin-bottom:6px'>➕ Add a paper</div>"
        "<textarea name='papers' rows='3' style='width:100%;"
        "box-sizing:border-box;font:inherit;padding:6px' placeholder='"
        "Paste an arXiv ID or link, a DOI, a journal link, or a title "
        "(one per line)'></textarea>"
        f"<input type='hidden' name='sig' value='{signature('add', 'form')}'>"
        "<button type='submit' style='margin-top:6px;padding:4px 14px'>"
        "Add to reading list</button></form>"
    )


def add_results_html(results):
    parts = []
    for key, info, note in results:
        if key is None:
            parts.append(f"<p style='color:#a33'>⚠ {html.escape(note)}</p>")
            continue
        parts.append(
            "<div style='margin:10px 0 14px'>"
            "🔖 Added: "
            f"<a href='{html.escape(info.get('url', ''), quote=True)}'>"
            f"{html.escape(info.get('title', key))}</a>"
            f"<div style='color:#666;font-size:13px'>→ "
            f"{html.escape(reading_category({**info, 'key': key}))}"
            + (f" · {html.escape(note)}" if note else "")
            + "</div>"
            + buttons({**info, "key": key}, ("summary", "save", "like"))
            + "</div>"
        )
    return "".join(parts)


def save_config():
    """Write the in-memory settings back to config.json."""
    CONFIG_PATH.write_text(
        json.dumps(CFG, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def set_learning_topic(topic):
    """Start (or stop, with an empty topic) the 📚 learning track."""
    topic = " ".join(topic.split())[:120]
    track = CFG.setdefault("learning_track", {})
    track["name"] = topic
    track["query"] = ""  # rebuilt from the name
    save_config()
    logging.info("Learning topic set to %r", topic)


def learn_form_html():
    topic = CFG.get("learning_track", {}).get("name", "")
    current = (
        f"Now learning: <b>{html.escape(topic)}</b>. One of the field's "
        "most-cited papers arrives in each digest."
        if topic else
        "No learning topic set."
    )
    return (
        "<form method='post' action='/learn' style='margin:12px 0 24px;"
        "padding:12px 14px;background:#f2f8f3;border:1px solid #cfe3d3;"
        "border-radius:8px'>"
        "<div style='font-weight:bold;margin-bottom:6px'>📚 Learn a topic "
        "from the ground up</div>"
        f"<div style='font-size:14px;margin-bottom:6px'>{current}</div>"
        "<input name='topic' style='width:70%;font:inherit;padding:5px' "
        f"value='{html.escape(topic, quote=True)}' "
        "placeholder='e.g. Rydberg atom arrays, topological insulators'>"
        f"<input type='hidden' name='sig' value='{signature('learn', 'form')}'>"
        " <button type='submit' style='padding:4px 14px'>Save</button>"
        "<div style='color:#666;font-size:12px;margin-top:4px'>Leave empty "
        "to turn it off. Put \"quotes\" around words that must appear "
        "together.</div></form>"
    )


def reading_list_html():
    saved = reading_list()
    parts = [
        "<h2>Your reading list "
        f"<span style='color:#666;font-size:15px'>({len(saved)})</span>"
        "</h2>",
        add_form_html(),
        learn_form_html(),
        reading_list_items_html(saved),
    ]

    if not saved:
        parts.append(
            "<p>Nothing saved. Use 🔖 Read later in the digest.</p>"
        )

    return "".join(parts)


# ============================================================
# ✨ Summarize button (local model via Ollama, free)
# ============================================================
#
# Summaries are written by a small model running on this computer
# through Ollama (https://ollama.com). The first click starts the
# summary in the background and shows a page that refreshes until
# it is ready; summaries are stored, so later clicks are instant.

SUMMARY_PROMPT = """You help a researcher triage new papers.

The researcher's interests:
{interests}

Paper title: {title}
Authors: {authors}
Source: {source}

{paper_text}

Write exactly two short sections, using only what the text above
says. Do not invent numbers, methods or results that are not in it.
Write each section once and then stop; do not offer alternative
versions.

SUMMARY: 3-4 plain sentences: the problem, what they did, and the
main result.

RELEVANCE: 1-2 sentences on how it connects to the researcher's
interests above, naming the specific interest. If the connection is
weak, say so plainly."""

SUMMARY_JOBS = set()
SUMMARY_LOCK = threading.Lock()


def ollama_settings():
    settings = CFG.get("summaries", {})
    return (
        settings.get("ollama_url", "http://127.0.0.1:11434").rstrip("/"),
        settings.get("ollama_model", "qwen2.5:3b"),
    )


def stored_summary(key):
    with sqlite3.connect(DATABASE) as db:
        row = db.execute(
            "SELECT text, model FROM summaries WHERE key=?", (key,)
        ).fetchone()
    return row


class ArxivTextParser(html.parser.HTMLParser):
    """
    Main-text paragraphs from an arXiv HTML paper (LaTeXML), in order.
    Skips the abstract, figures, tables, captions, footnotes, the
    bibliography and appendices; math is kept as its LaTeX source.
    Stops at the first supplementary/appendix heading.
    """

    SKIP_TAGS = {"figure", "table", "nav", "header", "footer", "script",
                 "style", "button"}
    SKIP_CLASSES = ("ltx_abstract", "ltx_bibliography", "ltx_appendix",
                    "ltx_note", "ltx_caption", "ltx_authors", "ltx_dates",
                    "ltx_role_footnote")
    END_HEADING = re.compile(
        r"^\s*(S\d|supplement|appendix|methods\b|references|acknowledg)",
        re.I,
    )

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.paragraphs = []
        self.stack = []        # (tag, skipping) for open elements
        self.paragraph = None  # text pieces of the open ltx_p
        self.heading = None
        self.in_math = 0
        self.done = False

    def skipping(self):
        return any(skip for _, skip in self.stack)

    def handle_starttag(self, tag, attrs):
        if self.done:
            return

        attrs = dict(attrs)
        # Exact class names: the <article> wrapper carries classes such
        # as "ltx_authors_1line" that a substring test would match.
        classes = set((attrs.get("class") or "").split())

        # The main text ends where acknowledgements, references or
        # appendices begin; supplementary sections follow those.
        if classes & {"ltx_acknowledgements", "ltx_bibliography",
                      "ltx_appendix"}:
            self.done = True
            return

        skip = tag in self.SKIP_TAGS or bool(
            classes & set(self.SKIP_CLASSES)
        )

        if tag not in ("br", "img", "hr", "input", "meta", "link"):
            self.stack.append((tag, skip))

        if self.skipping():
            return

        if tag == "math":
            self.in_math += 1
            if self.paragraph is not None and self.in_math == 1:
                self.paragraph.append(" " + (attrs.get("alttext") or "") + " ")
        elif tag in ("h2", "h3") and "ltx_title" in classes:
            self.heading = []
        elif tag == "p" and "ltx_p" in classes:
            self.paragraph = []

    def handle_endtag(self, tag):
        if self.done:
            return

        if not self.skipping():
            if tag == "math" and self.in_math:
                self.in_math -= 1
            elif tag in ("h2", "h3") and self.heading is not None:
                title = " ".join("".join(self.heading).split())
                self.heading = None
                if self.END_HEADING.match(title):
                    self.done = True
            elif tag == "p" and self.paragraph is not None:
                text = " ".join("".join(self.paragraph).split())
                if text:
                    self.paragraphs.append(text)
                self.paragraph = None

        # Pop back to the matching open tag (HTML is not always tidy).
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break

    def handle_data(self, data):
        if self.done or self.skipping() or self.in_math:
            return
        if self.heading is not None:
            self.heading.append(data)
        elif self.paragraph is not None:
            self.paragraph.append(data)


def first_words(paragraphs, limit):
    out, count = [], 0
    for paragraph in paragraphs:
        words = paragraph.split()
        if count + len(words) > limit:
            out.append(" ".join(words[:limit - count]) + " …")
            break
        out.append(paragraph)
        count += len(words)
    return out


def arxiv_excerpts(arxiv_id):
    """
    (beginning, ending) of an arXiv paper's main text, or None if no
    HTML version exists. Section names vary (letters often have none),
    so this takes the first ~1500 words (introduction and setup) and
    the last ~900 words of the main text (results and conclusions).
    """
    try:
        response = SESSION.get(
            f"https://arxiv.org/html/{arxiv_id}", timeout=60
        )
    except requests.RequestException:
        return None

    if response.status_code != 200 or "ltx_p" not in response.text:
        return None

    parser = ArxivTextParser()
    parser.feed(response.text)
    paragraphs = parser.paragraphs

    total = sum(len(paragraph.split()) for paragraph in paragraphs)
    if total < 300:
        return None

    beginning = first_words(paragraphs, 1500)
    used = sum(len(paragraph.split()) for paragraph in beginning)
    remaining = paragraphs[len(beginning):]
    ending = list(reversed(first_words(
        list(reversed(remaining)), min(900, max(0, total - used))
    )))

    return "\n\n".join(beginning), "\n\n".join(ending)


def write_summary(key):
    """Generate one summary with Ollama and store it (or the error)."""
    url, model = ollama_settings()

    with sqlite3.connect(DATABASE) as db:
        info = paper_info(db, key)

    paper_text = "Abstract:\n" + info.get("abstract", "")
    basis = "the abstract"

    if key.startswith("arxiv:"):
        excerpts = arxiv_excerpts(info.get("arxiv_id") or key[6:])
        if excerpts:
            beginning, ending = excerpts
            paper_text += (
                "\n\nBeginning of the main text (introduction):\n"
                + beginning
                + ("\n\nEnd of the main text (results and conclusions):\n"
                   + ending if ending else "")
            )
            basis = "the abstract, introduction and conclusions"

    prompt = SUMMARY_PROMPT.format(
        interests="\n".join("- " + text for text in profile_texts()),
        title=info.get("title", key),
        authors=short_authors(info.get("authors", ""), 8),
        source=info.get("journal") or info.get("source", ""),
        paper_text=paper_text,
    )

    try:
        response = requests.post(
            url + "/api/chat",
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "stream": False,
                # Cap the reply length: small models sometimes ramble.
                "options": {
                    "temperature": 0.2,
                    # Room for ~2,400 words of paper text plus prompt.
                    "num_ctx": 8192,
                    "num_predict": 400,
                },
            },
            timeout=600,
        )
        response.raise_for_status()
        text = response.json()["message"]["content"].strip()
    except requests.ConnectionError:
        text = (
            "ERROR: Ollama is not running. Start the Ollama app, then "
            "click ✨ Summarize again."
        )
    except (requests.RequestException, KeyError, ValueError) as exc:
        text = f"ERROR: the local model failed ({exc})."

    if not text.startswith("ERROR:"):
        with sqlite3.connect(DATABASE) as db:
            db.execute(
                "INSERT OR REPLACE INTO summaries VALUES (?, ?, ?, ?)",
                (
                    key,
                    f"{model}|{basis}",
                    text,
                    dt.datetime.now(UTC).isoformat(),
                ),
            )
    else:
        SUMMARY_ERRORS[key] = text

    with SUMMARY_LOCK:
        SUMMARY_JOBS.discard(key)


SUMMARY_ERRORS = {}


def summary_html(text):
    """
    Render the model's SUMMARY/RELEVANCE text as HTML sections. Only
    the first of each section is kept, since small models sometimes
    append alternative versions.
    """
    text = re.split(r"\n\s*\**\s*Alternatively\b", text, maxsplit=1)[0]
    parts = re.split(r"\**\s*(SUMMARY|RELEVANCE)\s*:?\**\s*:?", text)

    if len(parts) < 3:
        return "<p>" + html.escape(text).replace("\n", "<br>") + "</p>"

    headings = {
        "SUMMARY": "Summary",
        "RELEVANCE": "Why it may matter to you",
    }
    out = []
    seen = set()

    for label, body in zip(parts[1::2], parts[2::2]):
        if label in seen:
            continue
        seen.add(label)
        out.append(
            f"<h3 style='margin-bottom:4px'>{headings[label]}</h3>"
            f"<p style='margin-top:4px'>"
            f"{html.escape(body.strip()).replace(chr(10), '<br>')}</p>"
        )

    return "".join(out)


def summary_page(key):
    with sqlite3.connect(DATABASE) as db:
        info = paper_info(db, key)

    title = html.escape(info.get("title", key))
    link = (
        f"<h2 style='font-weight:normal'>"
        f"<a href='{html.escape(info.get('url', ''), quote=True)}'>"
        f"{title}</a></h2>"
    )
    muted = "color:#666;font-size:13px"

    # Without an abstract a small model just guesses from the title.
    if not info.get("abstract", "").strip():
        return page("No abstract available", (
            link
            + "<p>The publisher doesn't share this paper's abstract with "
            "the free metadata service, so there's nothing reliable to "
            "summarize. (A summary from the title alone would be "
            "guesswork.) Open the paper using the link above.</p>"
            + buttons({**info, "key": key}, ("like", "save"))
        ))

    row = stored_summary(key)
    if row:
        text, model = row
        model, _, basis = model.partition("|")
        return page("Summary: " + info.get("title", key), (
            link
            + summary_html(text)
            + f"<p style='{muted};margin-top:24px'>Written by "
            f"{html.escape(model)} on this computer from "
            f"{html.escape(basis or 'the abstract')}. Small local models "
            "can get details wrong, so check the paper before relying on "
            "it.</p>"
            + buttons({**info, "key": key}, ("like", "save"))
        ))

    if key in SUMMARY_ERRORS:
        error = SUMMARY_ERRORS.pop(key)
        return page("Summary failed", (
            link + f"<p>{html.escape(error)}</p>"
            + buttons({**info, "key": key}, ("summary",))
        ))

    with SUMMARY_LOCK:
        if key not in SUMMARY_JOBS:
            SUMMARY_JOBS.add(key)
            threading.Thread(
                target=write_summary, args=(key,), daemon=True
            ).start()

    return (
        "<!DOCTYPE html><html><head><meta charset='utf-8'>"
        "<meta http-equiv='refresh' content='3'>"
        f"<title>Summarizing…</title></head>"
        "<body style='font-family:Arial,sans-serif;max-width:720px;"
        "margin:40px auto;padding:0 16px;line-height:1.45;color:#222'>"
        + link
        + "<p>✨ Writing a summary on this computer… this takes about "
        "15 seconds, or up to a minute for arXiv papers (it reads the "
        "introduction and conclusions too). This page updates by "
        "itself.</p>"
        "</body></html>"
    )


class ButtonHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        url = urllib.parse.urlsplit(self.path)
        action = url.path.strip("/")
        query = urllib.parse.parse_qs(url.query)
        key = query.get("key", [""])[0]
        sig = query.get("sig", [""])[0]

        if action in ("", "reading-list", "add", "learn"):
            return self.reply(200, page("Reading list", reading_list_html()))

        if action not in ACTION_LABELS:
            return self.reply(404, page("Not found", "<p>Not found.</p>"))

        if not key or not hmac.compare_digest(sig, signature(action, key)):
            return self.reply(403, page(
                "Invalid link",
                "<p>This link is not valid. Use the buttons in the "
                "digest email.</p>",
            ))

        if action == "summary":
            return self.reply(200, summary_page(key))

        info, message = apply_action(action, key)
        title = html.escape(info.get("title", key))
        url_text = html.escape(info.get("url", ""), quote=True)

        self.reply(200, page(message, (
            f"<h2 style='font-weight:normal'>{html.escape(message)}</h2>"
            f"<p><a href='{url_text}'>{title}</a></p>"
            # Current state, so a mistaken click can be undone here.
            + buttons({**info, "key": key})
            + "<p style='color:#666'>You can close this tab.</p>"
            "<hr style='margin:32px 0'>"
            + reading_list_html()
        )))

    def do_POST(self):
        """The ➕ Add a paper and 📚 Learn forms."""
        form_name = urllib.parse.urlsplit(self.path).path.strip("/")
        if form_name not in ("add", "learn"):
            return self.reply(404, page("Not found", "<p>Not found.</p>"))

        length = min(int(self.headers.get("Content-Length") or 0), 20000)
        form = urllib.parse.parse_qs(
            self.rfile.read(length).decode("utf-8", "replace")
        )

        # The signed field proves the form came from this server's own
        # page, so other websites can't add papers behind your back.
        if not hmac.compare_digest(
            form.get("sig", [""])[0], signature(form_name, "form")
        ):
            return self.reply(403, page(
                "Invalid form", "<p>Please use the form on the reading "
                "list page (http://localhost:%d/add).</p>" % button_port(),
            ))

        if form_name == "learn":
            set_learning_topic(form.get("topic", [""])[0])
            return self.reply(200, page("Learning topic", (
                "<h2 style='font-weight:normal'>📚 Learning topic saved</h2>"
                + reading_list_html()
            )))

        results = add_papers(form.get("papers", [""])[0])
        self.reply(200, page("Added to reading list", (
            "<h2 style='font-weight:normal'>➕ Add papers</h2>"
            + (add_results_html(results) or "<p>Nothing to add.</p>")
            + "<hr style='margin:24px 0'>"
            + reading_list_html()
        )))

    def reply(self, status, body):
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, format, *args):
        logging.debug("Button server: " + format, *args)


class ExclusiveServer(http.server.ThreadingHTTPServer):
    """
    Refuse to share the port. The default allows address reuse,
    which on Windows lets a second copy bind the same port silently.
    """

    allow_reuse_address = False

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(
                socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1
            )
        super().server_bind()


def start_button_server(block=False):
    """Serve button clicks on 127.0.0.1; return the server or None."""
    initialize_database()

    try:
        server = ExclusiveServer(
            ("127.0.0.1", button_port()), ButtonHandler
        )
    except OSError as exc:
        logging.warning(
            "Button server not started on port %s (%s). Is another "
            "copy running? Change button_port in config.json if "
            "the port is taken.", button_port(), exc
        )
        return None

    logging.info(
        "Buttons active: http://localhost:%s (reading list)",
        button_port()
    )

    if block:
        server.serve_forever()
    else:
        threading.Thread(target=server.serve_forever, daemon=True).start()

    return server


# ============================================================
# Digest rendering
# ============================================================

def short_authors(authors, limit=6):
    names = [name for name in authors.split(", ") if name]
    if len(names) <= limit:
        return ", ".join(names)
    return ", ".join(names[:limit]) + f", … (+{len(names) - limit})"


def why(paper):
    """One-line explanation of why a paper was included."""
    reasons = []

    if paper.get("topics"):
        reasons.append(", ".join(paper["topics"]))
    if paper.get("followed_authors"):
        reasons.append(
            "followed: " + ", ".join(paper["followed_authors"])
        )
    if not reasons:
        reasons.append("similar to your interests")

    label = KIND_LABELS.get(paper.get("kind", ""))
    return "; ".join(([label] if label else []) + reasons)


def origin(paper):
    if paper["source"] == "arXiv":
        return f"arXiv:{paper.get('arxiv_id', '')}"
    return paper.get("journal") or "Journal"


def short_date(paper):
    return (paper.get("date") or "Unknown")[:10]


BUTTON_STYLE = (
    "display:inline-block;padding:2px 10px;margin:4px 6px 0 0;"
    "border:1px solid #c9c9c9;border-radius:12px;font-size:12px;"
    "color:#333;text-decoration:none;white-space:nowrap"
)


ACTIVE_STYLES = {
    "undislike": "background:#ececec;border-color:#b0b0b0;color:#555;",
    "unlike": "background:#ffe4ea;border-color:#e8a0b0;",
    "unsave": "background:#e3edff;border-color:#9db8e8;",
}

_STATE_CACHE = [0.0, (set(), set(), set())]


def current_states():
    """paper_states(), reused for 2 s so one email reads files once."""
    if time.monotonic() - _STATE_CACHE[0] > 2:
        _STATE_CACHE[:] = [time.monotonic(), paper_states()]
    return _STATE_CACHE[1]


def buttons(paper, actions=("summary", "like", "save", "dislike")):
    # No abstract means nothing reliable to summarize.
    if not paper.get("abstract", "").strip():
        actions = [action for action in actions if action != "summary"]

    # Already liked/saved papers get a highlighted button that undoes it.
    liked, saved, disliked = current_states()
    actions = [
        "unlike" if action == "like" and liked_key(paper["key"]) in liked
        else "unsave" if action == "save" and paper["key"] in saved
        else "undislike" if action == "dislike" and paper["key"] in disliked
        else action
        for action in actions
    ]

    return "<div>" + "".join(
        f"<a href='{html.escape(feedback_link(action, paper), quote=True)}' "
        f"style='{BUTTON_STYLE};{ACTIVE_STYLES.get(action, '')}'>"
        f"{ACTION_LABELS[action]}</a>"
        for action in actions
    ) + "</div>"


def feedback_summary(applied):
    if not applied:
        return ""
    words = {"like": "liked", "save": "saved", "done": "marked read"}
    return "Since the last digest: " + ", ".join(
        f"{applied[action]} {words[action]}"
        for action in ["like", "save", "done"]
        if applied[action]
    ) + "."


def excerpt(text, limit=280):
    text = text.strip()
    if len(text) <= limit:
        return text
    return text[:limit].rsplit(" ", 1)[0] + " …"


def blindspot_label(paper):
    return " · ".join(
        part for part in [
            paper.get("journal", ""),
            paper.get("subfield") or paper.get("field", ""),
            short_date(paper),
        ]
        if part
    )


def learning_label(paper):
    return " · ".join(
        str(part) for part in [
            paper.get("journal", ""),
            paper.get("year", ""),
            f"cited {paper.get('citations', 0):,} times",
        ]
        if part
    )


def render(sections, now, problems, saved=(), applied=None,
           blindspot=(), paper_of_day=None, learning=None):
    escape = lambda value: html.escape(str(value), quote=True)

    timestamp = now.astimezone(
        ZoneInfo(CFG["timezone"])
    ).strftime("%A %Y-%m-%d")

    top, more_arxiv, more_journal = sections
    shown = top + more_arxiv + more_journal
    counts = Counter(p["source"] for p in shown)

    muted = "color:#666;font-size:13px;margin:2px 0"

    parts = [
        "<!DOCTYPE html>",
        "<html><head><meta charset='utf-8'></head>",
        "<body style='font-family:Arial,sans-serif;max-width:860px;"
        "margin:24px auto;padding:0 16px;line-height:1.45;"
        "color:#222'>",
        f"<h2 style='margin-bottom:4px'>{escape(digest_title())}</h2>",
        f"<p style='{muted}'>{escape(timestamp)} · "
        f"{counts['arXiv']} arXiv · {counts['Journal']} journal</p>",
    ]

    for problem in problems:
        parts.append(
            "<p style='background:#fff4e5;padding:8px;"
            "border-left:3px solid #f0a020'>"
            f"⚠ {escape(problem)}</p>"
        )

    summary = feedback_summary(applied)
    if summary:
        parts.append(f"<p style='{muted}'>{escape(summary)}</p>")

    if paper_of_day:
        abstract = paper_of_day.get("abstract", "").strip()
        parts.extend([
            "<div style='margin:20px 0 8px;padding:14px 16px;"
            "background:#fff8e6;border:1px solid #f0d58a;"
            "border-radius:8px'>",
            "<div style='font-size:12px;font-weight:bold;color:#a07000;"
            "letter-spacing:.5px'>⭐ PAPER OF THE DAY</div>",
            f"<div style='font-size:17px;font-weight:bold;margin:4px 0'>"
            f"<a href='{escape(paper_of_day['url'])}'>"
            f"{escape(paper_of_day['title'])}</a></div>",
            f"<p style='{muted}'>{escape(blindspot_label(paper_of_day))}"
            "</p>",
            f"<p style='{muted}'>"
            f"{escape(short_authors(paper_of_day.get('authors', '')))}</p>",
            f"<p style='margin:6px 0'>{escape(abstract)}</p>",
            buttons(paper_of_day),
            "</div>",
        ])

    if top:
        parts.append("<h3 style='margin-top:24px'>Top picks</h3>")

    for rank, paper in enumerate(top, 1):
        abstract = paper.get("abstract", "").strip()

        parts.extend([
            "<div style='margin:16px 0 20px'>",
            f"<div style='font-size:16px;font-weight:bold'>{rank}. "
            f"<a href='{escape(paper['url'])}'>"
            f"{escape(paper['title'])}</a></div>",
            f"<p style='{muted}'>{escape(origin(paper))} · "
            f"{escape(short_date(paper))} · "
            f"score {paper['score']:.1f} · {escape(why(paper))}</p>",
            f"<p style='{muted}'>"
            f"{escape(short_authors(paper.get('authors', '')))}</p>",
            (
                f"<p style='margin:6px 0'>{escape(abstract)}</p>"
                if abstract
                else f"<p style='{muted}'><i>No abstract available "
                "from the metadata service.</i></p>"
            ),
            buttons(paper),
            "</div>",
        ])

    if blindspot:
        parts.append(
            "<h3 style='margin:28px 0 2px'>🔭 Blindspot</h3>"
            f"<p style='{muted}'>Notable results in selective journals, "
            "outside your usual areas</p>"
        )

    for paper in blindspot:
        abstract = paper.get("abstract", "")
        parts.extend([
            "<div style='margin:12px 0 16px;padding-left:10px;"
            "border-left:3px solid #8fb3e0'>",
            f"<a href='{escape(paper['url'])}'>"
            f"{escape(paper['title'])}</a>",
            f"<p style='{muted}'>{escape(blindspot_label(paper))}</p>",
            (
                f"<p style='margin:4px 0;font-size:14px'>"
                f"{escape(excerpt(abstract))}</p>"
                if abstract.strip()
                else ""
            ),
            buttons(paper),
            "</div>",
        ])

    if learning:
        track = CFG.get("learning_track", {}).get("name", "Learning track")
        abstract = learning.get("abstract", "")
        parts.extend([
            f"<h3 style='margin:28px 0 2px'>📚 Learning: {escape(track)}</h3>",
            f"<p style='{muted}'>Paper {learning.get('track_number', 1)} "
            "of the field's most-cited work, one per day · "
            f"<a href='http://localhost:{button_port()}/learn'>"
            "change topic</a></p>",
            "<div style='margin:12px 0 16px;padding-left:10px;"
            "border-left:3px solid #9bd3a8'>",
            f"<a href='{escape(learning['url'])}'>"
            f"{escape(learning['title'])}</a>",
            f"<p style='{muted}'>{escape(learning_label(learning))}</p>",
            f"<p style='{muted}'>"
            f"{escape(short_authors(learning.get('authors', ''), 4))}</p>",
            (
                f"<p style='margin:4px 0;font-size:14px'>"
                f"{escape(excerpt(abstract, 600))}</p>"
                if abstract.strip()
                else ""
            ),
            buttons(learning),
            "</div>",
        ])

    for heading, papers in [
        ("More from arXiv", more_arxiv),
        ("More from journals", more_journal),
    ]:
        if not papers:
            continue

        parts.append(
            f"<h3 style='margin-top:28px'>{heading} "
            f"<span style='{muted}'>({len(papers)})</span></h3>"
        )

        for paper in papers:
            parts.extend([
                "<div style='margin:10px 0'>",
                f"<a href='{escape(paper['url'])}'>"
                f"{escape(paper['title'])}</a>",
                f"<p style='{muted}'>{escape(origin(paper))} · "
                f"{escape(short_date(paper))} · "
                f"score {paper['score']:.1f} · "
                f"{escape(why(paper))} · "
                f"{escape(short_authors(paper.get('authors', ''), 3))}"
                "</p>",
                buttons(paper),
                "</div>",
            ])

    if not shown:
        parts.append("<p>No new matching papers.</p>")

    # Reading list last, grouped by category, with a link to add your
    # own papers (an email can't hold a text box, so it opens a page).
    add_link = (
        f"<a href='http://localhost:{button_port()}/add' "
        f"style='{BUTTON_STYLE};background:#eef5ee;border-color:#9bc79b'>"
        "➕ Add a paper</a>"
    )
    parts.append(
        "<h3 style='margin-top:32px;padding-top:12px;"
        "border-top:2px solid #ddd'>🔖 Your reading list "
        f"<span style='{muted}'>({len(saved)})</span></h3>"
        f"<div>{add_link}</div>"
    )
    if saved:
        parts.append(reading_list_items_html(saved, heading_tag="h4"))

    parts.append(
        "<hr><p style='color:#888;font-size:12px'>"
        "Ranked by topic keywords plus text similarity to your "
        "interest profile. ♥ Like and 🔖 Read later work on the "
        "computer running the digest (one click, applied at once). "
        "Liked papers are added to liked.txt and steer the ranking. "
        "Topics, journals and thresholds live in config.json.</p>"
    )
    parts.append("</body></html>")
    return "\n".join(parts)


def plain_digest(sections, now, problems, saved=(), applied=None,
                 blindspot=(), paper_of_day=None, learning=None):
    timestamp = now.astimezone(
        ZoneInfo(CFG["timezone"])
    ).strftime("%A %Y-%m-%d")

    top, more_arxiv, more_journal = sections
    lines = [digest_title(), timestamp, ""]

    for problem in problems:
        lines.extend(["WARNING: " + problem, ""])

    summary = feedback_summary(applied)
    if summary:
        lines.extend([summary, ""])

    if paper_of_day:
        lines.extend([
            "PAPER OF THE DAY",
            f"{paper_of_day['title']}",
            f"  {blindspot_label(paper_of_day)}",
            f"  {paper_of_day['url']}",
            "",
            paper_of_day.get("abstract", ""),
            "",
        ])

    if top:
        lines.extend(["TOP PICKS", ""])

    for rank, paper in enumerate(top, 1):
        lines.extend([
            f"{rank}. {paper['title']}",
            f"   {origin(paper)} | {short_date(paper)} | "
            f"score {paper['score']:.1f} | {why(paper)}",
            f"   {short_authors(paper.get('authors', ''))}",
            f"   {paper['url']}",
            "",
            paper.get("abstract") or "Abstract unavailable.",
            "",
        ])

    if blindspot:
        lines.extend([
            "-" * 60,
            "BLINDSPOT: notable results outside your usual areas",
            "",
        ])

    for paper in blindspot:
        lines.extend([
            f"- {paper['title']}",
            f"  {blindspot_label(paper)}",
            f"  {paper['url']}",
        ])

    if learning:
        track = CFG.get("learning_track", {}).get("name", "Learning track")
        lines.extend([
            "-" * 60,
            f"LEARNING: {track} (paper {learning.get('track_number', 1)})",
            "",
            f"- {learning['title']}",
            f"  {learning_label(learning)}",
            f"  {learning['url']}",
        ])

    for heading, papers in [
        ("MORE FROM ARXIV", more_arxiv),
        ("MORE FROM JOURNALS", more_journal),
    ]:
        if not papers:
            continue

        lines.extend(["-" * 60, heading, ""])

        for paper in papers:
            lines.extend([
                f"- {paper['title']}",
                f"  {origin(paper)} | score {paper['score']:.1f} | "
                f"{why(paper)}",
                f"  {paper['url']}",
            ])

    if not (top or more_arxiv or more_journal):
        lines.append("No new matching papers.")

    lines.extend([
        "", "-" * 60, f"YOUR READING LIST ({len(saved)})",
        f"Add a paper: http://localhost:{button_port()}/add",
    ])
    if saved:
        for category, group in group_reading_list(saved):
            lines.extend(["", f"{category} ({len(group)})"])
            for paper in group:
                lines.extend([
                    f"- {paper.get('title', paper['key'])}",
                    f"  {paper.get('url', '')}",
                ])

    return "\n".join(lines)


def split_sections(papers):
    """Top picks across sources, then compact lists per source."""
    settings = CFG.get("digest", {})
    ranked = sorted(papers, key=rank_key, reverse=True)

    # Some kinds (by default theory) never become Top picks; they stay
    # in the compact lists below.
    excluded = set(settings.get("top_picks_exclude_kinds", ["theory"]))
    top = [p for p in ranked if p.get("kind") not in excluded][
        :int(settings.get("top_picks", 10))
    ]
    top_keys = {p["key"] for p in top}
    rest = [p for p in ranked if p["key"] not in top_keys]

    more_arxiv = [p for p in rest if p["source"] == "arXiv"][
        :int(settings.get("max_more_arxiv", 40))
    ]
    more_journal = [p for p in rest if p["source"] == "Journal"][
        :int(settings.get("max_more_journal", 25))
    ]

    return top, more_arxiv, more_journal


def select_paper_of_day(candidates, exclude_keys):
    """
    The day's most impactful paper in your broad field, whatever its
    relevance score. New papers have no citations, so impact = venue
    tier (paper_of_the_day.tiers); within the best tier available, the
    paper most central to your field. "Your field" is
    paper_of_the_day.topics if set, otherwise your interest profile and
    keywords. Optional require_terms (regexes) must also appear.
    """
    settings = CFG.get("paper_of_the_day", {})
    tiers = settings.get("tiers", {})
    required = [
        re.compile(term, re.I) for term in settings.get("require_terms", [])
    ]

    pool = [
        paper
        for paper in candidates
        if tiers.get(paper.get("journal"), 0) > 0
        and paper["key"] not in exclude_keys
        and paper.get("abstract", "").strip()  # skips news/commentary
        and (
            not required
            or any(
                term.search(paper["title"] + " " + paper["abstract"])
                for term in required
            )
        )
    ]

    if not pool:
        return None

    field_texts = settings.get("topics") or (
        profile_texts() + [" ".join(search_terms())]
    )
    broad = InterestProfile(
        field_texts,
        [paper["title"] + " " + paper["abstract"] for paper in candidates],
    )
    for paper in pool:
        paper["field_centrality"] = broad.similarity(
            paper["title"] + " " + paper["abstract"]
        )

    # Merely sharing a word with your field isn't enough: the paper must
    # be clearly about it.
    floor = float(settings.get("min_centrality", 0.04))
    pool = [paper for paper in pool if paper["field_centrality"] >= floor]

    if not pool:
        return None

    return max(
        pool,
        key=lambda paper: (
            tiers[paper["journal"]], paper["field_centrality"]
        ),
    )


def learning_query(topic):
    """
    OpenAlex boolean search from a plain topic, e.g. "Rydberg atom
    arrays" -> 'Rydberg AND atom AND arrays' (all words must appear).
    A "quoted phrase" in the topic is kept as a phrase.
    """
    phrases = re.findall(r'"([^"]+)"', topic)
    words = [
        word for word in re.sub(r'"[^"]+"', " ", topic)
        .replace(",", " ").split()
        if len(word) > 2 and word.lower() not in STOPWORDS
    ]
    parts = [f'"{phrase}"' for phrase in phrases] + words
    return " AND ".join(parts)


def learning_pool():
    """
    Most-cited papers on the learning-track topic (OpenAlex), deduped,
    most cited first. Cached like other OpenAlex queries.
    """
    track = CFG.get("learning_track", {})
    query = track.get("query") or learning_query(track.get("name", ""))

    if not query:
        return []

    params = {
        "filter": (
            "title_and_abstract.search:" + query
            + ",type:article|review"
            + ",primary_location.source.type:journal"
            + f",from_publication_date:{int(track.get('min_year', 1995))}-01-01"
        ),
        "sort": "cited_by_count:desc",
        "per_page": int(track.get("pool_size", 100)),
        "select": (
            "id,doi,title,publication_year,cited_by_count,"
            "primary_location,locations,abstract_inverted_index,authorships"
        ),
        "mailto": CFG["recipient"],
    }
    api_key = os.environ.get("OPENALEX_API_KEY")
    if api_key:
        params["api_key"] = api_key

    data, _ = cached_json("https://api.openalex.org/works", params)
    exclude = [term.lower() for term in track.get("exclude_terms", [])]
    pool, titles = [], set()

    for work in data.get("results", []):
        title = clean_text(work.get("title") or "")
        if not title or normalize(title) in titles:
            continue
        if any(term in title.lower() for term in exclude):
            continue
        titles.add(normalize(title))

        paper = journal_paper(work, {})
        arxiv_url = next(
            (
                location.get("landing_page_url") or ""
                for location in work.get("locations") or []
                if "arxiv.org/abs/" in (location.get("landing_page_url") or "")
            ),
            "",
        )
        arxiv_id = (
            ARXIV_ID_PATTERN.search(arxiv_url.split("/abs/", 1)[1]).group(1)
            if arxiv_url and ARXIV_ID_PATTERN.search(arxiv_url.split("/abs/", 1)[1])
            else ""
        )

        paper.update({
            "year": work.get("publication_year"),
            "citations": work.get("cited_by_count", 0),
            "arxiv_id": arxiv_id,
            # The arXiv version gives the ✨ Summarize button free full
            # text (and an abstract, which old APS papers lack here).
            "key": "arxiv:" + arxiv_id if arxiv_id else paper["key"],
        })
        pool.append(paper)

    return pool


def select_learning_paper():
    """Next most-cited learning-track paper not already sent."""
    try:
        pool = learning_pool()
    except (RuntimeError, requests.RequestException, ValueError) as exc:
        logging.warning("Learning track unavailable: %s", exc)
        return None

    with sqlite3.connect(DATABASE) as db:
        done = {
            key for (key,) in db.execute("SELECT key FROM learning_sent")
        }

    for position, paper in enumerate(pool, 1):
        if paper["key"] in done:
            continue

        if not paper["abstract"] and paper["arxiv_id"]:
            found = lookup_papers([paper["key"]])
            if found:
                paper["abstract"] = found[0].get("abstract", "")

        # Position within this topic, so a new topic starts at 1.
        paper["track_number"] = sum(
            1 for other in pool if other["key"] in done
        ) + 1
        return paper

    return None


def select_blindspot(candidates, exclude_keys):
    """
    Notable papers outside the usual areas: recent articles in highly
    selective journals that did not make the digest, from physical-
    science fields, closest to the interest profile first, with at
    most max_per_subfield from any one subfield.
    """
    settings = CFG.get("blindspot", {})
    count = int(settings.get("count", 5))
    journals = set(settings.get("journals", []))
    fields = set(settings.get("fields", []))
    per_subfield = int(settings.get("max_per_subfield", 1))

    if not count or not journals:
        return []

    pool = [
        paper
        for paper in candidates
        if paper["source"] == "Journal"
        and paper.get("journal") in journals
        and paper.get("field") in fields
        and paper["key"] not in exclude_keys
        # Nature/Science items without an abstract are mostly news
        # and commentary; APS journals never supply abstracts.
        and (
            paper.get("abstract", "").strip()
            or paper.get("journal", "").startswith("Physical Review")
        )
    ]
    pool.sort(key=lambda paper: paper.get("similarity", 0), reverse=True)

    per_journal = int(settings.get("max_per_journal", 2))
    chosen, titles = [], set()
    per_field, per_venue = Counter(), Counter()

    for paper in pool:
        title = normalize(paper["title"])
        subfield = paper.get("subfield") or paper.get("field")

        if (
            title in titles
            or per_field[subfield] >= per_subfield
            or per_venue[paper["journal"]] >= per_journal
        ):
            continue

        chosen.append(paper)
        titles.add(title)
        per_field[subfield] += 1
        per_venue[paper["journal"]] += 1

        if len(chosen) == count:
            break

    return chosen


# ============================================================
# Email
# ============================================================

def send(subject, body, plain_body=None):
    for variable in ["SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD"]:
        if not os.environ.get(variable):
            raise RuntimeError(
                f"Missing {variable}. Set it as an environment "
                "variable or in secrets.env (see secrets.env.example)."
            )

    message = EmailMessage()
    message["From"] = os.environ.get("SMTP_FROM", os.environ["SMTP_USER"])
    message["To"] = CFG["recipient"]
    message["Subject"] = subject

    message.set_content(plain_body or clean_text(body))
    message.add_alternative(body, subtype="html")

    host = os.environ["SMTP_HOST"]
    port = int(os.environ.get("SMTP_PORT", "465"))
    user = os.environ["SMTP_USER"]
    password = os.environ["SMTP_PASSWORD"]

    if port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=60) as smtp:
            smtp.login(user, password)
            smtp.send_message(message)
    else:
        with smtplib.SMTP(host, port, timeout=60) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(message)


# ============================================================
# Main workflow and delivery history
# ============================================================

def initialize_database():
    with sqlite3.connect(DATABASE) as db:
        db.execute(
            "CREATE TABLE IF NOT EXISTS sent "
            "(key TEXT PRIMARY KEY, timestamp TEXT)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS settings "
            "(key TEXT PRIMARY KEY, value TEXT)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS seed_cache "
            "(id TEXT PRIMARY KEY, text TEXT NOT NULL)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS http_cache "
            "(key TEXT PRIMARY KEY, fetched_at TEXT, body BLOB)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS paper_info "
            "(key TEXT PRIMARY KEY, info TEXT NOT NULL)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS reading_list "
            "(key TEXT PRIMARY KEY, saved_at TEXT, done_at TEXT)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS learning_sent "
            "(key TEXT PRIMARY KEY, sent_at TEXT)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS disliked "
            "(key TEXT PRIMARY KEY, text TEXT, at TEXT)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS summaries "
            "(key TEXT PRIMARY KEY, model TEXT, text TEXT, created_at TEXT)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS feedback_log "
            "(at TEXT, action TEXT, key TEXT)"
        )


def run(preview=False, ignore_sent=False, arxiv_only=False):
    if ignore_sent and not preview:
        raise ValueError("--ignore-sent requires --preview")

    if arxiv_only and not preview:
        raise ValueError("--arxiv-only requires --preview")

    started = time.monotonic()
    initialize_database()
    now = dt.datetime.now(UTC)

    with sqlite3.connect(DATABASE) as db:
        last = db.execute(
            "SELECT value FROM settings WHERE key='last_success'"
        ).fetchone()

        delivered_keys = {
            row[0] for row in db.execute("SELECT key FROM sent")
        }

    previous = (
        dt.datetime.fromisoformat(last[0])
        if last
        else now - dt.timedelta(
            hours=float(CFG.get("initial_lookback_hours", 24))
        )
    )

    if previous.tzinfo is None:
        previous = previous.replace(tzinfo=UTC)

    start = previous - dt.timedelta(
        days=float(CFG.get("lookback_days", 7))
    )

    logging.info(
        "arXiv search window: %s to %s",
        start.isoformat(), now.isoformat()
    )

    sources = [
        ("arXiv daily feed", arxiv_feed),
        ("arXiv keyword search", lambda: arxiv_search(start, now)),
    ]

    if not arxiv_only:
        sources.append(("Journals (OpenAlex)", lambda: journals(now)))

    # A failing source is reported in the email instead of
    # aborting the whole digest; the overlapping search window
    # recovers missed papers on the next run.
    candidates = {}
    problems = []

    for source_name, fetch in sources:
        count = 0

        try:
            for paper in fetch():
                candidates.setdefault(paper["key"], paper)
                count += 1
        except (
            RuntimeError,
            requests.RequestException,
            ET.ParseError,
            ValueError,
            KeyError,
        ) as exc:
            logging.exception("%s failed", source_name)
            problems.append(
                f"{source_name} could not be retrieved ({exc}). "
                "Missed papers will be picked up on a later run."
            )

        logging.info("%s: %d records", source_name, count)

    if len(problems) == len(sources):
        raise RuntimeError("Every source failed; nothing to send.")

    applied = feedback_since(last[0] if last else "")
    saved = reading_list()
    write_reading_list(saved)

    profile = InterestProfile(
        profile_texts(),
        [
            p["title"] + " " + p.get("abstract", "")
            for p in candidates.values()
        ],
        liked_texts(),
        disliked_texts(),
    )

    papers = []
    skipped_sent = Counter()
    admitted = Counter()
    relevant_keys = set()

    for paper in candidates.values():
        if not matches(paper, profile):
            continue

        admitted[paper["source"]] += 1
        relevant_keys.add(paper["key"])

        if paper["key"] in delivered_keys and not ignore_sent:
            skipped_sent[paper["source"]] += 1
            continue

        papers.append(paper)

    for source_name in ["arXiv", "Journal"]:
        logging.info(
            "%s: %d relevant, %d previously delivered",
            source_name,
            admitted[source_name],
            skipped_sent[source_name],
        )

    already_sent = set() if ignore_sent else delivered_keys

    # Paper of the Day: picked first and taken out of the lists below
    # so it isn't shown twice.
    paper_of_day = select_paper_of_day(candidates.values(), already_sent)
    if paper_of_day:
        papers = [p for p in papers if p["key"] != paper_of_day["key"]]

    sections = split_sections(papers)
    # Blindspot: notable papers that did NOT make the digest itself.
    blindspot = select_blindspot(
        candidates.values(),
        relevant_keys | already_sent
        | ({paper_of_day["key"]} if paper_of_day else set()),
    )
    learning = select_learning_paper()
    extras = [paper for paper in (paper_of_day, learning) if paper]

    shown = (
        [paper for section in sections for paper in section]
        + blindspot + extras
    )
    top, more_arxiv, more_journal = sections
    for section, group in [("paper_of_day", [paper_of_day] if paper_of_day else []),
                           ("learning", [learning] if learning else []),
                           ("top", top), ("blindspot", blindspot),
                           ("more_arxiv", more_arxiv),
                           ("more_journal", more_journal)]:
        for rank, paper in enumerate(group, 1):
            paper["section"], paper["rank"] = section, rank
    remember_papers(shown)

    body = render(
        sections, now, problems, saved, applied, blindspot,
        paper_of_day, learning,
    )
    plain_body = plain_digest(
        sections, now, problems, saved, applied, blindspot,
        paper_of_day, learning,
    )

    (BASE / "preview.html").write_text(body, encoding="utf-8")
    (BASE / "preview.txt").write_text(plain_body, encoding="utf-8")

    logging.info(
        "Digest built in %.0f s: %d of %d new relevant papers shown, "
        "plus %d in Blindspot",
        time.monotonic() - started,
        len(shown) - len(blindspot) - len(extras),
        len(papers), len(blindspot)
    )

    if preview:
        logging.info("Preview only. Nothing sent or marked delivered.")
        return

    date_label = now.astimezone(
        ZoneInfo(CFG["timezone"])
    ).strftime("%Y-%m-%d")
    counts = Counter(p["source"] for p in shown)

    subject = (
        f"{digest_title()} — {date_label} — "
        f"{counts['arXiv']} arXiv, {counts['Journal']} journal"
    )

    send(subject, body, plain_body)

    # Only papers actually shown are recorded, so overflow papers
    # can still appear on a later day if they stay in the window.
    with sqlite3.connect(DATABASE) as db:
        db.executemany(
            "INSERT OR IGNORE INTO sent VALUES (?, ?)",
            [(paper["key"], now.isoformat()) for paper in shown],
        )
        db.execute(
            "INSERT OR REPLACE INTO settings "
            "VALUES ('last_success', ?)",
            (now.isoformat(),),
        )
        # The learning track only advances when an email really goes out.
        if learning:
            db.execute(
                "INSERT OR IGNORE INTO learning_sent VALUES (?, ?)",
                (learning["key"], now.isoformat()),
            )

    logging.info(
        "SMTP accepted digest for %s; %d papers recorded.",
        CFG["recipient"], len(shown)
    )


# ============================================================
# Command-line interface and scheduling
# ============================================================

def feedback_stats():
    """Text report: which sections and ranks your clicks come from."""
    initialize_database()
    names = {
        "top": "Top picks", "blindspot": "Blindspot",
        "more_arxiv": "More from arXiv", "more_journal": "More from journals",
        "": "(older emails / unknown)",
    }

    with sqlite3.connect(DATABASE) as db:
        shown = Counter()
        sections = {}
        for key, info in db.execute("SELECT key, info FROM paper_info"):
            info = json.loads(info)
            sections[key] = (info.get("section", ""), info.get("rank", 0))
            shown[info.get("section", "")] += 1

        clicks = db.execute(
            "SELECT action, key FROM feedback_log "
            "WHERE action IN ('like', 'save', 'dislike')"
        ).fetchall()

    table = Counter()
    top_ranks = Counter()
    for action, key in clicks:
        section, rank = sections.get(key, ("", 0))
        table[section, action] += 1
        if section == "top" and action in ("like", "save"):
            top_ranks["1-3" if rank <= 3 else "4-6" if rank <= 6 else "7-10"] += 1

    lines = [
        f"{'Section':26s} {'shown':>6s} {'like':>6s} {'save':>6s} "
        f"{'not relevant':>13s}"
    ]
    for section in ["top", "blindspot", "more_arxiv", "more_journal", ""]:
        counts = [table[section, a] for a in ("like", "save", "dislike")]
        if shown[section] or any(counts):
            lines.append(
                f"{names[section]:26s} {shown[section]:6d} "
                f"{counts[0]:6d} {counts[1]:6d} {counts[2]:13d}"
            )

    if top_ranks:
        lines.append(
            "Top-pick likes/saves by rank: "
            + ", ".join(f"#{r}: {top_ranks[r]}" for r in ("1-3", "4-6", "7-10"))
        )

    return "\n".join(lines)


def last_success():
    initialize_database()
    with sqlite3.connect(DATABASE) as db:
        row = db.execute(
            "SELECT value FROM settings WHERE key='last_success'"
        ).fetchone()

    if not row:
        return None

    value = dt.datetime.fromisoformat(row[0])
    return value if value.tzinfo else value.replace(tzinfo=UTC)


def digest_due(now_local):
    """
    True if today's delivery time has passed, today's digest has not
    been sent yet, and we are within catch_up_hours of delivery time.
    Uses the wall clock and the stored last_success, so it is correct
    after sleep, hibernation, restarts and reboots.
    """
    hour, minute = map(int, CFG.get("delivery_time", "09:00").split(":"))
    due = now_local.replace(hour=hour, minute=minute, second=0, microsecond=0)
    window = dt.timedelta(hours=float(CFG.get("catch_up_hours", 12)))

    if not due <= now_local <= due + window:
        return False

    sent = last_success()
    return sent is None or sent.astimezone(now_local.tzinfo) < due


def button_server_alive():
    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{button_port()}/", timeout=10
        ) as response:
            return response.status == 200
    except OSError:
        return False


def serve():
    """
    Check the clock every minute instead of sleeping until 11:00: a
    long timer stops counting while the computer sleeps, so after a
    weekend asleep the digest would be days late. Also restarts the
    button server if it stops answering (e.g. after a long sleep).
    """
    zone = ZoneInfo(CFG.get("timezone", "America/Los_Angeles"))
    server = start_button_server()
    retry_after = 0.0
    failed_checks = 0
    next_check = time.time() + 300

    logging.info(
        "Scheduler started: daily at %s in %s (checked every minute).",
        CFG.get("delivery_time", "09:00"), zone.key,
    )

    while True:
        now_local = dt.datetime.now(zone)

        if time.time() >= retry_after and digest_due(now_local):
            logging.info("Digest due; running now.")
            try:
                run()
            except Exception:  # keep serving; try again later
                logging.exception("Digest run failed; retrying in 30 min")
                retry_after = time.time() + 1800

        if time.time() >= next_check:
            next_check = time.time() + 300
            failed_checks = 0 if button_server_alive() else failed_checks + 1

            if failed_checks >= 2:
                logging.warning("Button server not answering; restarting it")
                if server:
                    threading.Thread(
                        target=server.shutdown, daemon=True
                    ).start()
                    time.sleep(5)
                    server.server_close()
                server = start_button_server()
                failed_checks = 0

        time.sleep(60)


INSTANCE_LOCK = None


def acquire_instance_lock():
    """
    Lock digest.lock for the life of this process. Returns False if
    another --serve copy holds it. The OS releases the lock when the
    process ends, even after a crash.
    """
    global INSTANCE_LOCK
    handle = open(BASE / "digest.lock", "a+")

    try:
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close()
        return False

    INSTANCE_LOCK = handle
    return True


def main():
    # Also log to digest.log, since a background task has no console.
    log_file = logging.handlers.RotatingFileHandler(
        BASE / "digest.log",
        maxBytes=1_000_000,
        backupCount=3,
        encoding="utf-8",
    )
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.StreamHandler(), log_file],
    )

    parser = argparse.ArgumentParser(
        description=f"{APP_NAME}: a daily email of new papers ranked "
        "for you"
    )
    parser.add_argument(
        "--setup",
        action="store_true",
        help="First-time setup wizard (email, keywords, field, library)",
    )
    parser.add_argument(
        "--import-zotero",
        nargs="?",
        const="",
        metavar="ZOTERO_SQLITE",
        help="Learn from your Zotero library (choose folders)",
    )
    parser.add_argument(
        "--import-bib",
        metavar="FILE.bib",
        help="Learn from the papers in a BibTeX file",
    )
    parser.add_argument(
        "--test-email",
        action="store_true",
        help="Send a short test email to check your email settings",
    )
    parser.add_argument(
        "--preview",
        action="store_true",
        help="Generate preview files without sending email",
    )
    parser.add_argument(
        "--ignore-sent",
        action="store_true",
        help="Include previously delivered papers in a preview",
    )
    parser.add_argument(
        "--arxiv-only",
        action="store_true",
        help="Preview arXiv alone for faster troubleshooting",
    )
    parser.add_argument(
        "--buttons",
        action="store_true",
        help="Only run the Like/Read-later button server "
        "(already included in --serve)",
    )
    parser.add_argument(
        "--serve",
        action="store_true",
        help="Run the daily scheduler",
    )
    parser.add_argument(
        "--stats",
        action="store_true",
        help="Show which digest sections your likes/saves/👎 come from",
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Ignore cached OpenAlex results and fetch fresh ones",
    )

    args = parser.parse_args()

    global REFRESH_CACHE
    REFRESH_CACHE = args.refresh

    if args.serve and (args.preview or args.ignore_sent or args.arxiv_only):
        parser.error("--serve cannot be combined with preview options")

    if args.ignore_sent and not args.preview:
        parser.error("--ignore-sent requires --preview")

    if args.arxiv_only and not args.preview:
        parser.error("--arxiv-only requires --preview")

    if args.setup:
        import dewey_setup
        dewey_setup.run_setup()
        return

    if not CONFIG_PATH.exists():
        parser.error(
            "no config.json yet. Run the setup wizard first: "
            "python dewey.py --setup"
        )

    if args.import_zotero is not None:
        import dewey_setup
        dewey_setup.import_zotero_interactive(args.import_zotero or None)
        return

    if args.import_bib:
        import dewey_setup
        dewey_setup.add_to_liked(
            dewey_setup.bib_items(args.import_bib), Path(args.import_bib).name
        )
        return

    if args.test_email:
        send(f"{APP_NAME} test email",
             f"<p>Your {APP_NAME} email connection works.</p>",
             f"Your {APP_NAME} email connection works.")
        print("Test email sent to", CFG["recipient"])
        return

    if not search_terms() and not CFG.get("arxiv_feed_categories"):
        parser.error(
            "config.json has no keywords or arXiv categories; run "
            "python dewey.py --setup or edit config.json"
        )

    if args.buttons:
        start_button_server(block=True)
        return

    if args.stats:
        print(feedback_stats())
        return

    if args.serve:
        if not acquire_instance_lock():
            logging.info(
                "Another copy of the digest is already running; "
                "this one exits so only one email is sent."
            )
            return

        serve()
    else:
        run(
            preview=args.preview,
            ignore_sent=args.ignore_sent,
            arxiv_only=args.arxiv_only,
        )


if __name__ == "__main__":
    main()
